// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_stock_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProductStockModel _$ProductStockModelFromJson(Map<String, dynamic> json) {
  return _ProductStockModel.fromJson(json);
}

/// @nodoc
mixin _$ProductStockModel {
  String get productId => throw _privateConstructorUsedError;
  String get productSupplierIds => throw _privateConstructorUsedError;
  String get productSaleId => throw _privateConstructorUsedError;
  int get quantity => throw _privateConstructorUsedError;
  String get note => throw _privateConstructorUsedError;
  bool get isNoteOpen => throw _privateConstructorUsedError;
  String get stock => throw _privateConstructorUsedError;
  double get totalPrice => throw _privateConstructorUsedError;
  String get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductStockModelCopyWith<ProductStockModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductStockModelCopyWith<$Res> {
  factory $ProductStockModelCopyWith(
          ProductStockModel value, $Res Function(ProductStockModel) then) =
      _$ProductStockModelCopyWithImpl<$Res, ProductStockModel>;
  @useResult
  $Res call(
      {String productId,
      String productSupplierIds,
      String productSaleId,
      int quantity,
      String note,
      bool isNoteOpen,
      String stock,
      double totalPrice,
      String lowStock});
}

/// @nodoc
class _$ProductStockModelCopyWithImpl<$Res, $Val extends ProductStockModel>
    implements $ProductStockModelCopyWith<$Res> {
  _$ProductStockModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productId = null,
    Object? productSupplierIds = null,
    Object? productSaleId = null,
    Object? quantity = null,
    Object? note = null,
    Object? isNoteOpen = null,
    Object? stock = null,
    Object? totalPrice = null,
    Object? lowStock = null,
  }) {
    return _then(_value.copyWith(
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      productSupplierIds: null == productSupplierIds
          ? _value.productSupplierIds
          : productSupplierIds // ignore: cast_nullable_to_non_nullable
              as String,
      productSaleId: null == productSaleId
          ? _value.productSaleId
          : productSaleId // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      note: null == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String,
      isNoteOpen: null == isNoteOpen
          ? _value.isNoteOpen
          : isNoteOpen // ignore: cast_nullable_to_non_nullable
              as bool,
      stock: null == stock
          ? _value.stock
          : stock // ignore: cast_nullable_to_non_nullable
              as String,
      totalPrice: null == totalPrice
          ? _value.totalPrice
          : totalPrice // ignore: cast_nullable_to_non_nullable
              as double,
      lowStock: null == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductStockModelImplCopyWith<$Res>
    implements $ProductStockModelCopyWith<$Res> {
  factory _$$ProductStockModelImplCopyWith(_$ProductStockModelImpl value,
          $Res Function(_$ProductStockModelImpl) then) =
      __$$ProductStockModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String productId,
      String productSupplierIds,
      String productSaleId,
      int quantity,
      String note,
      bool isNoteOpen,
      String stock,
      double totalPrice,
      String lowStock});
}

/// @nodoc
class __$$ProductStockModelImplCopyWithImpl<$Res>
    extends _$ProductStockModelCopyWithImpl<$Res, _$ProductStockModelImpl>
    implements _$$ProductStockModelImplCopyWith<$Res> {
  __$$ProductStockModelImplCopyWithImpl(_$ProductStockModelImpl _value,
      $Res Function(_$ProductStockModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productId = null,
    Object? productSupplierIds = null,
    Object? productSaleId = null,
    Object? quantity = null,
    Object? note = null,
    Object? isNoteOpen = null,
    Object? stock = null,
    Object? totalPrice = null,
    Object? lowStock = null,
  }) {
    return _then(_$ProductStockModelImpl(
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      productSupplierIds: null == productSupplierIds
          ? _value.productSupplierIds
          : productSupplierIds // ignore: cast_nullable_to_non_nullable
              as String,
      productSaleId: null == productSaleId
          ? _value.productSaleId
          : productSaleId // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      note: null == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String,
      isNoteOpen: null == isNoteOpen
          ? _value.isNoteOpen
          : isNoteOpen // ignore: cast_nullable_to_non_nullable
              as bool,
      stock: null == stock
          ? _value.stock
          : stock // ignore: cast_nullable_to_non_nullable
              as String,
      totalPrice: null == totalPrice
          ? _value.totalPrice
          : totalPrice // ignore: cast_nullable_to_non_nullable
              as double,
      lowStock: null == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductStockModelImpl implements _ProductStockModel {
  const _$ProductStockModelImpl(
      {required this.productId,
      this.productSupplierIds = '',
      this.productSaleId = '',
      this.quantity = 0,
      this.note = '',
      this.isNoteOpen = false,
      this.stock = '0',
      this.totalPrice = 0.0,
      this.lowStock = ''});

  factory _$ProductStockModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductStockModelImplFromJson(json);

  @override
  final String productId;
  @override
  @JsonKey()
  final String productSupplierIds;
  @override
  @JsonKey()
  final String productSaleId;
  @override
  @JsonKey()
  final int quantity;
  @override
  @JsonKey()
  final String note;
  @override
  @JsonKey()
  final bool isNoteOpen;
  @override
  @JsonKey()
  final String stock;
  @override
  @JsonKey()
  final double totalPrice;
  @override
  @JsonKey()
  final String lowStock;

  @override
  String toString() {
    return 'ProductStockModel(productId: $productId, productSupplierIds: $productSupplierIds, productSaleId: $productSaleId, quantity: $quantity, note: $note, isNoteOpen: $isNoteOpen, stock: $stock, totalPrice: $totalPrice, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductStockModelImpl &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.productSupplierIds, productSupplierIds) ||
                other.productSupplierIds == productSupplierIds) &&
            (identical(other.productSaleId, productSaleId) ||
                other.productSaleId == productSaleId) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.note, note) || other.note == note) &&
            (identical(other.isNoteOpen, isNoteOpen) ||
                other.isNoteOpen == isNoteOpen) &&
            (identical(other.stock, stock) || other.stock == stock) &&
            (identical(other.totalPrice, totalPrice) ||
                other.totalPrice == totalPrice) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, productId, productSupplierIds,
      productSaleId, quantity, note, isNoteOpen, stock, totalPrice, lowStock);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductStockModelImplCopyWith<_$ProductStockModelImpl> get copyWith =>
      __$$ProductStockModelImplCopyWithImpl<_$ProductStockModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductStockModelImplToJson(
      this,
    );
  }
}

abstract class _ProductStockModel implements ProductStockModel {
  const factory _ProductStockModel(
      {required final String productId,
      final String productSupplierIds,
      final String productSaleId,
      final int quantity,
      final String note,
      final bool isNoteOpen,
      final String stock,
      final double totalPrice,
      final String lowStock}) = _$ProductStockModelImpl;

  factory _ProductStockModel.fromJson(Map<String, dynamic> json) =
      _$ProductStockModelImpl.fromJson;

  @override
  String get productId;
  @override
  String get productSupplierIds;
  @override
  String get productSaleId;
  @override
  int get quantity;
  @override
  String get note;
  @override
  bool get isNoteOpen;
  @override
  String get stock;
  @override
  double get totalPrice;
  @override
  String get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$ProductStockModelImplCopyWith<_$ProductStockModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
