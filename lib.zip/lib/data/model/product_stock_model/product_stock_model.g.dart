// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_stock_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProductStockModelImpl _$$ProductStockModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProductStockModelImpl(
      productId: json['productId'] as String,
      productSupplierIds: json['productSupplierIds'] as String? ?? '',
      productSaleId: json['productSaleId'] as String? ?? '',
      quantity: json['quantity'] as int? ?? 0,
      note: json['note'] as String? ?? '',
      isNoteOpen: json['isNoteOpen'] as bool? ?? false,
      stock: json['stock'] as String? ?? '0',
      totalPrice: (json['totalPrice'] as num?)?.toDouble() ?? 0.0,
      lowStock: json['lowStock'] as String? ?? '',
    );

Map<String, dynamic> _$$ProductStockModelImplToJson(
        _$ProductStockModelImpl instance) =>
    <String, dynamic>{
      'productId': instance.productId,
      'productSupplierIds': instance.productSupplierIds,
      'productSaleId': instance.productSaleId,
      'quantity': instance.quantity,
      'note': instance.note,
      'isNoteOpen': instance.isNoteOpen,
      'stock': instance.stock,
      'totalPrice': instance.totalPrice,
      'lowStock': instance.lowStock,
    };
