// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_cart_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UpdateCartResModelImpl _$$UpdateCartResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$UpdateCartResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$UpdateCartResModelImplToJson(
        _$UpdateCartResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      cartProduct: json['cartProduct'] == null
          ? null
          : CartProduct.fromJson(json['cartProduct'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'cartProduct': instance.cartProduct,
    };

_$CartProductImpl _$$CartProductImplFromJson(Map<String, dynamic> json) =>
    _$CartProductImpl(
      id: json['_id'] as String?,
      productId: json['productId'] as String?,
      saleId: json['saleId'] as String?,
      quantity: json['quantity'] as int?,
      supplierId: json['supplierId'] as String?,
      actualPrice: (json['actualPrice'] as num?)?.toDouble(),
      cartId: json['cartId'] as String?,
      discountedprice: (json['discountedprice'] as num?)?.toDouble(),
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$CartProductImplToJson(_$CartProductImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productId': instance.productId,
      'saleId': instance.saleId,
      'quantity': instance.quantity,
      'supplierId': instance.supplierId,
      'actualPrice': instance.actualPrice,
      'cartId': instance.cartId,
      'discountedprice': instance.discountedprice,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
    };
