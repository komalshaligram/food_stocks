// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'previous_order_products_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PreviousOrderProductsResModel _$PreviousOrderProductsResModelFromJson(
    Map<String, dynamic> json) {
  return _PreviousOrderProductsResModel.fromJson(json);
}

/// @nodoc
mixin _$PreviousOrderProductsResModel {
  int? get status => throw _privateConstructorUsedError;
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<PreviousOrderProductData>? get previousProductData =>
      throw _privateConstructorUsedError;
  MetaData? get metaData => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PreviousOrderProductsResModelCopyWith<PreviousOrderProductsResModel>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PreviousOrderProductsResModelCopyWith<$Res> {
  factory $PreviousOrderProductsResModelCopyWith(
          PreviousOrderProductsResModel value,
          $Res Function(PreviousOrderProductsResModel) then) =
      _$PreviousOrderProductsResModelCopyWithImpl<$Res,
          PreviousOrderProductsResModel>;
  @useResult
  $Res call(
      {int? status,
      String? message,
      @JsonKey(name: "data")
      List<PreviousOrderProductData>? previousProductData,
      MetaData? metaData});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$PreviousOrderProductsResModelCopyWithImpl<$Res,
        $Val extends PreviousOrderProductsResModel>
    implements $PreviousOrderProductsResModelCopyWith<$Res> {
  _$PreviousOrderProductsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? previousProductData = freezed,
    Object? metaData = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      previousProductData: freezed == previousProductData
          ? _value.previousProductData
          : previousProductData // ignore: cast_nullable_to_non_nullable
              as List<PreviousOrderProductData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$PreviousOrderProductsResModelImplCopyWith<$Res>
    implements $PreviousOrderProductsResModelCopyWith<$Res> {
  factory _$$PreviousOrderProductsResModelImplCopyWith(
          _$PreviousOrderProductsResModelImpl value,
          $Res Function(_$PreviousOrderProductsResModelImpl) then) =
      __$$PreviousOrderProductsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int? status,
      String? message,
      @JsonKey(name: "data")
      List<PreviousOrderProductData>? previousProductData,
      MetaData? metaData});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$PreviousOrderProductsResModelImplCopyWithImpl<$Res>
    extends _$PreviousOrderProductsResModelCopyWithImpl<$Res,
        _$PreviousOrderProductsResModelImpl>
    implements _$$PreviousOrderProductsResModelImplCopyWith<$Res> {
  __$$PreviousOrderProductsResModelImplCopyWithImpl(
      _$PreviousOrderProductsResModelImpl _value,
      $Res Function(_$PreviousOrderProductsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? previousProductData = freezed,
    Object? metaData = freezed,
  }) {
    return _then(_$PreviousOrderProductsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      previousProductData: freezed == previousProductData
          ? _value._previousProductData
          : previousProductData // ignore: cast_nullable_to_non_nullable
              as List<PreviousOrderProductData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PreviousOrderProductsResModelImpl
    implements _PreviousOrderProductsResModel {
  const _$PreviousOrderProductsResModelImpl(
      {this.status,
      this.message,
      @JsonKey(name: "data")
      final List<PreviousOrderProductData>? previousProductData,
      this.metaData})
      : _previousProductData = previousProductData;

  factory _$PreviousOrderProductsResModelImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$PreviousOrderProductsResModelImplFromJson(json);

  @override
  final int? status;
  @override
  final String? message;
  final List<PreviousOrderProductData>? _previousProductData;
  @override
  @JsonKey(name: "data")
  List<PreviousOrderProductData>? get previousProductData {
    final value = _previousProductData;
    if (value == null) return null;
    if (_previousProductData is EqualUnmodifiableListView)
      return _previousProductData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final MetaData? metaData;

  @override
  String toString() {
    return 'PreviousOrderProductsResModel(status: $status, message: $message, previousProductData: $previousProductData, metaData: $metaData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PreviousOrderProductsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            const DeepCollectionEquality()
                .equals(other._previousProductData, _previousProductData) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message,
      const DeepCollectionEquality().hash(_previousProductData), metaData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PreviousOrderProductsResModelImplCopyWith<
          _$PreviousOrderProductsResModelImpl>
      get copyWith => __$$PreviousOrderProductsResModelImplCopyWithImpl<
          _$PreviousOrderProductsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PreviousOrderProductsResModelImplToJson(
      this,
    );
  }
}

abstract class _PreviousOrderProductsResModel
    implements PreviousOrderProductsResModel {
  const factory _PreviousOrderProductsResModel(
      {final int? status,
      final String? message,
      @JsonKey(name: "data")
      final List<PreviousOrderProductData>? previousProductData,
      final MetaData? metaData}) = _$PreviousOrderProductsResModelImpl;

  factory _PreviousOrderProductsResModel.fromJson(Map<String, dynamic> json) =
      _$PreviousOrderProductsResModelImpl.fromJson;

  @override
  int? get status;
  @override
  String? get message;
  @override
  @JsonKey(name: "data")
  List<PreviousOrderProductData>? get previousProductData;
  @override
  MetaData? get metaData;
  @override
  @JsonKey(ignore: true)
  _$$PreviousOrderProductsResModelImplCopyWith<
          _$PreviousOrderProductsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

PreviousOrderProductData _$PreviousOrderProductDataFromJson(
    Map<String, dynamic> json) {
  return _PreviousOrderProductData.fromJson(json);
}

/// @nodoc
mixin _$PreviousOrderProductData {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  double? get productStock => throw _privateConstructorUsedError;
  int? get totalSale => throw _privateConstructorUsedError;
  double? get productPrice => throw _privateConstructorUsedError;
  String? get mainImage => throw _privateConstructorUsedError;
  String? get productName => throw _privateConstructorUsedError;
  int? get numberOfUnit => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;
  bool? get isPesach => throw _privateConstructorUsedError;
  String? get nmMashlim => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PreviousOrderProductDataCopyWith<PreviousOrderProductData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PreviousOrderProductDataCopyWith<$Res> {
  factory $PreviousOrderProductDataCopyWith(PreviousOrderProductData value,
          $Res Function(PreviousOrderProductData) then) =
      _$PreviousOrderProductDataCopyWithImpl<$Res, PreviousOrderProductData>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      double? productStock,
      int? totalSale,
      double? productPrice,
      String? mainImage,
      String? productName,
      int? numberOfUnit,
      String? lowStock,
      bool? isPesach,
      String? nmMashlim});
}

/// @nodoc
class _$PreviousOrderProductDataCopyWithImpl<$Res,
        $Val extends PreviousOrderProductData>
    implements $PreviousOrderProductDataCopyWith<$Res> {
  _$PreviousOrderProductDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? totalSale = freezed,
    Object? productPrice = freezed,
    Object? mainImage = freezed,
    Object? productName = freezed,
    Object? numberOfUnit = freezed,
    Object? lowStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PreviousOrderProductDataImplCopyWith<$Res>
    implements $PreviousOrderProductDataCopyWith<$Res> {
  factory _$$PreviousOrderProductDataImplCopyWith(
          _$PreviousOrderProductDataImpl value,
          $Res Function(_$PreviousOrderProductDataImpl) then) =
      __$$PreviousOrderProductDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      double? productStock,
      int? totalSale,
      double? productPrice,
      String? mainImage,
      String? productName,
      int? numberOfUnit,
      String? lowStock,
      bool? isPesach,
      String? nmMashlim});
}

/// @nodoc
class __$$PreviousOrderProductDataImplCopyWithImpl<$Res>
    extends _$PreviousOrderProductDataCopyWithImpl<$Res,
        _$PreviousOrderProductDataImpl>
    implements _$$PreviousOrderProductDataImplCopyWith<$Res> {
  __$$PreviousOrderProductDataImplCopyWithImpl(
      _$PreviousOrderProductDataImpl _value,
      $Res Function(_$PreviousOrderProductDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? totalSale = freezed,
    Object? productPrice = freezed,
    Object? mainImage = freezed,
    Object? productName = freezed,
    Object? numberOfUnit = freezed,
    Object? lowStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
  }) {
    return _then(_$PreviousOrderProductDataImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PreviousOrderProductDataImpl implements _PreviousOrderProductData {
  const _$PreviousOrderProductDataImpl(
      {@JsonKey(name: "_id") this.id,
      this.productStock,
      this.totalSale,
      this.productPrice,
      this.mainImage,
      this.productName,
      this.numberOfUnit,
      this.lowStock,
      this.isPesach,
      this.nmMashlim});

  factory _$PreviousOrderProductDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$PreviousOrderProductDataImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  final double? productStock;
  @override
  final int? totalSale;
  @override
  final double? productPrice;
  @override
  final String? mainImage;
  @override
  final String? productName;
  @override
  final int? numberOfUnit;
  @override
  final String? lowStock;
  @override
  final bool? isPesach;
  @override
  final String? nmMashlim;

  @override
  String toString() {
    return 'PreviousOrderProductData(id: $id, productStock: $productStock, totalSale: $totalSale, productPrice: $productPrice, mainImage: $mainImage, productName: $productName, numberOfUnit: $numberOfUnit, lowStock: $lowStock, isPesach: $isPesach, nmMashlim: $nmMashlim)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PreviousOrderProductDataImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.totalSale, totalSale) ||
                other.totalSale == totalSale) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      productStock,
      totalSale,
      productPrice,
      mainImage,
      productName,
      numberOfUnit,
      lowStock,
      isPesach,
      nmMashlim);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PreviousOrderProductDataImplCopyWith<_$PreviousOrderProductDataImpl>
      get copyWith => __$$PreviousOrderProductDataImplCopyWithImpl<
          _$PreviousOrderProductDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PreviousOrderProductDataImplToJson(
      this,
    );
  }
}

abstract class _PreviousOrderProductData implements PreviousOrderProductData {
  const factory _PreviousOrderProductData(
      {@JsonKey(name: "_id") final String? id,
      final double? productStock,
      final int? totalSale,
      final double? productPrice,
      final String? mainImage,
      final String? productName,
      final int? numberOfUnit,
      final String? lowStock,
      final bool? isPesach,
      final String? nmMashlim}) = _$PreviousOrderProductDataImpl;

  factory _PreviousOrderProductData.fromJson(Map<String, dynamic> json) =
      _$PreviousOrderProductDataImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  double? get productStock;
  @override
  int? get totalSale;
  @override
  double? get productPrice;
  @override
  String? get mainImage;
  @override
  String? get productName;
  @override
  int? get numberOfUnit;
  @override
  String? get lowStock;
  @override
  bool? get isPesach;
  @override
  String? get nmMashlim;
  @override
  @JsonKey(ignore: true)
  _$$PreviousOrderProductDataImplCopyWith<_$PreviousOrderProductDataImpl>
      get copyWith => throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  int? get currentPage => throw _privateConstructorUsedError;
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {int? currentPage, int? totalFilteredCount, int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int? currentPage, int? totalFilteredCount, int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {this.currentPage, this.totalFilteredCount, this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  final int? currentPage;
  @override
  final int? totalFilteredCount;
  @override
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
      {final int? currentPage,
      final int? totalFilteredCount,
      final int? totalFilteredPage}) = _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  int? get currentPage;
  @override
  int? get totalFilteredCount;
  @override
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
