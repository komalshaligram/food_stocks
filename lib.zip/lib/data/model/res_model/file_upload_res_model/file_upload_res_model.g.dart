// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'file_upload_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$FileUploadResModelImpl _$$FileUploadResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$FileUploadResModelImpl(
      baseUrl: json['baseURL'] as String?,
      filepath: json['filepath'] as String?,
    );

Map<String, dynamic> _$$FileUploadResModelImplToJson(
        _$FileUploadResModelImpl instance) =>
    <String, dynamic>{
      'baseURL': instance.baseUrl,
      'filepath': instance.filepath,
    };
