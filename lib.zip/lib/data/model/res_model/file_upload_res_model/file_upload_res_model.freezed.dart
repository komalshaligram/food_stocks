// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'file_upload_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

FileUploadResModel _$FileUploadResModelFromJson(Map<String, dynamic> json) {
  return _FileUploadResModel.fromJson(json);
}

/// @nodoc
mixin _$FileUploadResModel {
  @JsonKey(name: "baseURL")
  String? get baseUrl => throw _privateConstructorUsedError;
  @JsonKey(name: "filepath")
  String? get filepath => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $FileUploadResModelCopyWith<FileUploadResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FileUploadResModelCopyWith<$Res> {
  factory $FileUploadResModelCopyWith(
          FileUploadResModel value, $Res Function(FileUploadResModel) then) =
      _$FileUploadResModelCopyWithImpl<$Res, FileUploadResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "baseURL") String? baseUrl,
      @JsonKey(name: "filepath") String? filepath});
}

/// @nodoc
class _$FileUploadResModelCopyWithImpl<$Res, $Val extends FileUploadResModel>
    implements $FileUploadResModelCopyWith<$Res> {
  _$FileUploadResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseUrl = freezed,
    Object? filepath = freezed,
  }) {
    return _then(_value.copyWith(
      baseUrl: freezed == baseUrl
          ? _value.baseUrl
          : baseUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      filepath: freezed == filepath
          ? _value.filepath
          : filepath // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FileUploadResModelImplCopyWith<$Res>
    implements $FileUploadResModelCopyWith<$Res> {
  factory _$$FileUploadResModelImplCopyWith(_$FileUploadResModelImpl value,
          $Res Function(_$FileUploadResModelImpl) then) =
      __$$FileUploadResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "baseURL") String? baseUrl,
      @JsonKey(name: "filepath") String? filepath});
}

/// @nodoc
class __$$FileUploadResModelImplCopyWithImpl<$Res>
    extends _$FileUploadResModelCopyWithImpl<$Res, _$FileUploadResModelImpl>
    implements _$$FileUploadResModelImplCopyWith<$Res> {
  __$$FileUploadResModelImplCopyWithImpl(_$FileUploadResModelImpl _value,
      $Res Function(_$FileUploadResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseUrl = freezed,
    Object? filepath = freezed,
  }) {
    return _then(_$FileUploadResModelImpl(
      baseUrl: freezed == baseUrl
          ? _value.baseUrl
          : baseUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      filepath: freezed == filepath
          ? _value.filepath
          : filepath // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$FileUploadResModelImpl implements _FileUploadResModel {
  const _$FileUploadResModelImpl(
      {@JsonKey(name: "baseURL") this.baseUrl,
      @JsonKey(name: "filepath") this.filepath});

  factory _$FileUploadResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$FileUploadResModelImplFromJson(json);

  @override
  @JsonKey(name: "baseURL")
  final String? baseUrl;
  @override
  @JsonKey(name: "filepath")
  final String? filepath;

  @override
  String toString() {
    return 'FileUploadResModel(baseUrl: $baseUrl, filepath: $filepath)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FileUploadResModelImpl &&
            (identical(other.baseUrl, baseUrl) || other.baseUrl == baseUrl) &&
            (identical(other.filepath, filepath) ||
                other.filepath == filepath));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, baseUrl, filepath);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FileUploadResModelImplCopyWith<_$FileUploadResModelImpl> get copyWith =>
      __$$FileUploadResModelImplCopyWithImpl<_$FileUploadResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$FileUploadResModelImplToJson(
      this,
    );
  }
}

abstract class _FileUploadResModel implements FileUploadResModel {
  const factory _FileUploadResModel(
          {@JsonKey(name: "baseURL") final String? baseUrl,
          @JsonKey(name: "filepath") final String? filepath}) =
      _$FileUploadResModelImpl;

  factory _FileUploadResModel.fromJson(Map<String, dynamic> json) =
      _$FileUploadResModelImpl.fromJson;

  @override
  @JsonKey(name: "baseURL")
  String? get baseUrl;
  @override
  @JsonKey(name: "filepath")
  String? get filepath;
  @override
  @JsonKey(ignore: true)
  _$$FileUploadResModelImplCopyWith<_$FileUploadResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
