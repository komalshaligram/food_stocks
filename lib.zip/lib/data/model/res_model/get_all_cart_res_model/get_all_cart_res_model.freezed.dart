// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_all_cart_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAllCartResModel _$GetAllCartResModelFromJson(Map<String, dynamic> json) {
  return _GetAllCartResModel.fromJson(json);
}

/// @nodoc
mixin _$GetAllCartResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAllCartResModelCopyWith<GetAllCartResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllCartResModelCopyWith<$Res> {
  factory $GetAllCartResModelCopyWith(
          GetAllCartResModel value, $Res Function(GetAllCartResModel) then) =
      _$GetAllCartResModelCopyWithImpl<$Res, GetAllCartResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$GetAllCartResModelCopyWithImpl<$Res, $Val extends GetAllCartResModel>
    implements $GetAllCartResModelCopyWith<$Res> {
  _$GetAllCartResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GetAllCartResModelImplCopyWith<$Res>
    implements $GetAllCartResModelCopyWith<$Res> {
  factory _$$GetAllCartResModelImplCopyWith(_$GetAllCartResModelImpl value,
          $Res Function(_$GetAllCartResModelImpl) then) =
      __$$GetAllCartResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$GetAllCartResModelImplCopyWithImpl<$Res>
    extends _$GetAllCartResModelCopyWithImpl<$Res, _$GetAllCartResModelImpl>
    implements _$$GetAllCartResModelImplCopyWith<$Res> {
  __$$GetAllCartResModelImplCopyWithImpl(_$GetAllCartResModelImpl _value,
      $Res Function(_$GetAllCartResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$GetAllCartResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAllCartResModelImpl implements _GetAllCartResModel {
  const _$GetAllCartResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$GetAllCartResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetAllCartResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'GetAllCartResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllCartResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllCartResModelImplCopyWith<_$GetAllCartResModelImpl> get copyWith =>
      __$$GetAllCartResModelImplCopyWithImpl<_$GetAllCartResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAllCartResModelImplToJson(
      this,
    );
  }
}

abstract class _GetAllCartResModel implements GetAllCartResModel {
  const factory _GetAllCartResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final Data? data,
          @JsonKey(name: "message") final String? message}) =
      _$GetAllCartResModelImpl;

  factory _GetAllCartResModel.fromJson(Map<String, dynamic> json) =
      _$GetAllCartResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$GetAllCartResModelImplCopyWith<_$GetAllCartResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  double? get vatPercentage => throw _privateConstructorUsedError;
  double? get bottleTax => throw _privateConstructorUsedError;
  @JsonKey(name: "cart")
  List<Cart>? get cart => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<Datum>? get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {double? vatPercentage,
      double? bottleTax,
      @JsonKey(name: "cart") List<Cart>? cart,
      @JsonKey(name: "data") List<Datum>? data});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? vatPercentage = freezed,
    Object? bottleTax = freezed,
    Object? cart = freezed,
    Object? data = freezed,
  }) {
    return _then(_value.copyWith(
      vatPercentage: freezed == vatPercentage
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      bottleTax: freezed == bottleTax
          ? _value.bottleTax
          : bottleTax // ignore: cast_nullable_to_non_nullable
              as double?,
      cart: freezed == cart
          ? _value.cart
          : cart // ignore: cast_nullable_to_non_nullable
              as List<Cart>?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {double? vatPercentage,
      double? bottleTax,
      @JsonKey(name: "cart") List<Cart>? cart,
      @JsonKey(name: "data") List<Datum>? data});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? vatPercentage = freezed,
    Object? bottleTax = freezed,
    Object? cart = freezed,
    Object? data = freezed,
  }) {
    return _then(_$DataImpl(
      vatPercentage: freezed == vatPercentage
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      bottleTax: freezed == bottleTax
          ? _value.bottleTax
          : bottleTax // ignore: cast_nullable_to_non_nullable
              as double?,
      cart: freezed == cart
          ? _value._cart
          : cart // ignore: cast_nullable_to_non_nullable
              as List<Cart>?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {this.vatPercentage,
      this.bottleTax,
      @JsonKey(name: "cart") final List<Cart>? cart,
      @JsonKey(name: "data") final List<Datum>? data})
      : _cart = cart,
        _data = data;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  final double? vatPercentage;
  @override
  final double? bottleTax;
  final List<Cart>? _cart;
  @override
  @JsonKey(name: "cart")
  List<Cart>? get cart {
    final value = _cart;
    if (value == null) return null;
    if (_cart is EqualUnmodifiableListView) return _cart;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Datum>? _data;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'Data(vatPercentage: $vatPercentage, bottleTax: $bottleTax, cart: $cart, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.vatPercentage, vatPercentage) ||
                other.vatPercentage == vatPercentage) &&
            (identical(other.bottleTax, bottleTax) ||
                other.bottleTax == bottleTax) &&
            const DeepCollectionEquality().equals(other._cart, _cart) &&
            const DeepCollectionEquality().equals(other._data, _data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      vatPercentage,
      bottleTax,
      const DeepCollectionEquality().hash(_cart),
      const DeepCollectionEquality().hash(_data));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {final double? vatPercentage,
      final double? bottleTax,
      @JsonKey(name: "cart") final List<Cart>? cart,
      @JsonKey(name: "data") final List<Datum>? data}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  double? get vatPercentage;
  @override
  double? get bottleTax;
  @override
  @JsonKey(name: "cart")
  List<Cart>? get cart;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Cart _$CartFromJson(Map<String, dynamic> json) {
  return _Cart.fromJson(json);
}

/// @nodoc
mixin _$Cart {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "totalAmount")
  double? get totalAmount => throw _privateConstructorUsedError;
  int? get suppliers => throw _privateConstructorUsedError;
  int? get bottleQuantities => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CartCopyWith<Cart> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CartCopyWith<$Res> {
  factory $CartCopyWith(Cart value, $Res Function(Cart) then) =
      _$CartCopyWithImpl<$Res, Cart>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "totalAmount") double? totalAmount,
      int? suppliers,
      int? bottleQuantities});
}

/// @nodoc
class _$CartCopyWithImpl<$Res, $Val extends Cart>
    implements $CartCopyWith<$Res> {
  _$CartCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? totalAmount = freezed,
    Object? suppliers = freezed,
    Object? bottleQuantities = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      suppliers: freezed == suppliers
          ? _value.suppliers
          : suppliers // ignore: cast_nullable_to_non_nullable
              as int?,
      bottleQuantities: freezed == bottleQuantities
          ? _value.bottleQuantities
          : bottleQuantities // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CartImplCopyWith<$Res> implements $CartCopyWith<$Res> {
  factory _$$CartImplCopyWith(
          _$CartImpl value, $Res Function(_$CartImpl) then) =
      __$$CartImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "totalAmount") double? totalAmount,
      int? suppliers,
      int? bottleQuantities});
}

/// @nodoc
class __$$CartImplCopyWithImpl<$Res>
    extends _$CartCopyWithImpl<$Res, _$CartImpl>
    implements _$$CartImplCopyWith<$Res> {
  __$$CartImplCopyWithImpl(_$CartImpl _value, $Res Function(_$CartImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? totalAmount = freezed,
    Object? suppliers = freezed,
    Object? bottleQuantities = freezed,
  }) {
    return _then(_$CartImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      suppliers: freezed == suppliers
          ? _value.suppliers
          : suppliers // ignore: cast_nullable_to_non_nullable
              as int?,
      bottleQuantities: freezed == bottleQuantities
          ? _value.bottleQuantities
          : bottleQuantities // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CartImpl implements _Cart {
  const _$CartImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "totalAmount") this.totalAmount,
      this.suppliers,
      this.bottleQuantities});

  factory _$CartImpl.fromJson(Map<String, dynamic> json) =>
      _$$CartImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "totalAmount")
  final double? totalAmount;
  @override
  final int? suppliers;
  @override
  final int? bottleQuantities;

  @override
  String toString() {
    return 'Cart(id: $id, totalAmount: $totalAmount, suppliers: $suppliers, bottleQuantities: $bottleQuantities)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CartImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.totalAmount, totalAmount) ||
                other.totalAmount == totalAmount) &&
            (identical(other.suppliers, suppliers) ||
                other.suppliers == suppliers) &&
            (identical(other.bottleQuantities, bottleQuantities) ||
                other.bottleQuantities == bottleQuantities));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, totalAmount, suppliers, bottleQuantities);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CartImplCopyWith<_$CartImpl> get copyWith =>
      __$$CartImplCopyWithImpl<_$CartImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CartImplToJson(
      this,
    );
  }
}

abstract class _Cart implements Cart {
  const factory _Cart(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "totalAmount") final double? totalAmount,
      final int? suppliers,
      final int? bottleQuantities}) = _$CartImpl;

  factory _Cart.fromJson(Map<String, dynamic> json) = _$CartImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "totalAmount")
  double? get totalAmount;
  @override
  int? get suppliers;
  @override
  int? get bottleQuantities;
  @override
  @JsonKey(ignore: true)
  _$$CartImplCopyWith<_$CartImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Datum _$DatumFromJson(Map<String, dynamic> json) {
  return _Datum.fromJson(json);
}

/// @nodoc
mixin _$Datum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productDetails")
  ProductDetails? get productDetails => throw _privateConstructorUsedError;
  @JsonKey(name: "cartProductId")
  String? get cartProductId => throw _privateConstructorUsedError;
  @JsonKey(name: "suppliers")
  List<Supplier>? get suppliers => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  double? get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  double? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "sales")
  List<Sale>? get sales => throw _privateConstructorUsedError;
  @JsonKey(name: "totalQuantity")
  int? get totalQuantity => throw _privateConstructorUsedError;
  @JsonKey(name: "totalAmount")
  double? get totalAmount => throw _privateConstructorUsedError;
  @JsonKey(name: "note")
  String? get note => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DatumCopyWith<Datum> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DatumCopyWith<$Res> {
  factory $DatumCopyWith(Datum value, $Res Function(Datum) then) =
      _$DatumCopyWithImpl<$Res, Datum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productDetails") ProductDetails? productDetails,
      @JsonKey(name: "cartProductId") String? cartProductId,
      @JsonKey(name: "suppliers") List<Supplier>? suppliers,
      @JsonKey(name: "productStock") double? productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "sales") List<Sale>? sales,
      @JsonKey(name: "totalQuantity") int? totalQuantity,
      @JsonKey(name: "totalAmount") double? totalAmount,
      @JsonKey(name: "note") String? note,
      String? lowStock});

  $ProductDetailsCopyWith<$Res>? get productDetails;
}

/// @nodoc
class _$DatumCopyWithImpl<$Res, $Val extends Datum>
    implements $DatumCopyWith<$Res> {
  _$DatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productDetails = freezed,
    Object? cartProductId = freezed,
    Object? suppliers = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? sales = freezed,
    Object? totalQuantity = freezed,
    Object? totalAmount = freezed,
    Object? note = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productDetails: freezed == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as ProductDetails?,
      cartProductId: freezed == cartProductId
          ? _value.cartProductId
          : cartProductId // ignore: cast_nullable_to_non_nullable
              as String?,
      suppliers: freezed == suppliers
          ? _value.suppliers
          : suppliers // ignore: cast_nullable_to_non_nullable
              as List<Supplier>?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      sales: freezed == sales
          ? _value.sales
          : sales // ignore: cast_nullable_to_non_nullable
              as List<Sale>?,
      totalQuantity: freezed == totalQuantity
          ? _value.totalQuantity
          : totalQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ProductDetailsCopyWith<$Res>? get productDetails {
    if (_value.productDetails == null) {
      return null;
    }

    return $ProductDetailsCopyWith<$Res>(_value.productDetails!, (value) {
      return _then(_value.copyWith(productDetails: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DatumImplCopyWith<$Res> implements $DatumCopyWith<$Res> {
  factory _$$DatumImplCopyWith(
          _$DatumImpl value, $Res Function(_$DatumImpl) then) =
      __$$DatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productDetails") ProductDetails? productDetails,
      @JsonKey(name: "cartProductId") String? cartProductId,
      @JsonKey(name: "suppliers") List<Supplier>? suppliers,
      @JsonKey(name: "productStock") double? productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "sales") List<Sale>? sales,
      @JsonKey(name: "totalQuantity") int? totalQuantity,
      @JsonKey(name: "totalAmount") double? totalAmount,
      @JsonKey(name: "note") String? note,
      String? lowStock});

  @override
  $ProductDetailsCopyWith<$Res>? get productDetails;
}

/// @nodoc
class __$$DatumImplCopyWithImpl<$Res>
    extends _$DatumCopyWithImpl<$Res, _$DatumImpl>
    implements _$$DatumImplCopyWith<$Res> {
  __$$DatumImplCopyWithImpl(
      _$DatumImpl _value, $Res Function(_$DatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productDetails = freezed,
    Object? cartProductId = freezed,
    Object? suppliers = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? sales = freezed,
    Object? totalQuantity = freezed,
    Object? totalAmount = freezed,
    Object? note = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_$DatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productDetails: freezed == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as ProductDetails?,
      cartProductId: freezed == cartProductId
          ? _value.cartProductId
          : cartProductId // ignore: cast_nullable_to_non_nullable
              as String?,
      suppliers: freezed == suppliers
          ? _value._suppliers
          : suppliers // ignore: cast_nullable_to_non_nullable
              as List<Supplier>?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      sales: freezed == sales
          ? _value._sales
          : sales // ignore: cast_nullable_to_non_nullable
              as List<Sale>?,
      totalQuantity: freezed == totalQuantity
          ? _value.totalQuantity
          : totalQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DatumImpl implements _Datum {
  const _$DatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "productDetails") this.productDetails,
      @JsonKey(name: "cartProductId") this.cartProductId,
      @JsonKey(name: "suppliers") final List<Supplier>? suppliers,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "sales") final List<Sale>? sales,
      @JsonKey(name: "totalQuantity") this.totalQuantity,
      @JsonKey(name: "totalAmount") this.totalAmount,
      @JsonKey(name: "note") this.note,
      this.lowStock})
      : _suppliers = suppliers,
        _sales = sales;

  factory _$DatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$DatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productDetails")
  final ProductDetails? productDetails;
  @override
  @JsonKey(name: "cartProductId")
  final String? cartProductId;
  final List<Supplier>? _suppliers;
  @override
  @JsonKey(name: "suppliers")
  List<Supplier>? get suppliers {
    final value = _suppliers;
    if (value == null) return null;
    if (_suppliers is EqualUnmodifiableListView) return _suppliers;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "productStock")
  final double? productStock;
  @override
  @JsonKey(name: "productPrice")
  final double? productPrice;
  final List<Sale>? _sales;
  @override
  @JsonKey(name: "sales")
  List<Sale>? get sales {
    final value = _sales;
    if (value == null) return null;
    if (_sales is EqualUnmodifiableListView) return _sales;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "totalQuantity")
  final int? totalQuantity;
  @override
  @JsonKey(name: "totalAmount")
  final double? totalAmount;
  @override
  @JsonKey(name: "note")
  final String? note;
  @override
  final String? lowStock;

  @override
  String toString() {
    return 'Datum(id: $id, productDetails: $productDetails, cartProductId: $cartProductId, suppliers: $suppliers, productStock: $productStock, productPrice: $productPrice, sales: $sales, totalQuantity: $totalQuantity, totalAmount: $totalAmount, note: $note, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productDetails, productDetails) ||
                other.productDetails == productDetails) &&
            (identical(other.cartProductId, cartProductId) ||
                other.cartProductId == cartProductId) &&
            const DeepCollectionEquality()
                .equals(other._suppliers, _suppliers) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            const DeepCollectionEquality().equals(other._sales, _sales) &&
            (identical(other.totalQuantity, totalQuantity) ||
                other.totalQuantity == totalQuantity) &&
            (identical(other.totalAmount, totalAmount) ||
                other.totalAmount == totalAmount) &&
            (identical(other.note, note) || other.note == note) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      productDetails,
      cartProductId,
      const DeepCollectionEquality().hash(_suppliers),
      productStock,
      productPrice,
      const DeepCollectionEquality().hash(_sales),
      totalQuantity,
      totalAmount,
      note,
      lowStock);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      __$$DatumImplCopyWithImpl<_$DatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DatumImplToJson(
      this,
    );
  }
}

abstract class _Datum implements Datum {
  const factory _Datum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "productDetails") final ProductDetails? productDetails,
      @JsonKey(name: "cartProductId") final String? cartProductId,
      @JsonKey(name: "suppliers") final List<Supplier>? suppliers,
      @JsonKey(name: "productStock") final double? productStock,
      @JsonKey(name: "productPrice") final double? productPrice,
      @JsonKey(name: "sales") final List<Sale>? sales,
      @JsonKey(name: "totalQuantity") final int? totalQuantity,
      @JsonKey(name: "totalAmount") final double? totalAmount,
      @JsonKey(name: "note") final String? note,
      final String? lowStock}) = _$DatumImpl;

  factory _Datum.fromJson(Map<String, dynamic> json) = _$DatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productDetails")
  ProductDetails? get productDetails;
  @override
  @JsonKey(name: "cartProductId")
  String? get cartProductId;
  @override
  @JsonKey(name: "suppliers")
  List<Supplier>? get suppliers;
  @override
  @JsonKey(name: "productStock")
  double? get productStock;
  @override
  @JsonKey(name: "productPrice")
  double? get productPrice;
  @override
  @JsonKey(name: "sales")
  List<Sale>? get sales;
  @override
  @JsonKey(name: "totalQuantity")
  int? get totalQuantity;
  @override
  @JsonKey(name: "totalAmount")
  double? get totalAmount;
  @override
  @JsonKey(name: "note")
  String? get note;
  @override
  String? get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ProductDetails _$ProductDetailsFromJson(Map<String, dynamic> json) {
  return _ProductDetails.fromJson(json);
}

/// @nodoc
mixin _$ProductDetails {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  double? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "images")
  List<Image>? get images => throw _privateConstructorUsedError;
  @JsonKey(name: "scales")
  String? get scales => throw _privateConstructorUsedError;
  @JsonKey(name: "numberOfUnit")
  int? get numberOfUnit => throw _privateConstructorUsedError;
  bool? get isPesach => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductDetailsCopyWith<ProductDetails> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductDetailsCopyWith<$Res> {
  factory $ProductDetailsCopyWith(
          ProductDetails value, $Res Function(ProductDetails) then) =
      _$ProductDetailsCopyWithImpl<$Res, ProductDetails>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") double? itemsWeight,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "scales") String? scales,
      @JsonKey(name: "numberOfUnit") int? numberOfUnit,
      bool? isPesach});
}

/// @nodoc
class _$ProductDetailsCopyWithImpl<$Res, $Val extends ProductDetails>
    implements $ProductDetailsCopyWith<$Res> {
  _$ProductDetailsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productName = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? images = freezed,
    Object? scales = freezed,
    Object? numberOfUnit = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      images: freezed == images
          ? _value.images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      scales: freezed == scales
          ? _value.scales
          : scales // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductDetailsImplCopyWith<$Res>
    implements $ProductDetailsCopyWith<$Res> {
  factory _$$ProductDetailsImplCopyWith(_$ProductDetailsImpl value,
          $Res Function(_$ProductDetailsImpl) then) =
      __$$ProductDetailsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") double? itemsWeight,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "scales") String? scales,
      @JsonKey(name: "numberOfUnit") int? numberOfUnit,
      bool? isPesach});
}

/// @nodoc
class __$$ProductDetailsImplCopyWithImpl<$Res>
    extends _$ProductDetailsCopyWithImpl<$Res, _$ProductDetailsImpl>
    implements _$$ProductDetailsImplCopyWith<$Res> {
  __$$ProductDetailsImplCopyWithImpl(
      _$ProductDetailsImpl _value, $Res Function(_$ProductDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productName = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? images = freezed,
    Object? scales = freezed,
    Object? numberOfUnit = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_$ProductDetailsImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      images: freezed == images
          ? _value._images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      scales: freezed == scales
          ? _value.scales
          : scales // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductDetailsImpl implements _ProductDetails {
  const _$ProductDetailsImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "scales") this.scales,
      @JsonKey(name: "numberOfUnit") this.numberOfUnit,
      this.isPesach})
      : _images = images;

  factory _$ProductDetailsImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductDetailsImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  final double? itemsWeight;
  final List<Image>? _images;
  @override
  @JsonKey(name: "images")
  List<Image>? get images {
    final value = _images;
    if (value == null) return null;
    if (_images is EqualUnmodifiableListView) return _images;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "scales")
  final String? scales;
  @override
  @JsonKey(name: "numberOfUnit")
  final int? numberOfUnit;
  @override
  final bool? isPesach;

  @override
  String toString() {
    return 'ProductDetails(id: $id, productName: $productName, mainImage: $mainImage, itemsWeight: $itemsWeight, images: $images, scales: $scales, numberOfUnit: $numberOfUnit, isPesach: $isPesach)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductDetailsImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            const DeepCollectionEquality().equals(other._images, _images) &&
            (identical(other.scales, scales) || other.scales == scales) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      productName,
      mainImage,
      itemsWeight,
      const DeepCollectionEquality().hash(_images),
      scales,
      numberOfUnit,
      isPesach);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductDetailsImplCopyWith<_$ProductDetailsImpl> get copyWith =>
      __$$ProductDetailsImplCopyWithImpl<_$ProductDetailsImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductDetailsImplToJson(
      this,
    );
  }
}

abstract class _ProductDetails implements ProductDetails {
  const factory _ProductDetails(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "itemsWeight") final double? itemsWeight,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "scales") final String? scales,
      @JsonKey(name: "numberOfUnit") final int? numberOfUnit,
      final bool? isPesach}) = _$ProductDetailsImpl;

  factory _ProductDetails.fromJson(Map<String, dynamic> json) =
      _$ProductDetailsImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  double? get itemsWeight;
  @override
  @JsonKey(name: "images")
  List<Image>? get images;
  @override
  @JsonKey(name: "scales")
  String? get scales;
  @override
  @JsonKey(name: "numberOfUnit")
  int? get numberOfUnit;
  @override
  bool? get isPesach;
  @override
  @JsonKey(ignore: true)
  _$$ProductDetailsImplCopyWith<_$ProductDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Image _$ImageFromJson(Map<String, dynamic> json) {
  return _Image.fromJson(json);
}

/// @nodoc
mixin _$Image {
  @JsonKey(name: "imageUrl")
  String? get imageUrl => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ImageCopyWith<Image> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ImageCopyWith<$Res> {
  factory $ImageCopyWith(Image value, $Res Function(Image) then) =
      _$ImageCopyWithImpl<$Res, Image>;
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class _$ImageCopyWithImpl<$Res, $Val extends Image>
    implements $ImageCopyWith<$Res> {
  _$ImageCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_value.copyWith(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ImageImplCopyWith<$Res> implements $ImageCopyWith<$Res> {
  factory _$$ImageImplCopyWith(
          _$ImageImpl value, $Res Function(_$ImageImpl) then) =
      __$$ImageImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class __$$ImageImplCopyWithImpl<$Res>
    extends _$ImageCopyWithImpl<$Res, _$ImageImpl>
    implements _$$ImageImplCopyWith<$Res> {
  __$$ImageImplCopyWithImpl(
      _$ImageImpl _value, $Res Function(_$ImageImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_$ImageImpl(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ImageImpl implements _Image {
  const _$ImageImpl(
      {@JsonKey(name: "imageUrl") this.imageUrl,
      @JsonKey(name: "order") this.order});

  factory _$ImageImpl.fromJson(Map<String, dynamic> json) =>
      _$$ImageImplFromJson(json);

  @override
  @JsonKey(name: "imageUrl")
  final String? imageUrl;
  @override
  @JsonKey(name: "order")
  final int? order;

  @override
  String toString() {
    return 'Image(imageUrl: $imageUrl, order: $order)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ImageImpl &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.order, order) || other.order == order));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, imageUrl, order);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      __$$ImageImplCopyWithImpl<_$ImageImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ImageImplToJson(
      this,
    );
  }
}

abstract class _Image implements Image {
  const factory _Image(
      {@JsonKey(name: "imageUrl") final String? imageUrl,
      @JsonKey(name: "order") final int? order}) = _$ImageImpl;

  factory _Image.fromJson(Map<String, dynamic> json) = _$ImageImpl.fromJson;

  @override
  @JsonKey(name: "imageUrl")
  String? get imageUrl;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(ignore: true)
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Sale _$SaleFromJson(Map<String, dynamic> json) {
  return _Sale.fromJson(json);
}

/// @nodoc
mixin _$Sale {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierDetails")
  String? get supplierDetails => throw _privateConstructorUsedError;
  @JsonKey(name: "salesName")
  String? get salesName => throw _privateConstructorUsedError;
  @JsonKey(name: "discountPercentage")
  double? get discountPercentage => throw _privateConstructorUsedError;
  @JsonKey(name: "salesType")
  String? get salesType => throw _privateConstructorUsedError;
  @JsonKey(name: "salesDescription")
  String? get salesDescription => throw _privateConstructorUsedError;
  @JsonKey(name: "fromDate")
  String? get fromDate => throw _privateConstructorUsedError;
  @JsonKey(name: "endDate")
  String? get endDate => throw _privateConstructorUsedError;
  @JsonKey(name: "salesTerms")
  String? get salesTerms => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SaleCopyWith<Sale> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SaleCopyWith<$Res> {
  factory $SaleCopyWith(Sale value, $Res Function(Sale) then) =
      _$SaleCopyWithImpl<$Res, Sale>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "supplierDetails") String? supplierDetails,
      @JsonKey(name: "salesName") String? salesName,
      @JsonKey(name: "discountPercentage") double? discountPercentage,
      @JsonKey(name: "salesType") String? salesType,
      @JsonKey(name: "salesDescription") String? salesDescription,
      @JsonKey(name: "fromDate") String? fromDate,
      @JsonKey(name: "endDate") String? endDate,
      @JsonKey(name: "salesTerms") String? salesTerms,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class _$SaleCopyWithImpl<$Res, $Val extends Sale>
    implements $SaleCopyWith<$Res> {
  _$SaleCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? status = freezed,
    Object? supplierDetails = freezed,
    Object? salesName = freezed,
    Object? discountPercentage = freezed,
    Object? salesType = freezed,
    Object? salesDescription = freezed,
    Object? fromDate = freezed,
    Object? endDate = freezed,
    Object? salesTerms = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierDetails: freezed == supplierDetails
          ? _value.supplierDetails
          : supplierDetails // ignore: cast_nullable_to_non_nullable
              as String?,
      salesName: freezed == salesName
          ? _value.salesName
          : salesName // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      salesType: freezed == salesType
          ? _value.salesType
          : salesType // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as String?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as String?,
      salesTerms: freezed == salesTerms
          ? _value.salesTerms
          : salesTerms // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SaleImplCopyWith<$Res> implements $SaleCopyWith<$Res> {
  factory _$$SaleImplCopyWith(
          _$SaleImpl value, $Res Function(_$SaleImpl) then) =
      __$$SaleImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "supplierDetails") String? supplierDetails,
      @JsonKey(name: "salesName") String? salesName,
      @JsonKey(name: "discountPercentage") double? discountPercentage,
      @JsonKey(name: "salesType") String? salesType,
      @JsonKey(name: "salesDescription") String? salesDescription,
      @JsonKey(name: "fromDate") String? fromDate,
      @JsonKey(name: "endDate") String? endDate,
      @JsonKey(name: "salesTerms") String? salesTerms,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class __$$SaleImplCopyWithImpl<$Res>
    extends _$SaleCopyWithImpl<$Res, _$SaleImpl>
    implements _$$SaleImplCopyWith<$Res> {
  __$$SaleImplCopyWithImpl(_$SaleImpl _value, $Res Function(_$SaleImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? status = freezed,
    Object? supplierDetails = freezed,
    Object? salesName = freezed,
    Object? discountPercentage = freezed,
    Object? salesType = freezed,
    Object? salesDescription = freezed,
    Object? fromDate = freezed,
    Object? endDate = freezed,
    Object? salesTerms = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$SaleImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierDetails: freezed == supplierDetails
          ? _value.supplierDetails
          : supplierDetails // ignore: cast_nullable_to_non_nullable
              as String?,
      salesName: freezed == salesName
          ? _value.salesName
          : salesName // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      salesType: freezed == salesType
          ? _value.salesType
          : salesType // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as String?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as String?,
      salesTerms: freezed == salesTerms
          ? _value.salesTerms
          : salesTerms // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SaleImpl implements _Sale {
  const _$SaleImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "supplierDetails") this.supplierDetails,
      @JsonKey(name: "salesName") this.salesName,
      @JsonKey(name: "discountPercentage") this.discountPercentage,
      @JsonKey(name: "salesType") this.salesType,
      @JsonKey(name: "salesDescription") this.salesDescription,
      @JsonKey(name: "fromDate") this.fromDate,
      @JsonKey(name: "endDate") this.endDate,
      @JsonKey(name: "salesTerms") this.salesTerms,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$SaleImpl.fromJson(Map<String, dynamic> json) =>
      _$$SaleImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "status")
  final String? status;
  @override
  @JsonKey(name: "supplierDetails")
  final String? supplierDetails;
  @override
  @JsonKey(name: "salesName")
  final String? salesName;
  @override
  @JsonKey(name: "discountPercentage")
  final double? discountPercentage;
  @override
  @JsonKey(name: "salesType")
  final String? salesType;
  @override
  @JsonKey(name: "salesDescription")
  final String? salesDescription;
  @override
  @JsonKey(name: "fromDate")
  final String? fromDate;
  @override
  @JsonKey(name: "endDate")
  final String? endDate;
  @override
  @JsonKey(name: "salesTerms")
  final String? salesTerms;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Sale(id: $id, status: $status, supplierDetails: $supplierDetails, salesName: $salesName, discountPercentage: $discountPercentage, salesType: $salesType, salesDescription: $salesDescription, fromDate: $fromDate, endDate: $endDate, salesTerms: $salesTerms, createdBy: $createdBy, updatedBy: $updatedBy, isDeleted: $isDeleted, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SaleImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.supplierDetails, supplierDetails) ||
                other.supplierDetails == supplierDetails) &&
            (identical(other.salesName, salesName) ||
                other.salesName == salesName) &&
            (identical(other.discountPercentage, discountPercentage) ||
                other.discountPercentage == discountPercentage) &&
            (identical(other.salesType, salesType) ||
                other.salesType == salesType) &&
            (identical(other.salesDescription, salesDescription) ||
                other.salesDescription == salesDescription) &&
            (identical(other.fromDate, fromDate) ||
                other.fromDate == fromDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate) &&
            (identical(other.salesTerms, salesTerms) ||
                other.salesTerms == salesTerms) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      status,
      supplierDetails,
      salesName,
      discountPercentage,
      salesType,
      salesDescription,
      fromDate,
      endDate,
      salesTerms,
      createdBy,
      updatedBy,
      isDeleted,
      createdAt,
      updatedAt,
      v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SaleImplCopyWith<_$SaleImpl> get copyWith =>
      __$$SaleImplCopyWithImpl<_$SaleImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SaleImplToJson(
      this,
    );
  }
}

abstract class _Sale implements Sale {
  const factory _Sale(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "status") final String? status,
      @JsonKey(name: "supplierDetails") final String? supplierDetails,
      @JsonKey(name: "salesName") final String? salesName,
      @JsonKey(name: "discountPercentage") final double? discountPercentage,
      @JsonKey(name: "salesType") final String? salesType,
      @JsonKey(name: "salesDescription") final String? salesDescription,
      @JsonKey(name: "fromDate") final String? fromDate,
      @JsonKey(name: "endDate") final String? endDate,
      @JsonKey(name: "salesTerms") final String? salesTerms,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$SaleImpl;

  factory _Sale.fromJson(Map<String, dynamic> json) = _$SaleImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "status")
  String? get status;
  @override
  @JsonKey(name: "supplierDetails")
  String? get supplierDetails;
  @override
  @JsonKey(name: "salesName")
  String? get salesName;
  @override
  @JsonKey(name: "discountPercentage")
  double? get discountPercentage;
  @override
  @JsonKey(name: "salesType")
  String? get salesType;
  @override
  @JsonKey(name: "salesDescription")
  String? get salesDescription;
  @override
  @JsonKey(name: "fromDate")
  String? get fromDate;
  @override
  @JsonKey(name: "endDate")
  String? get endDate;
  @override
  @JsonKey(name: "salesTerms")
  String? get salesTerms;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$SaleImplCopyWith<_$SaleImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Supplier _$SupplierFromJson(Map<String, dynamic> json) {
  return _Supplier.fromJson(json);
}

/// @nodoc
mixin _$Supplier {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierCopyWith<Supplier> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierCopyWith<$Res> {
  factory $SupplierCopyWith(Supplier value, $Res Function(Supplier) then) =
      _$SupplierCopyWithImpl<$Res, Supplier>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "contactName") String? contactName});
}

/// @nodoc
class _$SupplierCopyWithImpl<$Res, $Val extends Supplier>
    implements $SupplierCopyWith<$Res> {
  _$SupplierCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? contactName = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierImplCopyWith<$Res>
    implements $SupplierCopyWith<$Res> {
  factory _$$SupplierImplCopyWith(
          _$SupplierImpl value, $Res Function(_$SupplierImpl) then) =
      __$$SupplierImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "contactName") String? contactName});
}

/// @nodoc
class __$$SupplierImplCopyWithImpl<$Res>
    extends _$SupplierCopyWithImpl<$Res, _$SupplierImpl>
    implements _$$SupplierImplCopyWith<$Res> {
  __$$SupplierImplCopyWithImpl(
      _$SupplierImpl _value, $Res Function(_$SupplierImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? contactName = freezed,
  }) {
    return _then(_$SupplierImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierImpl implements _Supplier {
  const _$SupplierImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "contactName") this.contactName});

  factory _$SupplierImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;

  @override
  String toString() {
    return 'Supplier(id: $id, contactName: $contactName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, contactName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierImplCopyWith<_$SupplierImpl> get copyWith =>
      __$$SupplierImplCopyWithImpl<_$SupplierImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierImplToJson(
      this,
    );
  }
}

abstract class _Supplier implements Supplier {
  const factory _Supplier(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "contactName") final String? contactName}) =
      _$SupplierImpl;

  factory _Supplier.fromJson(Map<String, dynamic> json) =
      _$SupplierImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(ignore: true)
  _$$SupplierImplCopyWith<_$SupplierImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
