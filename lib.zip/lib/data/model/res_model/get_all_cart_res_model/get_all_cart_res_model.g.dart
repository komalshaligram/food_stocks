// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_all_cart_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllCartResModelImpl _$$GetAllCartResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetAllCartResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$GetAllCartResModelImplToJson(
        _$GetAllCartResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      vatPercentage: (json['vatPercentage'] as num?)?.toDouble(),
      bottleTax: (json['bottleTax'] as num?)?.toDouble(),
      cart: (json['cart'] as List<dynamic>?)
          ?.map((e) => Cart.fromJson(e as Map<String, dynamic>))
          .toList(),
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => Datum.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'vatPercentage': instance.vatPercentage,
      'bottleTax': instance.bottleTax,
      'cart': instance.cart,
      'data': instance.data,
    };

_$CartImpl _$$CartImplFromJson(Map<String, dynamic> json) => _$CartImpl(
      id: json['_id'] as String?,
      totalAmount: (json['totalAmount'] as num?)?.toDouble(),
      suppliers: json['suppliers'] as int?,
      bottleQuantities: json['bottleQuantities'] as int?,
    );

Map<String, dynamic> _$$CartImplToJson(_$CartImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'totalAmount': instance.totalAmount,
      'suppliers': instance.suppliers,
      'bottleQuantities': instance.bottleQuantities,
    };

_$DatumImpl _$$DatumImplFromJson(Map<String, dynamic> json) => _$DatumImpl(
      id: json['_id'] as String?,
      productDetails: json['productDetails'] == null
          ? null
          : ProductDetails.fromJson(
              json['productDetails'] as Map<String, dynamic>),
      cartProductId: json['cartProductId'] as String?,
      suppliers: (json['suppliers'] as List<dynamic>?)
          ?.map((e) => Supplier.fromJson(e as Map<String, dynamic>))
          .toList(),
      productStock: (json['productStock'] as num?)?.toDouble(),
      productPrice: (json['productPrice'] as num?)?.toDouble(),
      sales: (json['sales'] as List<dynamic>?)
          ?.map((e) => Sale.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalQuantity: json['totalQuantity'] as int?,
      totalAmount: (json['totalAmount'] as num?)?.toDouble(),
      note: json['note'] as String?,
      lowStock: json['lowStock'] as String?,
    );

Map<String, dynamic> _$$DatumImplToJson(_$DatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productDetails': instance.productDetails,
      'cartProductId': instance.cartProductId,
      'suppliers': instance.suppliers,
      'productStock': instance.productStock,
      'productPrice': instance.productPrice,
      'sales': instance.sales,
      'totalQuantity': instance.totalQuantity,
      'totalAmount': instance.totalAmount,
      'note': instance.note,
      'lowStock': instance.lowStock,
    };

_$ProductDetailsImpl _$$ProductDetailsImplFromJson(Map<String, dynamic> json) =>
    _$ProductDetailsImpl(
      id: json['_id'] as String?,
      productName: json['productName'] as String?,
      mainImage: json['mainImage'] as String?,
      itemsWeight: (json['itemsWeight'] as num?)?.toDouble(),
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => Image.fromJson(e as Map<String, dynamic>))
          .toList(),
      scales: json['scales'] as String?,
      numberOfUnit: json['numberOfUnit'] as int?,
      isPesach: json['isPesach'] as bool?,
    );

Map<String, dynamic> _$$ProductDetailsImplToJson(
        _$ProductDetailsImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productName': instance.productName,
      'mainImage': instance.mainImage,
      'itemsWeight': instance.itemsWeight,
      'images': instance.images,
      'scales': instance.scales,
      'numberOfUnit': instance.numberOfUnit,
      'isPesach': instance.isPesach,
    };

_$ImageImpl _$$ImageImplFromJson(Map<String, dynamic> json) => _$ImageImpl(
      imageUrl: json['imageUrl'] as String?,
      order: json['order'] as int?,
    );

Map<String, dynamic> _$$ImageImplToJson(_$ImageImpl instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'order': instance.order,
    };

_$SaleImpl _$$SaleImplFromJson(Map<String, dynamic> json) => _$SaleImpl(
      id: json['_id'] as String?,
      status: json['status'] as String?,
      supplierDetails: json['supplierDetails'] as String?,
      salesName: json['salesName'] as String?,
      discountPercentage: (json['discountPercentage'] as num?)?.toDouble(),
      salesType: json['salesType'] as String?,
      salesDescription: json['salesDescription'] as String?,
      fromDate: json['fromDate'] as String?,
      endDate: json['endDate'] as String?,
      salesTerms: json['salesTerms'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$SaleImplToJson(_$SaleImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'status': instance.status,
      'supplierDetails': instance.supplierDetails,
      'salesName': instance.salesName,
      'discountPercentage': instance.discountPercentage,
      'salesType': instance.salesType,
      'salesDescription': instance.salesDescription,
      'fromDate': instance.fromDate,
      'endDate': instance.endDate,
      'salesTerms': instance.salesTerms,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'isDeleted': instance.isDeleted,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
    };

_$SupplierImpl _$$SupplierImplFromJson(Map<String, dynamic> json) =>
    _$SupplierImpl(
      id: json['_id'] as String?,
      contactName: json['contactName'] as String?,
    );

Map<String, dynamic> _$$SupplierImplToJson(_$SupplierImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'contactName': instance.contactName,
    };
