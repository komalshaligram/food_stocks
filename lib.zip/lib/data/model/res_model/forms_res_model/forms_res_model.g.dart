// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'forms_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$FormsResModelImpl _$$FormsResModelImplFromJson(Map<String, dynamic> json) =>
    _$FormsResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$FormsResModelImplToJson(_$FormsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      clientForms: (json['ClientForms'] as List<dynamic>?)
          ?.map((e) => ClientForm.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'ClientForms': instance.clientForms,
    };

_$ClientFormImpl _$$ClientFormImplFromJson(Map<String, dynamic> json) =>
    _$ClientFormImpl(
      id: json['_id'] as String?,
      formName: json['formName'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
      sample: json['sample'] as String?,
      isShownInMobile: json['isShownInMobile'] as bool?,
    );

Map<String, dynamic> _$$ClientFormImplToJson(_$ClientFormImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'formName': instance.formName,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
      'sample': instance.sample,
      'isShownInMobile': instance.isShownInMobile,
    };
