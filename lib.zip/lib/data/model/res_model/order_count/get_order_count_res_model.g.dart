// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_order_count_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetOrderCountResModelImpl _$$GetOrderCountResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetOrderCountResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
      data: json['data'] as int?,
    );

Map<String, dynamic> _$$GetOrderCountResModelImplToJson(
        _$GetOrderCountResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
    };
