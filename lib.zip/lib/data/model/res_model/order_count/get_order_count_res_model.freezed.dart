// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_order_count_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetOrderCountResModel _$GetOrderCountResModelFromJson(
    Map<String, dynamic> json) {
  return _GetOrderCountResModel.fromJson(json);
}

/// @nodoc
mixin _$GetOrderCountResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  int? get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetOrderCountResModelCopyWith<GetOrderCountResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetOrderCountResModelCopyWith<$Res> {
  factory $GetOrderCountResModelCopyWith(GetOrderCountResModel value,
          $Res Function(GetOrderCountResModel) then) =
      _$GetOrderCountResModelCopyWithImpl<$Res, GetOrderCountResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") int? data});
}

/// @nodoc
class _$GetOrderCountResModelCopyWithImpl<$Res,
        $Val extends GetOrderCountResModel>
    implements $GetOrderCountResModelCopyWith<$Res> {
  _$GetOrderCountResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetOrderCountResModelImplCopyWith<$Res>
    implements $GetOrderCountResModelCopyWith<$Res> {
  factory _$$GetOrderCountResModelImplCopyWith(
          _$GetOrderCountResModelImpl value,
          $Res Function(_$GetOrderCountResModelImpl) then) =
      __$$GetOrderCountResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") int? data});
}

/// @nodoc
class __$$GetOrderCountResModelImplCopyWithImpl<$Res>
    extends _$GetOrderCountResModelCopyWithImpl<$Res,
        _$GetOrderCountResModelImpl>
    implements _$$GetOrderCountResModelImplCopyWith<$Res> {
  __$$GetOrderCountResModelImplCopyWithImpl(_$GetOrderCountResModelImpl _value,
      $Res Function(_$GetOrderCountResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_$GetOrderCountResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetOrderCountResModelImpl implements _GetOrderCountResModel {
  const _$GetOrderCountResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message,
      @JsonKey(name: "data") this.data});

  factory _$GetOrderCountResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetOrderCountResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;
  @override
  @JsonKey(name: "data")
  final int? data;

  @override
  String toString() {
    return 'GetOrderCountResModel(status: $status, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetOrderCountResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.data, data) || other.data == data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetOrderCountResModelImplCopyWith<_$GetOrderCountResModelImpl>
      get copyWith => __$$GetOrderCountResModelImplCopyWithImpl<
          _$GetOrderCountResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetOrderCountResModelImplToJson(
      this,
    );
  }
}

abstract class _GetOrderCountResModel implements GetOrderCountResModel {
  const factory _GetOrderCountResModel(
      {@JsonKey(name: "status") final int? status,
      @JsonKey(name: "message") final String? message,
      @JsonKey(name: "data") final int? data}) = _$GetOrderCountResModelImpl;

  factory _GetOrderCountResModel.fromJson(Map<String, dynamic> json) =
      _$GetOrderCountResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(name: "data")
  int? get data;
  @override
  @JsonKey(ignore: true)
  _$$GetOrderCountResModelImplCopyWith<_$GetOrderCountResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
