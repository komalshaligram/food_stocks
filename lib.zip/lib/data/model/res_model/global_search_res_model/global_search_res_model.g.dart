// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'global_search_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GlobalSearchResModelImpl _$$GlobalSearchResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GlobalSearchResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$GlobalSearchResModelImplToJson(
        _$GlobalSearchResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      categoryData: (json['categoryData'] as List<dynamic>?)
          ?.map((e) => CategoryDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
      subCategoryData: (json['subCategoryData'] as List<dynamic>?)
          ?.map((e) => SubCategoryDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
      companyData: (json['companyData'] as List<dynamic>?)
          ?.map((e) => CompanyDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
      saleData: (json['saleData'] as List<dynamic>?)
          ?.map((e) => SaleDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
      supplierProductData: (json['supplierProductData'] as List<dynamic>?)
          ?.map((e) => SupplierProductDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
      supplierData: (json['supplierData'] as List<dynamic>?)
          ?.map((e) => SupplierDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'categoryData': instance.categoryData,
      'subCategoryData': instance.subCategoryData,
      'companyData': instance.companyData,
      'saleData': instance.saleData,
      'supplierProductData': instance.supplierProductData,
      'supplierData': instance.supplierData,
    };

_$CategoryDatumImpl _$$CategoryDatumImplFromJson(Map<String, dynamic> json) =>
    _$CategoryDatumImpl(
      id: json['_id'] as String?,
      categoryName: json['categoryName'] as String?,
      categoryImage: json['categoryImage'] as String?,
      isHomePreference: json['isHomePreference'] as bool?,
      isDeleted: json['isDeleted'] as bool?,
      isPesach: json['isPesach'] as bool?,
    );

Map<String, dynamic> _$$CategoryDatumImplToJson(_$CategoryDatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'categoryName': instance.categoryName,
      'categoryImage': instance.categoryImage,
      'isHomePreference': instance.isHomePreference,
      'isDeleted': instance.isDeleted,
      'isPesach': instance.isPesach,
    };

_$SubCategoryDatumImpl _$$SubCategoryDatumImplFromJson(
        Map<String, dynamic> json) =>
    _$SubCategoryDatumImpl(
      id: json['_id'] as String?,
      subCategoryName: json['subCategoryName'] as String?,
      parentCategoryId: json['parentCategoryId'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
      isDeleted: json['isDeleted'] as bool?,
      subCategoryNumber: json['subCategoryNumber'] as int?,
      parentCategoryName: json['parentCategoryName'] as String?,
      isPesach: json['isPesach'] as bool?,
    );

Map<String, dynamic> _$$SubCategoryDatumImplToJson(
        _$SubCategoryDatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'subCategoryName': instance.subCategoryName,
      'parentCategoryId': instance.parentCategoryId,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
      'isDeleted': instance.isDeleted,
      'subCategoryNumber': instance.subCategoryNumber,
      'parentCategoryName': instance.parentCategoryName,
      'isPesach': instance.isPesach,
    };

_$CompanyDatumImpl _$$CompanyDatumImplFromJson(Map<String, dynamic> json) =>
    _$CompanyDatumImpl(
      id: json['_id'] as String?,
      brandName: json['brandName'] as String?,
      brandLogo: json['brandLogo'] as String?,
      isHomePreference: json['isHomePreference'] as bool?,
    );

Map<String, dynamic> _$$CompanyDatumImplToJson(_$CompanyDatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'brandName': instance.brandName,
      'brandLogo': instance.brandLogo,
      'isHomePreference': instance.isHomePreference,
    };

_$SaleDatumImpl _$$SaleDatumImplFromJson(Map<String, dynamic> json) =>
    _$SaleDatumImpl(
      id: json['_id'] as String?,
      brandName: json['brandName'] as String?,
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => Image.fromJson(e as Map<String, dynamic>))
          .toList(),
      mainImage: json['mainImage'] as String?,
      numberOfUnit: json['numberOfUnit'] as String?,
      itemsWeight: json['itemsWeight'] as String?,
      totalWeight: json['totalWeight'] as String?,
      productName: json['productName'] as String?,
      salesName: json['salesName'] as String?,
      discountPercentage: json['discountPercentage'] as String?,
      salesDescription: json['salesDescription'] as String?,
      isPesach: json['isPesach'] as bool?,
    );

Map<String, dynamic> _$$SaleDatumImplToJson(_$SaleDatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'brandName': instance.brandName,
      'images': instance.images,
      'mainImage': instance.mainImage,
      'numberOfUnit': instance.numberOfUnit,
      'itemsWeight': instance.itemsWeight,
      'totalWeight': instance.totalWeight,
      'productName': instance.productName,
      'salesName': instance.salesName,
      'discountPercentage': instance.discountPercentage,
      'salesDescription': instance.salesDescription,
      'isPesach': instance.isPesach,
    };

_$ImageImpl _$$ImageImplFromJson(Map<String, dynamic> json) => _$ImageImpl(
      imageUrl: json['imageUrl'] as String?,
      order: json['order'] as int?,
    );

Map<String, dynamic> _$$ImageImplToJson(_$ImageImpl instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'order': instance.order,
    };

_$SupplierDatumImpl _$$SupplierDatumImplFromJson(Map<String, dynamic> json) =>
    _$SupplierDatumImpl(
      id: json['_id'] as String?,
      contactName: json['contactName'] as String?,
      qrcode: json['qrcode'] as String?,
      logo: json['logo'] as String?,
      supplierDetail: json['supplierDetail'] == null
          ? null
          : SupplierDetail.fromJson(
              json['supplierDetail'] as Map<String, dynamic>),
      isDeleted: json['isDeleted'] as bool?,
      idSearch: json['_idSearch'] as String?,
      isPesach: json['isPesach'] as bool?,
    );

Map<String, dynamic> _$$SupplierDatumImplToJson(_$SupplierDatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'contactName': instance.contactName,
      'qrcode': instance.qrcode,
      'logo': instance.logo,
      'supplierDetail': instance.supplierDetail,
      'isDeleted': instance.isDeleted,
      '_idSearch': instance.idSearch,
      'isPesach': instance.isPesach,
    };

_$StatusImpl _$$StatusImplFromJson(Map<String, dynamic> json) => _$StatusImpl(
      id: json['_id'] as String?,
      statusName: json['statusName'] as String?,
      isDeleted: json['isDeleted'] as bool?,
    );

Map<String, dynamic> _$$StatusImplToJson(_$StatusImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'statusName': instance.statusName,
      'isDeleted': instance.isDeleted,
    };

_$SupplierDetailImpl _$$SupplierDetailImplFromJson(Map<String, dynamic> json) =>
    _$SupplierDetailImpl(
      companyIdNumber: json['companyIdNumber'] as int?,
      companyName: json['companyName'] as String?,
      suppliersTypeId: json['suppliersTypeId'] as String?,
      isHomePreference: json['isHomePreference'] as bool?,
      id: json['_id'] as String?,
      isPesach: json['isPesach'] as bool?,
    );

Map<String, dynamic> _$$SupplierDetailImplToJson(
        _$SupplierDetailImpl instance) =>
    <String, dynamic>{
      'companyIdNumber': instance.companyIdNumber,
      'companyName': instance.companyName,
      'suppliersTypeId': instance.suppliersTypeId,
      'isHomePreference': instance.isHomePreference,
      '_id': instance.id,
      'isPesach': instance.isPesach,
    };

_$DistributionDetailsImpl _$$DistributionDetailsImplFromJson(
        Map<String, dynamic> json) =>
    _$DistributionDetailsImpl(
      a1: json['A1'] == null
          ? null
          : A1.fromJson(json['A1'] as Map<String, dynamic>),
      center: json['center'] == null
          ? null
          : A1.fromJson(json['center'] as Map<String, dynamic>),
      east: json['east'] == null
          ? null
          : A1.fromJson(json['east'] as Map<String, dynamic>),
      judea: json['judea'] == null
          ? null
          : A1.fromJson(json['judea'] as Map<String, dynamic>),
      north: json['north'] == null
          ? null
          : A1.fromJson(json['north'] as Map<String, dynamic>),
      south: json['south'] == null
          ? null
          : A1.fromJson(json['south'] as Map<String, dynamic>),
      west: json['west'] == null
          ? null
          : A1.fromJson(json['west'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$DistributionDetailsImplToJson(
        _$DistributionDetailsImpl instance) =>
    <String, dynamic>{
      'A1': instance.a1,
      'center': instance.center,
      'east': instance.east,
      'judea': instance.judea,
      'north': instance.north,
      'south': instance.south,
      'west': instance.west,
    };

_$A1Impl _$$A1ImplFromJson(Map<String, dynamic> json) => _$A1Impl(
      sunday: json['Sunday'] == null
          ? null
          : Day.fromJson(json['Sunday'] as Map<String, dynamic>),
      monday: json['Monday'] == null
          ? null
          : Day.fromJson(json['Monday'] as Map<String, dynamic>),
      tuesday: json['Tuesday'] == null
          ? null
          : Day.fromJson(json['Tuesday'] as Map<String, dynamic>),
      wednesday: json['Wednesday'] == null
          ? null
          : Day.fromJson(json['Wednesday'] as Map<String, dynamic>),
      thursday: json['Thursday'] == null
          ? null
          : Day.fromJson(json['Thursday'] as Map<String, dynamic>),
      friday: json['Friday'] == null
          ? null
          : Day.fromJson(json['Friday'] as Map<String, dynamic>),
      saturday: json['Saturday'] == null
          ? null
          : Day.fromJson(json['Saturday'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$A1ImplToJson(_$A1Impl instance) => <String, dynamic>{
      'Sunday': instance.sunday,
      'Monday': instance.monday,
      'Tuesday': instance.tuesday,
      'Wednesday': instance.wednesday,
      'Thursday': instance.thursday,
      'Friday': instance.friday,
      'Saturday': instance.saturday,
    };

_$DayImpl _$$DayImplFromJson(Map<String, dynamic> json) => _$DayImpl(
      startTime: json['startTime'] as String?,
      endTime: json['endTime'] as String?,
    );

Map<String, dynamic> _$$DayImplToJson(_$DayImpl instance) => <String, dynamic>{
      'startTime': instance.startTime,
      'endTime': instance.endTime,
    };

_$SuplierPolicyImpl _$$SuplierPolicyImplFromJson(Map<String, dynamic> json) =>
    _$SuplierPolicyImpl(
      id: json['_id'] as String?,
      policyHeading: json['policyHeading'] as String?,
      toggleSwitchKey: json['toggleSwitchKey'] as String?,
      fields: (json['fields'] as List<dynamic>?)
          ?.map((e) => Field.fromJson(e as Map<String, dynamic>))
          .toList(),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      toggleSwitchValue: json['toggleSwitchValue'] as bool?,
    );

Map<String, dynamic> _$$SuplierPolicyImplToJson(_$SuplierPolicyImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'policyHeading': instance.policyHeading,
      'toggleSwitchKey': instance.toggleSwitchKey,
      'fields': instance.fields,
      'updatedAt': instance.updatedAt?.toIso8601String(),
      'createdAt': instance.createdAt?.toIso8601String(),
      'toggleSwitchValue': instance.toggleSwitchValue,
    };

_$FieldImpl _$$FieldImplFromJson(Map<String, dynamic> json) => _$FieldImpl(
      fieldKey: json['fieldKey'] as String?,
      fieldType: json['fieldType'] as String?,
      id: json['_id'] as String?,
    );

Map<String, dynamic> _$$FieldImplToJson(_$FieldImpl instance) =>
    <String, dynamic>{
      'fieldKey': instance.fieldKey,
      'fieldType': instance.fieldType,
      '_id': instance.id,
    };

_$SupplierProductDatumImpl _$$SupplierProductDatumImplFromJson(
        Map<String, dynamic> json) =>
    _$SupplierProductDatumImpl(
      id: json['_id'] as String?,
      brandName: json['brandName'] as String?,
      numberOfUnit: json['numberOfUnit'] as String?,
      productName: json['productName'] as String?,
      mainImage: json['mainImage'] as String?,
      itemsWeight: json['itemsWeight'] as String?,
      totalWeight: json['totalWeight'] as String?,
      productId: json['productId'] as String?,
      supplierId: json['supplierId'] as String?,
      productPrice: json['productPrice'] as String?,
      productStock: json['productStock'] as String?,
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
      lowStock: json['lowStock'] as String?,
    );

Map<String, dynamic> _$$SupplierProductDatumImplToJson(
        _$SupplierProductDatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'brandName': instance.brandName,
      'numberOfUnit': instance.numberOfUnit,
      'productName': instance.productName,
      'mainImage': instance.mainImage,
      'itemsWeight': instance.itemsWeight,
      'totalWeight': instance.totalWeight,
      'productId': instance.productId,
      'supplierId': instance.supplierId,
      'productPrice': instance.productPrice,
      'productStock': instance.productStock,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
      'lowStock': instance.lowStock,
    };
