// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'global_search_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GlobalSearchResModel _$GlobalSearchResModelFromJson(Map<String, dynamic> json) {
  return _GlobalSearchResModel.fromJson(json);
}

/// @nodoc
mixin _$GlobalSearchResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GlobalSearchResModelCopyWith<GlobalSearchResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GlobalSearchResModelCopyWith<$Res> {
  factory $GlobalSearchResModelCopyWith(GlobalSearchResModel value,
          $Res Function(GlobalSearchResModel) then) =
      _$GlobalSearchResModelCopyWithImpl<$Res, GlobalSearchResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$GlobalSearchResModelCopyWithImpl<$Res,
        $Val extends GlobalSearchResModel>
    implements $GlobalSearchResModelCopyWith<$Res> {
  _$GlobalSearchResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GlobalSearchResModelImplCopyWith<$Res>
    implements $GlobalSearchResModelCopyWith<$Res> {
  factory _$$GlobalSearchResModelImplCopyWith(_$GlobalSearchResModelImpl value,
          $Res Function(_$GlobalSearchResModelImpl) then) =
      __$$GlobalSearchResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$GlobalSearchResModelImplCopyWithImpl<$Res>
    extends _$GlobalSearchResModelCopyWithImpl<$Res, _$GlobalSearchResModelImpl>
    implements _$$GlobalSearchResModelImplCopyWith<$Res> {
  __$$GlobalSearchResModelImplCopyWithImpl(_$GlobalSearchResModelImpl _value,
      $Res Function(_$GlobalSearchResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$GlobalSearchResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GlobalSearchResModelImpl implements _GlobalSearchResModel {
  const _$GlobalSearchResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$GlobalSearchResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GlobalSearchResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'GlobalSearchResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalSearchResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalSearchResModelImplCopyWith<_$GlobalSearchResModelImpl>
      get copyWith =>
          __$$GlobalSearchResModelImplCopyWithImpl<_$GlobalSearchResModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GlobalSearchResModelImplToJson(
      this,
    );
  }
}

abstract class _GlobalSearchResModel implements GlobalSearchResModel {
  const factory _GlobalSearchResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final Data? data,
          @JsonKey(name: "message") final String? message}) =
      _$GlobalSearchResModelImpl;

  factory _GlobalSearchResModel.fromJson(Map<String, dynamic> json) =
      _$GlobalSearchResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$GlobalSearchResModelImplCopyWith<_$GlobalSearchResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "categoryData")
  List<CategoryDatum>? get categoryData => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryData")
  List<SubCategoryDatum>? get subCategoryData =>
      throw _privateConstructorUsedError;
  @JsonKey(name: "companyData")
  List<CompanyDatum>? get companyData => throw _privateConstructorUsedError;
  @JsonKey(name: "saleData")
  List<SaleDatum>? get saleData => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierProductData")
  List<SupplierProductDatum>? get supplierProductData =>
      throw _privateConstructorUsedError;
  @JsonKey(name: "supplierData")
  List<SupplierDatum>? get supplierData => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "categoryData") List<CategoryDatum>? categoryData,
      @JsonKey(name: "subCategoryData") List<SubCategoryDatum>? subCategoryData,
      @JsonKey(name: "companyData") List<CompanyDatum>? companyData,
      @JsonKey(name: "saleData") List<SaleDatum>? saleData,
      @JsonKey(name: "supplierProductData")
      List<SupplierProductDatum>? supplierProductData,
      @JsonKey(name: "supplierData") List<SupplierDatum>? supplierData});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? categoryData = freezed,
    Object? subCategoryData = freezed,
    Object? companyData = freezed,
    Object? saleData = freezed,
    Object? supplierProductData = freezed,
    Object? supplierData = freezed,
  }) {
    return _then(_value.copyWith(
      categoryData: freezed == categoryData
          ? _value.categoryData
          : categoryData // ignore: cast_nullable_to_non_nullable
              as List<CategoryDatum>?,
      subCategoryData: freezed == subCategoryData
          ? _value.subCategoryData
          : subCategoryData // ignore: cast_nullable_to_non_nullable
              as List<SubCategoryDatum>?,
      companyData: freezed == companyData
          ? _value.companyData
          : companyData // ignore: cast_nullable_to_non_nullable
              as List<CompanyDatum>?,
      saleData: freezed == saleData
          ? _value.saleData
          : saleData // ignore: cast_nullable_to_non_nullable
              as List<SaleDatum>?,
      supplierProductData: freezed == supplierProductData
          ? _value.supplierProductData
          : supplierProductData // ignore: cast_nullable_to_non_nullable
              as List<SupplierProductDatum>?,
      supplierData: freezed == supplierData
          ? _value.supplierData
          : supplierData // ignore: cast_nullable_to_non_nullable
              as List<SupplierDatum>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "categoryData") List<CategoryDatum>? categoryData,
      @JsonKey(name: "subCategoryData") List<SubCategoryDatum>? subCategoryData,
      @JsonKey(name: "companyData") List<CompanyDatum>? companyData,
      @JsonKey(name: "saleData") List<SaleDatum>? saleData,
      @JsonKey(name: "supplierProductData")
      List<SupplierProductDatum>? supplierProductData,
      @JsonKey(name: "supplierData") List<SupplierDatum>? supplierData});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? categoryData = freezed,
    Object? subCategoryData = freezed,
    Object? companyData = freezed,
    Object? saleData = freezed,
    Object? supplierProductData = freezed,
    Object? supplierData = freezed,
  }) {
    return _then(_$DataImpl(
      categoryData: freezed == categoryData
          ? _value._categoryData
          : categoryData // ignore: cast_nullable_to_non_nullable
              as List<CategoryDatum>?,
      subCategoryData: freezed == subCategoryData
          ? _value._subCategoryData
          : subCategoryData // ignore: cast_nullable_to_non_nullable
              as List<SubCategoryDatum>?,
      companyData: freezed == companyData
          ? _value._companyData
          : companyData // ignore: cast_nullable_to_non_nullable
              as List<CompanyDatum>?,
      saleData: freezed == saleData
          ? _value._saleData
          : saleData // ignore: cast_nullable_to_non_nullable
              as List<SaleDatum>?,
      supplierProductData: freezed == supplierProductData
          ? _value._supplierProductData
          : supplierProductData // ignore: cast_nullable_to_non_nullable
              as List<SupplierProductDatum>?,
      supplierData: freezed == supplierData
          ? _value._supplierData
          : supplierData // ignore: cast_nullable_to_non_nullable
              as List<SupplierDatum>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "categoryData") final List<CategoryDatum>? categoryData,
      @JsonKey(name: "subCategoryData")
      final List<SubCategoryDatum>? subCategoryData,
      @JsonKey(name: "companyData") final List<CompanyDatum>? companyData,
      @JsonKey(name: "saleData") final List<SaleDatum>? saleData,
      @JsonKey(name: "supplierProductData")
      final List<SupplierProductDatum>? supplierProductData,
      @JsonKey(name: "supplierData") final List<SupplierDatum>? supplierData})
      : _categoryData = categoryData,
        _subCategoryData = subCategoryData,
        _companyData = companyData,
        _saleData = saleData,
        _supplierProductData = supplierProductData,
        _supplierData = supplierData;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  final List<CategoryDatum>? _categoryData;
  @override
  @JsonKey(name: "categoryData")
  List<CategoryDatum>? get categoryData {
    final value = _categoryData;
    if (value == null) return null;
    if (_categoryData is EqualUnmodifiableListView) return _categoryData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<SubCategoryDatum>? _subCategoryData;
  @override
  @JsonKey(name: "subCategoryData")
  List<SubCategoryDatum>? get subCategoryData {
    final value = _subCategoryData;
    if (value == null) return null;
    if (_subCategoryData is EqualUnmodifiableListView) return _subCategoryData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<CompanyDatum>? _companyData;
  @override
  @JsonKey(name: "companyData")
  List<CompanyDatum>? get companyData {
    final value = _companyData;
    if (value == null) return null;
    if (_companyData is EqualUnmodifiableListView) return _companyData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<SaleDatum>? _saleData;
  @override
  @JsonKey(name: "saleData")
  List<SaleDatum>? get saleData {
    final value = _saleData;
    if (value == null) return null;
    if (_saleData is EqualUnmodifiableListView) return _saleData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<SupplierProductDatum>? _supplierProductData;
  @override
  @JsonKey(name: "supplierProductData")
  List<SupplierProductDatum>? get supplierProductData {
    final value = _supplierProductData;
    if (value == null) return null;
    if (_supplierProductData is EqualUnmodifiableListView)
      return _supplierProductData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<SupplierDatum>? _supplierData;
  @override
  @JsonKey(name: "supplierData")
  List<SupplierDatum>? get supplierData {
    final value = _supplierData;
    if (value == null) return null;
    if (_supplierData is EqualUnmodifiableListView) return _supplierData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'Data(categoryData: $categoryData, subCategoryData: $subCategoryData, companyData: $companyData, saleData: $saleData, supplierProductData: $supplierProductData, supplierData: $supplierData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            const DeepCollectionEquality()
                .equals(other._categoryData, _categoryData) &&
            const DeepCollectionEquality()
                .equals(other._subCategoryData, _subCategoryData) &&
            const DeepCollectionEquality()
                .equals(other._companyData, _companyData) &&
            const DeepCollectionEquality().equals(other._saleData, _saleData) &&
            const DeepCollectionEquality()
                .equals(other._supplierProductData, _supplierProductData) &&
            const DeepCollectionEquality()
                .equals(other._supplierData, _supplierData));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_categoryData),
      const DeepCollectionEquality().hash(_subCategoryData),
      const DeepCollectionEquality().hash(_companyData),
      const DeepCollectionEquality().hash(_saleData),
      const DeepCollectionEquality().hash(_supplierProductData),
      const DeepCollectionEquality().hash(_supplierData));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "categoryData") final List<CategoryDatum>? categoryData,
      @JsonKey(name: "subCategoryData")
      final List<SubCategoryDatum>? subCategoryData,
      @JsonKey(name: "companyData") final List<CompanyDatum>? companyData,
      @JsonKey(name: "saleData") final List<SaleDatum>? saleData,
      @JsonKey(name: "supplierProductData")
      final List<SupplierProductDatum>? supplierProductData,
      @JsonKey(name: "supplierData")
      final List<SupplierDatum>? supplierData}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "categoryData")
  List<CategoryDatum>? get categoryData;
  @override
  @JsonKey(name: "subCategoryData")
  List<SubCategoryDatum>? get subCategoryData;
  @override
  @JsonKey(name: "companyData")
  List<CompanyDatum>? get companyData;
  @override
  @JsonKey(name: "saleData")
  List<SaleDatum>? get saleData;
  @override
  @JsonKey(name: "supplierProductData")
  List<SupplierProductDatum>? get supplierProductData;
  @override
  @JsonKey(name: "supplierData")
  List<SupplierDatum>? get supplierData;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

CategoryDatum _$CategoryDatumFromJson(Map<String, dynamic> json) {
  return _CategoryDatum.fromJson(json);
}

/// @nodoc
mixin _$CategoryDatum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryName")
  String? get categoryName =>
      throw _privateConstructorUsedError; // @JsonKey(name: "createdAt") DateTime? createdAt,
// @JsonKey(name: "updatedAt") DateTime? updatedAt,
// @JsonKey(name: "__v") int? v,
  @JsonKey(name: "categoryImage")
  String? get categoryImage => throw _privateConstructorUsedError;
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference =>
      throw _privateConstructorUsedError; // @JsonKey(name: "order") int? order,
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CategoryDatumCopyWith<CategoryDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CategoryDatumCopyWith<$Res> {
  factory $CategoryDatumCopyWith(
          CategoryDatum value, $Res Function(CategoryDatum) then) =
      _$CategoryDatumCopyWithImpl<$Res, CategoryDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryName") String? categoryName,
      @JsonKey(name: "categoryImage") String? categoryImage,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class _$CategoryDatumCopyWithImpl<$Res, $Val extends CategoryDatum>
    implements $CategoryDatumCopyWith<$Res> {
  _$CategoryDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryName = freezed,
    Object? categoryImage = freezed,
    Object? isHomePreference = freezed,
    Object? isDeleted = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryImage: freezed == categoryImage
          ? _value.categoryImage
          : categoryImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CategoryDatumImplCopyWith<$Res>
    implements $CategoryDatumCopyWith<$Res> {
  factory _$$CategoryDatumImplCopyWith(
          _$CategoryDatumImpl value, $Res Function(_$CategoryDatumImpl) then) =
      __$$CategoryDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryName") String? categoryName,
      @JsonKey(name: "categoryImage") String? categoryImage,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class __$$CategoryDatumImplCopyWithImpl<$Res>
    extends _$CategoryDatumCopyWithImpl<$Res, _$CategoryDatumImpl>
    implements _$$CategoryDatumImplCopyWith<$Res> {
  __$$CategoryDatumImplCopyWithImpl(
      _$CategoryDatumImpl _value, $Res Function(_$CategoryDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryName = freezed,
    Object? categoryImage = freezed,
    Object? isHomePreference = freezed,
    Object? isDeleted = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_$CategoryDatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryImage: freezed == categoryImage
          ? _value.categoryImage
          : categoryImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CategoryDatumImpl implements _CategoryDatum {
  const _$CategoryDatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "categoryName") this.categoryName,
      @JsonKey(name: "categoryImage") this.categoryImage,
      @JsonKey(name: "isHomePreference") this.isHomePreference,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "isPesach") this.isPesach});

  factory _$CategoryDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$CategoryDatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "categoryName")
  final String? categoryName;
// @JsonKey(name: "createdAt") DateTime? createdAt,
// @JsonKey(name: "updatedAt") DateTime? updatedAt,
// @JsonKey(name: "__v") int? v,
  @override
  @JsonKey(name: "categoryImage")
  final String? categoryImage;
  @override
  @JsonKey(name: "isHomePreference")
  final bool? isHomePreference;
// @JsonKey(name: "order") int? order,
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;

  @override
  String toString() {
    return 'CategoryDatum(id: $id, categoryName: $categoryName, categoryImage: $categoryImage, isHomePreference: $isHomePreference, isDeleted: $isDeleted, isPesach: $isPesach)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CategoryDatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.categoryName, categoryName) ||
                other.categoryName == categoryName) &&
            (identical(other.categoryImage, categoryImage) ||
                other.categoryImage == categoryImage) &&
            (identical(other.isHomePreference, isHomePreference) ||
                other.isHomePreference == isHomePreference) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, categoryName, categoryImage,
      isHomePreference, isDeleted, isPesach);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CategoryDatumImplCopyWith<_$CategoryDatumImpl> get copyWith =>
      __$$CategoryDatumImplCopyWithImpl<_$CategoryDatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CategoryDatumImplToJson(
      this,
    );
  }
}

abstract class _CategoryDatum implements CategoryDatum {
  const factory _CategoryDatum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "categoryName") final String? categoryName,
      @JsonKey(name: "categoryImage") final String? categoryImage,
      @JsonKey(name: "isHomePreference") final bool? isHomePreference,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "isPesach") final bool? isPesach}) = _$CategoryDatumImpl;

  factory _CategoryDatum.fromJson(Map<String, dynamic> json) =
      _$CategoryDatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "categoryName")
  String? get categoryName;
  @override // @JsonKey(name: "createdAt") DateTime? createdAt,
// @JsonKey(name: "updatedAt") DateTime? updatedAt,
// @JsonKey(name: "__v") int? v,
  @JsonKey(name: "categoryImage")
  String? get categoryImage;
  @override
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference;
  @override // @JsonKey(name: "order") int? order,
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(ignore: true)
  _$$CategoryDatumImplCopyWith<_$CategoryDatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SubCategoryDatum _$SubCategoryDatumFromJson(Map<String, dynamic> json) {
  return _SubCategoryDatum.fromJson(json);
}

/// @nodoc
mixin _$SubCategoryDatum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryName")
  String? get subCategoryName => throw _privateConstructorUsedError;
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryNumber")
  int? get subCategoryNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "parentCategoryName")
  String? get parentCategoryName => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SubCategoryDatumCopyWith<SubCategoryDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubCategoryDatumCopyWith<$Res> {
  factory $SubCategoryDatumCopyWith(
          SubCategoryDatum value, $Res Function(SubCategoryDatum) then) =
      _$SubCategoryDatumCopyWithImpl<$Res, SubCategoryDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryName") String? subCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "subCategoryNumber") int? subCategoryNumber,
      @JsonKey(name: "parentCategoryName") String? parentCategoryName,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class _$SubCategoryDatumCopyWithImpl<$Res, $Val extends SubCategoryDatum>
    implements $SubCategoryDatumCopyWith<$Res> {
  _$SubCategoryDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
    Object? subCategoryNumber = freezed,
    Object? parentCategoryName = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      subCategoryNumber: freezed == subCategoryNumber
          ? _value.subCategoryNumber
          : subCategoryNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      parentCategoryName: freezed == parentCategoryName
          ? _value.parentCategoryName
          : parentCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubCategoryDatumImplCopyWith<$Res>
    implements $SubCategoryDatumCopyWith<$Res> {
  factory _$$SubCategoryDatumImplCopyWith(_$SubCategoryDatumImpl value,
          $Res Function(_$SubCategoryDatumImpl) then) =
      __$$SubCategoryDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryName") String? subCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "subCategoryNumber") int? subCategoryNumber,
      @JsonKey(name: "parentCategoryName") String? parentCategoryName,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class __$$SubCategoryDatumImplCopyWithImpl<$Res>
    extends _$SubCategoryDatumCopyWithImpl<$Res, _$SubCategoryDatumImpl>
    implements _$$SubCategoryDatumImplCopyWith<$Res> {
  __$$SubCategoryDatumImplCopyWithImpl(_$SubCategoryDatumImpl _value,
      $Res Function(_$SubCategoryDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
    Object? subCategoryNumber = freezed,
    Object? parentCategoryName = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_$SubCategoryDatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      subCategoryNumber: freezed == subCategoryNumber
          ? _value.subCategoryNumber
          : subCategoryNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      parentCategoryName: freezed == parentCategoryName
          ? _value.parentCategoryName
          : parentCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SubCategoryDatumImpl implements _SubCategoryDatum {
  const _$SubCategoryDatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "subCategoryName") this.subCategoryName,
      @JsonKey(name: "parentCategoryId") this.parentCategoryId,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "subCategoryNumber") this.subCategoryNumber,
      @JsonKey(name: "parentCategoryName") this.parentCategoryName,
      @JsonKey(name: "isPesach") this.isPesach});

  factory _$SubCategoryDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$SubCategoryDatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "subCategoryName")
  final String? subCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  final String? parentCategoryId;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "subCategoryNumber")
  final int? subCategoryNumber;
  @override
  @JsonKey(name: "parentCategoryName")
  final String? parentCategoryName;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;

  @override
  String toString() {
    return 'SubCategoryDatum(id: $id, subCategoryName: $subCategoryName, parentCategoryId: $parentCategoryId, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, isDeleted: $isDeleted, subCategoryNumber: $subCategoryNumber, parentCategoryName: $parentCategoryName, isPesach: $isPesach)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubCategoryDatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.subCategoryName, subCategoryName) ||
                other.subCategoryName == subCategoryName) &&
            (identical(other.parentCategoryId, parentCategoryId) ||
                other.parentCategoryId == parentCategoryId) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.subCategoryNumber, subCategoryNumber) ||
                other.subCategoryNumber == subCategoryNumber) &&
            (identical(other.parentCategoryName, parentCategoryName) ||
                other.parentCategoryName == parentCategoryName) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      subCategoryName,
      parentCategoryId,
      createdAt,
      updatedAt,
      v,
      isDeleted,
      subCategoryNumber,
      parentCategoryName,
      isPesach);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubCategoryDatumImplCopyWith<_$SubCategoryDatumImpl> get copyWith =>
      __$$SubCategoryDatumImplCopyWithImpl<_$SubCategoryDatumImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SubCategoryDatumImplToJson(
      this,
    );
  }
}

abstract class _SubCategoryDatum implements SubCategoryDatum {
  const factory _SubCategoryDatum(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "subCategoryName") final String? subCategoryName,
          @JsonKey(name: "parentCategoryId") final String? parentCategoryId,
          @JsonKey(name: "createdAt") final DateTime? createdAt,
          @JsonKey(name: "updatedAt") final DateTime? updatedAt,
          @JsonKey(name: "__v") final int? v,
          @JsonKey(name: "isDeleted") final bool? isDeleted,
          @JsonKey(name: "subCategoryNumber") final int? subCategoryNumber,
          @JsonKey(name: "parentCategoryName") final String? parentCategoryName,
          @JsonKey(name: "isPesach") final bool? isPesach}) =
      _$SubCategoryDatumImpl;

  factory _SubCategoryDatum.fromJson(Map<String, dynamic> json) =
      _$SubCategoryDatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "subCategoryName")
  String? get subCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "subCategoryNumber")
  int? get subCategoryNumber;
  @override
  @JsonKey(name: "parentCategoryName")
  String? get parentCategoryName;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(ignore: true)
  _$$SubCategoryDatumImplCopyWith<_$SubCategoryDatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

CompanyDatum _$CompanyDatumFromJson(Map<String, dynamic> json) {
  return _CompanyDatum.fromJson(json);
}

/// @nodoc
mixin _$CompanyDatum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "brandName")
  String? get brandName => throw _privateConstructorUsedError;
  @JsonKey(name: "brandLogo")
  String? get brandLogo => throw _privateConstructorUsedError;
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompanyDatumCopyWith<CompanyDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompanyDatumCopyWith<$Res> {
  factory $CompanyDatumCopyWith(
          CompanyDatum value, $Res Function(CompanyDatum) then) =
      _$CompanyDatumCopyWithImpl<$Res, CompanyDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "brandLogo") String? brandLogo,
      @JsonKey(name: "isHomePreference") bool? isHomePreference});
}

/// @nodoc
class _$CompanyDatumCopyWithImpl<$Res, $Val extends CompanyDatum>
    implements $CompanyDatumCopyWith<$Res> {
  _$CompanyDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? brandName = freezed,
    Object? brandLogo = freezed,
    Object? isHomePreference = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandLogo: freezed == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CompanyDatumImplCopyWith<$Res>
    implements $CompanyDatumCopyWith<$Res> {
  factory _$$CompanyDatumImplCopyWith(
          _$CompanyDatumImpl value, $Res Function(_$CompanyDatumImpl) then) =
      __$$CompanyDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "brandLogo") String? brandLogo,
      @JsonKey(name: "isHomePreference") bool? isHomePreference});
}

/// @nodoc
class __$$CompanyDatumImplCopyWithImpl<$Res>
    extends _$CompanyDatumCopyWithImpl<$Res, _$CompanyDatumImpl>
    implements _$$CompanyDatumImplCopyWith<$Res> {
  __$$CompanyDatumImplCopyWithImpl(
      _$CompanyDatumImpl _value, $Res Function(_$CompanyDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? brandName = freezed,
    Object? brandLogo = freezed,
    Object? isHomePreference = freezed,
  }) {
    return _then(_$CompanyDatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandLogo: freezed == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CompanyDatumImpl implements _CompanyDatum {
  const _$CompanyDatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "brandName") this.brandName,
      @JsonKey(name: "brandLogo") this.brandLogo,
      @JsonKey(name: "isHomePreference") this.isHomePreference});

  factory _$CompanyDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$CompanyDatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "brandName")
  final String? brandName;
  @override
  @JsonKey(name: "brandLogo")
  final String? brandLogo;
  @override
  @JsonKey(name: "isHomePreference")
  final bool? isHomePreference;

  @override
  String toString() {
    return 'CompanyDatum(id: $id, brandName: $brandName, brandLogo: $brandLogo, isHomePreference: $isHomePreference)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CompanyDatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.brandName, brandName) ||
                other.brandName == brandName) &&
            (identical(other.brandLogo, brandLogo) ||
                other.brandLogo == brandLogo) &&
            (identical(other.isHomePreference, isHomePreference) ||
                other.isHomePreference == isHomePreference));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, brandName, brandLogo, isHomePreference);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CompanyDatumImplCopyWith<_$CompanyDatumImpl> get copyWith =>
      __$$CompanyDatumImplCopyWithImpl<_$CompanyDatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CompanyDatumImplToJson(
      this,
    );
  }
}

abstract class _CompanyDatum implements CompanyDatum {
  const factory _CompanyDatum(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "brandName") final String? brandName,
          @JsonKey(name: "brandLogo") final String? brandLogo,
          @JsonKey(name: "isHomePreference") final bool? isHomePreference}) =
      _$CompanyDatumImpl;

  factory _CompanyDatum.fromJson(Map<String, dynamic> json) =
      _$CompanyDatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "brandName")
  String? get brandName;
  @override
  @JsonKey(name: "brandLogo")
  String? get brandLogo;
  @override
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference;
  @override
  @JsonKey(ignore: true)
  _$$CompanyDatumImplCopyWith<_$CompanyDatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SaleDatum _$SaleDatumFromJson(Map<String, dynamic> json) {
  return _SaleDatum.fromJson(json);
}

/// @nodoc
mixin _$SaleDatum {
  @JsonKey(name: "_id")
  String? get id =>
      throw _privateConstructorUsedError; // @JsonKey(name: "category") String? category,
// @JsonKey(name: "subcategories") String? subcategories,
// @JsonKey(name: "subsubcategories") String? subsubcategories,
// @JsonKey(name: "casetypes") String? casetypes,
// @JsonKey(name: "status") String? status,
// @JsonKey(name: "sku") String? sku,
  @JsonKey(name: "brandName")
  String? get brandName => throw _privateConstructorUsedError;
  @JsonKey(name: "images")
  List<Image>? get images => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  String? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName =>
      throw _privateConstructorUsedError; // @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
// @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
  @JsonKey(name: "salesName")
  String? get salesName => throw _privateConstructorUsedError;
  @JsonKey(name: "discountPercentage")
  String? get discountPercentage => throw _privateConstructorUsedError;
  @JsonKey(name: "salesDescription")
  String? get salesDescription => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SaleDatumCopyWith<SaleDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SaleDatumCopyWith<$Res> {
  factory $SaleDatumCopyWith(SaleDatum value, $Res Function(SaleDatum) then) =
      _$SaleDatumCopyWithImpl<$Res, SaleDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "salesName") String? salesName,
      @JsonKey(name: "discountPercentage") String? discountPercentage,
      @JsonKey(name: "salesDescription") String? salesDescription,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class _$SaleDatumCopyWithImpl<$Res, $Val extends SaleDatum>
    implements $SaleDatumCopyWith<$Res> {
  _$SaleDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? brandName = freezed,
    Object? images = freezed,
    Object? mainImage = freezed,
    Object? numberOfUnit = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? productName = freezed,
    Object? salesName = freezed,
    Object? discountPercentage = freezed,
    Object? salesDescription = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value.images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      salesName: freezed == salesName
          ? _value.salesName
          : salesName // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SaleDatumImplCopyWith<$Res>
    implements $SaleDatumCopyWith<$Res> {
  factory _$$SaleDatumImplCopyWith(
          _$SaleDatumImpl value, $Res Function(_$SaleDatumImpl) then) =
      __$$SaleDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "salesName") String? salesName,
      @JsonKey(name: "discountPercentage") String? discountPercentage,
      @JsonKey(name: "salesDescription") String? salesDescription,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class __$$SaleDatumImplCopyWithImpl<$Res>
    extends _$SaleDatumCopyWithImpl<$Res, _$SaleDatumImpl>
    implements _$$SaleDatumImplCopyWith<$Res> {
  __$$SaleDatumImplCopyWithImpl(
      _$SaleDatumImpl _value, $Res Function(_$SaleDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? brandName = freezed,
    Object? images = freezed,
    Object? mainImage = freezed,
    Object? numberOfUnit = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? productName = freezed,
    Object? salesName = freezed,
    Object? discountPercentage = freezed,
    Object? salesDescription = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_$SaleDatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value._images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      salesName: freezed == salesName
          ? _value.salesName
          : salesName // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SaleDatumImpl implements _SaleDatum {
  const _$SaleDatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "brandName") this.brandName,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "numberOfUnit") this.numberOfUnit,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "salesName") this.salesName,
      @JsonKey(name: "discountPercentage") this.discountPercentage,
      @JsonKey(name: "salesDescription") this.salesDescription,
      @JsonKey(name: "isPesach") this.isPesach})
      : _images = images;

  factory _$SaleDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$SaleDatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
// @JsonKey(name: "category") String? category,
// @JsonKey(name: "subcategories") String? subcategories,
// @JsonKey(name: "subsubcategories") String? subsubcategories,
// @JsonKey(name: "casetypes") String? casetypes,
// @JsonKey(name: "status") String? status,
// @JsonKey(name: "sku") String? sku,
  @override
  @JsonKey(name: "brandName")
  final String? brandName;
  final List<Image>? _images;
  @override
  @JsonKey(name: "images")
  List<Image>? get images {
    final value = _images;
    if (value == null) return null;
    if (_images is EqualUnmodifiableListView) return _images;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "numberOfUnit")
  final String? numberOfUnit;
  @override
  @JsonKey(name: "itemsWeight")
  final String? itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  final String? totalWeight;
  @override
  @JsonKey(name: "productName")
  final String? productName;
// @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
// @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
  @override
  @JsonKey(name: "salesName")
  final String? salesName;
  @override
  @JsonKey(name: "discountPercentage")
  final String? discountPercentage;
  @override
  @JsonKey(name: "salesDescription")
  final String? salesDescription;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;

  @override
  String toString() {
    return 'SaleDatum(id: $id, brandName: $brandName, images: $images, mainImage: $mainImage, numberOfUnit: $numberOfUnit, itemsWeight: $itemsWeight, totalWeight: $totalWeight, productName: $productName, salesName: $salesName, discountPercentage: $discountPercentage, salesDescription: $salesDescription, isPesach: $isPesach)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SaleDatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.brandName, brandName) ||
                other.brandName == brandName) &&
            const DeepCollectionEquality().equals(other._images, _images) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.salesName, salesName) ||
                other.salesName == salesName) &&
            (identical(other.discountPercentage, discountPercentage) ||
                other.discountPercentage == discountPercentage) &&
            (identical(other.salesDescription, salesDescription) ||
                other.salesDescription == salesDescription) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      brandName,
      const DeepCollectionEquality().hash(_images),
      mainImage,
      numberOfUnit,
      itemsWeight,
      totalWeight,
      productName,
      salesName,
      discountPercentage,
      salesDescription,
      isPesach);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SaleDatumImplCopyWith<_$SaleDatumImpl> get copyWith =>
      __$$SaleDatumImplCopyWithImpl<_$SaleDatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SaleDatumImplToJson(
      this,
    );
  }
}

abstract class _SaleDatum implements SaleDatum {
  const factory _SaleDatum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "brandName") final String? brandName,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "numberOfUnit") final String? numberOfUnit,
      @JsonKey(name: "itemsWeight") final String? itemsWeight,
      @JsonKey(name: "totalWeight") final String? totalWeight,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "salesName") final String? salesName,
      @JsonKey(name: "discountPercentage") final String? discountPercentage,
      @JsonKey(name: "salesDescription") final String? salesDescription,
      @JsonKey(name: "isPesach") final bool? isPesach}) = _$SaleDatumImpl;

  factory _SaleDatum.fromJson(Map<String, dynamic> json) =
      _$SaleDatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override // @JsonKey(name: "category") String? category,
// @JsonKey(name: "subcategories") String? subcategories,
// @JsonKey(name: "subsubcategories") String? subsubcategories,
// @JsonKey(name: "casetypes") String? casetypes,
// @JsonKey(name: "status") String? status,
// @JsonKey(name: "sku") String? sku,
  @JsonKey(name: "brandName")
  String? get brandName;
  @override
  @JsonKey(name: "images")
  List<Image>? get images;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit;
  @override
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  String? get totalWeight;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override // @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
// @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
  @JsonKey(name: "salesName")
  String? get salesName;
  @override
  @JsonKey(name: "discountPercentage")
  String? get discountPercentage;
  @override
  @JsonKey(name: "salesDescription")
  String? get salesDescription;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(ignore: true)
  _$$SaleDatumImplCopyWith<_$SaleDatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Image _$ImageFromJson(Map<String, dynamic> json) {
  return _Image.fromJson(json);
}

/// @nodoc
mixin _$Image {
  @JsonKey(name: "imageUrl")
  String? get imageUrl => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ImageCopyWith<Image> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ImageCopyWith<$Res> {
  factory $ImageCopyWith(Image value, $Res Function(Image) then) =
      _$ImageCopyWithImpl<$Res, Image>;
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class _$ImageCopyWithImpl<$Res, $Val extends Image>
    implements $ImageCopyWith<$Res> {
  _$ImageCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_value.copyWith(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ImageImplCopyWith<$Res> implements $ImageCopyWith<$Res> {
  factory _$$ImageImplCopyWith(
          _$ImageImpl value, $Res Function(_$ImageImpl) then) =
      __$$ImageImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class __$$ImageImplCopyWithImpl<$Res>
    extends _$ImageCopyWithImpl<$Res, _$ImageImpl>
    implements _$$ImageImplCopyWith<$Res> {
  __$$ImageImplCopyWithImpl(
      _$ImageImpl _value, $Res Function(_$ImageImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_$ImageImpl(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ImageImpl implements _Image {
  const _$ImageImpl(
      {@JsonKey(name: "imageUrl") this.imageUrl,
      @JsonKey(name: "order") this.order});

  factory _$ImageImpl.fromJson(Map<String, dynamic> json) =>
      _$$ImageImplFromJson(json);

  @override
  @JsonKey(name: "imageUrl")
  final String? imageUrl;
  @override
  @JsonKey(name: "order")
  final int? order;

  @override
  String toString() {
    return 'Image(imageUrl: $imageUrl, order: $order)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ImageImpl &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.order, order) || other.order == order));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, imageUrl, order);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      __$$ImageImplCopyWithImpl<_$ImageImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ImageImplToJson(
      this,
    );
  }
}

abstract class _Image implements Image {
  const factory _Image(
      {@JsonKey(name: "imageUrl") final String? imageUrl,
      @JsonKey(name: "order") final int? order}) = _$ImageImpl;

  factory _Image.fromJson(Map<String, dynamic> json) = _$ImageImpl.fromJson;

  @override
  @JsonKey(name: "imageUrl")
  String? get imageUrl;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(ignore: true)
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SupplierDatum _$SupplierDatumFromJson(Map<String, dynamic> json) {
  return _SupplierDatum.fromJson(json);
}

/// @nodoc
mixin _$SupplierDatum {
  @JsonKey(name: "_id")
  String? get id =>
      throw _privateConstructorUsedError; // @JsonKey(name: "email") String? email,
// @JsonKey(name: "password") dynamic password,
// @JsonKey(name: "phoneNumber") String? phoneNumber,
// @JsonKey(name: "address") String? address,
// @JsonKey(name: "cityId") String? cityId,
  @JsonKey(name: "contactName")
  String? get contactName =>
      throw _privateConstructorUsedError; // @JsonKey(name: "statusId") String? statusId,
  @JsonKey(name: "qrcode")
  String? get qrcode => throw _privateConstructorUsedError;
  @JsonKey(name: "logo")
  String? get logo =>
      throw _privateConstructorUsedError; // @JsonKey(name: "adminTypeId") String? adminTypeId,
  @JsonKey(name: "supplierDetail")
  SupplierDetail? get supplierDetail =>
      throw _privateConstructorUsedError; // @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
  @JsonKey(name: "isDeleted")
  bool? get isDeleted =>
      throw _privateConstructorUsedError; // @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
// @JsonKey(name: "__v") int? v,
// @JsonKey(name: "lastSeen") dynamic lastSeen,
// @JsonKey(name: "status") Status? status,
// @JsonKey(name: "fromDate") dynamic fromDate,
// @JsonKey(name: "order") String? order,
// @JsonKey(name: "totalIncome") String? totalIncome,
// @JsonKey(name: "incomeByThisMonth") String? incomeByThisMonth,
  @JsonKey(name: "_idSearch")
  String? get idSearch => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierDatumCopyWith<SupplierDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierDatumCopyWith<$Res> {
  factory $SupplierDatumCopyWith(
          SupplierDatum value, $Res Function(SupplierDatum) then) =
      _$SupplierDatumCopyWithImpl<$Res, SupplierDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "supplierDetail") SupplierDetail? supplierDetail,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "_idSearch") String? idSearch,
      @JsonKey(name: "isPesach") bool? isPesach});

  $SupplierDetailCopyWith<$Res>? get supplierDetail;
}

/// @nodoc
class _$SupplierDatumCopyWithImpl<$Res, $Val extends SupplierDatum>
    implements $SupplierDatumCopyWith<$Res> {
  _$SupplierDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? contactName = freezed,
    Object? qrcode = freezed,
    Object? logo = freezed,
    Object? supplierDetail = freezed,
    Object? isDeleted = freezed,
    Object? idSearch = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierDetail: freezed == supplierDetail
          ? _value.supplierDetail
          : supplierDetail // ignore: cast_nullable_to_non_nullable
              as SupplierDetail?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      idSearch: freezed == idSearch
          ? _value.idSearch
          : idSearch // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $SupplierDetailCopyWith<$Res>? get supplierDetail {
    if (_value.supplierDetail == null) {
      return null;
    }

    return $SupplierDetailCopyWith<$Res>(_value.supplierDetail!, (value) {
      return _then(_value.copyWith(supplierDetail: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SupplierDatumImplCopyWith<$Res>
    implements $SupplierDatumCopyWith<$Res> {
  factory _$$SupplierDatumImplCopyWith(
          _$SupplierDatumImpl value, $Res Function(_$SupplierDatumImpl) then) =
      __$$SupplierDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "supplierDetail") SupplierDetail? supplierDetail,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "_idSearch") String? idSearch,
      @JsonKey(name: "isPesach") bool? isPesach});

  @override
  $SupplierDetailCopyWith<$Res>? get supplierDetail;
}

/// @nodoc
class __$$SupplierDatumImplCopyWithImpl<$Res>
    extends _$SupplierDatumCopyWithImpl<$Res, _$SupplierDatumImpl>
    implements _$$SupplierDatumImplCopyWith<$Res> {
  __$$SupplierDatumImplCopyWithImpl(
      _$SupplierDatumImpl _value, $Res Function(_$SupplierDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? contactName = freezed,
    Object? qrcode = freezed,
    Object? logo = freezed,
    Object? supplierDetail = freezed,
    Object? isDeleted = freezed,
    Object? idSearch = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_$SupplierDatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierDetail: freezed == supplierDetail
          ? _value.supplierDetail
          : supplierDetail // ignore: cast_nullable_to_non_nullable
              as SupplierDetail?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      idSearch: freezed == idSearch
          ? _value.idSearch
          : idSearch // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierDatumImpl implements _SupplierDatum {
  const _$SupplierDatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "qrcode") this.qrcode,
      @JsonKey(name: "logo") this.logo,
      @JsonKey(name: "supplierDetail") this.supplierDetail,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "_idSearch") this.idSearch,
      @JsonKey(name: "isPesach") this.isPesach});

  factory _$SupplierDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierDatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
// @JsonKey(name: "email") String? email,
// @JsonKey(name: "password") dynamic password,
// @JsonKey(name: "phoneNumber") String? phoneNumber,
// @JsonKey(name: "address") String? address,
// @JsonKey(name: "cityId") String? cityId,
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
// @JsonKey(name: "statusId") String? statusId,
  @override
  @JsonKey(name: "qrcode")
  final String? qrcode;
  @override
  @JsonKey(name: "logo")
  final String? logo;
// @JsonKey(name: "adminTypeId") String? adminTypeId,
  @override
  @JsonKey(name: "supplierDetail")
  final SupplierDetail? supplierDetail;
// @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
// @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
// @JsonKey(name: "__v") int? v,
// @JsonKey(name: "lastSeen") dynamic lastSeen,
// @JsonKey(name: "status") Status? status,
// @JsonKey(name: "fromDate") dynamic fromDate,
// @JsonKey(name: "order") String? order,
// @JsonKey(name: "totalIncome") String? totalIncome,
// @JsonKey(name: "incomeByThisMonth") String? incomeByThisMonth,
  @override
  @JsonKey(name: "_idSearch")
  final String? idSearch;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;

  @override
  String toString() {
    return 'SupplierDatum(id: $id, contactName: $contactName, qrcode: $qrcode, logo: $logo, supplierDetail: $supplierDetail, isDeleted: $isDeleted, idSearch: $idSearch, isPesach: $isPesach)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierDatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.qrcode, qrcode) || other.qrcode == qrcode) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.supplierDetail, supplierDetail) ||
                other.supplierDetail == supplierDetail) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.idSearch, idSearch) ||
                other.idSearch == idSearch) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, contactName, qrcode, logo,
      supplierDetail, isDeleted, idSearch, isPesach);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierDatumImplCopyWith<_$SupplierDatumImpl> get copyWith =>
      __$$SupplierDatumImplCopyWithImpl<_$SupplierDatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierDatumImplToJson(
      this,
    );
  }
}

abstract class _SupplierDatum implements SupplierDatum {
  const factory _SupplierDatum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "qrcode") final String? qrcode,
      @JsonKey(name: "logo") final String? logo,
      @JsonKey(name: "supplierDetail") final SupplierDetail? supplierDetail,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "_idSearch") final String? idSearch,
      @JsonKey(name: "isPesach") final bool? isPesach}) = _$SupplierDatumImpl;

  factory _SupplierDatum.fromJson(Map<String, dynamic> json) =
      _$SupplierDatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override // @JsonKey(name: "email") String? email,
// @JsonKey(name: "password") dynamic password,
// @JsonKey(name: "phoneNumber") String? phoneNumber,
// @JsonKey(name: "address") String? address,
// @JsonKey(name: "cityId") String? cityId,
  @JsonKey(name: "contactName")
  String? get contactName;
  @override // @JsonKey(name: "statusId") String? statusId,
  @JsonKey(name: "qrcode")
  String? get qrcode;
  @override
  @JsonKey(name: "logo")
  String? get logo;
  @override // @JsonKey(name: "adminTypeId") String? adminTypeId,
  @JsonKey(name: "supplierDetail")
  SupplierDetail? get supplierDetail;
  @override // @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override // @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
// @JsonKey(name: "__v") int? v,
// @JsonKey(name: "lastSeen") dynamic lastSeen,
// @JsonKey(name: "status") Status? status,
// @JsonKey(name: "fromDate") dynamic fromDate,
// @JsonKey(name: "order") String? order,
// @JsonKey(name: "totalIncome") String? totalIncome,
// @JsonKey(name: "incomeByThisMonth") String? incomeByThisMonth,
  @JsonKey(name: "_idSearch")
  String? get idSearch;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(ignore: true)
  _$$SupplierDatumImplCopyWith<_$SupplierDatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Status _$StatusFromJson(Map<String, dynamic> json) {
  return _Status.fromJson(json);
}

/// @nodoc
mixin _$Status {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "statusName")
  String? get statusName =>
      throw _privateConstructorUsedError; // @JsonKey(name: "createdAt") DateTime? createdAt,
// @JsonKey(name: "updatedAt") DateTime? updatedAt,
// @JsonKey(name: "__v") int? v,
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StatusCopyWith<Status> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StatusCopyWith<$Res> {
  factory $StatusCopyWith(Status value, $Res Function(Status) then) =
      _$StatusCopyWithImpl<$Res, Status>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class _$StatusCopyWithImpl<$Res, $Val extends Status>
    implements $StatusCopyWith<$Res> {
  _$StatusCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StatusImplCopyWith<$Res> implements $StatusCopyWith<$Res> {
  factory _$$StatusImplCopyWith(
          _$StatusImpl value, $Res Function(_$StatusImpl) then) =
      __$$StatusImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class __$$StatusImplCopyWithImpl<$Res>
    extends _$StatusCopyWithImpl<$Res, _$StatusImpl>
    implements _$$StatusImplCopyWith<$Res> {
  __$$StatusImplCopyWithImpl(
      _$StatusImpl _value, $Res Function(_$StatusImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_$StatusImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StatusImpl implements _Status {
  const _$StatusImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "statusName") this.statusName,
      @JsonKey(name: "isDeleted") this.isDeleted});

  factory _$StatusImpl.fromJson(Map<String, dynamic> json) =>
      _$$StatusImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "statusName")
  final String? statusName;
// @JsonKey(name: "createdAt") DateTime? createdAt,
// @JsonKey(name: "updatedAt") DateTime? updatedAt,
// @JsonKey(name: "__v") int? v,
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;

  @override
  String toString() {
    return 'Status(id: $id, statusName: $statusName, isDeleted: $isDeleted)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StatusImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.statusName, statusName) ||
                other.statusName == statusName) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, statusName, isDeleted);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      __$$StatusImplCopyWithImpl<_$StatusImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StatusImplToJson(
      this,
    );
  }
}

abstract class _Status implements Status {
  const factory _Status(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "statusName") final String? statusName,
      @JsonKey(name: "isDeleted") final bool? isDeleted}) = _$StatusImpl;

  factory _Status.fromJson(Map<String, dynamic> json) = _$StatusImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "statusName")
  String? get statusName;
  @override // @JsonKey(name: "createdAt") DateTime? createdAt,
// @JsonKey(name: "updatedAt") DateTime? updatedAt,
// @JsonKey(name: "__v") int? v,
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(ignore: true)
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SupplierDetail _$SupplierDetailFromJson(Map<String, dynamic> json) {
  return _SupplierDetail.fromJson(json);
}

/// @nodoc
mixin _$SupplierDetail {
  @JsonKey(name: "companyIdNumber")
  int? get companyIdNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "companyName")
  String? get companyName => throw _privateConstructorUsedError;
  @JsonKey(name: "suppliersTypeId")
  String? get suppliersTypeId =>
      throw _privateConstructorUsedError; // @JsonKey(name: "hasImport") bool? hasImport,
// @JsonKey(name: "hasLogistics") bool? hasLogistics,
// @JsonKey(name: "hasDistribution") bool? hasDistribution,
// @JsonKey(name: "categoriesIds") List<String>? categoriesIds,
// @JsonKey(name: "suplierPolicy") List<SuplierPolicy>? suplierPolicy,
// @JsonKey(name: "hasDistributionPolicy") bool? hasDistributionPolicy,
// @JsonKey(name: "distributionDetails")
// DistributionDetails? distributionDetails,
// @JsonKey(name: "order") dynamic order,
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierDetailCopyWith<SupplierDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierDetailCopyWith<$Res> {
  factory $SupplierDetailCopyWith(
          SupplierDetail value, $Res Function(SupplierDetail) then) =
      _$SupplierDetailCopyWithImpl<$Res, SupplierDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "companyIdNumber") int? companyIdNumber,
      @JsonKey(name: "companyName") String? companyName,
      @JsonKey(name: "suppliersTypeId") String? suppliersTypeId,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class _$SupplierDetailCopyWithImpl<$Res, $Val extends SupplierDetail>
    implements $SupplierDetailCopyWith<$Res> {
  _$SupplierDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companyIdNumber = freezed,
    Object? companyName = freezed,
    Object? suppliersTypeId = freezed,
    Object? isHomePreference = freezed,
    Object? id = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_value.copyWith(
      companyIdNumber: freezed == companyIdNumber
          ? _value.companyIdNumber
          : companyIdNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      companyName: freezed == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String?,
      suppliersTypeId: freezed == suppliersTypeId
          ? _value.suppliersTypeId
          : suppliersTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierDetailImplCopyWith<$Res>
    implements $SupplierDetailCopyWith<$Res> {
  factory _$$SupplierDetailImplCopyWith(_$SupplierDetailImpl value,
          $Res Function(_$SupplierDetailImpl) then) =
      __$$SupplierDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "companyIdNumber") int? companyIdNumber,
      @JsonKey(name: "companyName") String? companyName,
      @JsonKey(name: "suppliersTypeId") String? suppliersTypeId,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "isPesach") bool? isPesach});
}

/// @nodoc
class __$$SupplierDetailImplCopyWithImpl<$Res>
    extends _$SupplierDetailCopyWithImpl<$Res, _$SupplierDetailImpl>
    implements _$$SupplierDetailImplCopyWith<$Res> {
  __$$SupplierDetailImplCopyWithImpl(
      _$SupplierDetailImpl _value, $Res Function(_$SupplierDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companyIdNumber = freezed,
    Object? companyName = freezed,
    Object? suppliersTypeId = freezed,
    Object? isHomePreference = freezed,
    Object? id = freezed,
    Object? isPesach = freezed,
  }) {
    return _then(_$SupplierDetailImpl(
      companyIdNumber: freezed == companyIdNumber
          ? _value.companyIdNumber
          : companyIdNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      companyName: freezed == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String?,
      suppliersTypeId: freezed == suppliersTypeId
          ? _value.suppliersTypeId
          : suppliersTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierDetailImpl implements _SupplierDetail {
  const _$SupplierDetailImpl(
      {@JsonKey(name: "companyIdNumber") this.companyIdNumber,
      @JsonKey(name: "companyName") this.companyName,
      @JsonKey(name: "suppliersTypeId") this.suppliersTypeId,
      @JsonKey(name: "isHomePreference") this.isHomePreference,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "isPesach") this.isPesach});

  factory _$SupplierDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierDetailImplFromJson(json);

  @override
  @JsonKey(name: "companyIdNumber")
  final int? companyIdNumber;
  @override
  @JsonKey(name: "companyName")
  final String? companyName;
  @override
  @JsonKey(name: "suppliersTypeId")
  final String? suppliersTypeId;
// @JsonKey(name: "hasImport") bool? hasImport,
// @JsonKey(name: "hasLogistics") bool? hasLogistics,
// @JsonKey(name: "hasDistribution") bool? hasDistribution,
// @JsonKey(name: "categoriesIds") List<String>? categoriesIds,
// @JsonKey(name: "suplierPolicy") List<SuplierPolicy>? suplierPolicy,
// @JsonKey(name: "hasDistributionPolicy") bool? hasDistributionPolicy,
// @JsonKey(name: "distributionDetails")
// DistributionDetails? distributionDetails,
// @JsonKey(name: "order") dynamic order,
  @override
  @JsonKey(name: "isHomePreference")
  final bool? isHomePreference;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;

  @override
  String toString() {
    return 'SupplierDetail(companyIdNumber: $companyIdNumber, companyName: $companyName, suppliersTypeId: $suppliersTypeId, isHomePreference: $isHomePreference, id: $id, isPesach: $isPesach)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierDetailImpl &&
            (identical(other.companyIdNumber, companyIdNumber) ||
                other.companyIdNumber == companyIdNumber) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.suppliersTypeId, suppliersTypeId) ||
                other.suppliersTypeId == suppliersTypeId) &&
            (identical(other.isHomePreference, isHomePreference) ||
                other.isHomePreference == isHomePreference) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, companyIdNumber, companyName,
      suppliersTypeId, isHomePreference, id, isPesach);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierDetailImplCopyWith<_$SupplierDetailImpl> get copyWith =>
      __$$SupplierDetailImplCopyWithImpl<_$SupplierDetailImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierDetailImplToJson(
      this,
    );
  }
}

abstract class _SupplierDetail implements SupplierDetail {
  const factory _SupplierDetail(
      {@JsonKey(name: "companyIdNumber") final int? companyIdNumber,
      @JsonKey(name: "companyName") final String? companyName,
      @JsonKey(name: "suppliersTypeId") final String? suppliersTypeId,
      @JsonKey(name: "isHomePreference") final bool? isHomePreference,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "isPesach") final bool? isPesach}) = _$SupplierDetailImpl;

  factory _SupplierDetail.fromJson(Map<String, dynamic> json) =
      _$SupplierDetailImpl.fromJson;

  @override
  @JsonKey(name: "companyIdNumber")
  int? get companyIdNumber;
  @override
  @JsonKey(name: "companyName")
  String? get companyName;
  @override
  @JsonKey(name: "suppliersTypeId")
  String? get suppliersTypeId;
  @override // @JsonKey(name: "hasImport") bool? hasImport,
// @JsonKey(name: "hasLogistics") bool? hasLogistics,
// @JsonKey(name: "hasDistribution") bool? hasDistribution,
// @JsonKey(name: "categoriesIds") List<String>? categoriesIds,
// @JsonKey(name: "suplierPolicy") List<SuplierPolicy>? suplierPolicy,
// @JsonKey(name: "hasDistributionPolicy") bool? hasDistributionPolicy,
// @JsonKey(name: "distributionDetails")
// DistributionDetails? distributionDetails,
// @JsonKey(name: "order") dynamic order,
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(ignore: true)
  _$$SupplierDetailImplCopyWith<_$SupplierDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

DistributionDetails _$DistributionDetailsFromJson(Map<String, dynamic> json) {
  return _DistributionDetails.fromJson(json);
}

/// @nodoc
mixin _$DistributionDetails {
  @JsonKey(name: "A1")
  A1? get a1 => throw _privateConstructorUsedError;
  @JsonKey(name: "center")
  A1? get center => throw _privateConstructorUsedError;
  @JsonKey(name: "east")
  A1? get east => throw _privateConstructorUsedError;
  @JsonKey(name: "judea")
  A1? get judea => throw _privateConstructorUsedError;
  @JsonKey(name: "north")
  A1? get north => throw _privateConstructorUsedError;
  @JsonKey(name: "south")
  A1? get south => throw _privateConstructorUsedError;
  @JsonKey(name: "west")
  A1? get west => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DistributionDetailsCopyWith<DistributionDetails> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DistributionDetailsCopyWith<$Res> {
  factory $DistributionDetailsCopyWith(
          DistributionDetails value, $Res Function(DistributionDetails) then) =
      _$DistributionDetailsCopyWithImpl<$Res, DistributionDetails>;
  @useResult
  $Res call(
      {@JsonKey(name: "A1") A1? a1,
      @JsonKey(name: "center") A1? center,
      @JsonKey(name: "east") A1? east,
      @JsonKey(name: "judea") A1? judea,
      @JsonKey(name: "north") A1? north,
      @JsonKey(name: "south") A1? south,
      @JsonKey(name: "west") A1? west});

  $A1CopyWith<$Res>? get a1;
  $A1CopyWith<$Res>? get center;
  $A1CopyWith<$Res>? get east;
  $A1CopyWith<$Res>? get judea;
  $A1CopyWith<$Res>? get north;
  $A1CopyWith<$Res>? get south;
  $A1CopyWith<$Res>? get west;
}

/// @nodoc
class _$DistributionDetailsCopyWithImpl<$Res, $Val extends DistributionDetails>
    implements $DistributionDetailsCopyWith<$Res> {
  _$DistributionDetailsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? a1 = freezed,
    Object? center = freezed,
    Object? east = freezed,
    Object? judea = freezed,
    Object? north = freezed,
    Object? south = freezed,
    Object? west = freezed,
  }) {
    return _then(_value.copyWith(
      a1: freezed == a1
          ? _value.a1
          : a1 // ignore: cast_nullable_to_non_nullable
              as A1?,
      center: freezed == center
          ? _value.center
          : center // ignore: cast_nullable_to_non_nullable
              as A1?,
      east: freezed == east
          ? _value.east
          : east // ignore: cast_nullable_to_non_nullable
              as A1?,
      judea: freezed == judea
          ? _value.judea
          : judea // ignore: cast_nullable_to_non_nullable
              as A1?,
      north: freezed == north
          ? _value.north
          : north // ignore: cast_nullable_to_non_nullable
              as A1?,
      south: freezed == south
          ? _value.south
          : south // ignore: cast_nullable_to_non_nullable
              as A1?,
      west: freezed == west
          ? _value.west
          : west // ignore: cast_nullable_to_non_nullable
              as A1?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $A1CopyWith<$Res>? get a1 {
    if (_value.a1 == null) {
      return null;
    }

    return $A1CopyWith<$Res>(_value.a1!, (value) {
      return _then(_value.copyWith(a1: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $A1CopyWith<$Res>? get center {
    if (_value.center == null) {
      return null;
    }

    return $A1CopyWith<$Res>(_value.center!, (value) {
      return _then(_value.copyWith(center: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $A1CopyWith<$Res>? get east {
    if (_value.east == null) {
      return null;
    }

    return $A1CopyWith<$Res>(_value.east!, (value) {
      return _then(_value.copyWith(east: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $A1CopyWith<$Res>? get judea {
    if (_value.judea == null) {
      return null;
    }

    return $A1CopyWith<$Res>(_value.judea!, (value) {
      return _then(_value.copyWith(judea: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $A1CopyWith<$Res>? get north {
    if (_value.north == null) {
      return null;
    }

    return $A1CopyWith<$Res>(_value.north!, (value) {
      return _then(_value.copyWith(north: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $A1CopyWith<$Res>? get south {
    if (_value.south == null) {
      return null;
    }

    return $A1CopyWith<$Res>(_value.south!, (value) {
      return _then(_value.copyWith(south: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $A1CopyWith<$Res>? get west {
    if (_value.west == null) {
      return null;
    }

    return $A1CopyWith<$Res>(_value.west!, (value) {
      return _then(_value.copyWith(west: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DistributionDetailsImplCopyWith<$Res>
    implements $DistributionDetailsCopyWith<$Res> {
  factory _$$DistributionDetailsImplCopyWith(_$DistributionDetailsImpl value,
          $Res Function(_$DistributionDetailsImpl) then) =
      __$$DistributionDetailsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "A1") A1? a1,
      @JsonKey(name: "center") A1? center,
      @JsonKey(name: "east") A1? east,
      @JsonKey(name: "judea") A1? judea,
      @JsonKey(name: "north") A1? north,
      @JsonKey(name: "south") A1? south,
      @JsonKey(name: "west") A1? west});

  @override
  $A1CopyWith<$Res>? get a1;
  @override
  $A1CopyWith<$Res>? get center;
  @override
  $A1CopyWith<$Res>? get east;
  @override
  $A1CopyWith<$Res>? get judea;
  @override
  $A1CopyWith<$Res>? get north;
  @override
  $A1CopyWith<$Res>? get south;
  @override
  $A1CopyWith<$Res>? get west;
}

/// @nodoc
class __$$DistributionDetailsImplCopyWithImpl<$Res>
    extends _$DistributionDetailsCopyWithImpl<$Res, _$DistributionDetailsImpl>
    implements _$$DistributionDetailsImplCopyWith<$Res> {
  __$$DistributionDetailsImplCopyWithImpl(_$DistributionDetailsImpl _value,
      $Res Function(_$DistributionDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? a1 = freezed,
    Object? center = freezed,
    Object? east = freezed,
    Object? judea = freezed,
    Object? north = freezed,
    Object? south = freezed,
    Object? west = freezed,
  }) {
    return _then(_$DistributionDetailsImpl(
      a1: freezed == a1
          ? _value.a1
          : a1 // ignore: cast_nullable_to_non_nullable
              as A1?,
      center: freezed == center
          ? _value.center
          : center // ignore: cast_nullable_to_non_nullable
              as A1?,
      east: freezed == east
          ? _value.east
          : east // ignore: cast_nullable_to_non_nullable
              as A1?,
      judea: freezed == judea
          ? _value.judea
          : judea // ignore: cast_nullable_to_non_nullable
              as A1?,
      north: freezed == north
          ? _value.north
          : north // ignore: cast_nullable_to_non_nullable
              as A1?,
      south: freezed == south
          ? _value.south
          : south // ignore: cast_nullable_to_non_nullable
              as A1?,
      west: freezed == west
          ? _value.west
          : west // ignore: cast_nullable_to_non_nullable
              as A1?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DistributionDetailsImpl implements _DistributionDetails {
  const _$DistributionDetailsImpl(
      {@JsonKey(name: "A1") this.a1,
      @JsonKey(name: "center") this.center,
      @JsonKey(name: "east") this.east,
      @JsonKey(name: "judea") this.judea,
      @JsonKey(name: "north") this.north,
      @JsonKey(name: "south") this.south,
      @JsonKey(name: "west") this.west});

  factory _$DistributionDetailsImpl.fromJson(Map<String, dynamic> json) =>
      _$$DistributionDetailsImplFromJson(json);

  @override
  @JsonKey(name: "A1")
  final A1? a1;
  @override
  @JsonKey(name: "center")
  final A1? center;
  @override
  @JsonKey(name: "east")
  final A1? east;
  @override
  @JsonKey(name: "judea")
  final A1? judea;
  @override
  @JsonKey(name: "north")
  final A1? north;
  @override
  @JsonKey(name: "south")
  final A1? south;
  @override
  @JsonKey(name: "west")
  final A1? west;

  @override
  String toString() {
    return 'DistributionDetails(a1: $a1, center: $center, east: $east, judea: $judea, north: $north, south: $south, west: $west)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DistributionDetailsImpl &&
            (identical(other.a1, a1) || other.a1 == a1) &&
            (identical(other.center, center) || other.center == center) &&
            (identical(other.east, east) || other.east == east) &&
            (identical(other.judea, judea) || other.judea == judea) &&
            (identical(other.north, north) || other.north == north) &&
            (identical(other.south, south) || other.south == south) &&
            (identical(other.west, west) || other.west == west));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, a1, center, east, judea, north, south, west);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DistributionDetailsImplCopyWith<_$DistributionDetailsImpl> get copyWith =>
      __$$DistributionDetailsImplCopyWithImpl<_$DistributionDetailsImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DistributionDetailsImplToJson(
      this,
    );
  }
}

abstract class _DistributionDetails implements DistributionDetails {
  const factory _DistributionDetails(
      {@JsonKey(name: "A1") final A1? a1,
      @JsonKey(name: "center") final A1? center,
      @JsonKey(name: "east") final A1? east,
      @JsonKey(name: "judea") final A1? judea,
      @JsonKey(name: "north") final A1? north,
      @JsonKey(name: "south") final A1? south,
      @JsonKey(name: "west") final A1? west}) = _$DistributionDetailsImpl;

  factory _DistributionDetails.fromJson(Map<String, dynamic> json) =
      _$DistributionDetailsImpl.fromJson;

  @override
  @JsonKey(name: "A1")
  A1? get a1;
  @override
  @JsonKey(name: "center")
  A1? get center;
  @override
  @JsonKey(name: "east")
  A1? get east;
  @override
  @JsonKey(name: "judea")
  A1? get judea;
  @override
  @JsonKey(name: "north")
  A1? get north;
  @override
  @JsonKey(name: "south")
  A1? get south;
  @override
  @JsonKey(name: "west")
  A1? get west;
  @override
  @JsonKey(ignore: true)
  _$$DistributionDetailsImplCopyWith<_$DistributionDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

A1 _$A1FromJson(Map<String, dynamic> json) {
  return _A1.fromJson(json);
}

/// @nodoc
mixin _$A1 {
  @JsonKey(name: "Sunday")
  Day? get sunday => throw _privateConstructorUsedError;
  @JsonKey(name: "Monday")
  Day? get monday => throw _privateConstructorUsedError;
  @JsonKey(name: "Tuesday")
  Day? get tuesday => throw _privateConstructorUsedError;
  @JsonKey(name: "Wednesday")
  Day? get wednesday => throw _privateConstructorUsedError;
  @JsonKey(name: "Thursday")
  Day? get thursday => throw _privateConstructorUsedError;
  @JsonKey(name: "Friday")
  Day? get friday => throw _privateConstructorUsedError;
  @JsonKey(name: "Saturday")
  Day? get saturday => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $A1CopyWith<A1> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $A1CopyWith<$Res> {
  factory $A1CopyWith(A1 value, $Res Function(A1) then) =
      _$A1CopyWithImpl<$Res, A1>;
  @useResult
  $Res call(
      {@JsonKey(name: "Sunday") Day? sunday,
      @JsonKey(name: "Monday") Day? monday,
      @JsonKey(name: "Tuesday") Day? tuesday,
      @JsonKey(name: "Wednesday") Day? wednesday,
      @JsonKey(name: "Thursday") Day? thursday,
      @JsonKey(name: "Friday") Day? friday,
      @JsonKey(name: "Saturday") Day? saturday});

  $DayCopyWith<$Res>? get sunday;
  $DayCopyWith<$Res>? get monday;
  $DayCopyWith<$Res>? get tuesday;
  $DayCopyWith<$Res>? get wednesday;
  $DayCopyWith<$Res>? get thursday;
  $DayCopyWith<$Res>? get friday;
  $DayCopyWith<$Res>? get saturday;
}

/// @nodoc
class _$A1CopyWithImpl<$Res, $Val extends A1> implements $A1CopyWith<$Res> {
  _$A1CopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sunday = freezed,
    Object? monday = freezed,
    Object? tuesday = freezed,
    Object? wednesday = freezed,
    Object? thursday = freezed,
    Object? friday = freezed,
    Object? saturday = freezed,
  }) {
    return _then(_value.copyWith(
      sunday: freezed == sunday
          ? _value.sunday
          : sunday // ignore: cast_nullable_to_non_nullable
              as Day?,
      monday: freezed == monday
          ? _value.monday
          : monday // ignore: cast_nullable_to_non_nullable
              as Day?,
      tuesday: freezed == tuesday
          ? _value.tuesday
          : tuesday // ignore: cast_nullable_to_non_nullable
              as Day?,
      wednesday: freezed == wednesday
          ? _value.wednesday
          : wednesday // ignore: cast_nullable_to_non_nullable
              as Day?,
      thursday: freezed == thursday
          ? _value.thursday
          : thursday // ignore: cast_nullable_to_non_nullable
              as Day?,
      friday: freezed == friday
          ? _value.friday
          : friday // ignore: cast_nullable_to_non_nullable
              as Day?,
      saturday: freezed == saturday
          ? _value.saturday
          : saturday // ignore: cast_nullable_to_non_nullable
              as Day?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DayCopyWith<$Res>? get sunday {
    if (_value.sunday == null) {
      return null;
    }

    return $DayCopyWith<$Res>(_value.sunday!, (value) {
      return _then(_value.copyWith(sunday: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $DayCopyWith<$Res>? get monday {
    if (_value.monday == null) {
      return null;
    }

    return $DayCopyWith<$Res>(_value.monday!, (value) {
      return _then(_value.copyWith(monday: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $DayCopyWith<$Res>? get tuesday {
    if (_value.tuesday == null) {
      return null;
    }

    return $DayCopyWith<$Res>(_value.tuesday!, (value) {
      return _then(_value.copyWith(tuesday: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $DayCopyWith<$Res>? get wednesday {
    if (_value.wednesday == null) {
      return null;
    }

    return $DayCopyWith<$Res>(_value.wednesday!, (value) {
      return _then(_value.copyWith(wednesday: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $DayCopyWith<$Res>? get thursday {
    if (_value.thursday == null) {
      return null;
    }

    return $DayCopyWith<$Res>(_value.thursday!, (value) {
      return _then(_value.copyWith(thursday: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $DayCopyWith<$Res>? get friday {
    if (_value.friday == null) {
      return null;
    }

    return $DayCopyWith<$Res>(_value.friday!, (value) {
      return _then(_value.copyWith(friday: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $DayCopyWith<$Res>? get saturday {
    if (_value.saturday == null) {
      return null;
    }

    return $DayCopyWith<$Res>(_value.saturday!, (value) {
      return _then(_value.copyWith(saturday: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$A1ImplCopyWith<$Res> implements $A1CopyWith<$Res> {
  factory _$$A1ImplCopyWith(_$A1Impl value, $Res Function(_$A1Impl) then) =
      __$$A1ImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "Sunday") Day? sunday,
      @JsonKey(name: "Monday") Day? monday,
      @JsonKey(name: "Tuesday") Day? tuesday,
      @JsonKey(name: "Wednesday") Day? wednesday,
      @JsonKey(name: "Thursday") Day? thursday,
      @JsonKey(name: "Friday") Day? friday,
      @JsonKey(name: "Saturday") Day? saturday});

  @override
  $DayCopyWith<$Res>? get sunday;
  @override
  $DayCopyWith<$Res>? get monday;
  @override
  $DayCopyWith<$Res>? get tuesday;
  @override
  $DayCopyWith<$Res>? get wednesday;
  @override
  $DayCopyWith<$Res>? get thursday;
  @override
  $DayCopyWith<$Res>? get friday;
  @override
  $DayCopyWith<$Res>? get saturday;
}

/// @nodoc
class __$$A1ImplCopyWithImpl<$Res> extends _$A1CopyWithImpl<$Res, _$A1Impl>
    implements _$$A1ImplCopyWith<$Res> {
  __$$A1ImplCopyWithImpl(_$A1Impl _value, $Res Function(_$A1Impl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sunday = freezed,
    Object? monday = freezed,
    Object? tuesday = freezed,
    Object? wednesday = freezed,
    Object? thursday = freezed,
    Object? friday = freezed,
    Object? saturday = freezed,
  }) {
    return _then(_$A1Impl(
      sunday: freezed == sunday
          ? _value.sunday
          : sunday // ignore: cast_nullable_to_non_nullable
              as Day?,
      monday: freezed == monday
          ? _value.monday
          : monday // ignore: cast_nullable_to_non_nullable
              as Day?,
      tuesday: freezed == tuesday
          ? _value.tuesday
          : tuesday // ignore: cast_nullable_to_non_nullable
              as Day?,
      wednesday: freezed == wednesday
          ? _value.wednesday
          : wednesday // ignore: cast_nullable_to_non_nullable
              as Day?,
      thursday: freezed == thursday
          ? _value.thursday
          : thursday // ignore: cast_nullable_to_non_nullable
              as Day?,
      friday: freezed == friday
          ? _value.friday
          : friday // ignore: cast_nullable_to_non_nullable
              as Day?,
      saturday: freezed == saturday
          ? _value.saturday
          : saturday // ignore: cast_nullable_to_non_nullable
              as Day?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$A1Impl implements _A1 {
  const _$A1Impl(
      {@JsonKey(name: "Sunday") this.sunday,
      @JsonKey(name: "Monday") this.monday,
      @JsonKey(name: "Tuesday") this.tuesday,
      @JsonKey(name: "Wednesday") this.wednesday,
      @JsonKey(name: "Thursday") this.thursday,
      @JsonKey(name: "Friday") this.friday,
      @JsonKey(name: "Saturday") this.saturday});

  factory _$A1Impl.fromJson(Map<String, dynamic> json) =>
      _$$A1ImplFromJson(json);

  @override
  @JsonKey(name: "Sunday")
  final Day? sunday;
  @override
  @JsonKey(name: "Monday")
  final Day? monday;
  @override
  @JsonKey(name: "Tuesday")
  final Day? tuesday;
  @override
  @JsonKey(name: "Wednesday")
  final Day? wednesday;
  @override
  @JsonKey(name: "Thursday")
  final Day? thursday;
  @override
  @JsonKey(name: "Friday")
  final Day? friday;
  @override
  @JsonKey(name: "Saturday")
  final Day? saturday;

  @override
  String toString() {
    return 'A1(sunday: $sunday, monday: $monday, tuesday: $tuesday, wednesday: $wednesday, thursday: $thursday, friday: $friday, saturday: $saturday)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$A1Impl &&
            (identical(other.sunday, sunday) || other.sunday == sunday) &&
            (identical(other.monday, monday) || other.monday == monday) &&
            (identical(other.tuesday, tuesday) || other.tuesday == tuesday) &&
            (identical(other.wednesday, wednesday) ||
                other.wednesday == wednesday) &&
            (identical(other.thursday, thursday) ||
                other.thursday == thursday) &&
            (identical(other.friday, friday) || other.friday == friday) &&
            (identical(other.saturday, saturday) ||
                other.saturday == saturday));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, sunday, monday, tuesday,
      wednesday, thursday, friday, saturday);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$A1ImplCopyWith<_$A1Impl> get copyWith =>
      __$$A1ImplCopyWithImpl<_$A1Impl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$A1ImplToJson(
      this,
    );
  }
}

abstract class _A1 implements A1 {
  const factory _A1(
      {@JsonKey(name: "Sunday") final Day? sunday,
      @JsonKey(name: "Monday") final Day? monday,
      @JsonKey(name: "Tuesday") final Day? tuesday,
      @JsonKey(name: "Wednesday") final Day? wednesday,
      @JsonKey(name: "Thursday") final Day? thursday,
      @JsonKey(name: "Friday") final Day? friday,
      @JsonKey(name: "Saturday") final Day? saturday}) = _$A1Impl;

  factory _A1.fromJson(Map<String, dynamic> json) = _$A1Impl.fromJson;

  @override
  @JsonKey(name: "Sunday")
  Day? get sunday;
  @override
  @JsonKey(name: "Monday")
  Day? get monday;
  @override
  @JsonKey(name: "Tuesday")
  Day? get tuesday;
  @override
  @JsonKey(name: "Wednesday")
  Day? get wednesday;
  @override
  @JsonKey(name: "Thursday")
  Day? get thursday;
  @override
  @JsonKey(name: "Friday")
  Day? get friday;
  @override
  @JsonKey(name: "Saturday")
  Day? get saturday;
  @override
  @JsonKey(ignore: true)
  _$$A1ImplCopyWith<_$A1Impl> get copyWith =>
      throw _privateConstructorUsedError;
}

Day _$DayFromJson(Map<String, dynamic> json) {
  return _Day.fromJson(json);
}

/// @nodoc
mixin _$Day {
  @JsonKey(name: "startTime")
  String? get startTime => throw _privateConstructorUsedError;
  @JsonKey(name: "endTime")
  String? get endTime => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DayCopyWith<Day> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DayCopyWith<$Res> {
  factory $DayCopyWith(Day value, $Res Function(Day) then) =
      _$DayCopyWithImpl<$Res, Day>;
  @useResult
  $Res call(
      {@JsonKey(name: "startTime") String? startTime,
      @JsonKey(name: "endTime") String? endTime});
}

/// @nodoc
class _$DayCopyWithImpl<$Res, $Val extends Day> implements $DayCopyWith<$Res> {
  _$DayCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? startTime = freezed,
    Object? endTime = freezed,
  }) {
    return _then(_value.copyWith(
      startTime: freezed == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as String?,
      endTime: freezed == endTime
          ? _value.endTime
          : endTime // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DayImplCopyWith<$Res> implements $DayCopyWith<$Res> {
  factory _$$DayImplCopyWith(_$DayImpl value, $Res Function(_$DayImpl) then) =
      __$$DayImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "startTime") String? startTime,
      @JsonKey(name: "endTime") String? endTime});
}

/// @nodoc
class __$$DayImplCopyWithImpl<$Res> extends _$DayCopyWithImpl<$Res, _$DayImpl>
    implements _$$DayImplCopyWith<$Res> {
  __$$DayImplCopyWithImpl(_$DayImpl _value, $Res Function(_$DayImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? startTime = freezed,
    Object? endTime = freezed,
  }) {
    return _then(_$DayImpl(
      startTime: freezed == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as String?,
      endTime: freezed == endTime
          ? _value.endTime
          : endTime // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DayImpl implements _Day {
  const _$DayImpl(
      {@JsonKey(name: "startTime") this.startTime,
      @JsonKey(name: "endTime") this.endTime});

  factory _$DayImpl.fromJson(Map<String, dynamic> json) =>
      _$$DayImplFromJson(json);

  @override
  @JsonKey(name: "startTime")
  final String? startTime;
  @override
  @JsonKey(name: "endTime")
  final String? endTime;

  @override
  String toString() {
    return 'Day(startTime: $startTime, endTime: $endTime)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DayImpl &&
            (identical(other.startTime, startTime) ||
                other.startTime == startTime) &&
            (identical(other.endTime, endTime) || other.endTime == endTime));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, startTime, endTime);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DayImplCopyWith<_$DayImpl> get copyWith =>
      __$$DayImplCopyWithImpl<_$DayImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DayImplToJson(
      this,
    );
  }
}

abstract class _Day implements Day {
  const factory _Day(
      {@JsonKey(name: "startTime") final String? startTime,
      @JsonKey(name: "endTime") final String? endTime}) = _$DayImpl;

  factory _Day.fromJson(Map<String, dynamic> json) = _$DayImpl.fromJson;

  @override
  @JsonKey(name: "startTime")
  String? get startTime;
  @override
  @JsonKey(name: "endTime")
  String? get endTime;
  @override
  @JsonKey(ignore: true)
  _$$DayImplCopyWith<_$DayImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SuplierPolicy _$SuplierPolicyFromJson(Map<String, dynamic> json) {
  return _SuplierPolicy.fromJson(json);
}

/// @nodoc
mixin _$SuplierPolicy {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "policyHeading")
  String? get policyHeading => throw _privateConstructorUsedError;
  @JsonKey(name: "toggleSwitchKey")
  String? get toggleSwitchKey => throw _privateConstructorUsedError;
  @JsonKey(name: "fields")
  List<Field>? get fields => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "toggleSwitchValue")
  bool? get toggleSwitchValue => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SuplierPolicyCopyWith<SuplierPolicy> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SuplierPolicyCopyWith<$Res> {
  factory $SuplierPolicyCopyWith(
          SuplierPolicy value, $Res Function(SuplierPolicy) then) =
      _$SuplierPolicyCopyWithImpl<$Res, SuplierPolicy>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "policyHeading") String? policyHeading,
      @JsonKey(name: "toggleSwitchKey") String? toggleSwitchKey,
      @JsonKey(name: "fields") List<Field>? fields,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "toggleSwitchValue") bool? toggleSwitchValue});
}

/// @nodoc
class _$SuplierPolicyCopyWithImpl<$Res, $Val extends SuplierPolicy>
    implements $SuplierPolicyCopyWith<$Res> {
  _$SuplierPolicyCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? policyHeading = freezed,
    Object? toggleSwitchKey = freezed,
    Object? fields = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
    Object? toggleSwitchValue = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      policyHeading: freezed == policyHeading
          ? _value.policyHeading
          : policyHeading // ignore: cast_nullable_to_non_nullable
              as String?,
      toggleSwitchKey: freezed == toggleSwitchKey
          ? _value.toggleSwitchKey
          : toggleSwitchKey // ignore: cast_nullable_to_non_nullable
              as String?,
      fields: freezed == fields
          ? _value.fields
          : fields // ignore: cast_nullable_to_non_nullable
              as List<Field>?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      toggleSwitchValue: freezed == toggleSwitchValue
          ? _value.toggleSwitchValue
          : toggleSwitchValue // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SuplierPolicyImplCopyWith<$Res>
    implements $SuplierPolicyCopyWith<$Res> {
  factory _$$SuplierPolicyImplCopyWith(
          _$SuplierPolicyImpl value, $Res Function(_$SuplierPolicyImpl) then) =
      __$$SuplierPolicyImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "policyHeading") String? policyHeading,
      @JsonKey(name: "toggleSwitchKey") String? toggleSwitchKey,
      @JsonKey(name: "fields") List<Field>? fields,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "toggleSwitchValue") bool? toggleSwitchValue});
}

/// @nodoc
class __$$SuplierPolicyImplCopyWithImpl<$Res>
    extends _$SuplierPolicyCopyWithImpl<$Res, _$SuplierPolicyImpl>
    implements _$$SuplierPolicyImplCopyWith<$Res> {
  __$$SuplierPolicyImplCopyWithImpl(
      _$SuplierPolicyImpl _value, $Res Function(_$SuplierPolicyImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? policyHeading = freezed,
    Object? toggleSwitchKey = freezed,
    Object? fields = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
    Object? toggleSwitchValue = freezed,
  }) {
    return _then(_$SuplierPolicyImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      policyHeading: freezed == policyHeading
          ? _value.policyHeading
          : policyHeading // ignore: cast_nullable_to_non_nullable
              as String?,
      toggleSwitchKey: freezed == toggleSwitchKey
          ? _value.toggleSwitchKey
          : toggleSwitchKey // ignore: cast_nullable_to_non_nullable
              as String?,
      fields: freezed == fields
          ? _value._fields
          : fields // ignore: cast_nullable_to_non_nullable
              as List<Field>?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      toggleSwitchValue: freezed == toggleSwitchValue
          ? _value.toggleSwitchValue
          : toggleSwitchValue // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SuplierPolicyImpl implements _SuplierPolicy {
  const _$SuplierPolicyImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "policyHeading") this.policyHeading,
      @JsonKey(name: "toggleSwitchKey") this.toggleSwitchKey,
      @JsonKey(name: "fields") final List<Field>? fields,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "toggleSwitchValue") this.toggleSwitchValue})
      : _fields = fields;

  factory _$SuplierPolicyImpl.fromJson(Map<String, dynamic> json) =>
      _$$SuplierPolicyImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "policyHeading")
  final String? policyHeading;
  @override
  @JsonKey(name: "toggleSwitchKey")
  final String? toggleSwitchKey;
  final List<Field>? _fields;
  @override
  @JsonKey(name: "fields")
  List<Field>? get fields {
    final value = _fields;
    if (value == null) return null;
    if (_fields is EqualUnmodifiableListView) return _fields;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "toggleSwitchValue")
  final bool? toggleSwitchValue;

  @override
  String toString() {
    return 'SuplierPolicy(id: $id, policyHeading: $policyHeading, toggleSwitchKey: $toggleSwitchKey, fields: $fields, updatedAt: $updatedAt, createdAt: $createdAt, toggleSwitchValue: $toggleSwitchValue)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SuplierPolicyImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.policyHeading, policyHeading) ||
                other.policyHeading == policyHeading) &&
            (identical(other.toggleSwitchKey, toggleSwitchKey) ||
                other.toggleSwitchKey == toggleSwitchKey) &&
            const DeepCollectionEquality().equals(other._fields, _fields) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.toggleSwitchValue, toggleSwitchValue) ||
                other.toggleSwitchValue == toggleSwitchValue));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      policyHeading,
      toggleSwitchKey,
      const DeepCollectionEquality().hash(_fields),
      updatedAt,
      createdAt,
      toggleSwitchValue);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SuplierPolicyImplCopyWith<_$SuplierPolicyImpl> get copyWith =>
      __$$SuplierPolicyImplCopyWithImpl<_$SuplierPolicyImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SuplierPolicyImplToJson(
      this,
    );
  }
}

abstract class _SuplierPolicy implements SuplierPolicy {
  const factory _SuplierPolicy(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "policyHeading") final String? policyHeading,
          @JsonKey(name: "toggleSwitchKey") final String? toggleSwitchKey,
          @JsonKey(name: "fields") final List<Field>? fields,
          @JsonKey(name: "updatedAt") final DateTime? updatedAt,
          @JsonKey(name: "createdAt") final DateTime? createdAt,
          @JsonKey(name: "toggleSwitchValue") final bool? toggleSwitchValue}) =
      _$SuplierPolicyImpl;

  factory _SuplierPolicy.fromJson(Map<String, dynamic> json) =
      _$SuplierPolicyImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "policyHeading")
  String? get policyHeading;
  @override
  @JsonKey(name: "toggleSwitchKey")
  String? get toggleSwitchKey;
  @override
  @JsonKey(name: "fields")
  List<Field>? get fields;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "toggleSwitchValue")
  bool? get toggleSwitchValue;
  @override
  @JsonKey(ignore: true)
  _$$SuplierPolicyImplCopyWith<_$SuplierPolicyImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Field _$FieldFromJson(Map<String, dynamic> json) {
  return _Field.fromJson(json);
}

/// @nodoc
mixin _$Field {
  @JsonKey(name: "fieldKey")
  String? get fieldKey => throw _privateConstructorUsedError;
  @JsonKey(name: "fieldType")
  String? get fieldType => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $FieldCopyWith<Field> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FieldCopyWith<$Res> {
  factory $FieldCopyWith(Field value, $Res Function(Field) then) =
      _$FieldCopyWithImpl<$Res, Field>;
  @useResult
  $Res call(
      {@JsonKey(name: "fieldKey") String? fieldKey,
      @JsonKey(name: "fieldType") String? fieldType,
      @JsonKey(name: "_id") String? id});
}

/// @nodoc
class _$FieldCopyWithImpl<$Res, $Val extends Field>
    implements $FieldCopyWith<$Res> {
  _$FieldCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fieldKey = freezed,
    Object? fieldType = freezed,
    Object? id = freezed,
  }) {
    return _then(_value.copyWith(
      fieldKey: freezed == fieldKey
          ? _value.fieldKey
          : fieldKey // ignore: cast_nullable_to_non_nullable
              as String?,
      fieldType: freezed == fieldType
          ? _value.fieldType
          : fieldType // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FieldImplCopyWith<$Res> implements $FieldCopyWith<$Res> {
  factory _$$FieldImplCopyWith(
          _$FieldImpl value, $Res Function(_$FieldImpl) then) =
      __$$FieldImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "fieldKey") String? fieldKey,
      @JsonKey(name: "fieldType") String? fieldType,
      @JsonKey(name: "_id") String? id});
}

/// @nodoc
class __$$FieldImplCopyWithImpl<$Res>
    extends _$FieldCopyWithImpl<$Res, _$FieldImpl>
    implements _$$FieldImplCopyWith<$Res> {
  __$$FieldImplCopyWithImpl(
      _$FieldImpl _value, $Res Function(_$FieldImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fieldKey = freezed,
    Object? fieldType = freezed,
    Object? id = freezed,
  }) {
    return _then(_$FieldImpl(
      fieldKey: freezed == fieldKey
          ? _value.fieldKey
          : fieldKey // ignore: cast_nullable_to_non_nullable
              as String?,
      fieldType: freezed == fieldType
          ? _value.fieldType
          : fieldType // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$FieldImpl implements _Field {
  const _$FieldImpl(
      {@JsonKey(name: "fieldKey") this.fieldKey,
      @JsonKey(name: "fieldType") this.fieldType,
      @JsonKey(name: "_id") this.id});

  factory _$FieldImpl.fromJson(Map<String, dynamic> json) =>
      _$$FieldImplFromJson(json);

  @override
  @JsonKey(name: "fieldKey")
  final String? fieldKey;
  @override
  @JsonKey(name: "fieldType")
  final String? fieldType;
  @override
  @JsonKey(name: "_id")
  final String? id;

  @override
  String toString() {
    return 'Field(fieldKey: $fieldKey, fieldType: $fieldType, id: $id)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FieldImpl &&
            (identical(other.fieldKey, fieldKey) ||
                other.fieldKey == fieldKey) &&
            (identical(other.fieldType, fieldType) ||
                other.fieldType == fieldType) &&
            (identical(other.id, id) || other.id == id));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, fieldKey, fieldType, id);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FieldImplCopyWith<_$FieldImpl> get copyWith =>
      __$$FieldImplCopyWithImpl<_$FieldImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$FieldImplToJson(
      this,
    );
  }
}

abstract class _Field implements Field {
  const factory _Field(
      {@JsonKey(name: "fieldKey") final String? fieldKey,
      @JsonKey(name: "fieldType") final String? fieldType,
      @JsonKey(name: "_id") final String? id}) = _$FieldImpl;

  factory _Field.fromJson(Map<String, dynamic> json) = _$FieldImpl.fromJson;

  @override
  @JsonKey(name: "fieldKey")
  String? get fieldKey;
  @override
  @JsonKey(name: "fieldType")
  String? get fieldType;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(ignore: true)
  _$$FieldImplCopyWith<_$FieldImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SupplierProductDatum _$SupplierProductDatumFromJson(Map<String, dynamic> json) {
  return _SupplierProductDatum.fromJson(json);
}

/// @nodoc
mixin _$SupplierProductDatum {
  @JsonKey(name: "_id")
  String? get id =>
      throw _privateConstructorUsedError; // @JsonKey(name: "category") String? category,
// @JsonKey(name: "subcategories") String? subcategories,
// @JsonKey(name: "subsubcategories") String? subsubcategories,
// @JsonKey(name: "casetypes") String? casetypes,
// @JsonKey(name: "status") String? status,
// @JsonKey(name: "sku") String? sku,
  @JsonKey(name: "brandName")
  String? get brandName => throw _privateConstructorUsedError;
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  String? get totalWeight =>
      throw _privateConstructorUsedError; // @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
// @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
  @JsonKey(name: "productId")
  String? get productId => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierId")
  String? get supplierId => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  String? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  String? get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierProductDatumCopyWith<SupplierProductDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierProductDatumCopyWith<$Res> {
  factory $SupplierProductDatumCopyWith(SupplierProductDatum value,
          $Res Function(SupplierProductDatum) then) =
      _$SupplierProductDatumCopyWithImpl<$Res, SupplierProductDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "productId") String? productId,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "productPrice") String? productPrice,
      @JsonKey(name: "productStock") String? productStock,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      String? lowStock});
}

/// @nodoc
class _$SupplierProductDatumCopyWithImpl<$Res,
        $Val extends SupplierProductDatum>
    implements $SupplierProductDatumCopyWith<$Res> {
  _$SupplierProductDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? brandName = freezed,
    Object? numberOfUnit = freezed,
    Object? productName = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? productId = freezed,
    Object? supplierId = freezed,
    Object? productPrice = freezed,
    Object? productStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierProductDatumImplCopyWith<$Res>
    implements $SupplierProductDatumCopyWith<$Res> {
  factory _$$SupplierProductDatumImplCopyWith(_$SupplierProductDatumImpl value,
          $Res Function(_$SupplierProductDatumImpl) then) =
      __$$SupplierProductDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "productId") String? productId,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "productPrice") String? productPrice,
      @JsonKey(name: "productStock") String? productStock,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      String? lowStock});
}

/// @nodoc
class __$$SupplierProductDatumImplCopyWithImpl<$Res>
    extends _$SupplierProductDatumCopyWithImpl<$Res, _$SupplierProductDatumImpl>
    implements _$$SupplierProductDatumImplCopyWith<$Res> {
  __$$SupplierProductDatumImplCopyWithImpl(_$SupplierProductDatumImpl _value,
      $Res Function(_$SupplierProductDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? brandName = freezed,
    Object? numberOfUnit = freezed,
    Object? productName = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? productId = freezed,
    Object? supplierId = freezed,
    Object? productPrice = freezed,
    Object? productStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_$SupplierProductDatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierProductDatumImpl implements _SupplierProductDatum {
  const _$SupplierProductDatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "brandName") this.brandName,
      @JsonKey(name: "numberOfUnit") this.numberOfUnit,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "productId") this.productId,
      @JsonKey(name: "supplierId") this.supplierId,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim,
      this.lowStock});

  factory _$SupplierProductDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierProductDatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
// @JsonKey(name: "category") String? category,
// @JsonKey(name: "subcategories") String? subcategories,
// @JsonKey(name: "subsubcategories") String? subsubcategories,
// @JsonKey(name: "casetypes") String? casetypes,
// @JsonKey(name: "status") String? status,
// @JsonKey(name: "sku") String? sku,
  @override
  @JsonKey(name: "brandName")
  final String? brandName;
  @override
  @JsonKey(name: "numberOfUnit")
  final String? numberOfUnit;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  final String? itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  final String? totalWeight;
// @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
// @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
  @override
  @JsonKey(name: "productId")
  final String? productId;
  @override
  @JsonKey(name: "supplierId")
  final String? supplierId;
  @override
  @JsonKey(name: "productPrice")
  final String? productPrice;
  @override
  @JsonKey(name: "productStock")
  final String? productStock;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;
  @override
  final String? lowStock;

  @override
  String toString() {
    return 'SupplierProductDatum(id: $id, brandName: $brandName, numberOfUnit: $numberOfUnit, productName: $productName, mainImage: $mainImage, itemsWeight: $itemsWeight, totalWeight: $totalWeight, productId: $productId, supplierId: $supplierId, productPrice: $productPrice, productStock: $productStock, isPesach: $isPesach, nmMashlim: $nmMashlim, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierProductDatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.brandName, brandName) ||
                other.brandName == brandName) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      brandName,
      numberOfUnit,
      productName,
      mainImage,
      itemsWeight,
      totalWeight,
      productId,
      supplierId,
      productPrice,
      productStock,
      isPesach,
      nmMashlim,
      lowStock);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierProductDatumImplCopyWith<_$SupplierProductDatumImpl>
      get copyWith =>
          __$$SupplierProductDatumImplCopyWithImpl<_$SupplierProductDatumImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierProductDatumImplToJson(
      this,
    );
  }
}

abstract class _SupplierProductDatum implements SupplierProductDatum {
  const factory _SupplierProductDatum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "brandName") final String? brandName,
      @JsonKey(name: "numberOfUnit") final String? numberOfUnit,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "itemsWeight") final String? itemsWeight,
      @JsonKey(name: "totalWeight") final String? totalWeight,
      @JsonKey(name: "productId") final String? productId,
      @JsonKey(name: "supplierId") final String? supplierId,
      @JsonKey(name: "productPrice") final String? productPrice,
      @JsonKey(name: "productStock") final String? productStock,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim") final String? nmMashlim,
      final String? lowStock}) = _$SupplierProductDatumImpl;

  factory _SupplierProductDatum.fromJson(Map<String, dynamic> json) =
      _$SupplierProductDatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override // @JsonKey(name: "category") String? category,
// @JsonKey(name: "subcategories") String? subcategories,
// @JsonKey(name: "subsubcategories") String? subsubcategories,
// @JsonKey(name: "casetypes") String? casetypes,
// @JsonKey(name: "status") String? status,
// @JsonKey(name: "sku") String? sku,
  @JsonKey(name: "brandName")
  String? get brandName;
  @override
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  String? get totalWeight;
  @override // @JsonKey(name: "createdBy") String? createdBy,
// @JsonKey(name: "updatedBy") String? updatedBy,
// @JsonKey(name: "createdAt") String? createdAt,
// @JsonKey(name: "updatedAt") String? updatedAt,
  @JsonKey(name: "productId")
  String? get productId;
  @override
  @JsonKey(name: "supplierId")
  String? get supplierId;
  @override
  @JsonKey(name: "productPrice")
  String? get productPrice;
  @override
  @JsonKey(name: "productStock")
  String? get productStock;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  String? get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$SupplierProductDatumImplCopyWith<_$SupplierProductDatumImpl>
      get copyWith => throw _privateConstructorUsedError;
}
