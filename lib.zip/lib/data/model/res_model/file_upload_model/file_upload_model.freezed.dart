// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'file_upload_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

FileUploadModel _$FileUploadModelFromJson(Map<String, dynamic> json) {
  return _FileUploadModel.fromJson(json);
}

/// @nodoc
mixin _$FileUploadModel {
  @JsonKey(name: "baseURL")
  String? get baseUrl => throw _privateConstructorUsedError;
  @JsonKey(name: "filepath")
  String? get filepath => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $FileUploadModelCopyWith<FileUploadModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FileUploadModelCopyWith<$Res> {
  factory $FileUploadModelCopyWith(
          FileUploadModel value, $Res Function(FileUploadModel) then) =
      _$FileUploadModelCopyWithImpl<$Res, FileUploadModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "baseURL") String? baseUrl,
      @JsonKey(name: "filepath") String? filepath});
}

/// @nodoc
class _$FileUploadModelCopyWithImpl<$Res, $Val extends FileUploadModel>
    implements $FileUploadModelCopyWith<$Res> {
  _$FileUploadModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseUrl = freezed,
    Object? filepath = freezed,
  }) {
    return _then(_value.copyWith(
      baseUrl: freezed == baseUrl
          ? _value.baseUrl
          : baseUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      filepath: freezed == filepath
          ? _value.filepath
          : filepath // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FileUploadModelImplCopyWith<$Res>
    implements $FileUploadModelCopyWith<$Res> {
  factory _$$FileUploadModelImplCopyWith(_$FileUploadModelImpl value,
          $Res Function(_$FileUploadModelImpl) then) =
      __$$FileUploadModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "baseURL") String? baseUrl,
      @JsonKey(name: "filepath") String? filepath});
}

/// @nodoc
class __$$FileUploadModelImplCopyWithImpl<$Res>
    extends _$FileUploadModelCopyWithImpl<$Res, _$FileUploadModelImpl>
    implements _$$FileUploadModelImplCopyWith<$Res> {
  __$$FileUploadModelImplCopyWithImpl(
      _$FileUploadModelImpl _value, $Res Function(_$FileUploadModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? baseUrl = freezed,
    Object? filepath = freezed,
  }) {
    return _then(_$FileUploadModelImpl(
      baseUrl: freezed == baseUrl
          ? _value.baseUrl
          : baseUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      filepath: freezed == filepath
          ? _value.filepath
          : filepath // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$FileUploadModelImpl implements _FileUploadModel {
  const _$FileUploadModelImpl(
      {@JsonKey(name: "baseURL") this.baseUrl,
      @JsonKey(name: "filepath") this.filepath});

  factory _$FileUploadModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$FileUploadModelImplFromJson(json);

  @override
  @JsonKey(name: "baseURL")
  final String? baseUrl;
  @override
  @JsonKey(name: "filepath")
  final String? filepath;

  @override
  String toString() {
    return 'FileUploadModel(baseUrl: $baseUrl, filepath: $filepath)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FileUploadModelImpl &&
            (identical(other.baseUrl, baseUrl) || other.baseUrl == baseUrl) &&
            (identical(other.filepath, filepath) ||
                other.filepath == filepath));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, baseUrl, filepath);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FileUploadModelImplCopyWith<_$FileUploadModelImpl> get copyWith =>
      __$$FileUploadModelImplCopyWithImpl<_$FileUploadModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$FileUploadModelImplToJson(
      this,
    );
  }
}

abstract class _FileUploadModel implements FileUploadModel {
  const factory _FileUploadModel(
          {@JsonKey(name: "baseURL") final String? baseUrl,
          @JsonKey(name: "filepath") final String? filepath}) =
      _$FileUploadModelImpl;

  factory _FileUploadModel.fromJson(Map<String, dynamic> json) =
      _$FileUploadModelImpl.fromJson;

  @override
  @JsonKey(name: "baseURL")
  String? get baseUrl;
  @override
  @JsonKey(name: "filepath")
  String? get filepath;
  @override
  @JsonKey(ignore: true)
  _$$FileUploadModelImplCopyWith<_$FileUploadModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
