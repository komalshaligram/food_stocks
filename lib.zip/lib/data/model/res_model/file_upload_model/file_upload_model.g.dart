// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'file_upload_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$FileUploadModelImpl _$$FileUploadModelImplFromJson(
        Map<String, dynamic> json) =>
    _$FileUploadModelImpl(
      baseUrl: json['baseURL'] as String?,
      filepath: json['filepath'] as String?,
    );

Map<String, dynamic> _$$FileUploadModelImplToJson(
        _$FileUploadModelImpl instance) =>
    <String, dynamic>{
      'baseURL': instance.baseUrl,
      'filepath': instance.filepath,
    };
