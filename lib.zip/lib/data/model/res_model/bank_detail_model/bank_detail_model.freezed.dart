// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'bank_detail_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

BankDetailModel _$BankDetailModelFromJson(Map<String, dynamic> json) {
  return _BankDetailModel.fromJson(json);
}

/// @nodoc
mixin _$BankDetailModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BankDetailModelCopyWith<BankDetailModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BankDetailModelCopyWith<$Res> {
  factory $BankDetailModelCopyWith(
          BankDetailModel value, $Res Function(BankDetailModel) then) =
      _$BankDetailModelCopyWithImpl<$Res, BankDetailModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$BankDetailModelCopyWithImpl<$Res, $Val extends BankDetailModel>
    implements $BankDetailModelCopyWith<$Res> {
  _$BankDetailModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$BankDetailModelImplCopyWith<$Res>
    implements $BankDetailModelCopyWith<$Res> {
  factory _$$BankDetailModelImplCopyWith(_$BankDetailModelImpl value,
          $Res Function(_$BankDetailModelImpl) then) =
      __$$BankDetailModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$BankDetailModelImplCopyWithImpl<$Res>
    extends _$BankDetailModelCopyWithImpl<$Res, _$BankDetailModelImpl>
    implements _$$BankDetailModelImplCopyWith<$Res> {
  __$$BankDetailModelImplCopyWithImpl(
      _$BankDetailModelImpl _value, $Res Function(_$BankDetailModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$BankDetailModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BankDetailModelImpl implements _BankDetailModel {
  const _$BankDetailModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$BankDetailModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$BankDetailModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'BankDetailModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BankDetailModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BankDetailModelImplCopyWith<_$BankDetailModelImpl> get copyWith =>
      __$$BankDetailModelImplCopyWithImpl<_$BankDetailModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BankDetailModelImplToJson(
      this,
    );
  }
}

abstract class _BankDetailModel implements BankDetailModel {
  const factory _BankDetailModel(
      {@JsonKey(name: "status") final int? status,
      @JsonKey(name: "data") final Data? data,
      @JsonKey(name: "message") final String? message}) = _$BankDetailModelImpl;

  factory _BankDetailModel.fromJson(Map<String, dynamic> json) =
      _$BankDetailModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$BankDetailModelImplCopyWith<_$BankDetailModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "BankDetail")
  List<BankDetail>? get bankDetail => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call({@JsonKey(name: "BankDetail") List<BankDetail>? bankDetail});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bankDetail = freezed,
  }) {
    return _then(_value.copyWith(
      bankDetail: freezed == bankDetail
          ? _value.bankDetail
          : bankDetail // ignore: cast_nullable_to_non_nullable
              as List<BankDetail>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({@JsonKey(name: "BankDetail") List<BankDetail>? bankDetail});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bankDetail = freezed,
  }) {
    return _then(_$DataImpl(
      bankDetail: freezed == bankDetail
          ? _value._bankDetail
          : bankDetail // ignore: cast_nullable_to_non_nullable
              as List<BankDetail>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "BankDetail") final List<BankDetail>? bankDetail})
      : _bankDetail = bankDetail;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  final List<BankDetail>? _bankDetail;
  @override
  @JsonKey(name: "BankDetail")
  List<BankDetail>? get bankDetail {
    final value = _bankDetail;
    if (value == null) return null;
    if (_bankDetail is EqualUnmodifiableListView) return _bankDetail;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'Data(bankDetail: $bankDetail)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            const DeepCollectionEquality()
                .equals(other._bankDetail, _bankDetail));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_bankDetail));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
          {@JsonKey(name: "BankDetail") final List<BankDetail>? bankDetail}) =
      _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "BankDetail")
  List<BankDetail>? get bankDetail;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

BankDetail _$BankDetailFromJson(Map<String, dynamic> json) {
  return _BankDetail.fromJson(json);
}

/// @nodoc
mixin _$BankDetail {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "bankName")
  String? get bankName => throw _privateConstructorUsedError;
  @JsonKey(name: "bankNumber")
  String? get bankNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "bankIncrementalNumber")
  int? get bankIncrementalNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "lowerField")
  String? get lowerField => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BankDetailCopyWith<BankDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BankDetailCopyWith<$Res> {
  factory $BankDetailCopyWith(
          BankDetail value, $Res Function(BankDetail) then) =
      _$BankDetailCopyWithImpl<$Res, BankDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "bankName") String? bankName,
      @JsonKey(name: "bankNumber") String? bankNumber,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "bankIncrementalNumber") int? bankIncrementalNumber,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "lowerField") String? lowerField});
}

/// @nodoc
class _$BankDetailCopyWithImpl<$Res, $Val extends BankDetail>
    implements $BankDetailCopyWith<$Res> {
  _$BankDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? bankName = freezed,
    Object? bankNumber = freezed,
    Object? isDeleted = freezed,
    Object? bankIncrementalNumber = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? lowerField = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      bankName: freezed == bankName
          ? _value.bankName
          : bankName // ignore: cast_nullable_to_non_nullable
              as String?,
      bankNumber: freezed == bankNumber
          ? _value.bankNumber
          : bankNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      bankIncrementalNumber: freezed == bankIncrementalNumber
          ? _value.bankIncrementalNumber
          : bankIncrementalNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      lowerField: freezed == lowerField
          ? _value.lowerField
          : lowerField // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$BankDetailImplCopyWith<$Res>
    implements $BankDetailCopyWith<$Res> {
  factory _$$BankDetailImplCopyWith(
          _$BankDetailImpl value, $Res Function(_$BankDetailImpl) then) =
      __$$BankDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "bankName") String? bankName,
      @JsonKey(name: "bankNumber") String? bankNumber,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "bankIncrementalNumber") int? bankIncrementalNumber,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "lowerField") String? lowerField});
}

/// @nodoc
class __$$BankDetailImplCopyWithImpl<$Res>
    extends _$BankDetailCopyWithImpl<$Res, _$BankDetailImpl>
    implements _$$BankDetailImplCopyWith<$Res> {
  __$$BankDetailImplCopyWithImpl(
      _$BankDetailImpl _value, $Res Function(_$BankDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? bankName = freezed,
    Object? bankNumber = freezed,
    Object? isDeleted = freezed,
    Object? bankIncrementalNumber = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? lowerField = freezed,
  }) {
    return _then(_$BankDetailImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      bankName: freezed == bankName
          ? _value.bankName
          : bankName // ignore: cast_nullable_to_non_nullable
              as String?,
      bankNumber: freezed == bankNumber
          ? _value.bankNumber
          : bankNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      bankIncrementalNumber: freezed == bankIncrementalNumber
          ? _value.bankIncrementalNumber
          : bankIncrementalNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      lowerField: freezed == lowerField
          ? _value.lowerField
          : lowerField // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BankDetailImpl implements _BankDetail {
  const _$BankDetailImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "bankName") this.bankName,
      @JsonKey(name: "bankNumber") this.bankNumber,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "bankIncrementalNumber") this.bankIncrementalNumber,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "lowerField") this.lowerField});

  factory _$BankDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$BankDetailImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "bankName")
  final String? bankName;
  @override
  @JsonKey(name: "bankNumber")
  final String? bankNumber;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "bankIncrementalNumber")
  final int? bankIncrementalNumber;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "lowerField")
  final String? lowerField;

  @override
  String toString() {
    return 'BankDetail(id: $id, bankName: $bankName, bankNumber: $bankNumber, isDeleted: $isDeleted, bankIncrementalNumber: $bankIncrementalNumber, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, lowerField: $lowerField)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BankDetailImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.bankName, bankName) ||
                other.bankName == bankName) &&
            (identical(other.bankNumber, bankNumber) ||
                other.bankNumber == bankNumber) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.bankIncrementalNumber, bankIncrementalNumber) ||
                other.bankIncrementalNumber == bankIncrementalNumber) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.lowerField, lowerField) ||
                other.lowerField == lowerField));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, bankName, bankNumber,
      isDeleted, bankIncrementalNumber, createdAt, updatedAt, v, lowerField);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BankDetailImplCopyWith<_$BankDetailImpl> get copyWith =>
      __$$BankDetailImplCopyWithImpl<_$BankDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BankDetailImplToJson(
      this,
    );
  }
}

abstract class _BankDetail implements BankDetail {
  const factory _BankDetail(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "bankName") final String? bankName,
      @JsonKey(name: "bankNumber") final String? bankNumber,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "bankIncrementalNumber") final int? bankIncrementalNumber,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v,
      @JsonKey(name: "lowerField")
      final String? lowerField}) = _$BankDetailImpl;

  factory _BankDetail.fromJson(Map<String, dynamic> json) =
      _$BankDetailImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "bankName")
  String? get bankName;
  @override
  @JsonKey(name: "bankNumber")
  String? get bankNumber;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "bankIncrementalNumber")
  int? get bankIncrementalNumber;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "lowerField")
  String? get lowerField;
  @override
  @JsonKey(ignore: true)
  _$$BankDetailImplCopyWith<_$BankDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
