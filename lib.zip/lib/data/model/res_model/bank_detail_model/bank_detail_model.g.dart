// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bank_detail_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$BankDetailModelImpl _$$BankDetailModelImplFromJson(
        Map<String, dynamic> json) =>
    _$BankDetailModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$BankDetailModelImplToJson(
        _$BankDetailModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      bankDetail: (json['BankDetail'] as List<dynamic>?)
          ?.map((e) => BankDetail.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'BankDetail': instance.bankDetail,
    };

_$BankDetailImpl _$$BankDetailImplFromJson(Map<String, dynamic> json) =>
    _$BankDetailImpl(
      id: json['_id'] as String?,
      bankName: json['bankName'] as String?,
      bankNumber: json['bankNumber'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      bankIncrementalNumber: json['bankIncrementalNumber'] as int?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      lowerField: json['lowerField'] as String?,
    );

Map<String, dynamic> _$$BankDetailImplToJson(_$BankDetailImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'bankName': instance.bankName,
      'bankNumber': instance.bankNumber,
      'isDeleted': instance.isDeleted,
      'bankIncrementalNumber': instance.bankIncrementalNumber,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'lowerField': instance.lowerField,
    };
