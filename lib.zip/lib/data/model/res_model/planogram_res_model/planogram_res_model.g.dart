// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'planogram_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PlanogramResModelImpl _$$PlanogramResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$PlanogramResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => PlanogramDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$PlanogramResModelImplToJson(
        _$PlanogramResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$PlanogramDatumImpl _$$PlanogramDatumImplFromJson(Map<String, dynamic> json) =>
    _$PlanogramDatumImpl(
      planogramproducts: (json['planogramproducts'] as List<dynamic>?)
          ?.map((e) => Planogramproduct.fromJson(e as Map<String, dynamic>))
          .toList(),
      id: json['_id'] as String?,
      planogramName: json['planogramName'] as String?,
      fromDate: json['fromDate'] == null
          ? null
          : DateTime.parse(json['fromDate'] as String),
      untilDate: json['untilDate'] == null
          ? null
          : DateTime.parse(json['untilDate'] as String),
    );

Map<String, dynamic> _$$PlanogramDatumImplToJson(
        _$PlanogramDatumImpl instance) =>
    <String, dynamic>{
      'planogramproducts': instance.planogramproducts,
      '_id': instance.id,
      'planogramName': instance.planogramName,
      'fromDate': instance.fromDate?.toIso8601String(),
      'untilDate': instance.untilDate?.toIso8601String(),
    };

_$PlanogramproductImpl _$$PlanogramproductImplFromJson(
        Map<String, dynamic> json) =>
    _$PlanogramproductImpl(
      id: json['_id'] as String?,
      productStock: (json['productStock'] as num?)?.toDouble(),
      totalSale: json['totalSale'] as int?,
      productPrice: (json['productPrice'] as num?)?.toDouble(),
      mainImage: json['mainImage'] as String?,
      productName: json['productName'] as String?,
      order: json['order'] as int?,
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
      numberOfUnit: json['numberOfUnit'] as int?,
      lowStock: json['lowStock'] as String?,
    );

Map<String, dynamic> _$$PlanogramproductImplToJson(
        _$PlanogramproductImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productStock': instance.productStock,
      'totalSale': instance.totalSale,
      'productPrice': instance.productPrice,
      'mainImage': instance.mainImage,
      'productName': instance.productName,
      'order': instance.order,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
      'numberOfUnit': instance.numberOfUnit,
      'lowStock': instance.lowStock,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
