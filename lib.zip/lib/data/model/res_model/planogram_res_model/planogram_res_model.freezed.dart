// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'planogram_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PlanogramResModel _$PlanogramResModelFromJson(Map<String, dynamic> json) {
  return _PlanogramResModel.fromJson(json);
}

/// @nodoc
mixin _$PlanogramResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<PlanogramDatum>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PlanogramResModelCopyWith<PlanogramResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramResModelCopyWith<$Res> {
  factory $PlanogramResModelCopyWith(
          PlanogramResModel value, $Res Function(PlanogramResModel) then) =
      _$PlanogramResModelCopyWithImpl<$Res, PlanogramResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<PlanogramDatum>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$PlanogramResModelCopyWithImpl<$Res, $Val extends PlanogramResModel>
    implements $PlanogramResModelCopyWith<$Res> {
  _$PlanogramResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$PlanogramResModelImplCopyWith<$Res>
    implements $PlanogramResModelCopyWith<$Res> {
  factory _$$PlanogramResModelImplCopyWith(_$PlanogramResModelImpl value,
          $Res Function(_$PlanogramResModelImpl) then) =
      __$$PlanogramResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<PlanogramDatum>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$PlanogramResModelImplCopyWithImpl<$Res>
    extends _$PlanogramResModelCopyWithImpl<$Res, _$PlanogramResModelImpl>
    implements _$$PlanogramResModelImplCopyWith<$Res> {
  __$$PlanogramResModelImplCopyWithImpl(_$PlanogramResModelImpl _value,
      $Res Function(_$PlanogramResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_$PlanogramResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlanogramResModelImpl implements _PlanogramResModel {
  const _$PlanogramResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<PlanogramDatum>? data,
      @JsonKey(name: "metaData") this.metaData,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$PlanogramResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlanogramResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<PlanogramDatum>? _data;
  @override
  @JsonKey(name: "data")
  List<PlanogramDatum>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'PlanogramResModel(status: $status, data: $data, metaData: $metaData, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), metaData, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramResModelImplCopyWith<_$PlanogramResModelImpl> get copyWith =>
      __$$PlanogramResModelImplCopyWithImpl<_$PlanogramResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlanogramResModelImplToJson(
      this,
    );
  }
}

abstract class _PlanogramResModel implements PlanogramResModel {
  const factory _PlanogramResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final List<PlanogramDatum>? data,
          @JsonKey(name: "metaData") final MetaData? metaData,
          @JsonKey(name: "message") final String? message}) =
      _$PlanogramResModelImpl;

  factory _PlanogramResModel.fromJson(Map<String, dynamic> json) =
      _$PlanogramResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<PlanogramDatum>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$PlanogramResModelImplCopyWith<_$PlanogramResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

PlanogramDatum _$PlanogramDatumFromJson(Map<String, dynamic> json) {
  return _PlanogramDatum.fromJson(json);
}

/// @nodoc
mixin _$PlanogramDatum {
  @JsonKey(name: "planogramproducts")
  List<Planogramproduct>? get planogramproducts =>
      throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "planogramName")
  String? get planogramName => throw _privateConstructorUsedError;
  @JsonKey(name: "fromDate")
  DateTime? get fromDate => throw _privateConstructorUsedError;
  @JsonKey(name: "untilDate")
  DateTime? get untilDate => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PlanogramDatumCopyWith<PlanogramDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramDatumCopyWith<$Res> {
  factory $PlanogramDatumCopyWith(
          PlanogramDatum value, $Res Function(PlanogramDatum) then) =
      _$PlanogramDatumCopyWithImpl<$Res, PlanogramDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "planogramproducts")
      List<Planogramproduct>? planogramproducts,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "planogramName") String? planogramName,
      @JsonKey(name: "fromDate") DateTime? fromDate,
      @JsonKey(name: "untilDate") DateTime? untilDate});
}

/// @nodoc
class _$PlanogramDatumCopyWithImpl<$Res, $Val extends PlanogramDatum>
    implements $PlanogramDatumCopyWith<$Res> {
  _$PlanogramDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? planogramproducts = freezed,
    Object? id = freezed,
    Object? planogramName = freezed,
    Object? fromDate = freezed,
    Object? untilDate = freezed,
  }) {
    return _then(_value.copyWith(
      planogramproducts: freezed == planogramproducts
          ? _value.planogramproducts
          : planogramproducts // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      planogramName: freezed == planogramName
          ? _value.planogramName
          : planogramName // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      untilDate: freezed == untilDate
          ? _value.untilDate
          : untilDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PlanogramDatumImplCopyWith<$Res>
    implements $PlanogramDatumCopyWith<$Res> {
  factory _$$PlanogramDatumImplCopyWith(_$PlanogramDatumImpl value,
          $Res Function(_$PlanogramDatumImpl) then) =
      __$$PlanogramDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "planogramproducts")
      List<Planogramproduct>? planogramproducts,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "planogramName") String? planogramName,
      @JsonKey(name: "fromDate") DateTime? fromDate,
      @JsonKey(name: "untilDate") DateTime? untilDate});
}

/// @nodoc
class __$$PlanogramDatumImplCopyWithImpl<$Res>
    extends _$PlanogramDatumCopyWithImpl<$Res, _$PlanogramDatumImpl>
    implements _$$PlanogramDatumImplCopyWith<$Res> {
  __$$PlanogramDatumImplCopyWithImpl(
      _$PlanogramDatumImpl _value, $Res Function(_$PlanogramDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? planogramproducts = freezed,
    Object? id = freezed,
    Object? planogramName = freezed,
    Object? fromDate = freezed,
    Object? untilDate = freezed,
  }) {
    return _then(_$PlanogramDatumImpl(
      planogramproducts: freezed == planogramproducts
          ? _value._planogramproducts
          : planogramproducts // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      planogramName: freezed == planogramName
          ? _value.planogramName
          : planogramName // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      untilDate: freezed == untilDate
          ? _value.untilDate
          : untilDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlanogramDatumImpl implements _PlanogramDatum {
  const _$PlanogramDatumImpl(
      {@JsonKey(name: "planogramproducts")
      final List<Planogramproduct>? planogramproducts,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "planogramName") this.planogramName,
      @JsonKey(name: "fromDate") this.fromDate,
      @JsonKey(name: "untilDate") this.untilDate})
      : _planogramproducts = planogramproducts;

  factory _$PlanogramDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlanogramDatumImplFromJson(json);

  final List<Planogramproduct>? _planogramproducts;
  @override
  @JsonKey(name: "planogramproducts")
  List<Planogramproduct>? get planogramproducts {
    final value = _planogramproducts;
    if (value == null) return null;
    if (_planogramproducts is EqualUnmodifiableListView)
      return _planogramproducts;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "planogramName")
  final String? planogramName;
  @override
  @JsonKey(name: "fromDate")
  final DateTime? fromDate;
  @override
  @JsonKey(name: "untilDate")
  final DateTime? untilDate;

  @override
  String toString() {
    return 'PlanogramDatum(planogramproducts: $planogramproducts, id: $id, planogramName: $planogramName, fromDate: $fromDate, untilDate: $untilDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramDatumImpl &&
            const DeepCollectionEquality()
                .equals(other._planogramproducts, _planogramproducts) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.planogramName, planogramName) ||
                other.planogramName == planogramName) &&
            (identical(other.fromDate, fromDate) ||
                other.fromDate == fromDate) &&
            (identical(other.untilDate, untilDate) ||
                other.untilDate == untilDate));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_planogramproducts),
      id,
      planogramName,
      fromDate,
      untilDate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramDatumImplCopyWith<_$PlanogramDatumImpl> get copyWith =>
      __$$PlanogramDatumImplCopyWithImpl<_$PlanogramDatumImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlanogramDatumImplToJson(
      this,
    );
  }
}

abstract class _PlanogramDatum implements PlanogramDatum {
  const factory _PlanogramDatum(
          {@JsonKey(name: "planogramproducts")
          final List<Planogramproduct>? planogramproducts,
          @JsonKey(name: "_id") final String? id,
          @JsonKey(name: "planogramName") final String? planogramName,
          @JsonKey(name: "fromDate") final DateTime? fromDate,
          @JsonKey(name: "untilDate") final DateTime? untilDate}) =
      _$PlanogramDatumImpl;

  factory _PlanogramDatum.fromJson(Map<String, dynamic> json) =
      _$PlanogramDatumImpl.fromJson;

  @override
  @JsonKey(name: "planogramproducts")
  List<Planogramproduct>? get planogramproducts;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "planogramName")
  String? get planogramName;
  @override
  @JsonKey(name: "fromDate")
  DateTime? get fromDate;
  @override
  @JsonKey(name: "untilDate")
  DateTime? get untilDate;
  @override
  @JsonKey(ignore: true)
  _$$PlanogramDatumImplCopyWith<_$PlanogramDatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Planogramproduct _$PlanogramproductFromJson(Map<String, dynamic> json) {
  return _Planogramproduct.fromJson(json);
}

/// @nodoc
mixin _$Planogramproduct {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  double? get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "totalSale")
  int? get totalSale => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  double? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;
  int? get numberOfUnit => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PlanogramproductCopyWith<Planogramproduct> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramproductCopyWith<$Res> {
  factory $PlanogramproductCopyWith(
          Planogramproduct value, $Res Function(Planogramproduct) then) =
      _$PlanogramproductCopyWithImpl<$Res, Planogramproduct>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productStock") double? productStock,
      @JsonKey(name: "totalSale") int? totalSale,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      int? numberOfUnit,
      String? lowStock});
}

/// @nodoc
class _$PlanogramproductCopyWithImpl<$Res, $Val extends Planogramproduct>
    implements $PlanogramproductCopyWith<$Res> {
  _$PlanogramproductCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? totalSale = freezed,
    Object? productPrice = freezed,
    Object? mainImage = freezed,
    Object? productName = freezed,
    Object? order = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? numberOfUnit = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PlanogramproductImplCopyWith<$Res>
    implements $PlanogramproductCopyWith<$Res> {
  factory _$$PlanogramproductImplCopyWith(_$PlanogramproductImpl value,
          $Res Function(_$PlanogramproductImpl) then) =
      __$$PlanogramproductImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productStock") double? productStock,
      @JsonKey(name: "totalSale") int? totalSale,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      int? numberOfUnit,
      String? lowStock});
}

/// @nodoc
class __$$PlanogramproductImplCopyWithImpl<$Res>
    extends _$PlanogramproductCopyWithImpl<$Res, _$PlanogramproductImpl>
    implements _$$PlanogramproductImplCopyWith<$Res> {
  __$$PlanogramproductImplCopyWithImpl(_$PlanogramproductImpl _value,
      $Res Function(_$PlanogramproductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? totalSale = freezed,
    Object? productPrice = freezed,
    Object? mainImage = freezed,
    Object? productName = freezed,
    Object? order = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? numberOfUnit = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_$PlanogramproductImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlanogramproductImpl implements _Planogramproduct {
  const _$PlanogramproductImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "totalSale") this.totalSale,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "order") this.order,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim,
      this.numberOfUnit,
      this.lowStock});

  factory _$PlanogramproductImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlanogramproductImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productStock")
  final double? productStock;
  @override
  @JsonKey(name: "totalSale")
  final int? totalSale;
  @override
  @JsonKey(name: "productPrice")
  final double? productPrice;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "order")
  final int? order;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;
  @override
  final int? numberOfUnit;
  @override
  final String? lowStock;

  @override
  String toString() {
    return 'Planogramproduct(id: $id, productStock: $productStock, totalSale: $totalSale, productPrice: $productPrice, mainImage: $mainImage, productName: $productName, order: $order, isPesach: $isPesach, nmMashlim: $nmMashlim, numberOfUnit: $numberOfUnit, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramproductImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.totalSale, totalSale) ||
                other.totalSale == totalSale) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.order, order) || other.order == order) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      productStock,
      totalSale,
      productPrice,
      mainImage,
      productName,
      order,
      isPesach,
      nmMashlim,
      numberOfUnit,
      lowStock);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramproductImplCopyWith<_$PlanogramproductImpl> get copyWith =>
      __$$PlanogramproductImplCopyWithImpl<_$PlanogramproductImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlanogramproductImplToJson(
      this,
    );
  }
}

abstract class _Planogramproduct implements Planogramproduct {
  const factory _Planogramproduct(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "productStock") final double? productStock,
      @JsonKey(name: "totalSale") final int? totalSale,
      @JsonKey(name: "productPrice") final double? productPrice,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "order") final int? order,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim") final String? nmMashlim,
      final int? numberOfUnit,
      final String? lowStock}) = _$PlanogramproductImpl;

  factory _Planogramproduct.fromJson(Map<String, dynamic> json) =
      _$PlanogramproductImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productStock")
  double? get productStock;
  @override
  @JsonKey(name: "totalSale")
  int? get totalSale;
  @override
  @JsonKey(name: "productPrice")
  double? get productPrice;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  int? get numberOfUnit;
  @override
  String? get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$PlanogramproductImplCopyWith<_$PlanogramproductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalFilteredCount") this.totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  final int? totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
          {@JsonKey(name: "currentPage") final int? currentPage,
          @JsonKey(name: "totalFilteredCount") final int? totalFilteredCount,
          @JsonKey(name: "totalFilteredPage") final int? totalFilteredPage}) =
      _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
