// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'categories_permission_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CategoriesPermissionResModel _$CategoriesPermissionResModelFromJson(
    Map<String, dynamic> json) {
  return _CategoriesPermissionResModel.fromJson(json);
}

/// @nodoc
mixin _$CategoriesPermissionResModel {
  @JsonKey(name: "data")
  List<categoriesPermission>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CategoriesPermissionResModelCopyWith<CategoriesPermissionResModel>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CategoriesPermissionResModelCopyWith<$Res> {
  factory $CategoriesPermissionResModelCopyWith(
          CategoriesPermissionResModel value,
          $Res Function(CategoriesPermissionResModel) then) =
      _$CategoriesPermissionResModelCopyWithImpl<$Res,
          CategoriesPermissionResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "data") List<categoriesPermission>? data,
      @JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class _$CategoriesPermissionResModelCopyWithImpl<$Res,
        $Val extends CategoriesPermissionResModel>
    implements $CategoriesPermissionResModelCopyWith<$Res> {
  _$CategoriesPermissionResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = freezed,
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<categoriesPermission>?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CategoriesPermissionResModelImplCopyWith<$Res>
    implements $CategoriesPermissionResModelCopyWith<$Res> {
  factory _$$CategoriesPermissionResModelImplCopyWith(
          _$CategoriesPermissionResModelImpl value,
          $Res Function(_$CategoriesPermissionResModelImpl) then) =
      __$$CategoriesPermissionResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "data") List<categoriesPermission>? data,
      @JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class __$$CategoriesPermissionResModelImplCopyWithImpl<$Res>
    extends _$CategoriesPermissionResModelCopyWithImpl<$Res,
        _$CategoriesPermissionResModelImpl>
    implements _$$CategoriesPermissionResModelImplCopyWith<$Res> {
  __$$CategoriesPermissionResModelImplCopyWithImpl(
      _$CategoriesPermissionResModelImpl _value,
      $Res Function(_$CategoriesPermissionResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = freezed,
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_$CategoriesPermissionResModelImpl(
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<categoriesPermission>?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CategoriesPermissionResModelImpl
    implements _CategoriesPermissionResModel {
  const _$CategoriesPermissionResModelImpl(
      {@JsonKey(name: "data") final List<categoriesPermission>? data,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$CategoriesPermissionResModelImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$CategoriesPermissionResModelImplFromJson(json);

  final List<categoriesPermission>? _data;
  @override
  @JsonKey(name: "data")
  List<categoriesPermission>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'CategoriesPermissionResModel(data: $data, status: $status, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CategoriesPermissionResModelImpl &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_data), status, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CategoriesPermissionResModelImplCopyWith<
          _$CategoriesPermissionResModelImpl>
      get copyWith => __$$CategoriesPermissionResModelImplCopyWithImpl<
          _$CategoriesPermissionResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CategoriesPermissionResModelImplToJson(
      this,
    );
  }
}

abstract class _CategoriesPermissionResModel
    implements CategoriesPermissionResModel {
  const factory _CategoriesPermissionResModel(
          {@JsonKey(name: "data") final List<categoriesPermission>? data,
          @JsonKey(name: "status") final int? status,
          @JsonKey(name: "message") final String? message}) =
      _$CategoriesPermissionResModelImpl;

  factory _CategoriesPermissionResModel.fromJson(Map<String, dynamic> json) =
      _$CategoriesPermissionResModelImpl.fromJson;

  @override
  @JsonKey(name: "data")
  List<categoriesPermission>? get data;
  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$CategoriesPermissionResModelImplCopyWith<
          _$CategoriesPermissionResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

categoriesPermission _$categoriesPermissionFromJson(Map<String, dynamic> json) {
  return _categoriesPermission.fromJson(json);
}

/// @nodoc
mixin _$categoriesPermission {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryId")
  String? get categoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "isAllowed")
  bool? get isAllowed => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategories")
  List<SubCategory>? get subCategories => throw _privateConstructorUsedError;
  @JsonKey(name: "category")
  Category? get category => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $categoriesPermissionCopyWith<categoriesPermission> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $categoriesPermissionCopyWith<$Res> {
  factory $categoriesPermissionCopyWith(categoriesPermission value,
          $Res Function(categoriesPermission) then) =
      _$categoriesPermissionCopyWithImpl<$Res, categoriesPermission>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryId") String? categoryId,
      @JsonKey(name: "isAllowed") bool? isAllowed,
      @JsonKey(name: "subCategories") List<SubCategory>? subCategories,
      @JsonKey(name: "category") Category? category});

  $CategoryCopyWith<$Res>? get category;
}

/// @nodoc
class _$categoriesPermissionCopyWithImpl<$Res,
        $Val extends categoriesPermission>
    implements $categoriesPermissionCopyWith<$Res> {
  _$categoriesPermissionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryId = freezed,
    Object? isAllowed = freezed,
    Object? subCategories = freezed,
    Object? category = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      isAllowed: freezed == isAllowed
          ? _value.isAllowed
          : isAllowed // ignore: cast_nullable_to_non_nullable
              as bool?,
      subCategories: freezed == subCategories
          ? _value.subCategories
          : subCategories // ignore: cast_nullable_to_non_nullable
              as List<SubCategory>?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as Category?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $CategoryCopyWith<$Res>? get category {
    if (_value.category == null) {
      return null;
    }

    return $CategoryCopyWith<$Res>(_value.category!, (value) {
      return _then(_value.copyWith(category: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$categoriesPermissionImplCopyWith<$Res>
    implements $categoriesPermissionCopyWith<$Res> {
  factory _$$categoriesPermissionImplCopyWith(_$categoriesPermissionImpl value,
          $Res Function(_$categoriesPermissionImpl) then) =
      __$$categoriesPermissionImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryId") String? categoryId,
      @JsonKey(name: "isAllowed") bool? isAllowed,
      @JsonKey(name: "subCategories") List<SubCategory>? subCategories,
      @JsonKey(name: "category") Category? category});

  @override
  $CategoryCopyWith<$Res>? get category;
}

/// @nodoc
class __$$categoriesPermissionImplCopyWithImpl<$Res>
    extends _$categoriesPermissionCopyWithImpl<$Res, _$categoriesPermissionImpl>
    implements _$$categoriesPermissionImplCopyWith<$Res> {
  __$$categoriesPermissionImplCopyWithImpl(_$categoriesPermissionImpl _value,
      $Res Function(_$categoriesPermissionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryId = freezed,
    Object? isAllowed = freezed,
    Object? subCategories = freezed,
    Object? category = freezed,
  }) {
    return _then(_$categoriesPermissionImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      isAllowed: freezed == isAllowed
          ? _value.isAllowed
          : isAllowed // ignore: cast_nullable_to_non_nullable
              as bool?,
      subCategories: freezed == subCategories
          ? _value.subCategories
          : subCategories // ignore: cast_nullable_to_non_nullable
              as List<SubCategory>?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as Category?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$categoriesPermissionImpl implements _categoriesPermission {
  const _$categoriesPermissionImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "categoryId") this.categoryId,
      @JsonKey(name: "isAllowed") this.isAllowed,
      @JsonKey(name: "subCategories") this.subCategories,
      @JsonKey(name: "category") this.category});

  factory _$categoriesPermissionImpl.fromJson(Map<String, dynamic> json) =>
      _$$categoriesPermissionImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "categoryId")
  final String? categoryId;
  @override
  @JsonKey(name: "isAllowed")
  final bool? isAllowed;
  @override
  @JsonKey(name: "subCategories")
  final List<SubCategory>? subCategories;
  @override
  @JsonKey(name: "category")
  final Category? category;

  @override
  String toString() {
    return 'categoriesPermission(id: $id, categoryId: $categoryId, isAllowed: $isAllowed, subCategories: $subCategories, category: $category)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$categoriesPermissionImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.categoryId, categoryId) ||
                other.categoryId == categoryId) &&
            (identical(other.isAllowed, isAllowed) ||
                other.isAllowed == isAllowed) &&
            const DeepCollectionEquality()
                .equals(other.subCategories, subCategories) &&
            (identical(other.category, category) ||
                other.category == category));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, categoryId, isAllowed,
      const DeepCollectionEquality().hash(subCategories), category);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$categoriesPermissionImplCopyWith<_$categoriesPermissionImpl>
      get copyWith =>
          __$$categoriesPermissionImplCopyWithImpl<_$categoriesPermissionImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$categoriesPermissionImplToJson(
      this,
    );
  }
}

abstract class _categoriesPermission implements categoriesPermission {
  const factory _categoriesPermission(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "categoryId") final String? categoryId,
      @JsonKey(name: "isAllowed") final bool? isAllowed,
      @JsonKey(name: "subCategories") final List<SubCategory>? subCategories,
      @JsonKey(name: "category")
      final Category? category}) = _$categoriesPermissionImpl;

  factory _categoriesPermission.fromJson(Map<String, dynamic> json) =
      _$categoriesPermissionImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "categoryId")
  String? get categoryId;
  @override
  @JsonKey(name: "isAllowed")
  bool? get isAllowed;
  @override
  @JsonKey(name: "subCategories")
  List<SubCategory>? get subCategories;
  @override
  @JsonKey(name: "category")
  Category? get category;
  @override
  @JsonKey(ignore: true)
  _$$categoriesPermissionImplCopyWith<_$categoriesPermissionImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Category _$CategoryFromJson(Map<String, dynamic> json) {
  return _Category.fromJson(json);
}

/// @nodoc
mixin _$Category {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryName")
  String? get categoryName => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryImage")
  String? get categoryImage => throw _privateConstructorUsedError;
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryNumber")
  int? get categoryNumber => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CategoryCopyWith<Category> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CategoryCopyWith<$Res> {
  factory $CategoryCopyWith(Category value, $Res Function(Category) then) =
      _$CategoryCopyWithImpl<$Res, Category>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryName") String? categoryName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "categoryImage") String? categoryImage,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "categoryNumber") int? categoryNumber});
}

/// @nodoc
class _$CategoryCopyWithImpl<$Res, $Val extends Category>
    implements $CategoryCopyWith<$Res> {
  _$CategoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? categoryImage = freezed,
    Object? isHomePreference = freezed,
    Object? order = freezed,
    Object? isDeleted = freezed,
    Object? categoryNumber = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryImage: freezed == categoryImage
          ? _value.categoryImage
          : categoryImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      categoryNumber: freezed == categoryNumber
          ? _value.categoryNumber
          : categoryNumber // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CategoryImplCopyWith<$Res>
    implements $CategoryCopyWith<$Res> {
  factory _$$CategoryImplCopyWith(
          _$CategoryImpl value, $Res Function(_$CategoryImpl) then) =
      __$$CategoryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryName") String? categoryName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "categoryImage") String? categoryImage,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "categoryNumber") int? categoryNumber});
}

/// @nodoc
class __$$CategoryImplCopyWithImpl<$Res>
    extends _$CategoryCopyWithImpl<$Res, _$CategoryImpl>
    implements _$$CategoryImplCopyWith<$Res> {
  __$$CategoryImplCopyWithImpl(
      _$CategoryImpl _value, $Res Function(_$CategoryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? categoryImage = freezed,
    Object? isHomePreference = freezed,
    Object? order = freezed,
    Object? isDeleted = freezed,
    Object? categoryNumber = freezed,
  }) {
    return _then(_$CategoryImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryImage: freezed == categoryImage
          ? _value.categoryImage
          : categoryImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      categoryNumber: freezed == categoryNumber
          ? _value.categoryNumber
          : categoryNumber // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CategoryImpl implements _Category {
  const _$CategoryImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "categoryName") this.categoryName,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "categoryImage") this.categoryImage,
      @JsonKey(name: "isHomePreference") this.isHomePreference,
      @JsonKey(name: "order") this.order,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "categoryNumber") this.categoryNumber});

  factory _$CategoryImpl.fromJson(Map<String, dynamic> json) =>
      _$$CategoryImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "categoryName")
  final String? categoryName;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "categoryImage")
  final String? categoryImage;
  @override
  @JsonKey(name: "isHomePreference")
  final bool? isHomePreference;
  @override
  @JsonKey(name: "order")
  final int? order;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "categoryNumber")
  final int? categoryNumber;

  @override
  String toString() {
    return 'Category(id: $id, categoryName: $categoryName, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, categoryImage: $categoryImage, isHomePreference: $isHomePreference, order: $order, isDeleted: $isDeleted, categoryNumber: $categoryNumber)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CategoryImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.categoryName, categoryName) ||
                other.categoryName == categoryName) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.categoryImage, categoryImage) ||
                other.categoryImage == categoryImage) &&
            (identical(other.isHomePreference, isHomePreference) ||
                other.isHomePreference == isHomePreference) &&
            (identical(other.order, order) || other.order == order) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.categoryNumber, categoryNumber) ||
                other.categoryNumber == categoryNumber));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      categoryName,
      createdAt,
      updatedAt,
      v,
      categoryImage,
      isHomePreference,
      order,
      isDeleted,
      categoryNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CategoryImplCopyWith<_$CategoryImpl> get copyWith =>
      __$$CategoryImplCopyWithImpl<_$CategoryImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CategoryImplToJson(
      this,
    );
  }
}

abstract class _Category implements Category {
  const factory _Category(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "categoryName") final String? categoryName,
          @JsonKey(name: "createdAt") final String? createdAt,
          @JsonKey(name: "updatedAt") final String? updatedAt,
          @JsonKey(name: "__v") final int? v,
          @JsonKey(name: "categoryImage") final String? categoryImage,
          @JsonKey(name: "isHomePreference") final bool? isHomePreference,
          @JsonKey(name: "order") final int? order,
          @JsonKey(name: "isDeleted") final bool? isDeleted,
          @JsonKey(name: "categoryNumber") final int? categoryNumber}) =
      _$CategoryImpl;

  factory _Category.fromJson(Map<String, dynamic> json) =
      _$CategoryImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "categoryName")
  String? get categoryName;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "categoryImage")
  String? get categoryImage;
  @override
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "categoryNumber")
  int? get categoryNumber;
  @override
  @JsonKey(ignore: true)
  _$$CategoryImplCopyWith<_$CategoryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SubCategory _$SubCategoryFromJson(Map<String, dynamic> json) {
  return _SubCategory.fromJson(json);
}

/// @nodoc
mixin _$SubCategory {
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "isAllowed")
  bool? get isAllowed => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryData")
  SubCategoryData? get subCategoryData => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SubCategoryCopyWith<SubCategory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubCategoryCopyWith<$Res> {
  factory $SubCategoryCopyWith(
          SubCategory value, $Res Function(SubCategory) then) =
      _$SubCategoryCopyWithImpl<$Res, SubCategory>;
  @useResult
  $Res call(
      {@JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "isAllowed") bool? isAllowed,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryData") SubCategoryData? subCategoryData});

  $SubCategoryDataCopyWith<$Res>? get subCategoryData;
}

/// @nodoc
class _$SubCategoryCopyWithImpl<$Res, $Val extends SubCategory>
    implements $SubCategoryCopyWith<$Res> {
  _$SubCategoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? subCategoryId = freezed,
    Object? isAllowed = freezed,
    Object? id = freezed,
    Object? subCategoryData = freezed,
  }) {
    return _then(_value.copyWith(
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      isAllowed: freezed == isAllowed
          ? _value.isAllowed
          : isAllowed // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryData: freezed == subCategoryData
          ? _value.subCategoryData
          : subCategoryData // ignore: cast_nullable_to_non_nullable
              as SubCategoryData?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $SubCategoryDataCopyWith<$Res>? get subCategoryData {
    if (_value.subCategoryData == null) {
      return null;
    }

    return $SubCategoryDataCopyWith<$Res>(_value.subCategoryData!, (value) {
      return _then(_value.copyWith(subCategoryData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SubCategoryImplCopyWith<$Res>
    implements $SubCategoryCopyWith<$Res> {
  factory _$$SubCategoryImplCopyWith(
          _$SubCategoryImpl value, $Res Function(_$SubCategoryImpl) then) =
      __$$SubCategoryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "isAllowed") bool? isAllowed,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryData") SubCategoryData? subCategoryData});

  @override
  $SubCategoryDataCopyWith<$Res>? get subCategoryData;
}

/// @nodoc
class __$$SubCategoryImplCopyWithImpl<$Res>
    extends _$SubCategoryCopyWithImpl<$Res, _$SubCategoryImpl>
    implements _$$SubCategoryImplCopyWith<$Res> {
  __$$SubCategoryImplCopyWithImpl(
      _$SubCategoryImpl _value, $Res Function(_$SubCategoryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? subCategoryId = freezed,
    Object? isAllowed = freezed,
    Object? id = freezed,
    Object? subCategoryData = freezed,
  }) {
    return _then(_$SubCategoryImpl(
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      isAllowed: freezed == isAllowed
          ? _value.isAllowed
          : isAllowed // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryData: freezed == subCategoryData
          ? _value.subCategoryData
          : subCategoryData // ignore: cast_nullable_to_non_nullable
              as SubCategoryData?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SubCategoryImpl implements _SubCategory {
  const _$SubCategoryImpl(
      {@JsonKey(name: "subCategoryId") this.subCategoryId,
      @JsonKey(name: "isAllowed") this.isAllowed,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "subCategoryData") this.subCategoryData});

  factory _$SubCategoryImpl.fromJson(Map<String, dynamic> json) =>
      _$$SubCategoryImplFromJson(json);

  @override
  @JsonKey(name: "subCategoryId")
  final String? subCategoryId;
  @override
  @JsonKey(name: "isAllowed")
  final bool? isAllowed;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "subCategoryData")
  final SubCategoryData? subCategoryData;

  @override
  String toString() {
    return 'SubCategory(subCategoryId: $subCategoryId, isAllowed: $isAllowed, id: $id, subCategoryData: $subCategoryData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubCategoryImpl &&
            (identical(other.subCategoryId, subCategoryId) ||
                other.subCategoryId == subCategoryId) &&
            (identical(other.isAllowed, isAllowed) ||
                other.isAllowed == isAllowed) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.subCategoryData, subCategoryData) ||
                other.subCategoryData == subCategoryData));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, subCategoryId, isAllowed, id, subCategoryData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubCategoryImplCopyWith<_$SubCategoryImpl> get copyWith =>
      __$$SubCategoryImplCopyWithImpl<_$SubCategoryImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SubCategoryImplToJson(
      this,
    );
  }
}

abstract class _SubCategory implements SubCategory {
  const factory _SubCategory(
      {@JsonKey(name: "subCategoryId") final String? subCategoryId,
      @JsonKey(name: "isAllowed") final bool? isAllowed,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "subCategoryData")
      final SubCategoryData? subCategoryData}) = _$SubCategoryImpl;

  factory _SubCategory.fromJson(Map<String, dynamic> json) =
      _$SubCategoryImpl.fromJson;

  @override
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId;
  @override
  @JsonKey(name: "isAllowed")
  bool? get isAllowed;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "subCategoryData")
  SubCategoryData? get subCategoryData;
  @override
  @JsonKey(ignore: true)
  _$$SubCategoryImplCopyWith<_$SubCategoryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SubCategoryData _$SubCategoryDataFromJson(Map<String, dynamic> json) {
  return _SubCategoryData.fromJson(json);
}

/// @nodoc
mixin _$SubCategoryData {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryName")
  String? get subCategoryName => throw _privateConstructorUsedError;
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryNumber")
  int? get subCategoryNumber => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SubCategoryDataCopyWith<SubCategoryData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubCategoryDataCopyWith<$Res> {
  factory $SubCategoryDataCopyWith(
          SubCategoryData value, $Res Function(SubCategoryData) then) =
      _$SubCategoryDataCopyWithImpl<$Res, SubCategoryData>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryName") String? subCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "subCategoryNumber") int? subCategoryNumber});
}

/// @nodoc
class _$SubCategoryDataCopyWithImpl<$Res, $Val extends SubCategoryData>
    implements $SubCategoryDataCopyWith<$Res> {
  _$SubCategoryDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
    Object? subCategoryNumber = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      subCategoryNumber: freezed == subCategoryNumber
          ? _value.subCategoryNumber
          : subCategoryNumber // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubCategoryDataImplCopyWith<$Res>
    implements $SubCategoryDataCopyWith<$Res> {
  factory _$$SubCategoryDataImplCopyWith(_$SubCategoryDataImpl value,
          $Res Function(_$SubCategoryDataImpl) then) =
      __$$SubCategoryDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryName") String? subCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "subCategoryNumber") int? subCategoryNumber});
}

/// @nodoc
class __$$SubCategoryDataImplCopyWithImpl<$Res>
    extends _$SubCategoryDataCopyWithImpl<$Res, _$SubCategoryDataImpl>
    implements _$$SubCategoryDataImplCopyWith<$Res> {
  __$$SubCategoryDataImplCopyWithImpl(
      _$SubCategoryDataImpl _value, $Res Function(_$SubCategoryDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
    Object? subCategoryNumber = freezed,
  }) {
    return _then(_$SubCategoryDataImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      subCategoryNumber: freezed == subCategoryNumber
          ? _value.subCategoryNumber
          : subCategoryNumber // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SubCategoryDataImpl implements _SubCategoryData {
  const _$SubCategoryDataImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "subCategoryName") this.subCategoryName,
      @JsonKey(name: "parentCategoryId") this.parentCategoryId,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "subCategoryNumber") this.subCategoryNumber});

  factory _$SubCategoryDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$SubCategoryDataImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "subCategoryName")
  final String? subCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  final String? parentCategoryId;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "subCategoryNumber")
  final int? subCategoryNumber;

  @override
  String toString() {
    return 'SubCategoryData(id: $id, subCategoryName: $subCategoryName, parentCategoryId: $parentCategoryId, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, isDeleted: $isDeleted, subCategoryNumber: $subCategoryNumber)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubCategoryDataImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.subCategoryName, subCategoryName) ||
                other.subCategoryName == subCategoryName) &&
            (identical(other.parentCategoryId, parentCategoryId) ||
                other.parentCategoryId == parentCategoryId) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.subCategoryNumber, subCategoryNumber) ||
                other.subCategoryNumber == subCategoryNumber));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, subCategoryName,
      parentCategoryId, createdAt, updatedAt, v, isDeleted, subCategoryNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubCategoryDataImplCopyWith<_$SubCategoryDataImpl> get copyWith =>
      __$$SubCategoryDataImplCopyWithImpl<_$SubCategoryDataImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SubCategoryDataImplToJson(
      this,
    );
  }
}

abstract class _SubCategoryData implements SubCategoryData {
  const factory _SubCategoryData(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "subCategoryName") final String? subCategoryName,
          @JsonKey(name: "parentCategoryId") final String? parentCategoryId,
          @JsonKey(name: "createdAt") final String? createdAt,
          @JsonKey(name: "updatedAt") final String? updatedAt,
          @JsonKey(name: "__v") final int? v,
          @JsonKey(name: "isDeleted") final bool? isDeleted,
          @JsonKey(name: "subCategoryNumber") final int? subCategoryNumber}) =
      _$SubCategoryDataImpl;

  factory _SubCategoryData.fromJson(Map<String, dynamic> json) =
      _$SubCategoryDataImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "subCategoryName")
  String? get subCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "subCategoryNumber")
  int? get subCategoryNumber;
  @override
  @JsonKey(ignore: true)
  _$$SubCategoryDataImplCopyWith<_$SubCategoryDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
