// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'categories_permission_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CategoriesPermissionResModelImpl _$$CategoriesPermissionResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$CategoriesPermissionResModelImpl(
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => categoriesPermission.fromJson(e as Map<String, dynamic>))
          .toList(),
      status: json['status'] as int?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$CategoriesPermissionResModelImplToJson(
        _$CategoriesPermissionResModelImpl instance) =>
    <String, dynamic>{
      'data': instance.data,
      'status': instance.status,
      'message': instance.message,
    };

_$categoriesPermissionImpl _$$categoriesPermissionImplFromJson(
        Map<String, dynamic> json) =>
    _$categoriesPermissionImpl(
      id: json['_id'] as String?,
      categoryId: json['categoryId'] as String?,
      isAllowed: json['isAllowed'] as bool?,
      subCategories: (json['subCategories'] as List<dynamic>?)
          ?.map((e) => SubCategory.fromJson(e as Map<String, dynamic>))
          .toList(),
      category: json['category'] == null
          ? null
          : Category.fromJson(json['category'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$categoriesPermissionImplToJson(
        _$categoriesPermissionImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'categoryId': instance.categoryId,
      'isAllowed': instance.isAllowed,
      'subCategories': instance.subCategories,
      'category': instance.category,
    };

_$CategoryImpl _$$CategoryImplFromJson(Map<String, dynamic> json) =>
    _$CategoryImpl(
      id: json['_id'] as String?,
      categoryName: json['categoryName'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      categoryImage: json['categoryImage'] as String?,
      isHomePreference: json['isHomePreference'] as bool?,
      order: json['order'] as int?,
      isDeleted: json['isDeleted'] as bool?,
      categoryNumber: json['categoryNumber'] as int?,
    );

Map<String, dynamic> _$$CategoryImplToJson(_$CategoryImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'categoryName': instance.categoryName,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'categoryImage': instance.categoryImage,
      'isHomePreference': instance.isHomePreference,
      'order': instance.order,
      'isDeleted': instance.isDeleted,
      'categoryNumber': instance.categoryNumber,
    };

_$SubCategoryImpl _$$SubCategoryImplFromJson(Map<String, dynamic> json) =>
    _$SubCategoryImpl(
      subCategoryId: json['subCategoryId'] as String?,
      isAllowed: json['isAllowed'] as bool?,
      id: json['_id'] as String?,
      subCategoryData: json['subCategoryData'] == null
          ? null
          : SubCategoryData.fromJson(
              json['subCategoryData'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$SubCategoryImplToJson(_$SubCategoryImpl instance) =>
    <String, dynamic>{
      'subCategoryId': instance.subCategoryId,
      'isAllowed': instance.isAllowed,
      '_id': instance.id,
      'subCategoryData': instance.subCategoryData,
    };

_$SubCategoryDataImpl _$$SubCategoryDataImplFromJson(
        Map<String, dynamic> json) =>
    _$SubCategoryDataImpl(
      id: json['_id'] as String?,
      subCategoryName: json['subCategoryName'] as String?,
      parentCategoryId: json['parentCategoryId'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      isDeleted: json['isDeleted'] as bool?,
      subCategoryNumber: json['subCategoryNumber'] as int?,
    );

Map<String, dynamic> _$$SubCategoryDataImplToJson(
        _$SubCategoryDataImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'subCategoryName': instance.subCategoryName,
      'parentCategoryId': instance.parentCategoryId,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'isDeleted': instance.isDeleted,
      'subCategoryNumber': instance.subCategoryNumber,
    };
