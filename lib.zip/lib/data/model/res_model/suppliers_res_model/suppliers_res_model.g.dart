// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'suppliers_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SuppliersResModelImpl _$$SuppliersResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$SuppliersResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => Datum.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$SuppliersResModelImplToJson(
        _$SuppliersResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$DatumImpl _$$DatumImplFromJson(Map<String, dynamic> json) => _$DatumImpl(
      id: json['_id'] as String?,
      email: json['email'] as String?,
      password: json['password'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      address: json['address'] as String?,
      cityId: json['cityId'] as String?,
      contactName: json['contactName'] as String?,
      statusId: json['statusId'] as String?,
      logo: json['logo'] as String?,
      adminTypeId: json['adminTypeId'] as String?,
      supplierDetail: json['supplierDetail'] == null
          ? null
          : SupplierDetail.fromJson(
              json['supplierDetail'] as Map<String, dynamic>),
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      status: json['status'] == null
          ? null
          : Status.fromJson(json['status'] as Map<String, dynamic>),
      fromDate: json['fromDate'],
      lastSeen: json['lastSeen'] as String?,
    );

Map<String, dynamic> _$$DatumImplToJson(_$DatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'email': instance.email,
      'password': instance.password,
      'phoneNumber': instance.phoneNumber,
      'address': instance.address,
      'cityId': instance.cityId,
      'contactName': instance.contactName,
      'statusId': instance.statusId,
      'logo': instance.logo,
      'adminTypeId': instance.adminTypeId,
      'supplierDetail': instance.supplierDetail,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'isDeleted': instance.isDeleted,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'status': instance.status,
      'fromDate': instance.fromDate,
      'lastSeen': instance.lastSeen,
    };

_$StatusImpl _$$StatusImplFromJson(Map<String, dynamic> json) => _$StatusImpl(
      id: json['_id'] as String?,
      statusName: json['statusName'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$StatusImplToJson(_$StatusImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'statusName': instance.statusName,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
    };

_$SupplierDetailImpl _$$SupplierDetailImplFromJson(Map<String, dynamic> json) =>
    _$SupplierDetailImpl(
      companyIdNumber: json['companyIdNumber'] as int?,
      companyName: json['companyName'] as String?,
      suppliersTypeId: json['suppliersTypeId'] as String?,
      hasImport: json['hasImport'] as bool?,
      hasLogistics: json['hasLogistics'] as bool?,
      hasDistribution: json['hasDistribution'] as bool?,
      categoriesIds: (json['categoriesIds'] as List<dynamic>?)
          ?.map((e) => e as String?)
          .toList(),
      suplierPolicy: (json['suplierPolicy'] as List<dynamic>?)
          ?.map((e) => SuplierPolicy.fromJson(e as Map<String, dynamic>))
          .toList(),
      hasDistributionPolicy: json['hasDistributionPolicy'] as bool?,
      isHomePreference: json['isHomePreference'] as bool?,
      id: json['_id'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      totalIncome: json['totalIncome'] as int?,
      incomeByThisMonth: json['incomeByThisMonth'] as int?,
    );

Map<String, dynamic> _$$SupplierDetailImplToJson(
        _$SupplierDetailImpl instance) =>
    <String, dynamic>{
      'companyIdNumber': instance.companyIdNumber,
      'companyName': instance.companyName,
      'suppliersTypeId': instance.suppliersTypeId,
      'hasImport': instance.hasImport,
      'hasLogistics': instance.hasLogistics,
      'hasDistribution': instance.hasDistribution,
      'categoriesIds': instance.categoriesIds,
      'suplierPolicy': instance.suplierPolicy,
      'hasDistributionPolicy': instance.hasDistributionPolicy,
      'isHomePreference': instance.isHomePreference,
      '_id': instance.id,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      'totalIncome': instance.totalIncome,
      'incomeByThisMonth': instance.incomeByThisMonth,
    };

_$SuplierPolicyImpl _$$SuplierPolicyImplFromJson(Map<String, dynamic> json) =>
    _$SuplierPolicyImpl(
      fields: (json['fields'] as List<dynamic>?)
          ?.map((e) => Field.fromJson(e as Map<String, dynamic>))
          .toList(),
      id: json['_id'] as String?,
      policyHeading: json['policyHeading'] as String?,
      toggleSwitchKey: json['toggleSwitchKey'] as String?,
      toggleSwitchValue: json['toggleSwitchValue'] as bool?,
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
    );

Map<String, dynamic> _$$SuplierPolicyImplToJson(_$SuplierPolicyImpl instance) =>
    <String, dynamic>{
      'fields': instance.fields,
      '_id': instance.id,
      'policyHeading': instance.policyHeading,
      'toggleSwitchKey': instance.toggleSwitchKey,
      'toggleSwitchValue': instance.toggleSwitchValue,
      'updatedAt': instance.updatedAt?.toIso8601String(),
      'createdAt': instance.createdAt?.toIso8601String(),
    };

_$FieldImpl _$$FieldImplFromJson(Map<String, dynamic> json) => _$FieldImpl(
      fieldKey: json['fieldKey'] as String?,
      fieldType: json['fieldType'] as String?,
      id: json['_id'] as String?,
      value: json['value'] as String?,
    );

Map<String, dynamic> _$$FieldImplToJson(_$FieldImpl instance) =>
    <String, dynamic>{
      'fieldKey': instance.fieldKey,
      'fieldType': instance.fieldType,
      '_id': instance.id,
      'value': instance.value,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalRecords: json['totalRecords'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalRecords': instance.totalRecords,
    };
