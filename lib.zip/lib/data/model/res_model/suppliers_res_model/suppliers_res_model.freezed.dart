// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'suppliers_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SuppliersResModel _$SuppliersResModelFromJson(Map<String, dynamic> json) {
  return _SuppliersResModel.fromJson(json);
}

/// @nodoc
mixin _$SuppliersResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<Datum>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SuppliersResModelCopyWith<SuppliersResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SuppliersResModelCopyWith<$Res> {
  factory $SuppliersResModelCopyWith(
          SuppliersResModel value, $Res Function(SuppliersResModel) then) =
      _$SuppliersResModelCopyWithImpl<$Res, SuppliersResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<Datum>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$SuppliersResModelCopyWithImpl<$Res, $Val extends SuppliersResModel>
    implements $SuppliersResModelCopyWith<$Res> {
  _$SuppliersResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SuppliersResModelImplCopyWith<$Res>
    implements $SuppliersResModelCopyWith<$Res> {
  factory _$$SuppliersResModelImplCopyWith(_$SuppliersResModelImpl value,
          $Res Function(_$SuppliersResModelImpl) then) =
      __$$SuppliersResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<Datum>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$SuppliersResModelImplCopyWithImpl<$Res>
    extends _$SuppliersResModelCopyWithImpl<$Res, _$SuppliersResModelImpl>
    implements _$$SuppliersResModelImplCopyWith<$Res> {
  __$$SuppliersResModelImplCopyWithImpl(_$SuppliersResModelImpl _value,
      $Res Function(_$SuppliersResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_$SuppliersResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SuppliersResModelImpl implements _SuppliersResModel {
  const _$SuppliersResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<Datum>? data,
      @JsonKey(name: "metaData") this.metaData,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$SuppliersResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SuppliersResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<Datum>? _data;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'SuppliersResModel(status: $status, data: $data, metaData: $metaData, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SuppliersResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), metaData, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SuppliersResModelImplCopyWith<_$SuppliersResModelImpl> get copyWith =>
      __$$SuppliersResModelImplCopyWithImpl<_$SuppliersResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SuppliersResModelImplToJson(
      this,
    );
  }
}

abstract class _SuppliersResModel implements SuppliersResModel {
  const factory _SuppliersResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final List<Datum>? data,
          @JsonKey(name: "metaData") final MetaData? metaData,
          @JsonKey(name: "message") final String? message}) =
      _$SuppliersResModelImpl;

  factory _SuppliersResModel.fromJson(Map<String, dynamic> json) =
      _$SuppliersResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$SuppliersResModelImplCopyWith<_$SuppliersResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Datum _$DatumFromJson(Map<String, dynamic> json) {
  return _Datum.fromJson(json);
}

/// @nodoc
mixin _$Datum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "password")
  String? get password => throw _privateConstructorUsedError;
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "address")
  String? get address => throw _privateConstructorUsedError;
  @JsonKey(name: "cityId")
  String? get cityId => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;
  @JsonKey(name: "statusId")
  String? get statusId => throw _privateConstructorUsedError;
  @JsonKey(name: "logo")
  String? get logo => throw _privateConstructorUsedError;
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierDetail")
  SupplierDetail? get supplierDetail => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  Status? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "fromDate")
  dynamic get fromDate => throw _privateConstructorUsedError;
  @JsonKey(name: "lastSeen")
  String? get lastSeen => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DatumCopyWith<Datum> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DatumCopyWith<$Res> {
  factory $DatumCopyWith(Datum value, $Res Function(Datum) then) =
      _$DatumCopyWithImpl<$Res, Datum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "password") String? password,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "supplierDetail") SupplierDetail? supplierDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "status") Status? status,
      @JsonKey(name: "fromDate") dynamic fromDate,
      @JsonKey(name: "lastSeen") String? lastSeen});

  $SupplierDetailCopyWith<$Res>? get supplierDetail;
  $StatusCopyWith<$Res>? get status;
}

/// @nodoc
class _$DatumCopyWithImpl<$Res, $Val extends Datum>
    implements $DatumCopyWith<$Res> {
  _$DatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? adminTypeId = freezed,
    Object? supplierDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? status = freezed,
    Object? fromDate = freezed,
    Object? lastSeen = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierDetail: freezed == supplierDetail
          ? _value.supplierDetail
          : supplierDetail // ignore: cast_nullable_to_non_nullable
              as SupplierDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as Status?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as dynamic,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $SupplierDetailCopyWith<$Res>? get supplierDetail {
    if (_value.supplierDetail == null) {
      return null;
    }

    return $SupplierDetailCopyWith<$Res>(_value.supplierDetail!, (value) {
      return _then(_value.copyWith(supplierDetail: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $StatusCopyWith<$Res>? get status {
    if (_value.status == null) {
      return null;
    }

    return $StatusCopyWith<$Res>(_value.status!, (value) {
      return _then(_value.copyWith(status: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DatumImplCopyWith<$Res> implements $DatumCopyWith<$Res> {
  factory _$$DatumImplCopyWith(
          _$DatumImpl value, $Res Function(_$DatumImpl) then) =
      __$$DatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "password") String? password,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "supplierDetail") SupplierDetail? supplierDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "status") Status? status,
      @JsonKey(name: "fromDate") dynamic fromDate,
      @JsonKey(name: "lastSeen") String? lastSeen});

  @override
  $SupplierDetailCopyWith<$Res>? get supplierDetail;
  @override
  $StatusCopyWith<$Res>? get status;
}

/// @nodoc
class __$$DatumImplCopyWithImpl<$Res>
    extends _$DatumCopyWithImpl<$Res, _$DatumImpl>
    implements _$$DatumImplCopyWith<$Res> {
  __$$DatumImplCopyWithImpl(
      _$DatumImpl _value, $Res Function(_$DatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? adminTypeId = freezed,
    Object? supplierDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? status = freezed,
    Object? fromDate = freezed,
    Object? lastSeen = freezed,
  }) {
    return _then(_$DatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierDetail: freezed == supplierDetail
          ? _value.supplierDetail
          : supplierDetail // ignore: cast_nullable_to_non_nullable
              as SupplierDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as Status?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as dynamic,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DatumImpl implements _Datum {
  const _$DatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "email") this.email,
      @JsonKey(name: "password") this.password,
      @JsonKey(name: "phoneNumber") this.phoneNumber,
      @JsonKey(name: "address") this.address,
      @JsonKey(name: "cityId") this.cityId,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "statusId") this.statusId,
      @JsonKey(name: "logo") this.logo,
      @JsonKey(name: "adminTypeId") this.adminTypeId,
      @JsonKey(name: "supplierDetail") this.supplierDetail,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "fromDate") this.fromDate,
      @JsonKey(name: "lastSeen") this.lastSeen});

  factory _$DatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$DatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "password")
  final String? password;
  @override
  @JsonKey(name: "phoneNumber")
  final String? phoneNumber;
  @override
  @JsonKey(name: "address")
  final String? address;
  @override
  @JsonKey(name: "cityId")
  final String? cityId;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
  @override
  @JsonKey(name: "statusId")
  final String? statusId;
  @override
  @JsonKey(name: "logo")
  final String? logo;
  @override
  @JsonKey(name: "adminTypeId")
  final String? adminTypeId;
  @override
  @JsonKey(name: "supplierDetail")
  final SupplierDetail? supplierDetail;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "status")
  final Status? status;
  @override
  @JsonKey(name: "fromDate")
  final dynamic fromDate;
  @override
  @JsonKey(name: "lastSeen")
  final String? lastSeen;

  @override
  String toString() {
    return 'Datum(id: $id, email: $email, password: $password, phoneNumber: $phoneNumber, address: $address, cityId: $cityId, contactName: $contactName, statusId: $statusId, logo: $logo, adminTypeId: $adminTypeId, supplierDetail: $supplierDetail, createdBy: $createdBy, updatedBy: $updatedBy, isDeleted: $isDeleted, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, status: $status, fromDate: $fromDate, lastSeen: $lastSeen)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.password, password) ||
                other.password == password) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.cityId, cityId) || other.cityId == cityId) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.statusId, statusId) ||
                other.statusId == statusId) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.adminTypeId, adminTypeId) ||
                other.adminTypeId == adminTypeId) &&
            (identical(other.supplierDetail, supplierDetail) ||
                other.supplierDetail == supplierDetail) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other.fromDate, fromDate) &&
            (identical(other.lastSeen, lastSeen) ||
                other.lastSeen == lastSeen));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        email,
        password,
        phoneNumber,
        address,
        cityId,
        contactName,
        statusId,
        logo,
        adminTypeId,
        supplierDetail,
        createdBy,
        updatedBy,
        isDeleted,
        createdAt,
        updatedAt,
        v,
        status,
        const DeepCollectionEquality().hash(fromDate),
        lastSeen
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      __$$DatumImplCopyWithImpl<_$DatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DatumImplToJson(
      this,
    );
  }
}

abstract class _Datum implements Datum {
  const factory _Datum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "email") final String? email,
      @JsonKey(name: "password") final String? password,
      @JsonKey(name: "phoneNumber") final String? phoneNumber,
      @JsonKey(name: "address") final String? address,
      @JsonKey(name: "cityId") final String? cityId,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "statusId") final String? statusId,
      @JsonKey(name: "logo") final String? logo,
      @JsonKey(name: "adminTypeId") final String? adminTypeId,
      @JsonKey(name: "supplierDetail") final SupplierDetail? supplierDetail,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v,
      @JsonKey(name: "status") final Status? status,
      @JsonKey(name: "fromDate") final dynamic fromDate,
      @JsonKey(name: "lastSeen") final String? lastSeen}) = _$DatumImpl;

  factory _Datum.fromJson(Map<String, dynamic> json) = _$DatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "password")
  String? get password;
  @override
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber;
  @override
  @JsonKey(name: "address")
  String? get address;
  @override
  @JsonKey(name: "cityId")
  String? get cityId;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(name: "statusId")
  String? get statusId;
  @override
  @JsonKey(name: "logo")
  String? get logo;
  @override
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId;
  @override
  @JsonKey(name: "supplierDetail")
  SupplierDetail? get supplierDetail;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "status")
  Status? get status;
  @override
  @JsonKey(name: "fromDate")
  dynamic get fromDate;
  @override
  @JsonKey(name: "lastSeen")
  String? get lastSeen;
  @override
  @JsonKey(ignore: true)
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Status _$StatusFromJson(Map<String, dynamic> json) {
  return _Status.fromJson(json);
}

/// @nodoc
mixin _$Status {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "statusName")
  String? get statusName => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StatusCopyWith<Status> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StatusCopyWith<$Res> {
  factory $StatusCopyWith(Status value, $Res Function(Status) then) =
      _$StatusCopyWithImpl<$Res, Status>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class _$StatusCopyWithImpl<$Res, $Val extends Status>
    implements $StatusCopyWith<$Res> {
  _$StatusCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StatusImplCopyWith<$Res> implements $StatusCopyWith<$Res> {
  factory _$$StatusImplCopyWith(
          _$StatusImpl value, $Res Function(_$StatusImpl) then) =
      __$$StatusImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class __$$StatusImplCopyWithImpl<$Res>
    extends _$StatusCopyWithImpl<$Res, _$StatusImpl>
    implements _$$StatusImplCopyWith<$Res> {
  __$$StatusImplCopyWithImpl(
      _$StatusImpl _value, $Res Function(_$StatusImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$StatusImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StatusImpl implements _Status {
  const _$StatusImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "statusName") this.statusName,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$StatusImpl.fromJson(Map<String, dynamic> json) =>
      _$$StatusImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "statusName")
  final String? statusName;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Status(id: $id, statusName: $statusName, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StatusImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.statusName, statusName) ||
                other.statusName == statusName) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, statusName, createdAt, updatedAt, v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      __$$StatusImplCopyWithImpl<_$StatusImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StatusImplToJson(
      this,
    );
  }
}

abstract class _Status implements Status {
  const factory _Status(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "statusName") final String? statusName,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$StatusImpl;

  factory _Status.fromJson(Map<String, dynamic> json) = _$StatusImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "statusName")
  String? get statusName;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SupplierDetail _$SupplierDetailFromJson(Map<String, dynamic> json) {
  return _SupplierDetail.fromJson(json);
}

/// @nodoc
mixin _$SupplierDetail {
  @JsonKey(name: "companyIdNumber")
  int? get companyIdNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "companyName")
  String? get companyName => throw _privateConstructorUsedError;
  @JsonKey(name: "suppliersTypeId")
  String? get suppliersTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "hasImport")
  bool? get hasImport => throw _privateConstructorUsedError;
  @JsonKey(name: "hasLogistics")
  bool? get hasLogistics => throw _privateConstructorUsedError;
  @JsonKey(name: "hasDistribution")
  bool? get hasDistribution => throw _privateConstructorUsedError;
  @JsonKey(name: "categoriesIds")
  List<String?>? get categoriesIds => throw _privateConstructorUsedError;
  @JsonKey(name: "suplierPolicy")
  List<SuplierPolicy>? get suplierPolicy => throw _privateConstructorUsedError;
  @JsonKey(name: "hasDistributionPolicy")
  bool? get hasDistributionPolicy => throw _privateConstructorUsedError;
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "totalIncome")
  int? get totalIncome => throw _privateConstructorUsedError;
  @JsonKey(name: "incomeByThisMonth")
  int? get incomeByThisMonth => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierDetailCopyWith<SupplierDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierDetailCopyWith<$Res> {
  factory $SupplierDetailCopyWith(
          SupplierDetail value, $Res Function(SupplierDetail) then) =
      _$SupplierDetailCopyWithImpl<$Res, SupplierDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "companyIdNumber") int? companyIdNumber,
      @JsonKey(name: "companyName") String? companyName,
      @JsonKey(name: "suppliersTypeId") String? suppliersTypeId,
      @JsonKey(name: "hasImport") bool? hasImport,
      @JsonKey(name: "hasLogistics") bool? hasLogistics,
      @JsonKey(name: "hasDistribution") bool? hasDistribution,
      @JsonKey(name: "categoriesIds") List<String?>? categoriesIds,
      @JsonKey(name: "suplierPolicy") List<SuplierPolicy>? suplierPolicy,
      @JsonKey(name: "hasDistributionPolicy") bool? hasDistributionPolicy,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "totalIncome") int? totalIncome,
      @JsonKey(name: "incomeByThisMonth") int? incomeByThisMonth});
}

/// @nodoc
class _$SupplierDetailCopyWithImpl<$Res, $Val extends SupplierDetail>
    implements $SupplierDetailCopyWith<$Res> {
  _$SupplierDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companyIdNumber = freezed,
    Object? companyName = freezed,
    Object? suppliersTypeId = freezed,
    Object? hasImport = freezed,
    Object? hasLogistics = freezed,
    Object? hasDistribution = freezed,
    Object? categoriesIds = freezed,
    Object? suplierPolicy = freezed,
    Object? hasDistributionPolicy = freezed,
    Object? isHomePreference = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? totalIncome = freezed,
    Object? incomeByThisMonth = freezed,
  }) {
    return _then(_value.copyWith(
      companyIdNumber: freezed == companyIdNumber
          ? _value.companyIdNumber
          : companyIdNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      companyName: freezed == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String?,
      suppliersTypeId: freezed == suppliersTypeId
          ? _value.suppliersTypeId
          : suppliersTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      hasImport: freezed == hasImport
          ? _value.hasImport
          : hasImport // ignore: cast_nullable_to_non_nullable
              as bool?,
      hasLogistics: freezed == hasLogistics
          ? _value.hasLogistics
          : hasLogistics // ignore: cast_nullable_to_non_nullable
              as bool?,
      hasDistribution: freezed == hasDistribution
          ? _value.hasDistribution
          : hasDistribution // ignore: cast_nullable_to_non_nullable
              as bool?,
      categoriesIds: freezed == categoriesIds
          ? _value.categoriesIds
          : categoriesIds // ignore: cast_nullable_to_non_nullable
              as List<String?>?,
      suplierPolicy: freezed == suplierPolicy
          ? _value.suplierPolicy
          : suplierPolicy // ignore: cast_nullable_to_non_nullable
              as List<SuplierPolicy>?,
      hasDistributionPolicy: freezed == hasDistributionPolicy
          ? _value.hasDistributionPolicy
          : hasDistributionPolicy // ignore: cast_nullable_to_non_nullable
              as bool?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      totalIncome: freezed == totalIncome
          ? _value.totalIncome
          : totalIncome // ignore: cast_nullable_to_non_nullable
              as int?,
      incomeByThisMonth: freezed == incomeByThisMonth
          ? _value.incomeByThisMonth
          : incomeByThisMonth // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierDetailImplCopyWith<$Res>
    implements $SupplierDetailCopyWith<$Res> {
  factory _$$SupplierDetailImplCopyWith(_$SupplierDetailImpl value,
          $Res Function(_$SupplierDetailImpl) then) =
      __$$SupplierDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "companyIdNumber") int? companyIdNumber,
      @JsonKey(name: "companyName") String? companyName,
      @JsonKey(name: "suppliersTypeId") String? suppliersTypeId,
      @JsonKey(name: "hasImport") bool? hasImport,
      @JsonKey(name: "hasLogistics") bool? hasLogistics,
      @JsonKey(name: "hasDistribution") bool? hasDistribution,
      @JsonKey(name: "categoriesIds") List<String?>? categoriesIds,
      @JsonKey(name: "suplierPolicy") List<SuplierPolicy>? suplierPolicy,
      @JsonKey(name: "hasDistributionPolicy") bool? hasDistributionPolicy,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "totalIncome") int? totalIncome,
      @JsonKey(name: "incomeByThisMonth") int? incomeByThisMonth});
}

/// @nodoc
class __$$SupplierDetailImplCopyWithImpl<$Res>
    extends _$SupplierDetailCopyWithImpl<$Res, _$SupplierDetailImpl>
    implements _$$SupplierDetailImplCopyWith<$Res> {
  __$$SupplierDetailImplCopyWithImpl(
      _$SupplierDetailImpl _value, $Res Function(_$SupplierDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companyIdNumber = freezed,
    Object? companyName = freezed,
    Object? suppliersTypeId = freezed,
    Object? hasImport = freezed,
    Object? hasLogistics = freezed,
    Object? hasDistribution = freezed,
    Object? categoriesIds = freezed,
    Object? suplierPolicy = freezed,
    Object? hasDistributionPolicy = freezed,
    Object? isHomePreference = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? totalIncome = freezed,
    Object? incomeByThisMonth = freezed,
  }) {
    return _then(_$SupplierDetailImpl(
      companyIdNumber: freezed == companyIdNumber
          ? _value.companyIdNumber
          : companyIdNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      companyName: freezed == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String?,
      suppliersTypeId: freezed == suppliersTypeId
          ? _value.suppliersTypeId
          : suppliersTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      hasImport: freezed == hasImport
          ? _value.hasImport
          : hasImport // ignore: cast_nullable_to_non_nullable
              as bool?,
      hasLogistics: freezed == hasLogistics
          ? _value.hasLogistics
          : hasLogistics // ignore: cast_nullable_to_non_nullable
              as bool?,
      hasDistribution: freezed == hasDistribution
          ? _value.hasDistribution
          : hasDistribution // ignore: cast_nullable_to_non_nullable
              as bool?,
      categoriesIds: freezed == categoriesIds
          ? _value._categoriesIds
          : categoriesIds // ignore: cast_nullable_to_non_nullable
              as List<String?>?,
      suplierPolicy: freezed == suplierPolicy
          ? _value._suplierPolicy
          : suplierPolicy // ignore: cast_nullable_to_non_nullable
              as List<SuplierPolicy>?,
      hasDistributionPolicy: freezed == hasDistributionPolicy
          ? _value.hasDistributionPolicy
          : hasDistributionPolicy // ignore: cast_nullable_to_non_nullable
              as bool?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      totalIncome: freezed == totalIncome
          ? _value.totalIncome
          : totalIncome // ignore: cast_nullable_to_non_nullable
              as int?,
      incomeByThisMonth: freezed == incomeByThisMonth
          ? _value.incomeByThisMonth
          : incomeByThisMonth // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierDetailImpl implements _SupplierDetail {
  const _$SupplierDetailImpl(
      {@JsonKey(name: "companyIdNumber") this.companyIdNumber,
      @JsonKey(name: "companyName") this.companyName,
      @JsonKey(name: "suppliersTypeId") this.suppliersTypeId,
      @JsonKey(name: "hasImport") this.hasImport,
      @JsonKey(name: "hasLogistics") this.hasLogistics,
      @JsonKey(name: "hasDistribution") this.hasDistribution,
      @JsonKey(name: "categoriesIds") final List<String?>? categoriesIds,
      @JsonKey(name: "suplierPolicy") final List<SuplierPolicy>? suplierPolicy,
      @JsonKey(name: "hasDistributionPolicy") this.hasDistributionPolicy,
      @JsonKey(name: "isHomePreference") this.isHomePreference,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "totalIncome") this.totalIncome,
      @JsonKey(name: "incomeByThisMonth") this.incomeByThisMonth})
      : _categoriesIds = categoriesIds,
        _suplierPolicy = suplierPolicy;

  factory _$SupplierDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierDetailImplFromJson(json);

  @override
  @JsonKey(name: "companyIdNumber")
  final int? companyIdNumber;
  @override
  @JsonKey(name: "companyName")
  final String? companyName;
  @override
  @JsonKey(name: "suppliersTypeId")
  final String? suppliersTypeId;
  @override
  @JsonKey(name: "hasImport")
  final bool? hasImport;
  @override
  @JsonKey(name: "hasLogistics")
  final bool? hasLogistics;
  @override
  @JsonKey(name: "hasDistribution")
  final bool? hasDistribution;
  final List<String?>? _categoriesIds;
  @override
  @JsonKey(name: "categoriesIds")
  List<String?>? get categoriesIds {
    final value = _categoriesIds;
    if (value == null) return null;
    if (_categoriesIds is EqualUnmodifiableListView) return _categoriesIds;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<SuplierPolicy>? _suplierPolicy;
  @override
  @JsonKey(name: "suplierPolicy")
  List<SuplierPolicy>? get suplierPolicy {
    final value = _suplierPolicy;
    if (value == null) return null;
    if (_suplierPolicy is EqualUnmodifiableListView) return _suplierPolicy;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "hasDistributionPolicy")
  final bool? hasDistributionPolicy;
  @override
  @JsonKey(name: "isHomePreference")
  final bool? isHomePreference;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "totalIncome")
  final int? totalIncome;
  @override
  @JsonKey(name: "incomeByThisMonth")
  final int? incomeByThisMonth;

  @override
  String toString() {
    return 'SupplierDetail(companyIdNumber: $companyIdNumber, companyName: $companyName, suppliersTypeId: $suppliersTypeId, hasImport: $hasImport, hasLogistics: $hasLogistics, hasDistribution: $hasDistribution, categoriesIds: $categoriesIds, suplierPolicy: $suplierPolicy, hasDistributionPolicy: $hasDistributionPolicy, isHomePreference: $isHomePreference, id: $id, createdAt: $createdAt, updatedAt: $updatedAt, totalIncome: $totalIncome, incomeByThisMonth: $incomeByThisMonth)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierDetailImpl &&
            (identical(other.companyIdNumber, companyIdNumber) ||
                other.companyIdNumber == companyIdNumber) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.suppliersTypeId, suppliersTypeId) ||
                other.suppliersTypeId == suppliersTypeId) &&
            (identical(other.hasImport, hasImport) ||
                other.hasImport == hasImport) &&
            (identical(other.hasLogistics, hasLogistics) ||
                other.hasLogistics == hasLogistics) &&
            (identical(other.hasDistribution, hasDistribution) ||
                other.hasDistribution == hasDistribution) &&
            const DeepCollectionEquality()
                .equals(other._categoriesIds, _categoriesIds) &&
            const DeepCollectionEquality()
                .equals(other._suplierPolicy, _suplierPolicy) &&
            (identical(other.hasDistributionPolicy, hasDistributionPolicy) ||
                other.hasDistributionPolicy == hasDistributionPolicy) &&
            (identical(other.isHomePreference, isHomePreference) ||
                other.isHomePreference == isHomePreference) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.totalIncome, totalIncome) ||
                other.totalIncome == totalIncome) &&
            (identical(other.incomeByThisMonth, incomeByThisMonth) ||
                other.incomeByThisMonth == incomeByThisMonth));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      companyIdNumber,
      companyName,
      suppliersTypeId,
      hasImport,
      hasLogistics,
      hasDistribution,
      const DeepCollectionEquality().hash(_categoriesIds),
      const DeepCollectionEquality().hash(_suplierPolicy),
      hasDistributionPolicy,
      isHomePreference,
      id,
      createdAt,
      updatedAt,
      totalIncome,
      incomeByThisMonth);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierDetailImplCopyWith<_$SupplierDetailImpl> get copyWith =>
      __$$SupplierDetailImplCopyWithImpl<_$SupplierDetailImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierDetailImplToJson(
      this,
    );
  }
}

abstract class _SupplierDetail implements SupplierDetail {
  const factory _SupplierDetail(
      {@JsonKey(name: "companyIdNumber") final int? companyIdNumber,
      @JsonKey(name: "companyName") final String? companyName,
      @JsonKey(name: "suppliersTypeId") final String? suppliersTypeId,
      @JsonKey(name: "hasImport") final bool? hasImport,
      @JsonKey(name: "hasLogistics") final bool? hasLogistics,
      @JsonKey(name: "hasDistribution") final bool? hasDistribution,
      @JsonKey(name: "categoriesIds") final List<String?>? categoriesIds,
      @JsonKey(name: "suplierPolicy") final List<SuplierPolicy>? suplierPolicy,
      @JsonKey(name: "hasDistributionPolicy") final bool? hasDistributionPolicy,
      @JsonKey(name: "isHomePreference") final bool? isHomePreference,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "totalIncome") final int? totalIncome,
      @JsonKey(name: "incomeByThisMonth")
      final int? incomeByThisMonth}) = _$SupplierDetailImpl;

  factory _SupplierDetail.fromJson(Map<String, dynamic> json) =
      _$SupplierDetailImpl.fromJson;

  @override
  @JsonKey(name: "companyIdNumber")
  int? get companyIdNumber;
  @override
  @JsonKey(name: "companyName")
  String? get companyName;
  @override
  @JsonKey(name: "suppliersTypeId")
  String? get suppliersTypeId;
  @override
  @JsonKey(name: "hasImport")
  bool? get hasImport;
  @override
  @JsonKey(name: "hasLogistics")
  bool? get hasLogistics;
  @override
  @JsonKey(name: "hasDistribution")
  bool? get hasDistribution;
  @override
  @JsonKey(name: "categoriesIds")
  List<String?>? get categoriesIds;
  @override
  @JsonKey(name: "suplierPolicy")
  List<SuplierPolicy>? get suplierPolicy;
  @override
  @JsonKey(name: "hasDistributionPolicy")
  bool? get hasDistributionPolicy;
  @override
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "totalIncome")
  int? get totalIncome;
  @override
  @JsonKey(name: "incomeByThisMonth")
  int? get incomeByThisMonth;
  @override
  @JsonKey(ignore: true)
  _$$SupplierDetailImplCopyWith<_$SupplierDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SuplierPolicy _$SuplierPolicyFromJson(Map<String, dynamic> json) {
  return _SuplierPolicy.fromJson(json);
}

/// @nodoc
mixin _$SuplierPolicy {
  @JsonKey(name: "fields")
  List<Field>? get fields => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "policyHeading")
  String? get policyHeading => throw _privateConstructorUsedError;
  @JsonKey(name: "toggleSwitchKey")
  String? get toggleSwitchKey => throw _privateConstructorUsedError;
  @JsonKey(name: "toggleSwitchValue")
  bool? get toggleSwitchValue => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SuplierPolicyCopyWith<SuplierPolicy> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SuplierPolicyCopyWith<$Res> {
  factory $SuplierPolicyCopyWith(
          SuplierPolicy value, $Res Function(SuplierPolicy) then) =
      _$SuplierPolicyCopyWithImpl<$Res, SuplierPolicy>;
  @useResult
  $Res call(
      {@JsonKey(name: "fields") List<Field>? fields,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "policyHeading") String? policyHeading,
      @JsonKey(name: "toggleSwitchKey") String? toggleSwitchKey,
      @JsonKey(name: "toggleSwitchValue") bool? toggleSwitchValue,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "createdAt") DateTime? createdAt});
}

/// @nodoc
class _$SuplierPolicyCopyWithImpl<$Res, $Val extends SuplierPolicy>
    implements $SuplierPolicyCopyWith<$Res> {
  _$SuplierPolicyCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fields = freezed,
    Object? id = freezed,
    Object? policyHeading = freezed,
    Object? toggleSwitchKey = freezed,
    Object? toggleSwitchValue = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_value.copyWith(
      fields: freezed == fields
          ? _value.fields
          : fields // ignore: cast_nullable_to_non_nullable
              as List<Field>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      policyHeading: freezed == policyHeading
          ? _value.policyHeading
          : policyHeading // ignore: cast_nullable_to_non_nullable
              as String?,
      toggleSwitchKey: freezed == toggleSwitchKey
          ? _value.toggleSwitchKey
          : toggleSwitchKey // ignore: cast_nullable_to_non_nullable
              as String?,
      toggleSwitchValue: freezed == toggleSwitchValue
          ? _value.toggleSwitchValue
          : toggleSwitchValue // ignore: cast_nullable_to_non_nullable
              as bool?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SuplierPolicyImplCopyWith<$Res>
    implements $SuplierPolicyCopyWith<$Res> {
  factory _$$SuplierPolicyImplCopyWith(
          _$SuplierPolicyImpl value, $Res Function(_$SuplierPolicyImpl) then) =
      __$$SuplierPolicyImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "fields") List<Field>? fields,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "policyHeading") String? policyHeading,
      @JsonKey(name: "toggleSwitchKey") String? toggleSwitchKey,
      @JsonKey(name: "toggleSwitchValue") bool? toggleSwitchValue,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "createdAt") DateTime? createdAt});
}

/// @nodoc
class __$$SuplierPolicyImplCopyWithImpl<$Res>
    extends _$SuplierPolicyCopyWithImpl<$Res, _$SuplierPolicyImpl>
    implements _$$SuplierPolicyImplCopyWith<$Res> {
  __$$SuplierPolicyImplCopyWithImpl(
      _$SuplierPolicyImpl _value, $Res Function(_$SuplierPolicyImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fields = freezed,
    Object? id = freezed,
    Object? policyHeading = freezed,
    Object? toggleSwitchKey = freezed,
    Object? toggleSwitchValue = freezed,
    Object? updatedAt = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(_$SuplierPolicyImpl(
      fields: freezed == fields
          ? _value._fields
          : fields // ignore: cast_nullable_to_non_nullable
              as List<Field>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      policyHeading: freezed == policyHeading
          ? _value.policyHeading
          : policyHeading // ignore: cast_nullable_to_non_nullable
              as String?,
      toggleSwitchKey: freezed == toggleSwitchKey
          ? _value.toggleSwitchKey
          : toggleSwitchKey // ignore: cast_nullable_to_non_nullable
              as String?,
      toggleSwitchValue: freezed == toggleSwitchValue
          ? _value.toggleSwitchValue
          : toggleSwitchValue // ignore: cast_nullable_to_non_nullable
              as bool?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SuplierPolicyImpl implements _SuplierPolicy {
  const _$SuplierPolicyImpl(
      {@JsonKey(name: "fields") final List<Field>? fields,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "policyHeading") this.policyHeading,
      @JsonKey(name: "toggleSwitchKey") this.toggleSwitchKey,
      @JsonKey(name: "toggleSwitchValue") this.toggleSwitchValue,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "createdAt") this.createdAt})
      : _fields = fields;

  factory _$SuplierPolicyImpl.fromJson(Map<String, dynamic> json) =>
      _$$SuplierPolicyImplFromJson(json);

  final List<Field>? _fields;
  @override
  @JsonKey(name: "fields")
  List<Field>? get fields {
    final value = _fields;
    if (value == null) return null;
    if (_fields is EqualUnmodifiableListView) return _fields;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "policyHeading")
  final String? policyHeading;
  @override
  @JsonKey(name: "toggleSwitchKey")
  final String? toggleSwitchKey;
  @override
  @JsonKey(name: "toggleSwitchValue")
  final bool? toggleSwitchValue;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;

  @override
  String toString() {
    return 'SuplierPolicy(fields: $fields, id: $id, policyHeading: $policyHeading, toggleSwitchKey: $toggleSwitchKey, toggleSwitchValue: $toggleSwitchValue, updatedAt: $updatedAt, createdAt: $createdAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SuplierPolicyImpl &&
            const DeepCollectionEquality().equals(other._fields, _fields) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.policyHeading, policyHeading) ||
                other.policyHeading == policyHeading) &&
            (identical(other.toggleSwitchKey, toggleSwitchKey) ||
                other.toggleSwitchKey == toggleSwitchKey) &&
            (identical(other.toggleSwitchValue, toggleSwitchValue) ||
                other.toggleSwitchValue == toggleSwitchValue) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_fields),
      id,
      policyHeading,
      toggleSwitchKey,
      toggleSwitchValue,
      updatedAt,
      createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SuplierPolicyImplCopyWith<_$SuplierPolicyImpl> get copyWith =>
      __$$SuplierPolicyImplCopyWithImpl<_$SuplierPolicyImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SuplierPolicyImplToJson(
      this,
    );
  }
}

abstract class _SuplierPolicy implements SuplierPolicy {
  const factory _SuplierPolicy(
          {@JsonKey(name: "fields") final List<Field>? fields,
          @JsonKey(name: "_id") final String? id,
          @JsonKey(name: "policyHeading") final String? policyHeading,
          @JsonKey(name: "toggleSwitchKey") final String? toggleSwitchKey,
          @JsonKey(name: "toggleSwitchValue") final bool? toggleSwitchValue,
          @JsonKey(name: "updatedAt") final DateTime? updatedAt,
          @JsonKey(name: "createdAt") final DateTime? createdAt}) =
      _$SuplierPolicyImpl;

  factory _SuplierPolicy.fromJson(Map<String, dynamic> json) =
      _$SuplierPolicyImpl.fromJson;

  @override
  @JsonKey(name: "fields")
  List<Field>? get fields;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "policyHeading")
  String? get policyHeading;
  @override
  @JsonKey(name: "toggleSwitchKey")
  String? get toggleSwitchKey;
  @override
  @JsonKey(name: "toggleSwitchValue")
  bool? get toggleSwitchValue;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$SuplierPolicyImplCopyWith<_$SuplierPolicyImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Field _$FieldFromJson(Map<String, dynamic> json) {
  return _Field.fromJson(json);
}

/// @nodoc
mixin _$Field {
  @JsonKey(name: "fieldKey")
  String? get fieldKey => throw _privateConstructorUsedError;
  @JsonKey(name: "fieldType")
  String? get fieldType => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "value")
  String? get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $FieldCopyWith<Field> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FieldCopyWith<$Res> {
  factory $FieldCopyWith(Field value, $Res Function(Field) then) =
      _$FieldCopyWithImpl<$Res, Field>;
  @useResult
  $Res call(
      {@JsonKey(name: "fieldKey") String? fieldKey,
      @JsonKey(name: "fieldType") String? fieldType,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "value") String? value});
}

/// @nodoc
class _$FieldCopyWithImpl<$Res, $Val extends Field>
    implements $FieldCopyWith<$Res> {
  _$FieldCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fieldKey = freezed,
    Object? fieldType = freezed,
    Object? id = freezed,
    Object? value = freezed,
  }) {
    return _then(_value.copyWith(
      fieldKey: freezed == fieldKey
          ? _value.fieldKey
          : fieldKey // ignore: cast_nullable_to_non_nullable
              as String?,
      fieldType: freezed == fieldType
          ? _value.fieldType
          : fieldType // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      value: freezed == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FieldImplCopyWith<$Res> implements $FieldCopyWith<$Res> {
  factory _$$FieldImplCopyWith(
          _$FieldImpl value, $Res Function(_$FieldImpl) then) =
      __$$FieldImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "fieldKey") String? fieldKey,
      @JsonKey(name: "fieldType") String? fieldType,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "value") String? value});
}

/// @nodoc
class __$$FieldImplCopyWithImpl<$Res>
    extends _$FieldCopyWithImpl<$Res, _$FieldImpl>
    implements _$$FieldImplCopyWith<$Res> {
  __$$FieldImplCopyWithImpl(
      _$FieldImpl _value, $Res Function(_$FieldImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fieldKey = freezed,
    Object? fieldType = freezed,
    Object? id = freezed,
    Object? value = freezed,
  }) {
    return _then(_$FieldImpl(
      fieldKey: freezed == fieldKey
          ? _value.fieldKey
          : fieldKey // ignore: cast_nullable_to_non_nullable
              as String?,
      fieldType: freezed == fieldType
          ? _value.fieldType
          : fieldType // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      value: freezed == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$FieldImpl implements _Field {
  const _$FieldImpl(
      {@JsonKey(name: "fieldKey") this.fieldKey,
      @JsonKey(name: "fieldType") this.fieldType,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "value") this.value});

  factory _$FieldImpl.fromJson(Map<String, dynamic> json) =>
      _$$FieldImplFromJson(json);

  @override
  @JsonKey(name: "fieldKey")
  final String? fieldKey;
  @override
  @JsonKey(name: "fieldType")
  final String? fieldType;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "value")
  final String? value;

  @override
  String toString() {
    return 'Field(fieldKey: $fieldKey, fieldType: $fieldType, id: $id, value: $value)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FieldImpl &&
            (identical(other.fieldKey, fieldKey) ||
                other.fieldKey == fieldKey) &&
            (identical(other.fieldType, fieldType) ||
                other.fieldType == fieldType) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.value, value) || other.value == value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, fieldKey, fieldType, id, value);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FieldImplCopyWith<_$FieldImpl> get copyWith =>
      __$$FieldImplCopyWithImpl<_$FieldImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$FieldImplToJson(
      this,
    );
  }
}

abstract class _Field implements Field {
  const factory _Field(
      {@JsonKey(name: "fieldKey") final String? fieldKey,
      @JsonKey(name: "fieldType") final String? fieldType,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "value") final String? value}) = _$FieldImpl;

  factory _Field.fromJson(Map<String, dynamic> json) = _$FieldImpl.fromJson;

  @override
  @JsonKey(name: "fieldKey")
  String? get fieldKey;
  @override
  @JsonKey(name: "fieldType")
  String? get fieldType;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "value")
  String? get value;
  @override
  @JsonKey(ignore: true)
  _$$FieldImplCopyWith<_$FieldImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalRecords")
  int? get totalRecords => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalRecords") int? totalRecords});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalRecords = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalRecords: freezed == totalRecords
          ? _value.totalRecords
          : totalRecords // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalRecords") int? totalRecords});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalRecords = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalRecords: freezed == totalRecords
          ? _value.totalRecords
          : totalRecords // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalRecords") this.totalRecords});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalRecords")
  final int? totalRecords;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalRecords: $totalRecords)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalRecords, totalRecords) ||
                other.totalRecords == totalRecords));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, currentPage, totalRecords);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
      {@JsonKey(name: "currentPage") final int? currentPage,
      @JsonKey(name: "totalRecords") final int? totalRecords}) = _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalRecords")
  int? get totalRecords;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
