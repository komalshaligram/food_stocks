// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_planogram_product_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetPlanogramProductModelImpl _$$GetPlanogramProductModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetPlanogramProductModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => PlanogramAllProduct.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$GetPlanogramProductModelImplToJson(
        _$GetPlanogramProductModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$PlanogramAllProductImpl _$$PlanogramAllProductImplFromJson(
        Map<String, dynamic> json) =>
    _$PlanogramAllProductImpl(
      id: json['_id'] as String?,
      productId: json['productId'] as String?,
      subCategoryId: json['subCategoryId'] as String?,
      v: json['__v'] as int?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      isDeleted: json['isDeleted'] as bool?,
      isHomePreference: json['isHomePreference'] as bool?,
      order: json['order'] as int?,
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      product: json['product'] == null
          ? null
          : PlanoProduct.fromJson(json['product'] as Map<String, dynamic>),
      sortField: (json['sortField'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$$PlanogramAllProductImplToJson(
        _$PlanogramAllProductImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productId': instance.productId,
      'subCategoryId': instance.subCategoryId,
      '__v': instance.v,
      'createdAt': instance.createdAt?.toIso8601String(),
      'isDeleted': instance.isDeleted,
      'isHomePreference': instance.isHomePreference,
      'order': instance.order,
      'updatedAt': instance.updatedAt?.toIso8601String(),
      'product': instance.product,
      'sortField': instance.sortField,
    };

_$PlanoProductImpl _$$PlanoProductImplFromJson(Map<String, dynamic> json) =>
    _$PlanoProductImpl(
      numberOfUnit: json['numberOfUnit'] as String?,
      itemsWeight: json['itemsWeight'] as String?,
      totalWeightCardboard: json['totalWeightCardboard'] as String?,
      totalWeightSurface: json['totalWeightSurface'] as String?,
      totalWeight: json['totalWeight'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      isBottle: json['isBottle'] as bool?,
      id: json['_id'] as String?,
      productName: json['productName'] as String?,
      brandId: json['brandId'] as String?,
      brandLogo: json['brandLogo'] as String?,
      manufactureName: json['manufactureName'] as String?,
      healthAndLifestye: json['healthAndLifestye'] as String?,
      productDescription: json['productDescription'] as String?,
      component: json['component'] as String?,
      nutritionalValue: json['nutritionalValue'] as String?,
      mainImage: json['mainImage'] as String?,
      images: json['images'] as List<dynamic>?,
      qrcode: json['qrcode'] as String?,
      sku: json['sku'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      categories: json['categories'] as String?,
      subcategories: json['subcategories'] as String?,
      manufacturingCountry: json['manufacturingCountry'] as String?,
      caseType: json['caseType'] as String?,
      scale: json['scale'] as String?,
      status: json['status'] as String?,
      productNumber: json['productNumber'] as String?,
      productStock: json['productStock'] as String?,
      productPrice: (json['productPrice'] as num?)?.toDouble(),
      totalSale: json['totalSale'] as int?,
      lowStock: json['lowStock'] as String?,
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
    );

Map<String, dynamic> _$$PlanoProductImplToJson(_$PlanoProductImpl instance) =>
    <String, dynamic>{
      'numberOfUnit': instance.numberOfUnit,
      'itemsWeight': instance.itemsWeight,
      'totalWeightCardboard': instance.totalWeightCardboard,
      'totalWeightSurface': instance.totalWeightSurface,
      'totalWeight': instance.totalWeight,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      'isBottle': instance.isBottle,
      '_id': instance.id,
      'productName': instance.productName,
      'brandId': instance.brandId,
      'brandLogo': instance.brandLogo,
      'manufactureName': instance.manufactureName,
      'healthAndLifestye': instance.healthAndLifestye,
      'productDescription': instance.productDescription,
      'component': instance.component,
      'nutritionalValue': instance.nutritionalValue,
      'mainImage': instance.mainImage,
      'images': instance.images,
      'qrcode': instance.qrcode,
      'sku': instance.sku,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'categories': instance.categories,
      'subcategories': instance.subcategories,
      'manufacturingCountry': instance.manufacturingCountry,
      'caseType': instance.caseType,
      'scale': instance.scale,
      'status': instance.status,
      'productNumber': instance.productNumber,
      'productStock': instance.productStock,
      'productPrice': instance.productPrice,
      'totalSale': instance.totalSale,
      'lowStock': instance.lowStock,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
