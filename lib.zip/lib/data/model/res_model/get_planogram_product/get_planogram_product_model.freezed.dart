// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_planogram_product_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetPlanogramProductModel _$GetPlanogramProductModelFromJson(
    Map<String, dynamic> json) {
  return _GetPlanogramProductModel.fromJson(json);
}

/// @nodoc
mixin _$GetPlanogramProductModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<PlanogramAllProduct>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetPlanogramProductModelCopyWith<GetPlanogramProductModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetPlanogramProductModelCopyWith<$Res> {
  factory $GetPlanogramProductModelCopyWith(GetPlanogramProductModel value,
          $Res Function(GetPlanogramProductModel) then) =
      _$GetPlanogramProductModelCopyWithImpl<$Res, GetPlanogramProductModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<PlanogramAllProduct>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$GetPlanogramProductModelCopyWithImpl<$Res,
        $Val extends GetPlanogramProductModel>
    implements $GetPlanogramProductModelCopyWith<$Res> {
  _$GetPlanogramProductModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<PlanogramAllProduct>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GetPlanogramProductModelImplCopyWith<$Res>
    implements $GetPlanogramProductModelCopyWith<$Res> {
  factory _$$GetPlanogramProductModelImplCopyWith(
          _$GetPlanogramProductModelImpl value,
          $Res Function(_$GetPlanogramProductModelImpl) then) =
      __$$GetPlanogramProductModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<PlanogramAllProduct>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$GetPlanogramProductModelImplCopyWithImpl<$Res>
    extends _$GetPlanogramProductModelCopyWithImpl<$Res,
        _$GetPlanogramProductModelImpl>
    implements _$$GetPlanogramProductModelImplCopyWith<$Res> {
  __$$GetPlanogramProductModelImplCopyWithImpl(
      _$GetPlanogramProductModelImpl _value,
      $Res Function(_$GetPlanogramProductModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_$GetPlanogramProductModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<PlanogramAllProduct>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetPlanogramProductModelImpl implements _GetPlanogramProductModel {
  const _$GetPlanogramProductModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<PlanogramAllProduct>? data,
      @JsonKey(name: "metaData") this.metaData,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$GetPlanogramProductModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetPlanogramProductModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<PlanogramAllProduct>? _data;
  @override
  @JsonKey(name: "data")
  List<PlanogramAllProduct>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'GetPlanogramProductModel(status: $status, data: $data, metaData: $metaData, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetPlanogramProductModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), metaData, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetPlanogramProductModelImplCopyWith<_$GetPlanogramProductModelImpl>
      get copyWith => __$$GetPlanogramProductModelImplCopyWithImpl<
          _$GetPlanogramProductModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetPlanogramProductModelImplToJson(
      this,
    );
  }
}

abstract class _GetPlanogramProductModel implements GetPlanogramProductModel {
  const factory _GetPlanogramProductModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final List<PlanogramAllProduct>? data,
          @JsonKey(name: "metaData") final MetaData? metaData,
          @JsonKey(name: "message") final String? message}) =
      _$GetPlanogramProductModelImpl;

  factory _GetPlanogramProductModel.fromJson(Map<String, dynamic> json) =
      _$GetPlanogramProductModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<PlanogramAllProduct>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$GetPlanogramProductModelImplCopyWith<_$GetPlanogramProductModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

PlanogramAllProduct _$PlanogramAllProductFromJson(Map<String, dynamic> json) {
  return _PlanogramAllProduct.fromJson(json);
}

/// @nodoc
mixin _$PlanogramAllProduct {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productId")
  String? get productId => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "product")
  PlanoProduct? get product => throw _privateConstructorUsedError;
  @JsonKey(name: "sortField")
  double? get sortField => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PlanogramAllProductCopyWith<PlanogramAllProduct> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramAllProductCopyWith<$Res> {
  factory $PlanogramAllProductCopyWith(
          PlanogramAllProduct value, $Res Function(PlanogramAllProduct) then) =
      _$PlanogramAllProductCopyWithImpl<$Res, PlanogramAllProduct>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productId") String? productId,
      @JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "product") PlanoProduct? product,
      @JsonKey(name: "sortField") double? sortField});

  $PlanoProductCopyWith<$Res>? get product;
}

/// @nodoc
class _$PlanogramAllProductCopyWithImpl<$Res, $Val extends PlanogramAllProduct>
    implements $PlanogramAllProductCopyWith<$Res> {
  _$PlanogramAllProductCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productId = freezed,
    Object? subCategoryId = freezed,
    Object? v = freezed,
    Object? createdAt = freezed,
    Object? isDeleted = freezed,
    Object? isHomePreference = freezed,
    Object? order = freezed,
    Object? updatedAt = freezed,
    Object? product = freezed,
    Object? sortField = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      product: freezed == product
          ? _value.product
          : product // ignore: cast_nullable_to_non_nullable
              as PlanoProduct?,
      sortField: freezed == sortField
          ? _value.sortField
          : sortField // ignore: cast_nullable_to_non_nullable
              as double?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $PlanoProductCopyWith<$Res>? get product {
    if (_value.product == null) {
      return null;
    }

    return $PlanoProductCopyWith<$Res>(_value.product!, (value) {
      return _then(_value.copyWith(product: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$PlanogramAllProductImplCopyWith<$Res>
    implements $PlanogramAllProductCopyWith<$Res> {
  factory _$$PlanogramAllProductImplCopyWith(_$PlanogramAllProductImpl value,
          $Res Function(_$PlanogramAllProductImpl) then) =
      __$$PlanogramAllProductImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productId") String? productId,
      @JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "product") PlanoProduct? product,
      @JsonKey(name: "sortField") double? sortField});

  @override
  $PlanoProductCopyWith<$Res>? get product;
}

/// @nodoc
class __$$PlanogramAllProductImplCopyWithImpl<$Res>
    extends _$PlanogramAllProductCopyWithImpl<$Res, _$PlanogramAllProductImpl>
    implements _$$PlanogramAllProductImplCopyWith<$Res> {
  __$$PlanogramAllProductImplCopyWithImpl(_$PlanogramAllProductImpl _value,
      $Res Function(_$PlanogramAllProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productId = freezed,
    Object? subCategoryId = freezed,
    Object? v = freezed,
    Object? createdAt = freezed,
    Object? isDeleted = freezed,
    Object? isHomePreference = freezed,
    Object? order = freezed,
    Object? updatedAt = freezed,
    Object? product = freezed,
    Object? sortField = freezed,
  }) {
    return _then(_$PlanogramAllProductImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      product: freezed == product
          ? _value.product
          : product // ignore: cast_nullable_to_non_nullable
              as PlanoProduct?,
      sortField: freezed == sortField
          ? _value.sortField
          : sortField // ignore: cast_nullable_to_non_nullable
              as double?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlanogramAllProductImpl implements _PlanogramAllProduct {
  const _$PlanogramAllProductImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "productId") this.productId,
      @JsonKey(name: "subCategoryId") this.subCategoryId,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "isHomePreference") this.isHomePreference,
      @JsonKey(name: "order") this.order,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "product") this.product,
      @JsonKey(name: "sortField") this.sortField});

  factory _$PlanogramAllProductImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlanogramAllProductImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productId")
  final String? productId;
  @override
  @JsonKey(name: "subCategoryId")
  final String? subCategoryId;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "isHomePreference")
  final bool? isHomePreference;
  @override
  @JsonKey(name: "order")
  final int? order;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "product")
  final PlanoProduct? product;
  @override
  @JsonKey(name: "sortField")
  final double? sortField;

  @override
  String toString() {
    return 'PlanogramAllProduct(id: $id, productId: $productId, subCategoryId: $subCategoryId, v: $v, createdAt: $createdAt, isDeleted: $isDeleted, isHomePreference: $isHomePreference, order: $order, updatedAt: $updatedAt, product: $product, sortField: $sortField)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramAllProductImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.subCategoryId, subCategoryId) ||
                other.subCategoryId == subCategoryId) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.isHomePreference, isHomePreference) ||
                other.isHomePreference == isHomePreference) &&
            (identical(other.order, order) || other.order == order) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.product, product) || other.product == product) &&
            (identical(other.sortField, sortField) ||
                other.sortField == sortField));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      productId,
      subCategoryId,
      v,
      createdAt,
      isDeleted,
      isHomePreference,
      order,
      updatedAt,
      product,
      sortField);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramAllProductImplCopyWith<_$PlanogramAllProductImpl> get copyWith =>
      __$$PlanogramAllProductImplCopyWithImpl<_$PlanogramAllProductImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlanogramAllProductImplToJson(
      this,
    );
  }
}

abstract class _PlanogramAllProduct implements PlanogramAllProduct {
  const factory _PlanogramAllProduct(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "productId") final String? productId,
          @JsonKey(name: "subCategoryId") final String? subCategoryId,
          @JsonKey(name: "__v") final int? v,
          @JsonKey(name: "createdAt") final DateTime? createdAt,
          @JsonKey(name: "isDeleted") final bool? isDeleted,
          @JsonKey(name: "isHomePreference") final bool? isHomePreference,
          @JsonKey(name: "order") final int? order,
          @JsonKey(name: "updatedAt") final DateTime? updatedAt,
          @JsonKey(name: "product") final PlanoProduct? product,
          @JsonKey(name: "sortField") final double? sortField}) =
      _$PlanogramAllProductImpl;

  factory _PlanogramAllProduct.fromJson(Map<String, dynamic> json) =
      _$PlanogramAllProductImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productId")
  String? get productId;
  @override
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "product")
  PlanoProduct? get product;
  @override
  @JsonKey(name: "sortField")
  double? get sortField;
  @override
  @JsonKey(ignore: true)
  _$$PlanogramAllProductImplCopyWith<_$PlanogramAllProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

PlanoProduct _$PlanoProductFromJson(Map<String, dynamic> json) {
  return _PlanoProduct.fromJson(json);
}

/// @nodoc
mixin _$PlanoProduct {
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeightCardboard")
  String? get totalWeightCardboard => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeightSurface")
  String? get totalWeightSurface => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  String? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "isBottle")
  bool? get isBottle => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "brandId")
  String? get brandId => throw _privateConstructorUsedError;
  @JsonKey(name: "brandLogo")
  String? get brandLogo => throw _privateConstructorUsedError;
  @JsonKey(name: "manufactureName")
  String? get manufactureName => throw _privateConstructorUsedError;
  @JsonKey(name: "healthAndLifestye")
  String? get healthAndLifestye => throw _privateConstructorUsedError;
  @JsonKey(name: "productDescription")
  String? get productDescription => throw _privateConstructorUsedError;
  @JsonKey(name: "component")
  String? get component => throw _privateConstructorUsedError;
  @JsonKey(name: "nutritionalValue")
  String? get nutritionalValue => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "images")
  List<dynamic>? get images => throw _privateConstructorUsedError;
  @JsonKey(name: "qrcode")
  String? get qrcode => throw _privateConstructorUsedError;
  @JsonKey(name: "sku")
  String? get sku => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "categories")
  String? get categories => throw _privateConstructorUsedError;
  @JsonKey(name: "subcategories")
  String? get subcategories => throw _privateConstructorUsedError;
  @JsonKey(name: "manufacturingCountry")
  String? get manufacturingCountry => throw _privateConstructorUsedError;
  @JsonKey(name: "caseType")
  String? get caseType => throw _privateConstructorUsedError;
  @JsonKey(name: "scale")
  String? get scale => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "productNumber")
  String? get productNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  String? get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  double? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "totalSale")
  int? get totalSale => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PlanoProductCopyWith<PlanoProduct> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanoProductCopyWith<$Res> {
  factory $PlanoProductCopyWith(
          PlanoProduct value, $Res Function(PlanoProduct) then) =
      _$PlanoProductCopyWithImpl<$Res, PlanoProduct>;
  @useResult
  $Res call(
      {@JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeightCardboard") String? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") String? totalWeightSurface,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "isBottle") bool? isBottle,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "brandId") String? brandId,
      @JsonKey(name: "brandLogo") String? brandLogo,
      @JsonKey(name: "manufactureName") String? manufactureName,
      @JsonKey(name: "healthAndLifestye") String? healthAndLifestye,
      @JsonKey(name: "productDescription") String? productDescription,
      @JsonKey(name: "component") String? component,
      @JsonKey(name: "nutritionalValue") String? nutritionalValue,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "images") List<dynamic>? images,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "categories") String? categories,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "manufacturingCountry") String? manufacturingCountry,
      @JsonKey(name: "caseType") String? caseType,
      @JsonKey(name: "scale") String? scale,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "productNumber") String? productNumber,
      @JsonKey(name: "productStock") String? productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "totalSale") int? totalSale,
      String? lowStock,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim});
}

/// @nodoc
class _$PlanoProductCopyWithImpl<$Res, $Val extends PlanoProduct>
    implements $PlanoProductCopyWith<$Res> {
  _$PlanoProductCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberOfUnit = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeightCardboard = freezed,
    Object? totalWeightSurface = freezed,
    Object? totalWeight = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? isBottle = freezed,
    Object? id = freezed,
    Object? productName = freezed,
    Object? brandId = freezed,
    Object? brandLogo = freezed,
    Object? manufactureName = freezed,
    Object? healthAndLifestye = freezed,
    Object? productDescription = freezed,
    Object? component = freezed,
    Object? nutritionalValue = freezed,
    Object? mainImage = freezed,
    Object? images = freezed,
    Object? qrcode = freezed,
    Object? sku = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? categories = freezed,
    Object? subcategories = freezed,
    Object? manufacturingCountry = freezed,
    Object? caseType = freezed,
    Object? scale = freezed,
    Object? status = freezed,
    Object? productNumber = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? totalSale = freezed,
    Object? lowStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
  }) {
    return _then(_value.copyWith(
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightCardboard: freezed == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightSurface: freezed == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      isBottle: freezed == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandId: freezed == brandId
          ? _value.brandId
          : brandId // ignore: cast_nullable_to_non_nullable
              as String?,
      brandLogo: freezed == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String?,
      manufactureName: freezed == manufactureName
          ? _value.manufactureName
          : manufactureName // ignore: cast_nullable_to_non_nullable
              as String?,
      healthAndLifestye: freezed == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String?,
      productDescription: freezed == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      component: freezed == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String?,
      nutritionalValue: freezed == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value.images
          : images // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      categories: freezed == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      manufacturingCountry: freezed == manufacturingCountry
          ? _value.manufacturingCountry
          : manufacturingCountry // ignore: cast_nullable_to_non_nullable
              as String?,
      caseType: freezed == caseType
          ? _value.caseType
          : caseType // ignore: cast_nullable_to_non_nullable
              as String?,
      scale: freezed == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      productNumber: freezed == productNumber
          ? _value.productNumber
          : productNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PlanoProductImplCopyWith<$Res>
    implements $PlanoProductCopyWith<$Res> {
  factory _$$PlanoProductImplCopyWith(
          _$PlanoProductImpl value, $Res Function(_$PlanoProductImpl) then) =
      __$$PlanoProductImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeightCardboard") String? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") String? totalWeightSurface,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "isBottle") bool? isBottle,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "brandId") String? brandId,
      @JsonKey(name: "brandLogo") String? brandLogo,
      @JsonKey(name: "manufactureName") String? manufactureName,
      @JsonKey(name: "healthAndLifestye") String? healthAndLifestye,
      @JsonKey(name: "productDescription") String? productDescription,
      @JsonKey(name: "component") String? component,
      @JsonKey(name: "nutritionalValue") String? nutritionalValue,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "images") List<dynamic>? images,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "categories") String? categories,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "manufacturingCountry") String? manufacturingCountry,
      @JsonKey(name: "caseType") String? caseType,
      @JsonKey(name: "scale") String? scale,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "productNumber") String? productNumber,
      @JsonKey(name: "productStock") String? productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "totalSale") int? totalSale,
      String? lowStock,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim});
}

/// @nodoc
class __$$PlanoProductImplCopyWithImpl<$Res>
    extends _$PlanoProductCopyWithImpl<$Res, _$PlanoProductImpl>
    implements _$$PlanoProductImplCopyWith<$Res> {
  __$$PlanoProductImplCopyWithImpl(
      _$PlanoProductImpl _value, $Res Function(_$PlanoProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberOfUnit = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeightCardboard = freezed,
    Object? totalWeightSurface = freezed,
    Object? totalWeight = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? isBottle = freezed,
    Object? id = freezed,
    Object? productName = freezed,
    Object? brandId = freezed,
    Object? brandLogo = freezed,
    Object? manufactureName = freezed,
    Object? healthAndLifestye = freezed,
    Object? productDescription = freezed,
    Object? component = freezed,
    Object? nutritionalValue = freezed,
    Object? mainImage = freezed,
    Object? images = freezed,
    Object? qrcode = freezed,
    Object? sku = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? categories = freezed,
    Object? subcategories = freezed,
    Object? manufacturingCountry = freezed,
    Object? caseType = freezed,
    Object? scale = freezed,
    Object? status = freezed,
    Object? productNumber = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? totalSale = freezed,
    Object? lowStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
  }) {
    return _then(_$PlanoProductImpl(
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightCardboard: freezed == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightSurface: freezed == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      isBottle: freezed == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandId: freezed == brandId
          ? _value.brandId
          : brandId // ignore: cast_nullable_to_non_nullable
              as String?,
      brandLogo: freezed == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String?,
      manufactureName: freezed == manufactureName
          ? _value.manufactureName
          : manufactureName // ignore: cast_nullable_to_non_nullable
              as String?,
      healthAndLifestye: freezed == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String?,
      productDescription: freezed == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      component: freezed == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String?,
      nutritionalValue: freezed == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value._images
          : images // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      categories: freezed == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      manufacturingCountry: freezed == manufacturingCountry
          ? _value.manufacturingCountry
          : manufacturingCountry // ignore: cast_nullable_to_non_nullable
              as String?,
      caseType: freezed == caseType
          ? _value.caseType
          : caseType // ignore: cast_nullable_to_non_nullable
              as String?,
      scale: freezed == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      productNumber: freezed == productNumber
          ? _value.productNumber
          : productNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlanoProductImpl implements _PlanoProduct {
  const _$PlanoProductImpl(
      {@JsonKey(name: "numberOfUnit") this.numberOfUnit,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "totalWeightCardboard") this.totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") this.totalWeightSurface,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "isBottle") this.isBottle,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "brandId") this.brandId,
      @JsonKey(name: "brandLogo") this.brandLogo,
      @JsonKey(name: "manufactureName") this.manufactureName,
      @JsonKey(name: "healthAndLifestye") this.healthAndLifestye,
      @JsonKey(name: "productDescription") this.productDescription,
      @JsonKey(name: "component") this.component,
      @JsonKey(name: "nutritionalValue") this.nutritionalValue,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "images") final List<dynamic>? images,
      @JsonKey(name: "qrcode") this.qrcode,
      @JsonKey(name: "sku") this.sku,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "categories") this.categories,
      @JsonKey(name: "subcategories") this.subcategories,
      @JsonKey(name: "manufacturingCountry") this.manufacturingCountry,
      @JsonKey(name: "caseType") this.caseType,
      @JsonKey(name: "scale") this.scale,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "productNumber") this.productNumber,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "totalSale") this.totalSale,
      this.lowStock,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim})
      : _images = images;

  factory _$PlanoProductImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlanoProductImplFromJson(json);

  @override
  @JsonKey(name: "numberOfUnit")
  final String? numberOfUnit;
  @override
  @JsonKey(name: "itemsWeight")
  final String? itemsWeight;
  @override
  @JsonKey(name: "totalWeightCardboard")
  final String? totalWeightCardboard;
  @override
  @JsonKey(name: "totalWeightSurface")
  final String? totalWeightSurface;
  @override
  @JsonKey(name: "totalWeight")
  final String? totalWeight;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "isBottle")
  final bool? isBottle;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "brandId")
  final String? brandId;
  @override
  @JsonKey(name: "brandLogo")
  final String? brandLogo;
  @override
  @JsonKey(name: "manufactureName")
  final String? manufactureName;
  @override
  @JsonKey(name: "healthAndLifestye")
  final String? healthAndLifestye;
  @override
  @JsonKey(name: "productDescription")
  final String? productDescription;
  @override
  @JsonKey(name: "component")
  final String? component;
  @override
  @JsonKey(name: "nutritionalValue")
  final String? nutritionalValue;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  final List<dynamic>? _images;
  @override
  @JsonKey(name: "images")
  List<dynamic>? get images {
    final value = _images;
    if (value == null) return null;
    if (_images is EqualUnmodifiableListView) return _images;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "qrcode")
  final String? qrcode;
  @override
  @JsonKey(name: "sku")
  final String? sku;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "categories")
  final String? categories;
  @override
  @JsonKey(name: "subcategories")
  final String? subcategories;
  @override
  @JsonKey(name: "manufacturingCountry")
  final String? manufacturingCountry;
  @override
  @JsonKey(name: "caseType")
  final String? caseType;
  @override
  @JsonKey(name: "scale")
  final String? scale;
  @override
  @JsonKey(name: "status")
  final String? status;
  @override
  @JsonKey(name: "productNumber")
  final String? productNumber;
  @override
  @JsonKey(name: "productStock")
  final String? productStock;
  @override
  @JsonKey(name: "productPrice")
  final double? productPrice;
  @override
  @JsonKey(name: "totalSale")
  final int? totalSale;
  @override
  final String? lowStock;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;

  @override
  String toString() {
    return 'PlanoProduct(numberOfUnit: $numberOfUnit, itemsWeight: $itemsWeight, totalWeightCardboard: $totalWeightCardboard, totalWeightSurface: $totalWeightSurface, totalWeight: $totalWeight, createdAt: $createdAt, updatedAt: $updatedAt, isBottle: $isBottle, id: $id, productName: $productName, brandId: $brandId, brandLogo: $brandLogo, manufactureName: $manufactureName, healthAndLifestye: $healthAndLifestye, productDescription: $productDescription, component: $component, nutritionalValue: $nutritionalValue, mainImage: $mainImage, images: $images, qrcode: $qrcode, sku: $sku, createdBy: $createdBy, updatedBy: $updatedBy, categories: $categories, subcategories: $subcategories, manufacturingCountry: $manufacturingCountry, caseType: $caseType, scale: $scale, status: $status, productNumber: $productNumber, productStock: $productStock, productPrice: $productPrice, totalSale: $totalSale, lowStock: $lowStock, isPesach: $isPesach, nmMashlim: $nmMashlim)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanoProductImpl &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.totalWeightCardboard, totalWeightCardboard) ||
                other.totalWeightCardboard == totalWeightCardboard) &&
            (identical(other.totalWeightSurface, totalWeightSurface) ||
                other.totalWeightSurface == totalWeightSurface) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.isBottle, isBottle) ||
                other.isBottle == isBottle) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.brandId, brandId) || other.brandId == brandId) &&
            (identical(other.brandLogo, brandLogo) ||
                other.brandLogo == brandLogo) &&
            (identical(other.manufactureName, manufactureName) ||
                other.manufactureName == manufactureName) &&
            (identical(other.healthAndLifestye, healthAndLifestye) ||
                other.healthAndLifestye == healthAndLifestye) &&
            (identical(other.productDescription, productDescription) ||
                other.productDescription == productDescription) &&
            (identical(other.component, component) ||
                other.component == component) &&
            (identical(other.nutritionalValue, nutritionalValue) ||
                other.nutritionalValue == nutritionalValue) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            const DeepCollectionEquality().equals(other._images, _images) &&
            (identical(other.qrcode, qrcode) || other.qrcode == qrcode) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.categories, categories) ||
                other.categories == categories) &&
            (identical(other.subcategories, subcategories) ||
                other.subcategories == subcategories) &&
            (identical(other.manufacturingCountry, manufacturingCountry) ||
                other.manufacturingCountry == manufacturingCountry) &&
            (identical(other.caseType, caseType) ||
                other.caseType == caseType) &&
            (identical(other.scale, scale) || other.scale == scale) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.productNumber, productNumber) ||
                other.productNumber == productNumber) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.totalSale, totalSale) ||
                other.totalSale == totalSale) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        numberOfUnit,
        itemsWeight,
        totalWeightCardboard,
        totalWeightSurface,
        totalWeight,
        createdAt,
        updatedAt,
        isBottle,
        id,
        productName,
        brandId,
        brandLogo,
        manufactureName,
        healthAndLifestye,
        productDescription,
        component,
        nutritionalValue,
        mainImage,
        const DeepCollectionEquality().hash(_images),
        qrcode,
        sku,
        createdBy,
        updatedBy,
        categories,
        subcategories,
        manufacturingCountry,
        caseType,
        scale,
        status,
        productNumber,
        productStock,
        productPrice,
        totalSale,
        lowStock,
        isPesach,
        nmMashlim
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanoProductImplCopyWith<_$PlanoProductImpl> get copyWith =>
      __$$PlanoProductImplCopyWithImpl<_$PlanoProductImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlanoProductImplToJson(
      this,
    );
  }
}

abstract class _PlanoProduct implements PlanoProduct {
  const factory _PlanoProduct(
      {@JsonKey(name: "numberOfUnit") final String? numberOfUnit,
      @JsonKey(name: "itemsWeight") final String? itemsWeight,
      @JsonKey(name: "totalWeightCardboard") final String? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") final String? totalWeightSurface,
      @JsonKey(name: "totalWeight") final String? totalWeight,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "isBottle") final bool? isBottle,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "brandId") final String? brandId,
      @JsonKey(name: "brandLogo") final String? brandLogo,
      @JsonKey(name: "manufactureName") final String? manufactureName,
      @JsonKey(name: "healthAndLifestye") final String? healthAndLifestye,
      @JsonKey(name: "productDescription") final String? productDescription,
      @JsonKey(name: "component") final String? component,
      @JsonKey(name: "nutritionalValue") final String? nutritionalValue,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "images") final List<dynamic>? images,
      @JsonKey(name: "qrcode") final String? qrcode,
      @JsonKey(name: "sku") final String? sku,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "categories") final String? categories,
      @JsonKey(name: "subcategories") final String? subcategories,
      @JsonKey(name: "manufacturingCountry") final String? manufacturingCountry,
      @JsonKey(name: "caseType") final String? caseType,
      @JsonKey(name: "scale") final String? scale,
      @JsonKey(name: "status") final String? status,
      @JsonKey(name: "productNumber") final String? productNumber,
      @JsonKey(name: "productStock") final String? productStock,
      @JsonKey(name: "productPrice") final double? productPrice,
      @JsonKey(name: "totalSale") final int? totalSale,
      final String? lowStock,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim")
      final String? nmMashlim}) = _$PlanoProductImpl;

  factory _PlanoProduct.fromJson(Map<String, dynamic> json) =
      _$PlanoProductImpl.fromJson;

  @override
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit;
  @override
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight;
  @override
  @JsonKey(name: "totalWeightCardboard")
  String? get totalWeightCardboard;
  @override
  @JsonKey(name: "totalWeightSurface")
  String? get totalWeightSurface;
  @override
  @JsonKey(name: "totalWeight")
  String? get totalWeight;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "isBottle")
  bool? get isBottle;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "brandId")
  String? get brandId;
  @override
  @JsonKey(name: "brandLogo")
  String? get brandLogo;
  @override
  @JsonKey(name: "manufactureName")
  String? get manufactureName;
  @override
  @JsonKey(name: "healthAndLifestye")
  String? get healthAndLifestye;
  @override
  @JsonKey(name: "productDescription")
  String? get productDescription;
  @override
  @JsonKey(name: "component")
  String? get component;
  @override
  @JsonKey(name: "nutritionalValue")
  String? get nutritionalValue;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "images")
  List<dynamic>? get images;
  @override
  @JsonKey(name: "qrcode")
  String? get qrcode;
  @override
  @JsonKey(name: "sku")
  String? get sku;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "categories")
  String? get categories;
  @override
  @JsonKey(name: "subcategories")
  String? get subcategories;
  @override
  @JsonKey(name: "manufacturingCountry")
  String? get manufacturingCountry;
  @override
  @JsonKey(name: "caseType")
  String? get caseType;
  @override
  @JsonKey(name: "scale")
  String? get scale;
  @override
  @JsonKey(name: "status")
  String? get status;
  @override
  @JsonKey(name: "productNumber")
  String? get productNumber;
  @override
  @JsonKey(name: "productStock")
  String? get productStock;
  @override
  @JsonKey(name: "productPrice")
  double? get productPrice;
  @override
  @JsonKey(name: "totalSale")
  int? get totalSale;
  @override
  String? get lowStock;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  @JsonKey(ignore: true)
  _$$PlanoProductImplCopyWith<_$PlanoProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalFilteredCount") this.totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  final int? totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
          {@JsonKey(name: "currentPage") final int? currentPage,
          @JsonKey(name: "totalFilteredCount") final int? totalFilteredCount,
          @JsonKey(name: "totalFilteredPage") final int? totalFilteredPage}) =
      _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
