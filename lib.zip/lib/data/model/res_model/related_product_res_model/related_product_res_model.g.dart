// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'related_product_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RelatedProductResModelImpl _$$RelatedProductResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$RelatedProductResModelImpl(
      status: json['status'] as int,
      message: json['message'] as String,
      data: (json['data'] as List<dynamic>)
          .map((e) => RelatedProductDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$RelatedProductResModelImplToJson(
        _$RelatedProductResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
    };

_$DatumImpl _$$DatumImplFromJson(Map<String, dynamic> json) => _$DatumImpl(
      numberOfUnit: json['numberOfUnit'] as String,
      itemsWeight: json['itemsWeight'] as String,
      totalWeightCardboard: json['totalWeightCardboard'] as String,
      totalWeightSurface: json['totalWeightSurface'] as String,
      totalWeight: json['totalWeight'] as String,
      createdAt: json['createdAt'] as String,
      updatedAt: json['updatedAt'] as String,
      isBottle: json['isBottle'] as bool,
      id: json['_id'] as String,
      productName: json['productName'] as String,
      brandId: json['brandId'] as String,
      brandLogo: json['brandLogo'] as String,
      manufactureName: json['manufactureName'] as String,
      healthAndLifestye: json['healthAndLifestye'] as String,
      productDescription: json['productDescription'] as String,
      component: json['component'] as String,
      nutritionalValue: json['nutritionalValue'] as String,
      mainImage: json['mainImage'] as String,
      images: json['images'] as List<dynamic>,
      qrcode: json['qrcode'] as String,
      sku: json['sku'] as String,
      createdBy: json['createdBy'] as String,
      updatedBy: json['updatedBy'] as String,
      categories: json['categories'] as String,
      subcategories: json['subcategories'] as String,
      manufacturingCountry: json['manufacturingCountry'] as String,
      caseType: json['caseType'] as String,
      scale: json['scale'] as String,
      status: json['status'] as String,
      productNumber: json['productNumber'] as String,
      productStock: json['productStock'] as String,
      productPrice: (json['productPrice'] as num).toDouble(),
      totalSale: json['totalSale'] as int,
      lowStock: json['lowStock'] as String,
      isPesach: json['isPesach'] as bool,
      nmMashlim: json['nmMashlim'] as String,
    );

Map<String, dynamic> _$$DatumImplToJson(_$DatumImpl instance) =>
    <String, dynamic>{
      'numberOfUnit': instance.numberOfUnit,
      'itemsWeight': instance.itemsWeight,
      'totalWeightCardboard': instance.totalWeightCardboard,
      'totalWeightSurface': instance.totalWeightSurface,
      'totalWeight': instance.totalWeight,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      'isBottle': instance.isBottle,
      '_id': instance.id,
      'productName': instance.productName,
      'brandId': instance.brandId,
      'brandLogo': instance.brandLogo,
      'manufactureName': instance.manufactureName,
      'healthAndLifestye': instance.healthAndLifestye,
      'productDescription': instance.productDescription,
      'component': instance.component,
      'nutritionalValue': instance.nutritionalValue,
      'mainImage': instance.mainImage,
      'images': instance.images,
      'qrcode': instance.qrcode,
      'sku': instance.sku,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'categories': instance.categories,
      'subcategories': instance.subcategories,
      'manufacturingCountry': instance.manufacturingCountry,
      'caseType': instance.caseType,
      'scale': instance.scale,
      'status': instance.status,
      'productNumber': instance.productNumber,
      'productStock': instance.productStock,
      'productPrice': instance.productPrice,
      'totalSale': instance.totalSale,
      'lowStock': instance.lowStock,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
    };
