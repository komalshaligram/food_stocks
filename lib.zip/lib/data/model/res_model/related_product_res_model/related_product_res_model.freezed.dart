// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'related_product_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

RelatedProductResModel _$RelatedProductResModelFromJson(
    Map<String, dynamic> json) {
  return _RelatedProductResModel.fromJson(json);
}

/// @nodoc
mixin _$RelatedProductResModel {
  int get status => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RelatedProductResModelCopyWith<RelatedProductResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RelatedProductResModelCopyWith<$Res> {
  factory $RelatedProductResModelCopyWith(RelatedProductResModel value,
          $Res Function(RelatedProductResModel) then) =
      _$RelatedProductResModelCopyWithImpl<$Res, RelatedProductResModel>;
  @useResult
  $Res call({int status, String message, List<RelatedProductDatum> data});
}

/// @nodoc
class _$RelatedProductResModelCopyWithImpl<$Res,
        $Val extends RelatedProductResModel>
    implements $RelatedProductResModelCopyWith<$Res> {
  _$RelatedProductResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RelatedProductResModelImplCopyWith<$Res>
    implements $RelatedProductResModelCopyWith<$Res> {
  factory _$$RelatedProductResModelImplCopyWith(
          _$RelatedProductResModelImpl value,
          $Res Function(_$RelatedProductResModelImpl) then) =
      __$$RelatedProductResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int status, String message, List<RelatedProductDatum> data});
}

/// @nodoc
class __$$RelatedProductResModelImplCopyWithImpl<$Res>
    extends _$RelatedProductResModelCopyWithImpl<$Res,
        _$RelatedProductResModelImpl>
    implements _$$RelatedProductResModelImplCopyWith<$Res> {
  __$$RelatedProductResModelImplCopyWithImpl(
      _$RelatedProductResModelImpl _value,
      $Res Function(_$RelatedProductResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_$RelatedProductResModelImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RelatedProductResModelImpl implements _RelatedProductResModel {
  const _$RelatedProductResModelImpl(
      {required this.status,
      required this.message,
      required final List<RelatedProductDatum> data})
      : _data = data;

  factory _$RelatedProductResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$RelatedProductResModelImplFromJson(json);

  @override
  final int status;
  @override
  final String message;
  final List<RelatedProductDatum> _data;
  @override
  List<RelatedProductDatum> get data {
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_data);
  }

  @override
  String toString() {
    return 'RelatedProductResModel(status: $status, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            const DeepCollectionEquality().equals(other._data, _data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, status, message, const DeepCollectionEquality().hash(_data));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductResModelImplCopyWith<_$RelatedProductResModelImpl>
      get copyWith => __$$RelatedProductResModelImplCopyWithImpl<
          _$RelatedProductResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RelatedProductResModelImplToJson(
      this,
    );
  }
}

abstract class _RelatedProductResModel implements RelatedProductResModel {
  const factory _RelatedProductResModel(
          {required final int status,
          required final String message,
          required final List<RelatedProductDatum> data}) =
      _$RelatedProductResModelImpl;

  factory _RelatedProductResModel.fromJson(Map<String, dynamic> json) =
      _$RelatedProductResModelImpl.fromJson;

  @override
  int get status;
  @override
  String get message;
  @override
  List<RelatedProductDatum> get data;
  @override
  @JsonKey(ignore: true)
  _$$RelatedProductResModelImplCopyWith<_$RelatedProductResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

RelatedProductDatum _$RelatedProductDatumFromJson(Map<String, dynamic> json) {
  return _Datum.fromJson(json);
}

/// @nodoc
mixin _$RelatedProductDatum {
  String get numberOfUnit => throw _privateConstructorUsedError;
  String get itemsWeight => throw _privateConstructorUsedError;
  String get totalWeightCardboard => throw _privateConstructorUsedError;
  String get totalWeightSurface => throw _privateConstructorUsedError;
  String get totalWeight => throw _privateConstructorUsedError;
  String get createdAt => throw _privateConstructorUsedError;
  String get updatedAt => throw _privateConstructorUsedError;
  bool get isBottle => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String get id => throw _privateConstructorUsedError;
  String get productName => throw _privateConstructorUsedError;
  String get brandId => throw _privateConstructorUsedError;
  String get brandLogo => throw _privateConstructorUsedError;
  String get manufactureName => throw _privateConstructorUsedError;
  String get healthAndLifestye => throw _privateConstructorUsedError;
  String get productDescription => throw _privateConstructorUsedError;
  String get component => throw _privateConstructorUsedError;
  String get nutritionalValue => throw _privateConstructorUsedError;
  String get mainImage => throw _privateConstructorUsedError;
  List<dynamic> get images => throw _privateConstructorUsedError;
  String get qrcode => throw _privateConstructorUsedError;
  String get sku => throw _privateConstructorUsedError;
  String get createdBy => throw _privateConstructorUsedError;
  String get updatedBy => throw _privateConstructorUsedError;
  String get categories => throw _privateConstructorUsedError;
  String get subcategories => throw _privateConstructorUsedError;
  String get manufacturingCountry => throw _privateConstructorUsedError;
  String get caseType => throw _privateConstructorUsedError;
  String get scale => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get productNumber => throw _privateConstructorUsedError;
  String get productStock => throw _privateConstructorUsedError;
  double get productPrice => throw _privateConstructorUsedError;
  int get totalSale => throw _privateConstructorUsedError;
  String get lowStock => throw _privateConstructorUsedError;
  bool get isPesach => throw _privateConstructorUsedError;
  String get nmMashlim => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RelatedProductDatumCopyWith<RelatedProductDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RelatedProductDatumCopyWith<$Res> {
  factory $RelatedProductDatumCopyWith(
          RelatedProductDatum value, $Res Function(RelatedProductDatum) then) =
      _$RelatedProductDatumCopyWithImpl<$Res, RelatedProductDatum>;
  @useResult
  $Res call(
      {String numberOfUnit,
      String itemsWeight,
      String totalWeightCardboard,
      String totalWeightSurface,
      String totalWeight,
      String createdAt,
      String updatedAt,
      bool isBottle,
      @JsonKey(name: "_id") String id,
      String productName,
      String brandId,
      String brandLogo,
      String manufactureName,
      String healthAndLifestye,
      String productDescription,
      String component,
      String nutritionalValue,
      String mainImage,
      List<dynamic> images,
      String qrcode,
      String sku,
      String createdBy,
      String updatedBy,
      String categories,
      String subcategories,
      String manufacturingCountry,
      String caseType,
      String scale,
      String status,
      String productNumber,
      String productStock,
      double productPrice,
      int totalSale,
      String lowStock,
      bool isPesach,
      String nmMashlim});
}

/// @nodoc
class _$RelatedProductDatumCopyWithImpl<$Res, $Val extends RelatedProductDatum>
    implements $RelatedProductDatumCopyWith<$Res> {
  _$RelatedProductDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberOfUnit = null,
    Object? itemsWeight = null,
    Object? totalWeightCardboard = null,
    Object? totalWeightSurface = null,
    Object? totalWeight = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? isBottle = null,
    Object? id = null,
    Object? productName = null,
    Object? brandId = null,
    Object? brandLogo = null,
    Object? manufactureName = null,
    Object? healthAndLifestye = null,
    Object? productDescription = null,
    Object? component = null,
    Object? nutritionalValue = null,
    Object? mainImage = null,
    Object? images = null,
    Object? qrcode = null,
    Object? sku = null,
    Object? createdBy = null,
    Object? updatedBy = null,
    Object? categories = null,
    Object? subcategories = null,
    Object? manufacturingCountry = null,
    Object? caseType = null,
    Object? scale = null,
    Object? status = null,
    Object? productNumber = null,
    Object? productStock = null,
    Object? productPrice = null,
    Object? totalSale = null,
    Object? lowStock = null,
    Object? isPesach = null,
    Object? nmMashlim = null,
  }) {
    return _then(_value.copyWith(
      numberOfUnit: null == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String,
      itemsWeight: null == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String,
      totalWeightCardboard: null == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as String,
      totalWeightSurface: null == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as String,
      totalWeight: null == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String,
      isBottle: null == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool,
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      productName: null == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String,
      brandId: null == brandId
          ? _value.brandId
          : brandId // ignore: cast_nullable_to_non_nullable
              as String,
      brandLogo: null == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String,
      manufactureName: null == manufactureName
          ? _value.manufactureName
          : manufactureName // ignore: cast_nullable_to_non_nullable
              as String,
      healthAndLifestye: null == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String,
      productDescription: null == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String,
      component: null == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String,
      nutritionalValue: null == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String,
      mainImage: null == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String,
      images: null == images
          ? _value.images
          : images // ignore: cast_nullable_to_non_nullable
              as List<dynamic>,
      qrcode: null == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String,
      sku: null == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String,
      createdBy: null == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String,
      updatedBy: null == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String,
      categories: null == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as String,
      subcategories: null == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String,
      manufacturingCountry: null == manufacturingCountry
          ? _value.manufacturingCountry
          : manufacturingCountry // ignore: cast_nullable_to_non_nullable
              as String,
      caseType: null == caseType
          ? _value.caseType
          : caseType // ignore: cast_nullable_to_non_nullable
              as String,
      scale: null == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      productNumber: null == productNumber
          ? _value.productNumber
          : productNumber // ignore: cast_nullable_to_non_nullable
              as String,
      productStock: null == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String,
      productPrice: null == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double,
      totalSale: null == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int,
      lowStock: null == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String,
      isPesach: null == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool,
      nmMashlim: null == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DatumImplCopyWith<$Res>
    implements $RelatedProductDatumCopyWith<$Res> {
  factory _$$DatumImplCopyWith(
          _$DatumImpl value, $Res Function(_$DatumImpl) then) =
      __$$DatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String numberOfUnit,
      String itemsWeight,
      String totalWeightCardboard,
      String totalWeightSurface,
      String totalWeight,
      String createdAt,
      String updatedAt,
      bool isBottle,
      @JsonKey(name: "_id") String id,
      String productName,
      String brandId,
      String brandLogo,
      String manufactureName,
      String healthAndLifestye,
      String productDescription,
      String component,
      String nutritionalValue,
      String mainImage,
      List<dynamic> images,
      String qrcode,
      String sku,
      String createdBy,
      String updatedBy,
      String categories,
      String subcategories,
      String manufacturingCountry,
      String caseType,
      String scale,
      String status,
      String productNumber,
      String productStock,
      double productPrice,
      int totalSale,
      String lowStock,
      bool isPesach,
      String nmMashlim});
}

/// @nodoc
class __$$DatumImplCopyWithImpl<$Res>
    extends _$RelatedProductDatumCopyWithImpl<$Res, _$DatumImpl>
    implements _$$DatumImplCopyWith<$Res> {
  __$$DatumImplCopyWithImpl(
      _$DatumImpl _value, $Res Function(_$DatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberOfUnit = null,
    Object? itemsWeight = null,
    Object? totalWeightCardboard = null,
    Object? totalWeightSurface = null,
    Object? totalWeight = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? isBottle = null,
    Object? id = null,
    Object? productName = null,
    Object? brandId = null,
    Object? brandLogo = null,
    Object? manufactureName = null,
    Object? healthAndLifestye = null,
    Object? productDescription = null,
    Object? component = null,
    Object? nutritionalValue = null,
    Object? mainImage = null,
    Object? images = null,
    Object? qrcode = null,
    Object? sku = null,
    Object? createdBy = null,
    Object? updatedBy = null,
    Object? categories = null,
    Object? subcategories = null,
    Object? manufacturingCountry = null,
    Object? caseType = null,
    Object? scale = null,
    Object? status = null,
    Object? productNumber = null,
    Object? productStock = null,
    Object? productPrice = null,
    Object? totalSale = null,
    Object? lowStock = null,
    Object? isPesach = null,
    Object? nmMashlim = null,
  }) {
    return _then(_$DatumImpl(
      numberOfUnit: null == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String,
      itemsWeight: null == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String,
      totalWeightCardboard: null == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as String,
      totalWeightSurface: null == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as String,
      totalWeight: null == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String,
      isBottle: null == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool,
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      productName: null == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String,
      brandId: null == brandId
          ? _value.brandId
          : brandId // ignore: cast_nullable_to_non_nullable
              as String,
      brandLogo: null == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String,
      manufactureName: null == manufactureName
          ? _value.manufactureName
          : manufactureName // ignore: cast_nullable_to_non_nullable
              as String,
      healthAndLifestye: null == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String,
      productDescription: null == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String,
      component: null == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String,
      nutritionalValue: null == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String,
      mainImage: null == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String,
      images: null == images
          ? _value._images
          : images // ignore: cast_nullable_to_non_nullable
              as List<dynamic>,
      qrcode: null == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String,
      sku: null == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String,
      createdBy: null == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String,
      updatedBy: null == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String,
      categories: null == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as String,
      subcategories: null == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String,
      manufacturingCountry: null == manufacturingCountry
          ? _value.manufacturingCountry
          : manufacturingCountry // ignore: cast_nullable_to_non_nullable
              as String,
      caseType: null == caseType
          ? _value.caseType
          : caseType // ignore: cast_nullable_to_non_nullable
              as String,
      scale: null == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      productNumber: null == productNumber
          ? _value.productNumber
          : productNumber // ignore: cast_nullable_to_non_nullable
              as String,
      productStock: null == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String,
      productPrice: null == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double,
      totalSale: null == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int,
      lowStock: null == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String,
      isPesach: null == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool,
      nmMashlim: null == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DatumImpl implements _Datum {
  const _$DatumImpl(
      {required this.numberOfUnit,
      required this.itemsWeight,
      required this.totalWeightCardboard,
      required this.totalWeightSurface,
      required this.totalWeight,
      required this.createdAt,
      required this.updatedAt,
      required this.isBottle,
      @JsonKey(name: "_id") required this.id,
      required this.productName,
      required this.brandId,
      required this.brandLogo,
      required this.manufactureName,
      required this.healthAndLifestye,
      required this.productDescription,
      required this.component,
      required this.nutritionalValue,
      required this.mainImage,
      required final List<dynamic> images,
      required this.qrcode,
      required this.sku,
      required this.createdBy,
      required this.updatedBy,
      required this.categories,
      required this.subcategories,
      required this.manufacturingCountry,
      required this.caseType,
      required this.scale,
      required this.status,
      required this.productNumber,
      required this.productStock,
      required this.productPrice,
      required this.totalSale,
      required this.lowStock,
      required this.isPesach,
      required this.nmMashlim})
      : _images = images;

  factory _$DatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$DatumImplFromJson(json);

  @override
  final String numberOfUnit;
  @override
  final String itemsWeight;
  @override
  final String totalWeightCardboard;
  @override
  final String totalWeightSurface;
  @override
  final String totalWeight;
  @override
  final String createdAt;
  @override
  final String updatedAt;
  @override
  final bool isBottle;
  @override
  @JsonKey(name: "_id")
  final String id;
  @override
  final String productName;
  @override
  final String brandId;
  @override
  final String brandLogo;
  @override
  final String manufactureName;
  @override
  final String healthAndLifestye;
  @override
  final String productDescription;
  @override
  final String component;
  @override
  final String nutritionalValue;
  @override
  final String mainImage;
  final List<dynamic> _images;
  @override
  List<dynamic> get images {
    if (_images is EqualUnmodifiableListView) return _images;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_images);
  }

  @override
  final String qrcode;
  @override
  final String sku;
  @override
  final String createdBy;
  @override
  final String updatedBy;
  @override
  final String categories;
  @override
  final String subcategories;
  @override
  final String manufacturingCountry;
  @override
  final String caseType;
  @override
  final String scale;
  @override
  final String status;
  @override
  final String productNumber;
  @override
  final String productStock;
  @override
  final double productPrice;
  @override
  final int totalSale;
  @override
  final String lowStock;
  @override
  final bool isPesach;
  @override
  final String nmMashlim;

  @override
  String toString() {
    return 'RelatedProductDatum(numberOfUnit: $numberOfUnit, itemsWeight: $itemsWeight, totalWeightCardboard: $totalWeightCardboard, totalWeightSurface: $totalWeightSurface, totalWeight: $totalWeight, createdAt: $createdAt, updatedAt: $updatedAt, isBottle: $isBottle, id: $id, productName: $productName, brandId: $brandId, brandLogo: $brandLogo, manufactureName: $manufactureName, healthAndLifestye: $healthAndLifestye, productDescription: $productDescription, component: $component, nutritionalValue: $nutritionalValue, mainImage: $mainImage, images: $images, qrcode: $qrcode, sku: $sku, createdBy: $createdBy, updatedBy: $updatedBy, categories: $categories, subcategories: $subcategories, manufacturingCountry: $manufacturingCountry, caseType: $caseType, scale: $scale, status: $status, productNumber: $productNumber, productStock: $productStock, productPrice: $productPrice, totalSale: $totalSale, lowStock: $lowStock, isPesach: $isPesach, nmMashlim: $nmMashlim)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DatumImpl &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.totalWeightCardboard, totalWeightCardboard) ||
                other.totalWeightCardboard == totalWeightCardboard) &&
            (identical(other.totalWeightSurface, totalWeightSurface) ||
                other.totalWeightSurface == totalWeightSurface) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.isBottle, isBottle) ||
                other.isBottle == isBottle) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.brandId, brandId) || other.brandId == brandId) &&
            (identical(other.brandLogo, brandLogo) ||
                other.brandLogo == brandLogo) &&
            (identical(other.manufactureName, manufactureName) ||
                other.manufactureName == manufactureName) &&
            (identical(other.healthAndLifestye, healthAndLifestye) ||
                other.healthAndLifestye == healthAndLifestye) &&
            (identical(other.productDescription, productDescription) ||
                other.productDescription == productDescription) &&
            (identical(other.component, component) ||
                other.component == component) &&
            (identical(other.nutritionalValue, nutritionalValue) ||
                other.nutritionalValue == nutritionalValue) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            const DeepCollectionEquality().equals(other._images, _images) &&
            (identical(other.qrcode, qrcode) || other.qrcode == qrcode) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.categories, categories) ||
                other.categories == categories) &&
            (identical(other.subcategories, subcategories) ||
                other.subcategories == subcategories) &&
            (identical(other.manufacturingCountry, manufacturingCountry) ||
                other.manufacturingCountry == manufacturingCountry) &&
            (identical(other.caseType, caseType) ||
                other.caseType == caseType) &&
            (identical(other.scale, scale) || other.scale == scale) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.productNumber, productNumber) ||
                other.productNumber == productNumber) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.totalSale, totalSale) ||
                other.totalSale == totalSale) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        numberOfUnit,
        itemsWeight,
        totalWeightCardboard,
        totalWeightSurface,
        totalWeight,
        createdAt,
        updatedAt,
        isBottle,
        id,
        productName,
        brandId,
        brandLogo,
        manufactureName,
        healthAndLifestye,
        productDescription,
        component,
        nutritionalValue,
        mainImage,
        const DeepCollectionEquality().hash(_images),
        qrcode,
        sku,
        createdBy,
        updatedBy,
        categories,
        subcategories,
        manufacturingCountry,
        caseType,
        scale,
        status,
        productNumber,
        productStock,
        productPrice,
        totalSale,
        lowStock,
        isPesach,
        nmMashlim
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      __$$DatumImplCopyWithImpl<_$DatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DatumImplToJson(
      this,
    );
  }
}

abstract class _Datum implements RelatedProductDatum {
  const factory _Datum(
      {required final String numberOfUnit,
      required final String itemsWeight,
      required final String totalWeightCardboard,
      required final String totalWeightSurface,
      required final String totalWeight,
      required final String createdAt,
      required final String updatedAt,
      required final bool isBottle,
      @JsonKey(name: "_id") required final String id,
      required final String productName,
      required final String brandId,
      required final String brandLogo,
      required final String manufactureName,
      required final String healthAndLifestye,
      required final String productDescription,
      required final String component,
      required final String nutritionalValue,
      required final String mainImage,
      required final List<dynamic> images,
      required final String qrcode,
      required final String sku,
      required final String createdBy,
      required final String updatedBy,
      required final String categories,
      required final String subcategories,
      required final String manufacturingCountry,
      required final String caseType,
      required final String scale,
      required final String status,
      required final String productNumber,
      required final String productStock,
      required final double productPrice,
      required final int totalSale,
      required final String lowStock,
      required final bool isPesach,
      required final String nmMashlim}) = _$DatumImpl;

  factory _Datum.fromJson(Map<String, dynamic> json) = _$DatumImpl.fromJson;

  @override
  String get numberOfUnit;
  @override
  String get itemsWeight;
  @override
  String get totalWeightCardboard;
  @override
  String get totalWeightSurface;
  @override
  String get totalWeight;
  @override
  String get createdAt;
  @override
  String get updatedAt;
  @override
  bool get isBottle;
  @override
  @JsonKey(name: "_id")
  String get id;
  @override
  String get productName;
  @override
  String get brandId;
  @override
  String get brandLogo;
  @override
  String get manufactureName;
  @override
  String get healthAndLifestye;
  @override
  String get productDescription;
  @override
  String get component;
  @override
  String get nutritionalValue;
  @override
  String get mainImage;
  @override
  List<dynamic> get images;
  @override
  String get qrcode;
  @override
  String get sku;
  @override
  String get createdBy;
  @override
  String get updatedBy;
  @override
  String get categories;
  @override
  String get subcategories;
  @override
  String get manufacturingCountry;
  @override
  String get caseType;
  @override
  String get scale;
  @override
  String get status;
  @override
  String get productNumber;
  @override
  String get productStock;
  @override
  double get productPrice;
  @override
  int get totalSale;
  @override
  String get lowStock;
  @override
  bool get isPesach;
  @override
  String get nmMashlim;
  @override
  @JsonKey(ignore: true)
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
