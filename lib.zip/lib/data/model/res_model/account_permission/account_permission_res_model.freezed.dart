// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'account_permission_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

AccountPermissionResModel _$AccountPermissionResModelFromJson(
    Map<String, dynamic> json) {
  return _AccountPermissionResModel.fromJson(json);
}

/// @nodoc
mixin _$AccountPermissionResModel {
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AccountPermissionResModelCopyWith<AccountPermissionResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AccountPermissionResModelCopyWith<$Res> {
  factory $AccountPermissionResModelCopyWith(AccountPermissionResModel value,
          $Res Function(AccountPermissionResModel) then) =
      _$AccountPermissionResModelCopyWithImpl<$Res, AccountPermissionResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "data") Data? data,
      @JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$AccountPermissionResModelCopyWithImpl<$Res,
        $Val extends AccountPermissionResModel>
    implements $AccountPermissionResModelCopyWith<$Res> {
  _$AccountPermissionResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = freezed,
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$AccountPermissionResModelImplCopyWith<$Res>
    implements $AccountPermissionResModelCopyWith<$Res> {
  factory _$$AccountPermissionResModelImplCopyWith(
          _$AccountPermissionResModelImpl value,
          $Res Function(_$AccountPermissionResModelImpl) then) =
      __$$AccountPermissionResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "data") Data? data,
      @JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$AccountPermissionResModelImplCopyWithImpl<$Res>
    extends _$AccountPermissionResModelCopyWithImpl<$Res,
        _$AccountPermissionResModelImpl>
    implements _$$AccountPermissionResModelImplCopyWith<$Res> {
  __$$AccountPermissionResModelImplCopyWithImpl(
      _$AccountPermissionResModelImpl _value,
      $Res Function(_$AccountPermissionResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = freezed,
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_$AccountPermissionResModelImpl(
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AccountPermissionResModelImpl implements _AccountPermissionResModel {
  const _$AccountPermissionResModelImpl(
      {@JsonKey(name: "data") this.data,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message});

  factory _$AccountPermissionResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$AccountPermissionResModelImplFromJson(json);

  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'AccountPermissionResModel(data: $data, status: $status, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AccountPermissionResModelImpl &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, data, status, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AccountPermissionResModelImplCopyWith<_$AccountPermissionResModelImpl>
      get copyWith => __$$AccountPermissionResModelImplCopyWithImpl<
          _$AccountPermissionResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AccountPermissionResModelImplToJson(
      this,
    );
  }
}

abstract class _AccountPermissionResModel implements AccountPermissionResModel {
  const factory _AccountPermissionResModel(
          {@JsonKey(name: "data") final Data? data,
          @JsonKey(name: "status") final int? status,
          @JsonKey(name: "message") final String? message}) =
      _$AccountPermissionResModelImpl;

  factory _AccountPermissionResModel.fromJson(Map<String, dynamic> json) =
      _$AccountPermissionResModelImpl.fromJson;

  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$AccountPermissionResModelImplCopyWith<_$AccountPermissionResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "subUserId")
  String? get subUserId => throw _privateConstructorUsedError;
  @JsonKey(name: "permissions")
  Permissions? get permissions => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subUserId") String? subUserId,
      @JsonKey(name: "permissions") Permissions? permissions,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  $PermissionsCopyWith<$Res>? get permissions;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subUserId = freezed,
    Object? permissions = freezed,
    Object? createdBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subUserId: freezed == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String?,
      permissions: freezed == permissions
          ? _value.permissions
          : permissions // ignore: cast_nullable_to_non_nullable
              as Permissions?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $PermissionsCopyWith<$Res>? get permissions {
    if (_value.permissions == null) {
      return null;
    }

    return $PermissionsCopyWith<$Res>(_value.permissions!, (value) {
      return _then(_value.copyWith(permissions: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subUserId") String? subUserId,
      @JsonKey(name: "permissions") Permissions? permissions,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  @override
  $PermissionsCopyWith<$Res>? get permissions;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subUserId = freezed,
    Object? permissions = freezed,
    Object? createdBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$DataImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subUserId: freezed == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String?,
      permissions: freezed == permissions
          ? _value.permissions
          : permissions // ignore: cast_nullable_to_non_nullable
              as Permissions?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "subUserId") this.subUserId,
      @JsonKey(name: "permissions") this.permissions,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "subUserId")
  final String? subUserId;
  @override
  @JsonKey(name: "permissions")
  final Permissions? permissions;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Data(id: $id, subUserId: $subUserId, permissions: $permissions, createdBy: $createdBy, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId) &&
            (identical(other.permissions, permissions) ||
                other.permissions == permissions) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, subUserId, permissions,
      createdBy, createdAt, updatedAt, v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "subUserId") final String? subUserId,
      @JsonKey(name: "permissions") final Permissions? permissions,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "subUserId")
  String? get subUserId;
  @override
  @JsonKey(name: "permissions")
  Permissions? get permissions;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Permissions _$PermissionsFromJson(Map<String, dynamic> json) {
  return _Permissions.fromJson(json);
}

/// @nodoc
mixin _$Permissions {
  @JsonKey(name: "accountAdmin")
  bool? get accountAdmin => throw _privateConstructorUsedError;
  @JsonKey(name: "canSeeWallet")
  bool? get canSeeWallet => throw _privateConstructorUsedError;
  @JsonKey(name: "canCreateOrder")
  bool? get canCreateOrder => throw _privateConstructorUsedError;
  @JsonKey(name: "canAddToCart")
  bool? get canAddToCart => throw _privateConstructorUsedError;
  @JsonKey(name: "canSeeOrders")
  bool? get canSeeOrders => throw _privateConstructorUsedError;
  @JsonKey(name: "canApproveOrders")
  bool? get canApproveOrders => throw _privateConstructorUsedError;
  @JsonKey(name: "canDuplicateOrders")
  bool? get canDuplicateOrders => throw _privateConstructorUsedError;
  @JsonKey(name: "canSeeAndUpdateBusinessInfo")
  bool? get canSeeAndUpdateBusinessInfo => throw _privateConstructorUsedError;
  @JsonKey(name: "canSeeAndUpdateAdditionalInfo")
  bool? get canSeeAndUpdateAdditionalInfo => throw _privateConstructorUsedError;
  @JsonKey(name: "canSeeFileAndForms")
  bool? get canSeeFileAndForms => throw _privateConstructorUsedError;
  @JsonKey(name: "canManageSubUsers")
  bool? get canManageSubUsers => throw _privateConstructorUsedError;
  bool? get canSeeAndUpdateTimesInfo => throw _privateConstructorUsedError;
  bool? get canSeeInvoices => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PermissionsCopyWith<Permissions> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PermissionsCopyWith<$Res> {
  factory $PermissionsCopyWith(
          Permissions value, $Res Function(Permissions) then) =
      _$PermissionsCopyWithImpl<$Res, Permissions>;
  @useResult
  $Res call(
      {@JsonKey(name: "accountAdmin") bool? accountAdmin,
      @JsonKey(name: "canSeeWallet") bool? canSeeWallet,
      @JsonKey(name: "canCreateOrder") bool? canCreateOrder,
      @JsonKey(name: "canAddToCart") bool? canAddToCart,
      @JsonKey(name: "canSeeOrders") bool? canSeeOrders,
      @JsonKey(name: "canApproveOrders") bool? canApproveOrders,
      @JsonKey(name: "canDuplicateOrders") bool? canDuplicateOrders,
      @JsonKey(name: "canSeeAndUpdateBusinessInfo")
      bool? canSeeAndUpdateBusinessInfo,
      @JsonKey(name: "canSeeAndUpdateAdditionalInfo")
      bool? canSeeAndUpdateAdditionalInfo,
      @JsonKey(name: "canSeeFileAndForms") bool? canSeeFileAndForms,
      @JsonKey(name: "canManageSubUsers") bool? canManageSubUsers,
      bool? canSeeAndUpdateTimesInfo,
      bool? canSeeInvoices});
}

/// @nodoc
class _$PermissionsCopyWithImpl<$Res, $Val extends Permissions>
    implements $PermissionsCopyWith<$Res> {
  _$PermissionsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? accountAdmin = freezed,
    Object? canSeeWallet = freezed,
    Object? canCreateOrder = freezed,
    Object? canAddToCart = freezed,
    Object? canSeeOrders = freezed,
    Object? canApproveOrders = freezed,
    Object? canDuplicateOrders = freezed,
    Object? canSeeAndUpdateBusinessInfo = freezed,
    Object? canSeeAndUpdateAdditionalInfo = freezed,
    Object? canSeeFileAndForms = freezed,
    Object? canManageSubUsers = freezed,
    Object? canSeeAndUpdateTimesInfo = freezed,
    Object? canSeeInvoices = freezed,
  }) {
    return _then(_value.copyWith(
      accountAdmin: freezed == accountAdmin
          ? _value.accountAdmin
          : accountAdmin // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeWallet: freezed == canSeeWallet
          ? _value.canSeeWallet
          : canSeeWallet // ignore: cast_nullable_to_non_nullable
              as bool?,
      canCreateOrder: freezed == canCreateOrder
          ? _value.canCreateOrder
          : canCreateOrder // ignore: cast_nullable_to_non_nullable
              as bool?,
      canAddToCart: freezed == canAddToCart
          ? _value.canAddToCart
          : canAddToCart // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeOrders: freezed == canSeeOrders
          ? _value.canSeeOrders
          : canSeeOrders // ignore: cast_nullable_to_non_nullable
              as bool?,
      canApproveOrders: freezed == canApproveOrders
          ? _value.canApproveOrders
          : canApproveOrders // ignore: cast_nullable_to_non_nullable
              as bool?,
      canDuplicateOrders: freezed == canDuplicateOrders
          ? _value.canDuplicateOrders
          : canDuplicateOrders // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeAndUpdateBusinessInfo: freezed == canSeeAndUpdateBusinessInfo
          ? _value.canSeeAndUpdateBusinessInfo
          : canSeeAndUpdateBusinessInfo // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeAndUpdateAdditionalInfo: freezed == canSeeAndUpdateAdditionalInfo
          ? _value.canSeeAndUpdateAdditionalInfo
          : canSeeAndUpdateAdditionalInfo // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeFileAndForms: freezed == canSeeFileAndForms
          ? _value.canSeeFileAndForms
          : canSeeFileAndForms // ignore: cast_nullable_to_non_nullable
              as bool?,
      canManageSubUsers: freezed == canManageSubUsers
          ? _value.canManageSubUsers
          : canManageSubUsers // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeAndUpdateTimesInfo: freezed == canSeeAndUpdateTimesInfo
          ? _value.canSeeAndUpdateTimesInfo
          : canSeeAndUpdateTimesInfo // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeInvoices: freezed == canSeeInvoices
          ? _value.canSeeInvoices
          : canSeeInvoices // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PermissionsImplCopyWith<$Res>
    implements $PermissionsCopyWith<$Res> {
  factory _$$PermissionsImplCopyWith(
          _$PermissionsImpl value, $Res Function(_$PermissionsImpl) then) =
      __$$PermissionsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "accountAdmin") bool? accountAdmin,
      @JsonKey(name: "canSeeWallet") bool? canSeeWallet,
      @JsonKey(name: "canCreateOrder") bool? canCreateOrder,
      @JsonKey(name: "canAddToCart") bool? canAddToCart,
      @JsonKey(name: "canSeeOrders") bool? canSeeOrders,
      @JsonKey(name: "canApproveOrders") bool? canApproveOrders,
      @JsonKey(name: "canDuplicateOrders") bool? canDuplicateOrders,
      @JsonKey(name: "canSeeAndUpdateBusinessInfo")
      bool? canSeeAndUpdateBusinessInfo,
      @JsonKey(name: "canSeeAndUpdateAdditionalInfo")
      bool? canSeeAndUpdateAdditionalInfo,
      @JsonKey(name: "canSeeFileAndForms") bool? canSeeFileAndForms,
      @JsonKey(name: "canManageSubUsers") bool? canManageSubUsers,
      bool? canSeeAndUpdateTimesInfo,
      bool? canSeeInvoices});
}

/// @nodoc
class __$$PermissionsImplCopyWithImpl<$Res>
    extends _$PermissionsCopyWithImpl<$Res, _$PermissionsImpl>
    implements _$$PermissionsImplCopyWith<$Res> {
  __$$PermissionsImplCopyWithImpl(
      _$PermissionsImpl _value, $Res Function(_$PermissionsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? accountAdmin = freezed,
    Object? canSeeWallet = freezed,
    Object? canCreateOrder = freezed,
    Object? canAddToCart = freezed,
    Object? canSeeOrders = freezed,
    Object? canApproveOrders = freezed,
    Object? canDuplicateOrders = freezed,
    Object? canSeeAndUpdateBusinessInfo = freezed,
    Object? canSeeAndUpdateAdditionalInfo = freezed,
    Object? canSeeFileAndForms = freezed,
    Object? canManageSubUsers = freezed,
    Object? canSeeAndUpdateTimesInfo = freezed,
    Object? canSeeInvoices = freezed,
  }) {
    return _then(_$PermissionsImpl(
      accountAdmin: freezed == accountAdmin
          ? _value.accountAdmin
          : accountAdmin // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeWallet: freezed == canSeeWallet
          ? _value.canSeeWallet
          : canSeeWallet // ignore: cast_nullable_to_non_nullable
              as bool?,
      canCreateOrder: freezed == canCreateOrder
          ? _value.canCreateOrder
          : canCreateOrder // ignore: cast_nullable_to_non_nullable
              as bool?,
      canAddToCart: freezed == canAddToCart
          ? _value.canAddToCart
          : canAddToCart // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeOrders: freezed == canSeeOrders
          ? _value.canSeeOrders
          : canSeeOrders // ignore: cast_nullable_to_non_nullable
              as bool?,
      canApproveOrders: freezed == canApproveOrders
          ? _value.canApproveOrders
          : canApproveOrders // ignore: cast_nullable_to_non_nullable
              as bool?,
      canDuplicateOrders: freezed == canDuplicateOrders
          ? _value.canDuplicateOrders
          : canDuplicateOrders // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeAndUpdateBusinessInfo: freezed == canSeeAndUpdateBusinessInfo
          ? _value.canSeeAndUpdateBusinessInfo
          : canSeeAndUpdateBusinessInfo // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeAndUpdateAdditionalInfo: freezed == canSeeAndUpdateAdditionalInfo
          ? _value.canSeeAndUpdateAdditionalInfo
          : canSeeAndUpdateAdditionalInfo // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeFileAndForms: freezed == canSeeFileAndForms
          ? _value.canSeeFileAndForms
          : canSeeFileAndForms // ignore: cast_nullable_to_non_nullable
              as bool?,
      canManageSubUsers: freezed == canManageSubUsers
          ? _value.canManageSubUsers
          : canManageSubUsers // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeAndUpdateTimesInfo: freezed == canSeeAndUpdateTimesInfo
          ? _value.canSeeAndUpdateTimesInfo
          : canSeeAndUpdateTimesInfo // ignore: cast_nullable_to_non_nullable
              as bool?,
      canSeeInvoices: freezed == canSeeInvoices
          ? _value.canSeeInvoices
          : canSeeInvoices // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PermissionsImpl implements _Permissions {
  const _$PermissionsImpl(
      {@JsonKey(name: "accountAdmin") this.accountAdmin,
      @JsonKey(name: "canSeeWallet") this.canSeeWallet,
      @JsonKey(name: "canCreateOrder") this.canCreateOrder,
      @JsonKey(name: "canAddToCart") this.canAddToCart,
      @JsonKey(name: "canSeeOrders") this.canSeeOrders,
      @JsonKey(name: "canApproveOrders") this.canApproveOrders,
      @JsonKey(name: "canDuplicateOrders") this.canDuplicateOrders,
      @JsonKey(name: "canSeeAndUpdateBusinessInfo")
      this.canSeeAndUpdateBusinessInfo,
      @JsonKey(name: "canSeeAndUpdateAdditionalInfo")
      this.canSeeAndUpdateAdditionalInfo,
      @JsonKey(name: "canSeeFileAndForms") this.canSeeFileAndForms,
      @JsonKey(name: "canManageSubUsers") this.canManageSubUsers,
      this.canSeeAndUpdateTimesInfo,
      this.canSeeInvoices});

  factory _$PermissionsImpl.fromJson(Map<String, dynamic> json) =>
      _$$PermissionsImplFromJson(json);

  @override
  @JsonKey(name: "accountAdmin")
  final bool? accountAdmin;
  @override
  @JsonKey(name: "canSeeWallet")
  final bool? canSeeWallet;
  @override
  @JsonKey(name: "canCreateOrder")
  final bool? canCreateOrder;
  @override
  @JsonKey(name: "canAddToCart")
  final bool? canAddToCart;
  @override
  @JsonKey(name: "canSeeOrders")
  final bool? canSeeOrders;
  @override
  @JsonKey(name: "canApproveOrders")
  final bool? canApproveOrders;
  @override
  @JsonKey(name: "canDuplicateOrders")
  final bool? canDuplicateOrders;
  @override
  @JsonKey(name: "canSeeAndUpdateBusinessInfo")
  final bool? canSeeAndUpdateBusinessInfo;
  @override
  @JsonKey(name: "canSeeAndUpdateAdditionalInfo")
  final bool? canSeeAndUpdateAdditionalInfo;
  @override
  @JsonKey(name: "canSeeFileAndForms")
  final bool? canSeeFileAndForms;
  @override
  @JsonKey(name: "canManageSubUsers")
  final bool? canManageSubUsers;
  @override
  final bool? canSeeAndUpdateTimesInfo;
  @override
  final bool? canSeeInvoices;

  @override
  String toString() {
    return 'Permissions(accountAdmin: $accountAdmin, canSeeWallet: $canSeeWallet, canCreateOrder: $canCreateOrder, canAddToCart: $canAddToCart, canSeeOrders: $canSeeOrders, canApproveOrders: $canApproveOrders, canDuplicateOrders: $canDuplicateOrders, canSeeAndUpdateBusinessInfo: $canSeeAndUpdateBusinessInfo, canSeeAndUpdateAdditionalInfo: $canSeeAndUpdateAdditionalInfo, canSeeFileAndForms: $canSeeFileAndForms, canManageSubUsers: $canManageSubUsers, canSeeAndUpdateTimesInfo: $canSeeAndUpdateTimesInfo, canSeeInvoices: $canSeeInvoices)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PermissionsImpl &&
            (identical(other.accountAdmin, accountAdmin) ||
                other.accountAdmin == accountAdmin) &&
            (identical(other.canSeeWallet, canSeeWallet) ||
                other.canSeeWallet == canSeeWallet) &&
            (identical(other.canCreateOrder, canCreateOrder) ||
                other.canCreateOrder == canCreateOrder) &&
            (identical(other.canAddToCart, canAddToCart) ||
                other.canAddToCart == canAddToCart) &&
            (identical(other.canSeeOrders, canSeeOrders) ||
                other.canSeeOrders == canSeeOrders) &&
            (identical(other.canApproveOrders, canApproveOrders) ||
                other.canApproveOrders == canApproveOrders) &&
            (identical(other.canDuplicateOrders, canDuplicateOrders) ||
                other.canDuplicateOrders == canDuplicateOrders) &&
            (identical(other.canSeeAndUpdateBusinessInfo,
                    canSeeAndUpdateBusinessInfo) ||
                other.canSeeAndUpdateBusinessInfo ==
                    canSeeAndUpdateBusinessInfo) &&
            (identical(other.canSeeAndUpdateAdditionalInfo,
                    canSeeAndUpdateAdditionalInfo) ||
                other.canSeeAndUpdateAdditionalInfo ==
                    canSeeAndUpdateAdditionalInfo) &&
            (identical(other.canSeeFileAndForms, canSeeFileAndForms) ||
                other.canSeeFileAndForms == canSeeFileAndForms) &&
            (identical(other.canManageSubUsers, canManageSubUsers) ||
                other.canManageSubUsers == canManageSubUsers) &&
            (identical(
                    other.canSeeAndUpdateTimesInfo, canSeeAndUpdateTimesInfo) ||
                other.canSeeAndUpdateTimesInfo == canSeeAndUpdateTimesInfo) &&
            (identical(other.canSeeInvoices, canSeeInvoices) ||
                other.canSeeInvoices == canSeeInvoices));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      accountAdmin,
      canSeeWallet,
      canCreateOrder,
      canAddToCart,
      canSeeOrders,
      canApproveOrders,
      canDuplicateOrders,
      canSeeAndUpdateBusinessInfo,
      canSeeAndUpdateAdditionalInfo,
      canSeeFileAndForms,
      canManageSubUsers,
      canSeeAndUpdateTimesInfo,
      canSeeInvoices);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PermissionsImplCopyWith<_$PermissionsImpl> get copyWith =>
      __$$PermissionsImplCopyWithImpl<_$PermissionsImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PermissionsImplToJson(
      this,
    );
  }
}

abstract class _Permissions implements Permissions {
  const factory _Permissions(
      {@JsonKey(name: "accountAdmin") final bool? accountAdmin,
      @JsonKey(name: "canSeeWallet") final bool? canSeeWallet,
      @JsonKey(name: "canCreateOrder") final bool? canCreateOrder,
      @JsonKey(name: "canAddToCart") final bool? canAddToCart,
      @JsonKey(name: "canSeeOrders") final bool? canSeeOrders,
      @JsonKey(name: "canApproveOrders") final bool? canApproveOrders,
      @JsonKey(name: "canDuplicateOrders") final bool? canDuplicateOrders,
      @JsonKey(name: "canSeeAndUpdateBusinessInfo")
      final bool? canSeeAndUpdateBusinessInfo,
      @JsonKey(name: "canSeeAndUpdateAdditionalInfo")
      final bool? canSeeAndUpdateAdditionalInfo,
      @JsonKey(name: "canSeeFileAndForms") final bool? canSeeFileAndForms,
      @JsonKey(name: "canManageSubUsers") final bool? canManageSubUsers,
      final bool? canSeeAndUpdateTimesInfo,
      final bool? canSeeInvoices}) = _$PermissionsImpl;

  factory _Permissions.fromJson(Map<String, dynamic> json) =
      _$PermissionsImpl.fromJson;

  @override
  @JsonKey(name: "accountAdmin")
  bool? get accountAdmin;
  @override
  @JsonKey(name: "canSeeWallet")
  bool? get canSeeWallet;
  @override
  @JsonKey(name: "canCreateOrder")
  bool? get canCreateOrder;
  @override
  @JsonKey(name: "canAddToCart")
  bool? get canAddToCart;
  @override
  @JsonKey(name: "canSeeOrders")
  bool? get canSeeOrders;
  @override
  @JsonKey(name: "canApproveOrders")
  bool? get canApproveOrders;
  @override
  @JsonKey(name: "canDuplicateOrders")
  bool? get canDuplicateOrders;
  @override
  @JsonKey(name: "canSeeAndUpdateBusinessInfo")
  bool? get canSeeAndUpdateBusinessInfo;
  @override
  @JsonKey(name: "canSeeAndUpdateAdditionalInfo")
  bool? get canSeeAndUpdateAdditionalInfo;
  @override
  @JsonKey(name: "canSeeFileAndForms")
  bool? get canSeeFileAndForms;
  @override
  @JsonKey(name: "canManageSubUsers")
  bool? get canManageSubUsers;
  @override
  bool? get canSeeAndUpdateTimesInfo;
  @override
  bool? get canSeeInvoices;
  @override
  @JsonKey(ignore: true)
  _$$PermissionsImplCopyWith<_$PermissionsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
