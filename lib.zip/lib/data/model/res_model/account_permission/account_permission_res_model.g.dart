// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_permission_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AccountPermissionResModelImpl _$$AccountPermissionResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$AccountPermissionResModelImpl(
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      status: json['status'] as int?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$AccountPermissionResModelImplToJson(
        _$AccountPermissionResModelImpl instance) =>
    <String, dynamic>{
      'data': instance.data,
      'status': instance.status,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      id: json['_id'] as String?,
      subUserId: json['subUserId'] as String?,
      permissions: json['permissions'] == null
          ? null
          : Permissions.fromJson(json['permissions'] as Map<String, dynamic>),
      createdBy: json['createdBy'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'subUserId': instance.subUserId,
      'permissions': instance.permissions,
      'createdBy': instance.createdBy,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
    };

_$PermissionsImpl _$$PermissionsImplFromJson(Map<String, dynamic> json) =>
    _$PermissionsImpl(
      accountAdmin: json['accountAdmin'] as bool?,
      canSeeWallet: json['canSeeWallet'] as bool?,
      canCreateOrder: json['canCreateOrder'] as bool?,
      canAddToCart: json['canAddToCart'] as bool?,
      canSeeOrders: json['canSeeOrders'] as bool?,
      canApproveOrders: json['canApproveOrders'] as bool?,
      canDuplicateOrders: json['canDuplicateOrders'] as bool?,
      canSeeAndUpdateBusinessInfo: json['canSeeAndUpdateBusinessInfo'] as bool?,
      canSeeAndUpdateAdditionalInfo:
          json['canSeeAndUpdateAdditionalInfo'] as bool?,
      canSeeFileAndForms: json['canSeeFileAndForms'] as bool?,
      canManageSubUsers: json['canManageSubUsers'] as bool?,
      canSeeAndUpdateTimesInfo: json['canSeeAndUpdateTimesInfo'] as bool?,
      canSeeInvoices: json['canSeeInvoices'] as bool?,
    );

Map<String, dynamic> _$$PermissionsImplToJson(_$PermissionsImpl instance) =>
    <String, dynamic>{
      'accountAdmin': instance.accountAdmin,
      'canSeeWallet': instance.canSeeWallet,
      'canCreateOrder': instance.canCreateOrder,
      'canAddToCart': instance.canAddToCart,
      'canSeeOrders': instance.canSeeOrders,
      'canApproveOrders': instance.canApproveOrders,
      'canDuplicateOrders': instance.canDuplicateOrders,
      'canSeeAndUpdateBusinessInfo': instance.canSeeAndUpdateBusinessInfo,
      'canSeeAndUpdateAdditionalInfo': instance.canSeeAndUpdateAdditionalInfo,
      'canSeeFileAndForms': instance.canSeeFileAndForms,
      'canManageSubUsers': instance.canManageSubUsers,
      'canSeeAndUpdateTimesInfo': instance.canSeeAndUpdateTimesInfo,
      'canSeeInvoices': instance.canSeeInvoices,
    };
