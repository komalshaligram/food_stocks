// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'supplier_products_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SupplierProductsResModel _$SupplierProductsResModelFromJson(
    Map<String, dynamic> json) {
  return _SupplierProductsResModel.fromJson(json);
}

/// @nodoc
mixin _$SupplierProductsResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<SupplierProductsData>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierProductsResModelCopyWith<SupplierProductsResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierProductsResModelCopyWith<$Res> {
  factory $SupplierProductsResModelCopyWith(SupplierProductsResModel value,
          $Res Function(SupplierProductsResModel) then) =
      _$SupplierProductsResModelCopyWithImpl<$Res, SupplierProductsResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<SupplierProductsData>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$SupplierProductsResModelCopyWithImpl<$Res,
        $Val extends SupplierProductsResModel>
    implements $SupplierProductsResModelCopyWith<$Res> {
  _$SupplierProductsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<SupplierProductsData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SupplierProductsResModelImplCopyWith<$Res>
    implements $SupplierProductsResModelCopyWith<$Res> {
  factory _$$SupplierProductsResModelImplCopyWith(
          _$SupplierProductsResModelImpl value,
          $Res Function(_$SupplierProductsResModelImpl) then) =
      __$$SupplierProductsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<SupplierProductsData>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$SupplierProductsResModelImplCopyWithImpl<$Res>
    extends _$SupplierProductsResModelCopyWithImpl<$Res,
        _$SupplierProductsResModelImpl>
    implements _$$SupplierProductsResModelImplCopyWith<$Res> {
  __$$SupplierProductsResModelImplCopyWithImpl(
      _$SupplierProductsResModelImpl _value,
      $Res Function(_$SupplierProductsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_$SupplierProductsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<SupplierProductsData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierProductsResModelImpl implements _SupplierProductsResModel {
  const _$SupplierProductsResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<SupplierProductsData>? data,
      @JsonKey(name: "metaData") this.metaData,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$SupplierProductsResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierProductsResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<SupplierProductsData>? _data;
  @override
  @JsonKey(name: "data")
  List<SupplierProductsData>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'SupplierProductsResModel(status: $status, data: $data, metaData: $metaData, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierProductsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), metaData, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierProductsResModelImplCopyWith<_$SupplierProductsResModelImpl>
      get copyWith => __$$SupplierProductsResModelImplCopyWithImpl<
          _$SupplierProductsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierProductsResModelImplToJson(
      this,
    );
  }
}

abstract class _SupplierProductsResModel implements SupplierProductsResModel {
  const factory _SupplierProductsResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final List<SupplierProductsData>? data,
          @JsonKey(name: "metaData") final MetaData? metaData,
          @JsonKey(name: "message") final String? message}) =
      _$SupplierProductsResModelImpl;

  factory _SupplierProductsResModel.fromJson(Map<String, dynamic> json) =
      _$SupplierProductsResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<SupplierProductsData>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$SupplierProductsResModelImplCopyWith<_$SupplierProductsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

SupplierProductsData _$SupplierProductsDataFromJson(Map<String, dynamic> json) {
  return _SupplierProductsData.fromJson(json);
}

/// @nodoc
mixin _$SupplierProductsData {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "category")
  String? get category => throw _privateConstructorUsedError;
  @JsonKey(name: "subcategories")
  String? get subcategories =>
      throw _privateConstructorUsedError; //@JsonKey(name: "subsubcategories") String? subsubcategories,
  @JsonKey(name: "casetypes")
  String? get casetypes => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "sku")
  String? get sku => throw _privateConstructorUsedError;
  @JsonKey(name: "brandName")
  String? get brandName => throw _privateConstructorUsedError;
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  String? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "productId")
  String? get productId => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierId")
  String? get supplierId => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  dynamic get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  dynamic get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierProductsDataCopyWith<SupplierProductsData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierProductsDataCopyWith<$Res> {
  factory $SupplierProductsDataCopyWith(SupplierProductsData value,
          $Res Function(SupplierProductsData) then) =
      _$SupplierProductsDataCopyWithImpl<$Res, SupplierProductsData>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "category") String? category,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "casetypes") String? casetypes,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "productId") String? productId,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "productPrice") dynamic productPrice,
      @JsonKey(name: "productStock") dynamic productStock,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      String? lowStock});
}

/// @nodoc
class _$SupplierProductsDataCopyWithImpl<$Res,
        $Val extends SupplierProductsData>
    implements $SupplierProductsDataCopyWith<$Res> {
  _$SupplierProductsDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? category = freezed,
    Object? subcategories = freezed,
    Object? casetypes = freezed,
    Object? status = freezed,
    Object? sku = freezed,
    Object? brandName = freezed,
    Object? numberOfUnit = freezed,
    Object? productName = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? productId = freezed,
    Object? supplierId = freezed,
    Object? productPrice = freezed,
    Object? productStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      casetypes: freezed == casetypes
          ? _value.casetypes
          : casetypes // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as dynamic,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as dynamic,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierProductsDataImplCopyWith<$Res>
    implements $SupplierProductsDataCopyWith<$Res> {
  factory _$$SupplierProductsDataImplCopyWith(_$SupplierProductsDataImpl value,
          $Res Function(_$SupplierProductsDataImpl) then) =
      __$$SupplierProductsDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "category") String? category,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "casetypes") String? casetypes,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "productId") String? productId,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "productPrice") dynamic productPrice,
      @JsonKey(name: "productStock") dynamic productStock,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      String? lowStock});
}

/// @nodoc
class __$$SupplierProductsDataImplCopyWithImpl<$Res>
    extends _$SupplierProductsDataCopyWithImpl<$Res, _$SupplierProductsDataImpl>
    implements _$$SupplierProductsDataImplCopyWith<$Res> {
  __$$SupplierProductsDataImplCopyWithImpl(_$SupplierProductsDataImpl _value,
      $Res Function(_$SupplierProductsDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? category = freezed,
    Object? subcategories = freezed,
    Object? casetypes = freezed,
    Object? status = freezed,
    Object? sku = freezed,
    Object? brandName = freezed,
    Object? numberOfUnit = freezed,
    Object? productName = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? productId = freezed,
    Object? supplierId = freezed,
    Object? productPrice = freezed,
    Object? productStock = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_$SupplierProductsDataImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      casetypes: freezed == casetypes
          ? _value.casetypes
          : casetypes // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as dynamic,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as dynamic,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierProductsDataImpl implements _SupplierProductsData {
  const _$SupplierProductsDataImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "category") this.category,
      @JsonKey(name: "subcategories") this.subcategories,
      @JsonKey(name: "casetypes") this.casetypes,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "sku") this.sku,
      @JsonKey(name: "brandName") this.brandName,
      @JsonKey(name: "numberOfUnit") this.numberOfUnit,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "productId") this.productId,
      @JsonKey(name: "supplierId") this.supplierId,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim,
      this.lowStock});

  factory _$SupplierProductsDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierProductsDataImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "category")
  final String? category;
  @override
  @JsonKey(name: "subcategories")
  final String? subcategories;
//@JsonKey(name: "subsubcategories") String? subsubcategories,
  @override
  @JsonKey(name: "casetypes")
  final String? casetypes;
  @override
  @JsonKey(name: "status")
  final String? status;
  @override
  @JsonKey(name: "sku")
  final String? sku;
  @override
  @JsonKey(name: "brandName")
  final String? brandName;
  @override
  @JsonKey(name: "numberOfUnit")
  final String? numberOfUnit;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  final String? itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  final String? totalWeight;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "productId")
  final String? productId;
  @override
  @JsonKey(name: "supplierId")
  final String? supplierId;
  @override
  @JsonKey(name: "productPrice")
  final dynamic productPrice;
  @override
  @JsonKey(name: "productStock")
  final dynamic productStock;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;
  @override
  final String? lowStock;

  @override
  String toString() {
    return 'SupplierProductsData(id: $id, category: $category, subcategories: $subcategories, casetypes: $casetypes, status: $status, sku: $sku, brandName: $brandName, numberOfUnit: $numberOfUnit, productName: $productName, mainImage: $mainImage, itemsWeight: $itemsWeight, totalWeight: $totalWeight, createdBy: $createdBy, updatedBy: $updatedBy, createdAt: $createdAt, updatedAt: $updatedAt, productId: $productId, supplierId: $supplierId, productPrice: $productPrice, productStock: $productStock, isPesach: $isPesach, nmMashlim: $nmMashlim, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierProductsDataImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.category, category) ||
                other.category == category) &&
            (identical(other.subcategories, subcategories) ||
                other.subcategories == subcategories) &&
            (identical(other.casetypes, casetypes) ||
                other.casetypes == casetypes) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            (identical(other.brandName, brandName) ||
                other.brandName == brandName) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            const DeepCollectionEquality()
                .equals(other.productPrice, productPrice) &&
            const DeepCollectionEquality()
                .equals(other.productStock, productStock) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        category,
        subcategories,
        casetypes,
        status,
        sku,
        brandName,
        numberOfUnit,
        productName,
        mainImage,
        itemsWeight,
        totalWeight,
        createdBy,
        updatedBy,
        createdAt,
        updatedAt,
        productId,
        supplierId,
        const DeepCollectionEquality().hash(productPrice),
        const DeepCollectionEquality().hash(productStock),
        isPesach,
        nmMashlim,
        lowStock
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierProductsDataImplCopyWith<_$SupplierProductsDataImpl>
      get copyWith =>
          __$$SupplierProductsDataImplCopyWithImpl<_$SupplierProductsDataImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierProductsDataImplToJson(
      this,
    );
  }
}

abstract class _SupplierProductsData implements SupplierProductsData {
  const factory _SupplierProductsData(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "category") final String? category,
      @JsonKey(name: "subcategories") final String? subcategories,
      @JsonKey(name: "casetypes") final String? casetypes,
      @JsonKey(name: "status") final String? status,
      @JsonKey(name: "sku") final String? sku,
      @JsonKey(name: "brandName") final String? brandName,
      @JsonKey(name: "numberOfUnit") final String? numberOfUnit,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "itemsWeight") final String? itemsWeight,
      @JsonKey(name: "totalWeight") final String? totalWeight,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "productId") final String? productId,
      @JsonKey(name: "supplierId") final String? supplierId,
      @JsonKey(name: "productPrice") final dynamic productPrice,
      @JsonKey(name: "productStock") final dynamic productStock,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim") final String? nmMashlim,
      final String? lowStock}) = _$SupplierProductsDataImpl;

  factory _SupplierProductsData.fromJson(Map<String, dynamic> json) =
      _$SupplierProductsDataImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "category")
  String? get category;
  @override
  @JsonKey(name: "subcategories")
  String? get subcategories;
  @override //@JsonKey(name: "subsubcategories") String? subsubcategories,
  @JsonKey(name: "casetypes")
  String? get casetypes;
  @override
  @JsonKey(name: "status")
  String? get status;
  @override
  @JsonKey(name: "sku")
  String? get sku;
  @override
  @JsonKey(name: "brandName")
  String? get brandName;
  @override
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  String? get totalWeight;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "productId")
  String? get productId;
  @override
  @JsonKey(name: "supplierId")
  String? get supplierId;
  @override
  @JsonKey(name: "productPrice")
  dynamic get productPrice;
  @override
  @JsonKey(name: "productStock")
  dynamic get productStock;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  String? get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$SupplierProductsDataImplCopyWith<_$SupplierProductsDataImpl>
      get copyWith => throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalFilteredCount") this.totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  final int? totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
          {@JsonKey(name: "currentPage") final int? currentPage,
          @JsonKey(name: "totalFilteredCount") final int? totalFilteredCount,
          @JsonKey(name: "totalFilteredPage") final int? totalFilteredPage}) =
      _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
