// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'supplier_products_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SupplierProductsResModelImpl _$$SupplierProductsResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$SupplierProductsResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => SupplierProductsData.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$SupplierProductsResModelImplToJson(
        _$SupplierProductsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$SupplierProductsDataImpl _$$SupplierProductsDataImplFromJson(
        Map<String, dynamic> json) =>
    _$SupplierProductsDataImpl(
      id: json['_id'] as String?,
      category: json['category'] as String?,
      subcategories: json['subcategories'] as String?,
      casetypes: json['casetypes'] as String?,
      status: json['status'] as String?,
      sku: json['sku'] as String?,
      brandName: json['brandName'] as String?,
      numberOfUnit: json['numberOfUnit'] as String?,
      productName: json['productName'] as String?,
      mainImage: json['mainImage'] as String?,
      itemsWeight: json['itemsWeight'] as String?,
      totalWeight: json['totalWeight'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      productId: json['productId'] as String?,
      supplierId: json['supplierId'] as String?,
      productPrice: json['productPrice'],
      productStock: json['productStock'],
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
      lowStock: json['lowStock'] as String?,
    );

Map<String, dynamic> _$$SupplierProductsDataImplToJson(
        _$SupplierProductsDataImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'category': instance.category,
      'subcategories': instance.subcategories,
      'casetypes': instance.casetypes,
      'status': instance.status,
      'sku': instance.sku,
      'brandName': instance.brandName,
      'numberOfUnit': instance.numberOfUnit,
      'productName': instance.productName,
      'mainImage': instance.mainImage,
      'itemsWeight': instance.itemsWeight,
      'totalWeight': instance.totalWeight,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      'productId': instance.productId,
      'supplierId': instance.supplierId,
      'productPrice': instance.productPrice,
      'productStock': instance.productStock,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
      'lowStock': instance.lowStock,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
