// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProfileResModel _$ProfileResModelFromJson(Map<String, dynamic> json) {
  return _ProfileResModel.fromJson(json);
}

/// @nodoc
mixin _$ProfileResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfileResModelCopyWith<ProfileResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileResModelCopyWith<$Res> {
  factory $ProfileResModelCopyWith(
          ProfileResModel value, $Res Function(ProfileResModel) then) =
      _$ProfileResModelCopyWithImpl<$Res, ProfileResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$ProfileResModelCopyWithImpl<$Res, $Val extends ProfileResModel>
    implements $ProfileResModelCopyWith<$Res> {
  _$ProfileResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProfileResModelImplCopyWith<$Res>
    implements $ProfileResModelCopyWith<$Res> {
  factory _$$ProfileResModelImplCopyWith(_$ProfileResModelImpl value,
          $Res Function(_$ProfileResModelImpl) then) =
      __$$ProfileResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$ProfileResModelImplCopyWithImpl<$Res>
    extends _$ProfileResModelCopyWithImpl<$Res, _$ProfileResModelImpl>
    implements _$$ProfileResModelImplCopyWith<$Res> {
  __$$ProfileResModelImplCopyWithImpl(
      _$ProfileResModelImpl _value, $Res Function(_$ProfileResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$ProfileResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileResModelImpl implements _ProfileResModel {
  const _$ProfileResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$ProfileResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfileResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'ProfileResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileResModelImplCopyWith<_$ProfileResModelImpl> get copyWith =>
      __$$ProfileResModelImplCopyWithImpl<_$ProfileResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileResModelImplToJson(
      this,
    );
  }
}

abstract class _ProfileResModel implements ProfileResModel {
  const factory _ProfileResModel(
      {@JsonKey(name: "status") final int? status,
      @JsonKey(name: "data") final Data? data,
      @JsonKey(name: "message") final String? message}) = _$ProfileResModelImpl;

  factory _ProfileResModel.fromJson(Map<String, dynamic> json) =
      _$ProfileResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$ProfileResModelImplCopyWith<_$ProfileResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "client")
  Client? get client => throw _privateConstructorUsedError;
  @JsonKey(name: "authToken")
  AuthToken? get authToken => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "client") Client? client,
      @JsonKey(name: "authToken") AuthToken? authToken});

  $ClientCopyWith<$Res>? get client;
  $AuthTokenCopyWith<$Res>? get authToken;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? client = freezed,
    Object? authToken = freezed,
  }) {
    return _then(_value.copyWith(
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
      authToken: freezed == authToken
          ? _value.authToken
          : authToken // ignore: cast_nullable_to_non_nullable
              as AuthToken?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientCopyWith<$Res>? get client {
    if (_value.client == null) {
      return null;
    }

    return $ClientCopyWith<$Res>(_value.client!, (value) {
      return _then(_value.copyWith(client: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $AuthTokenCopyWith<$Res>? get authToken {
    if (_value.authToken == null) {
      return null;
    }

    return $AuthTokenCopyWith<$Res>(_value.authToken!, (value) {
      return _then(_value.copyWith(authToken: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "client") Client? client,
      @JsonKey(name: "authToken") AuthToken? authToken});

  @override
  $ClientCopyWith<$Res>? get client;
  @override
  $AuthTokenCopyWith<$Res>? get authToken;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? client = freezed,
    Object? authToken = freezed,
  }) {
    return _then(_$DataImpl(
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
      authToken: freezed == authToken
          ? _value.authToken
          : authToken // ignore: cast_nullable_to_non_nullable
              as AuthToken?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "client") this.client,
      @JsonKey(name: "authToken") this.authToken});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  @JsonKey(name: "client")
  final Client? client;
  @override
  @JsonKey(name: "authToken")
  final AuthToken? authToken;

  @override
  String toString() {
    return 'Data(client: $client, authToken: $authToken)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.client, client) || other.client == client) &&
            (identical(other.authToken, authToken) ||
                other.authToken == authToken));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, client, authToken);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "client") final Client? client,
      @JsonKey(name: "authToken") final AuthToken? authToken}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "client")
  Client? get client;
  @override
  @JsonKey(name: "authToken")
  AuthToken? get authToken;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

AuthToken _$AuthTokenFromJson(Map<String, dynamic> json) {
  return _AuthToken.fromJson(json);
}

/// @nodoc
mixin _$AuthToken {
  @JsonKey(name: "accessToken")
  String? get accessToken => throw _privateConstructorUsedError;
  @JsonKey(name: "refreshToken")
  String? get refreshToken => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AuthTokenCopyWith<AuthToken> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AuthTokenCopyWith<$Res> {
  factory $AuthTokenCopyWith(AuthToken value, $Res Function(AuthToken) then) =
      _$AuthTokenCopyWithImpl<$Res, AuthToken>;
  @useResult
  $Res call(
      {@JsonKey(name: "accessToken") String? accessToken,
      @JsonKey(name: "refreshToken") String? refreshToken});
}

/// @nodoc
class _$AuthTokenCopyWithImpl<$Res, $Val extends AuthToken>
    implements $AuthTokenCopyWith<$Res> {
  _$AuthTokenCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? accessToken = freezed,
    Object? refreshToken = freezed,
  }) {
    return _then(_value.copyWith(
      accessToken: freezed == accessToken
          ? _value.accessToken
          : accessToken // ignore: cast_nullable_to_non_nullable
              as String?,
      refreshToken: freezed == refreshToken
          ? _value.refreshToken
          : refreshToken // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AuthTokenImplCopyWith<$Res>
    implements $AuthTokenCopyWith<$Res> {
  factory _$$AuthTokenImplCopyWith(
          _$AuthTokenImpl value, $Res Function(_$AuthTokenImpl) then) =
      __$$AuthTokenImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "accessToken") String? accessToken,
      @JsonKey(name: "refreshToken") String? refreshToken});
}

/// @nodoc
class __$$AuthTokenImplCopyWithImpl<$Res>
    extends _$AuthTokenCopyWithImpl<$Res, _$AuthTokenImpl>
    implements _$$AuthTokenImplCopyWith<$Res> {
  __$$AuthTokenImplCopyWithImpl(
      _$AuthTokenImpl _value, $Res Function(_$AuthTokenImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? accessToken = freezed,
    Object? refreshToken = freezed,
  }) {
    return _then(_$AuthTokenImpl(
      accessToken: freezed == accessToken
          ? _value.accessToken
          : accessToken // ignore: cast_nullable_to_non_nullable
              as String?,
      refreshToken: freezed == refreshToken
          ? _value.refreshToken
          : refreshToken // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AuthTokenImpl implements _AuthToken {
  const _$AuthTokenImpl(
      {@JsonKey(name: "accessToken") this.accessToken,
      @JsonKey(name: "refreshToken") this.refreshToken});

  factory _$AuthTokenImpl.fromJson(Map<String, dynamic> json) =>
      _$$AuthTokenImplFromJson(json);

  @override
  @JsonKey(name: "accessToken")
  final String? accessToken;
  @override
  @JsonKey(name: "refreshToken")
  final String? refreshToken;

  @override
  String toString() {
    return 'AuthToken(accessToken: $accessToken, refreshToken: $refreshToken)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AuthTokenImpl &&
            (identical(other.accessToken, accessToken) ||
                other.accessToken == accessToken) &&
            (identical(other.refreshToken, refreshToken) ||
                other.refreshToken == refreshToken));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, accessToken, refreshToken);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AuthTokenImplCopyWith<_$AuthTokenImpl> get copyWith =>
      __$$AuthTokenImplCopyWithImpl<_$AuthTokenImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AuthTokenImplToJson(
      this,
    );
  }
}

abstract class _AuthToken implements AuthToken {
  const factory _AuthToken(
          {@JsonKey(name: "accessToken") final String? accessToken,
          @JsonKey(name: "refreshToken") final String? refreshToken}) =
      _$AuthTokenImpl;

  factory _AuthToken.fromJson(Map<String, dynamic> json) =
      _$AuthTokenImpl.fromJson;

  @override
  @JsonKey(name: "accessToken")
  String? get accessToken;
  @override
  @JsonKey(name: "refreshToken")
  String? get refreshToken;
  @override
  @JsonKey(ignore: true)
  _$$AuthTokenImplCopyWith<_$AuthTokenImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Client _$ClientFromJson(Map<String, dynamic> json) {
  return _Client.fromJson(json);
}

/// @nodoc
mixin _$Client {
  @JsonKey(name: "clientData")
  ClientData? get clientData => throw _privateConstructorUsedError;
  @JsonKey(name: "cartId")
  String? get cartId => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientCopyWith<Client> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientCopyWith<$Res> {
  factory $ClientCopyWith(Client value, $Res Function(Client) then) =
      _$ClientCopyWithImpl<$Res, Client>;
  @useResult
  $Res call(
      {@JsonKey(name: "clientData") ClientData? clientData,
      @JsonKey(name: "cartId") String? cartId});

  $ClientDataCopyWith<$Res>? get clientData;
}

/// @nodoc
class _$ClientCopyWithImpl<$Res, $Val extends Client>
    implements $ClientCopyWith<$Res> {
  _$ClientCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? clientData = freezed,
    Object? cartId = freezed,
  }) {
    return _then(_value.copyWith(
      clientData: freezed == clientData
          ? _value.clientData
          : clientData // ignore: cast_nullable_to_non_nullable
              as ClientData?,
      cartId: freezed == cartId
          ? _value.cartId
          : cartId // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientDataCopyWith<$Res>? get clientData {
    if (_value.clientData == null) {
      return null;
    }

    return $ClientDataCopyWith<$Res>(_value.clientData!, (value) {
      return _then(_value.copyWith(clientData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ClientImplCopyWith<$Res> implements $ClientCopyWith<$Res> {
  factory _$$ClientImplCopyWith(
          _$ClientImpl value, $Res Function(_$ClientImpl) then) =
      __$$ClientImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "clientData") ClientData? clientData,
      @JsonKey(name: "cartId") String? cartId});

  @override
  $ClientDataCopyWith<$Res>? get clientData;
}

/// @nodoc
class __$$ClientImplCopyWithImpl<$Res>
    extends _$ClientCopyWithImpl<$Res, _$ClientImpl>
    implements _$$ClientImplCopyWith<$Res> {
  __$$ClientImplCopyWithImpl(
      _$ClientImpl _value, $Res Function(_$ClientImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? clientData = freezed,
    Object? cartId = freezed,
  }) {
    return _then(_$ClientImpl(
      clientData: freezed == clientData
          ? _value.clientData
          : clientData // ignore: cast_nullable_to_non_nullable
              as ClientData?,
      cartId: freezed == cartId
          ? _value.cartId
          : cartId // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientImpl implements _Client {
  const _$ClientImpl(
      {@JsonKey(name: "clientData") this.clientData,
      @JsonKey(name: "cartId") this.cartId});

  factory _$ClientImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientImplFromJson(json);

  @override
  @JsonKey(name: "clientData")
  final ClientData? clientData;
  @override
  @JsonKey(name: "cartId")
  final String? cartId;

  @override
  String toString() {
    return 'Client(clientData: $clientData, cartId: $cartId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientImpl &&
            (identical(other.clientData, clientData) ||
                other.clientData == clientData) &&
            (identical(other.cartId, cartId) || other.cartId == cartId));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, clientData, cartId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      __$$ClientImplCopyWithImpl<_$ClientImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientImplToJson(
      this,
    );
  }
}

abstract class _Client implements Client {
  const factory _Client(
      {@JsonKey(name: "clientData") final ClientData? clientData,
      @JsonKey(name: "cartId") final String? cartId}) = _$ClientImpl;

  factory _Client.fromJson(Map<String, dynamic> json) = _$ClientImpl.fromJson;

  @override
  @JsonKey(name: "clientData")
  ClientData? get clientData;
  @override
  @JsonKey(name: "cartId")
  String? get cartId;
  @override
  @JsonKey(ignore: true)
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientData _$ClientDataFromJson(Map<String, dynamic> json) {
  return _ClientData.fromJson(json);
}

/// @nodoc
mixin _$ClientData {
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "password")
  dynamic get password => throw _privateConstructorUsedError;
  @JsonKey(name: "firstName")
  String? get firstName => throw _privateConstructorUsedError;
  @JsonKey(name: "lastName")
  String? get lastName => throw _privateConstructorUsedError;
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "address")
  String? get address => throw _privateConstructorUsedError;
  @JsonKey(name: "cityId")
  String? get cityId => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;
  @JsonKey(name: "statusId")
  String? get statusId => throw _privateConstructorUsedError;
  @JsonKey(name: "logo")
  String? get logo => throw _privateConstructorUsedError;
  @JsonKey(name: "profileImage")
  String? get profileImage => throw _privateConstructorUsedError;
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientDataCopyWith<ClientData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientDataCopyWith<$Res> {
  factory $ClientDataCopyWith(
          ClientData value, $Res Function(ClientData) then) =
      _$ClientDataCopyWithImpl<$Res, ClientData>;
  @useResult
  $Res call(
      {@JsonKey(name: "email") String? email,
      @JsonKey(name: "password") dynamic password,
      @JsonKey(name: "firstName") String? firstName,
      @JsonKey(name: "lastName") String? lastName,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class _$ClientDataCopyWithImpl<$Res, $Val extends ClientData>
    implements $ClientDataCopyWith<$Res> {
  _$ClientDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = freezed,
    Object? password = freezed,
    Object? firstName = freezed,
    Object? lastName = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? isDeleted = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as dynamic,
      firstName: freezed == firstName
          ? _value.firstName
          : firstName // ignore: cast_nullable_to_non_nullable
              as String?,
      lastName: freezed == lastName
          ? _value.lastName
          : lastName // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientDetailCopyWith<$Res>? get clientDetail {
    if (_value.clientDetail == null) {
      return null;
    }

    return $ClientDetailCopyWith<$Res>(_value.clientDetail!, (value) {
      return _then(_value.copyWith(clientDetail: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ClientDataImplCopyWith<$Res>
    implements $ClientDataCopyWith<$Res> {
  factory _$$ClientDataImplCopyWith(
          _$ClientDataImpl value, $Res Function(_$ClientDataImpl) then) =
      __$$ClientDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "email") String? email,
      @JsonKey(name: "password") dynamic password,
      @JsonKey(name: "firstName") String? firstName,
      @JsonKey(name: "lastName") String? lastName,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  @override
  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class __$$ClientDataImplCopyWithImpl<$Res>
    extends _$ClientDataCopyWithImpl<$Res, _$ClientDataImpl>
    implements _$$ClientDataImplCopyWith<$Res> {
  __$$ClientDataImplCopyWithImpl(
      _$ClientDataImpl _value, $Res Function(_$ClientDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = freezed,
    Object? password = freezed,
    Object? firstName = freezed,
    Object? lastName = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? isDeleted = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$ClientDataImpl(
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as dynamic,
      firstName: freezed == firstName
          ? _value.firstName
          : firstName // ignore: cast_nullable_to_non_nullable
              as String?,
      lastName: freezed == lastName
          ? _value.lastName
          : lastName // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientDataImpl implements _ClientData {
  const _$ClientDataImpl(
      {@JsonKey(name: "email") this.email,
      @JsonKey(name: "password") this.password,
      @JsonKey(name: "firstName") this.firstName,
      @JsonKey(name: "lastName") this.lastName,
      @JsonKey(name: "phoneNumber") this.phoneNumber,
      @JsonKey(name: "address") this.address,
      @JsonKey(name: "cityId") this.cityId,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "statusId") this.statusId,
      @JsonKey(name: "logo") this.logo,
      @JsonKey(name: "profileImage") this.profileImage,
      @JsonKey(name: "adminTypeId") this.adminTypeId,
      @JsonKey(name: "clientDetail") this.clientDetail,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$ClientDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientDataImplFromJson(json);

  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "password")
  final dynamic password;
  @override
  @JsonKey(name: "firstName")
  final String? firstName;
  @override
  @JsonKey(name: "lastName")
  final String? lastName;
  @override
  @JsonKey(name: "phoneNumber")
  final String? phoneNumber;
  @override
  @JsonKey(name: "address")
  final String? address;
  @override
  @JsonKey(name: "cityId")
  final String? cityId;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
  @override
  @JsonKey(name: "statusId")
  final String? statusId;
  @override
  @JsonKey(name: "logo")
  final String? logo;
  @override
  @JsonKey(name: "profileImage")
  final String? profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  final String? adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  final ClientDetail? clientDetail;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'ClientData(email: $email, password: $password, firstName: $firstName, lastName: $lastName, phoneNumber: $phoneNumber, address: $address, cityId: $cityId, contactName: $contactName, statusId: $statusId, logo: $logo, profileImage: $profileImage, adminTypeId: $adminTypeId, clientDetail: $clientDetail, isDeleted: $isDeleted, id: $id, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientDataImpl &&
            (identical(other.email, email) || other.email == email) &&
            const DeepCollectionEquality().equals(other.password, password) &&
            (identical(other.firstName, firstName) ||
                other.firstName == firstName) &&
            (identical(other.lastName, lastName) ||
                other.lastName == lastName) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.cityId, cityId) || other.cityId == cityId) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.statusId, statusId) ||
                other.statusId == statusId) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.profileImage, profileImage) ||
                other.profileImage == profileImage) &&
            (identical(other.adminTypeId, adminTypeId) ||
                other.adminTypeId == adminTypeId) &&
            (identical(other.clientDetail, clientDetail) ||
                other.clientDetail == clientDetail) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      email,
      const DeepCollectionEquality().hash(password),
      firstName,
      lastName,
      phoneNumber,
      address,
      cityId,
      contactName,
      statusId,
      logo,
      profileImage,
      adminTypeId,
      clientDetail,
      isDeleted,
      id,
      createdAt,
      updatedAt,
      v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientDataImplCopyWith<_$ClientDataImpl> get copyWith =>
      __$$ClientDataImplCopyWithImpl<_$ClientDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientDataImplToJson(
      this,
    );
  }
}

abstract class _ClientData implements ClientData {
  const factory _ClientData(
      {@JsonKey(name: "email") final String? email,
      @JsonKey(name: "password") final dynamic password,
      @JsonKey(name: "firstName") final String? firstName,
      @JsonKey(name: "lastName") final String? lastName,
      @JsonKey(name: "phoneNumber") final String? phoneNumber,
      @JsonKey(name: "address") final String? address,
      @JsonKey(name: "cityId") final String? cityId,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "statusId") final String? statusId,
      @JsonKey(name: "logo") final String? logo,
      @JsonKey(name: "profileImage") final String? profileImage,
      @JsonKey(name: "adminTypeId") final String? adminTypeId,
      @JsonKey(name: "clientDetail") final ClientDetail? clientDetail,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$ClientDataImpl;

  factory _ClientData.fromJson(Map<String, dynamic> json) =
      _$ClientDataImpl.fromJson;

  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "password")
  dynamic get password;
  @override
  @JsonKey(name: "firstName")
  String? get firstName;
  @override
  @JsonKey(name: "lastName")
  String? get lastName;
  @override
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber;
  @override
  @JsonKey(name: "address")
  String? get address;
  @override
  @JsonKey(name: "cityId")
  String? get cityId;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(name: "statusId")
  String? get statusId;
  @override
  @JsonKey(name: "logo")
  String? get logo;
  @override
  @JsonKey(name: "profileImage")
  String? get profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$ClientDataImplCopyWith<_$ClientDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientDetail _$ClientDetailFromJson(Map<String, dynamic> json) {
  return _ClientDetail.fromJson(json);
}

/// @nodoc
mixin _$ClientDetail {
  @JsonKey(name: "bussinessId")
  int? get bussinessId => throw _privateConstructorUsedError;
  @JsonKey(name: "bussinessName")
  String? get bussinessName => throw _privateConstructorUsedError;
  @JsonKey(name: "ownerName")
  String? get ownerName => throw _privateConstructorUsedError;
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "israelId")
  String? get israelId => throw _privateConstructorUsedError;
  @JsonKey(name: "tokenId")
  String? get tokenId => throw _privateConstructorUsedError;
  @JsonKey(name: "fax")
  String? get fax => throw _privateConstructorUsedError;
  @JsonKey(name: "lastSeen")
  String? get lastSeen => throw _privateConstructorUsedError;
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion => throw _privateConstructorUsedError;
  @JsonKey(name: "deviceType")
  String? get deviceType => throw _privateConstructorUsedError;
  @JsonKey(name: "operationTime")
  List<dynamic>? get operationTime => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientDetailCopyWith<ClientDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientDetailCopyWith<$Res> {
  factory $ClientDetailCopyWith(
          ClientDetail value, $Res Function(ClientDetail) then) =
      _$ClientDetailCopyWithImpl<$Res, ClientDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "lastSeen") String? lastSeen,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<dynamic>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt});
}

/// @nodoc
class _$ClientDetailCopyWithImpl<$Res, $Val extends ClientDetail>
    implements $ClientDetailCopyWith<$Res> {
  _$ClientDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_value.copyWith(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as String?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value.operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientDetailImplCopyWith<$Res>
    implements $ClientDetailCopyWith<$Res> {
  factory _$$ClientDetailImplCopyWith(
          _$ClientDetailImpl value, $Res Function(_$ClientDetailImpl) then) =
      __$$ClientDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "lastSeen") String? lastSeen,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<dynamic>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt});
}

/// @nodoc
class __$$ClientDetailImplCopyWithImpl<$Res>
    extends _$ClientDetailCopyWithImpl<$Res, _$ClientDetailImpl>
    implements _$$ClientDetailImplCopyWith<$Res> {
  __$$ClientDetailImplCopyWithImpl(
      _$ClientDetailImpl _value, $Res Function(_$ClientDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_$ClientDetailImpl(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as String?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value._operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientDetailImpl implements _ClientDetail {
  const _$ClientDetailImpl(
      {@JsonKey(name: "bussinessId") this.bussinessId,
      @JsonKey(name: "bussinessName") this.bussinessName,
      @JsonKey(name: "ownerName") this.ownerName,
      @JsonKey(name: "clientTypeId") this.clientTypeId,
      @JsonKey(name: "israelId") this.israelId,
      @JsonKey(name: "tokenId") this.tokenId,
      @JsonKey(name: "fax") this.fax,
      @JsonKey(name: "lastSeen") this.lastSeen,
      @JsonKey(name: "applicationVersion") this.applicationVersion,
      @JsonKey(name: "deviceType") this.deviceType,
      @JsonKey(name: "operationTime") final List<dynamic>? operationTime,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt})
      : _operationTime = operationTime;

  factory _$ClientDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientDetailImplFromJson(json);

  @override
  @JsonKey(name: "bussinessId")
  final int? bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  final String? bussinessName;
  @override
  @JsonKey(name: "ownerName")
  final String? ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  final String? clientTypeId;
  @override
  @JsonKey(name: "israelId")
  final String? israelId;
  @override
  @JsonKey(name: "tokenId")
  final String? tokenId;
  @override
  @JsonKey(name: "fax")
  final String? fax;
  @override
  @JsonKey(name: "lastSeen")
  final String? lastSeen;
  @override
  @JsonKey(name: "applicationVersion")
  final String? applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  final String? deviceType;
  final List<dynamic>? _operationTime;
  @override
  @JsonKey(name: "operationTime")
  List<dynamic>? get operationTime {
    final value = _operationTime;
    if (value == null) return null;
    if (_operationTime is EqualUnmodifiableListView) return _operationTime;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;

  @override
  String toString() {
    return 'ClientDetail(bussinessId: $bussinessId, bussinessName: $bussinessName, ownerName: $ownerName, clientTypeId: $clientTypeId, israelId: $israelId, tokenId: $tokenId, fax: $fax, lastSeen: $lastSeen, applicationVersion: $applicationVersion, deviceType: $deviceType, operationTime: $operationTime, id: $id, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientDetailImpl &&
            (identical(other.bussinessId, bussinessId) ||
                other.bussinessId == bussinessId) &&
            (identical(other.bussinessName, bussinessName) ||
                other.bussinessName == bussinessName) &&
            (identical(other.ownerName, ownerName) ||
                other.ownerName == ownerName) &&
            (identical(other.clientTypeId, clientTypeId) ||
                other.clientTypeId == clientTypeId) &&
            (identical(other.israelId, israelId) ||
                other.israelId == israelId) &&
            (identical(other.tokenId, tokenId) || other.tokenId == tokenId) &&
            (identical(other.fax, fax) || other.fax == fax) &&
            (identical(other.lastSeen, lastSeen) ||
                other.lastSeen == lastSeen) &&
            (identical(other.applicationVersion, applicationVersion) ||
                other.applicationVersion == applicationVersion) &&
            (identical(other.deviceType, deviceType) ||
                other.deviceType == deviceType) &&
            const DeepCollectionEquality()
                .equals(other._operationTime, _operationTime) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      bussinessId,
      bussinessName,
      ownerName,
      clientTypeId,
      israelId,
      tokenId,
      fax,
      lastSeen,
      applicationVersion,
      deviceType,
      const DeepCollectionEquality().hash(_operationTime),
      id,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      __$$ClientDetailImplCopyWithImpl<_$ClientDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientDetailImplToJson(
      this,
    );
  }
}

abstract class _ClientDetail implements ClientDetail {
  const factory _ClientDetail(
          {@JsonKey(name: "bussinessId") final int? bussinessId,
          @JsonKey(name: "bussinessName") final String? bussinessName,
          @JsonKey(name: "ownerName") final String? ownerName,
          @JsonKey(name: "clientTypeId") final String? clientTypeId,
          @JsonKey(name: "israelId") final String? israelId,
          @JsonKey(name: "tokenId") final String? tokenId,
          @JsonKey(name: "fax") final String? fax,
          @JsonKey(name: "lastSeen") final String? lastSeen,
          @JsonKey(name: "applicationVersion") final String? applicationVersion,
          @JsonKey(name: "deviceType") final String? deviceType,
          @JsonKey(name: "operationTime") final List<dynamic>? operationTime,
          @JsonKey(name: "_id") final String? id,
          @JsonKey(name: "createdAt") final String? createdAt,
          @JsonKey(name: "updatedAt") final String? updatedAt}) =
      _$ClientDetailImpl;

  factory _ClientDetail.fromJson(Map<String, dynamic> json) =
      _$ClientDetailImpl.fromJson;

  @override
  @JsonKey(name: "bussinessId")
  int? get bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  String? get bussinessName;
  @override
  @JsonKey(name: "ownerName")
  String? get ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId;
  @override
  @JsonKey(name: "israelId")
  String? get israelId;
  @override
  @JsonKey(name: "tokenId")
  String? get tokenId;
  @override
  @JsonKey(name: "fax")
  String? get fax;
  @override
  @JsonKey(name: "lastSeen")
  String? get lastSeen;
  @override
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  String? get deviceType;
  @override
  @JsonKey(name: "operationTime")
  List<dynamic>? get operationTime;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
