// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_sales_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProductSalesResModel _$ProductSalesResModelFromJson(Map<String, dynamic> json) {
  return _ProductSalesResModel.fromJson(json);
}

/// @nodoc
mixin _$ProductSalesResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<ProductSale>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductSalesResModelCopyWith<ProductSalesResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductSalesResModelCopyWith<$Res> {
  factory $ProductSalesResModelCopyWith(ProductSalesResModel value,
          $Res Function(ProductSalesResModel) then) =
      _$ProductSalesResModelCopyWithImpl<$Res, ProductSalesResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<ProductSale>? data,
      @JsonKey(name: "metaData") MetaData? metaData});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$ProductSalesResModelCopyWithImpl<$Res,
        $Val extends ProductSalesResModel>
    implements $ProductSalesResModelCopyWith<$Res> {
  _$ProductSalesResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProductSalesResModelImplCopyWith<$Res>
    implements $ProductSalesResModelCopyWith<$Res> {
  factory _$$ProductSalesResModelImplCopyWith(_$ProductSalesResModelImpl value,
          $Res Function(_$ProductSalesResModelImpl) then) =
      __$$ProductSalesResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<ProductSale>? data,
      @JsonKey(name: "metaData") MetaData? metaData});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$ProductSalesResModelImplCopyWithImpl<$Res>
    extends _$ProductSalesResModelCopyWithImpl<$Res, _$ProductSalesResModelImpl>
    implements _$$ProductSalesResModelImplCopyWith<$Res> {
  __$$ProductSalesResModelImplCopyWithImpl(_$ProductSalesResModelImpl _value,
      $Res Function(_$ProductSalesResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
  }) {
    return _then(_$ProductSalesResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductSalesResModelImpl implements _ProductSalesResModel {
  const _$ProductSalesResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<ProductSale>? data,
      @JsonKey(name: "metaData") this.metaData})
      : _data = data;

  factory _$ProductSalesResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductSalesResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<ProductSale>? _data;
  @override
  @JsonKey(name: "data")
  List<ProductSale>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;

  @override
  String toString() {
    return 'ProductSalesResModel(status: $status, data: $data, metaData: $metaData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductSalesResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), metaData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductSalesResModelImplCopyWith<_$ProductSalesResModelImpl>
      get copyWith =>
          __$$ProductSalesResModelImplCopyWithImpl<_$ProductSalesResModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductSalesResModelImplToJson(
      this,
    );
  }
}

abstract class _ProductSalesResModel implements ProductSalesResModel {
  const factory _ProductSalesResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final List<ProductSale>? data,
          @JsonKey(name: "metaData") final MetaData? metaData}) =
      _$ProductSalesResModelImpl;

  factory _ProductSalesResModel.fromJson(Map<String, dynamic> json) =
      _$ProductSalesResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<ProductSale>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(ignore: true)
  _$$ProductSalesResModelImplCopyWith<_$ProductSalesResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

ProductSale _$ProductSaleFromJson(Map<String, dynamic> json) {
  return _ProductSale.fromJson(json);
}

/// @nodoc
mixin _$ProductSale {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "category")
  String? get category => throw _privateConstructorUsedError;
  @JsonKey(name: "subcategories")
  String? get subcategories =>
      throw _privateConstructorUsedError; //  @JsonKey(name: "subsubcategories") String? subsubcategories,
  @JsonKey(name: "casetypes")
  String? get casetypes => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "sku")
  String? get sku => throw _privateConstructorUsedError;
  @JsonKey(name: "brandName")
  String? get brandName => throw _privateConstructorUsedError;
  @JsonKey(name: "images")
  List<Image>? get images => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "salesName")
  String? get salesName => throw _privateConstructorUsedError;
  @JsonKey(name: "discountPercentage")
  String? get discountPercentage => throw _privateConstructorUsedError;
  @JsonKey(name: "salesDescription")
  String? get salesDescription => throw _privateConstructorUsedError;
  @JsonKey(name: "fromDate")
  String? get fromDate => throw _privateConstructorUsedError;
  @JsonKey(name: "endDate")
  String? get endDate => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;
  @JsonKey(name: "lowStock")
  String? get lowStock => throw _privateConstructorUsedError;
  double? get discountedPrice => throw _privateConstructorUsedError;
  double? get originalPrice => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductSaleCopyWith<ProductSale> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductSaleCopyWith<$Res> {
  factory $ProductSaleCopyWith(
          ProductSale value, $Res Function(ProductSale) then) =
      _$ProductSaleCopyWithImpl<$Res, ProductSale>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "category") String? category,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "casetypes") String? casetypes,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "salesName") String? salesName,
      @JsonKey(name: "discountPercentage") String? discountPercentage,
      @JsonKey(name: "salesDescription") String? salesDescription,
      @JsonKey(name: "fromDate") String? fromDate,
      @JsonKey(name: "endDate") String? endDate,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      @JsonKey(name: "lowStock") String? lowStock,
      double? discountedPrice,
      double? originalPrice});
}

/// @nodoc
class _$ProductSaleCopyWithImpl<$Res, $Val extends ProductSale>
    implements $ProductSaleCopyWith<$Res> {
  _$ProductSaleCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? category = freezed,
    Object? subcategories = freezed,
    Object? casetypes = freezed,
    Object? status = freezed,
    Object? sku = freezed,
    Object? brandName = freezed,
    Object? images = freezed,
    Object? mainImage = freezed,
    Object? numberOfUnit = freezed,
    Object? productName = freezed,
    Object? itemsWeight = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? salesName = freezed,
    Object? discountPercentage = freezed,
    Object? salesDescription = freezed,
    Object? fromDate = freezed,
    Object? endDate = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
    Object? discountedPrice = freezed,
    Object? originalPrice = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      casetypes: freezed == casetypes
          ? _value.casetypes
          : casetypes // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value.images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      salesName: freezed == salesName
          ? _value.salesName
          : salesName // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as String?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
      discountedPrice: freezed == discountedPrice
          ? _value.discountedPrice
          : discountedPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      originalPrice: freezed == originalPrice
          ? _value.originalPrice
          : originalPrice // ignore: cast_nullable_to_non_nullable
              as double?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductSaleImplCopyWith<$Res>
    implements $ProductSaleCopyWith<$Res> {
  factory _$$ProductSaleImplCopyWith(
          _$ProductSaleImpl value, $Res Function(_$ProductSaleImpl) then) =
      __$$ProductSaleImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "category") String? category,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "casetypes") String? casetypes,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "salesName") String? salesName,
      @JsonKey(name: "discountPercentage") String? discountPercentage,
      @JsonKey(name: "salesDescription") String? salesDescription,
      @JsonKey(name: "fromDate") String? fromDate,
      @JsonKey(name: "endDate") String? endDate,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      @JsonKey(name: "lowStock") String? lowStock,
      double? discountedPrice,
      double? originalPrice});
}

/// @nodoc
class __$$ProductSaleImplCopyWithImpl<$Res>
    extends _$ProductSaleCopyWithImpl<$Res, _$ProductSaleImpl>
    implements _$$ProductSaleImplCopyWith<$Res> {
  __$$ProductSaleImplCopyWithImpl(
      _$ProductSaleImpl _value, $Res Function(_$ProductSaleImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? category = freezed,
    Object? subcategories = freezed,
    Object? casetypes = freezed,
    Object? status = freezed,
    Object? sku = freezed,
    Object? brandName = freezed,
    Object? images = freezed,
    Object? mainImage = freezed,
    Object? numberOfUnit = freezed,
    Object? productName = freezed,
    Object? itemsWeight = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? salesName = freezed,
    Object? discountPercentage = freezed,
    Object? salesDescription = freezed,
    Object? fromDate = freezed,
    Object? endDate = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
    Object? discountedPrice = freezed,
    Object? originalPrice = freezed,
  }) {
    return _then(_$ProductSaleImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      casetypes: freezed == casetypes
          ? _value.casetypes
          : casetypes // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value._images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      salesName: freezed == salesName
          ? _value.salesName
          : salesName // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as String?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
      discountedPrice: freezed == discountedPrice
          ? _value.discountedPrice
          : discountedPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      originalPrice: freezed == originalPrice
          ? _value.originalPrice
          : originalPrice // ignore: cast_nullable_to_non_nullable
              as double?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductSaleImpl implements _ProductSale {
  const _$ProductSaleImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "category") this.category,
      @JsonKey(name: "subcategories") this.subcategories,
      @JsonKey(name: "casetypes") this.casetypes,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "sku") this.sku,
      @JsonKey(name: "brandName") this.brandName,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "numberOfUnit") this.numberOfUnit,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "salesName") this.salesName,
      @JsonKey(name: "discountPercentage") this.discountPercentage,
      @JsonKey(name: "salesDescription") this.salesDescription,
      @JsonKey(name: "fromDate") this.fromDate,
      @JsonKey(name: "endDate") this.endDate,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim,
      @JsonKey(name: "lowStock") this.lowStock,
      this.discountedPrice,
      this.originalPrice})
      : _images = images;

  factory _$ProductSaleImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductSaleImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "category")
  final String? category;
  @override
  @JsonKey(name: "subcategories")
  final String? subcategories;
//  @JsonKey(name: "subsubcategories") String? subsubcategories,
  @override
  @JsonKey(name: "casetypes")
  final String? casetypes;
  @override
  @JsonKey(name: "status")
  final String? status;
  @override
  @JsonKey(name: "sku")
  final String? sku;
  @override
  @JsonKey(name: "brandName")
  final String? brandName;
  final List<Image>? _images;
  @override
  @JsonKey(name: "images")
  List<Image>? get images {
    final value = _images;
    if (value == null) return null;
    if (_images is EqualUnmodifiableListView) return _images;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "numberOfUnit")
  final String? numberOfUnit;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "itemsWeight")
  final String? itemsWeight;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "salesName")
  final String? salesName;
  @override
  @JsonKey(name: "discountPercentage")
  final String? discountPercentage;
  @override
  @JsonKey(name: "salesDescription")
  final String? salesDescription;
  @override
  @JsonKey(name: "fromDate")
  final String? fromDate;
  @override
  @JsonKey(name: "endDate")
  final String? endDate;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;
  @override
  @JsonKey(name: "lowStock")
  final String? lowStock;
  @override
  final double? discountedPrice;
  @override
  final double? originalPrice;

  @override
  String toString() {
    return 'ProductSale(id: $id, category: $category, subcategories: $subcategories, casetypes: $casetypes, status: $status, sku: $sku, brandName: $brandName, images: $images, mainImage: $mainImage, numberOfUnit: $numberOfUnit, productName: $productName, itemsWeight: $itemsWeight, createdBy: $createdBy, updatedBy: $updatedBy, createdAt: $createdAt, updatedAt: $updatedAt, salesName: $salesName, discountPercentage: $discountPercentage, salesDescription: $salesDescription, fromDate: $fromDate, endDate: $endDate, isPesach: $isPesach, nmMashlim: $nmMashlim, lowStock: $lowStock, discountedPrice: $discountedPrice, originalPrice: $originalPrice)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductSaleImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.category, category) ||
                other.category == category) &&
            (identical(other.subcategories, subcategories) ||
                other.subcategories == subcategories) &&
            (identical(other.casetypes, casetypes) ||
                other.casetypes == casetypes) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            (identical(other.brandName, brandName) ||
                other.brandName == brandName) &&
            const DeepCollectionEquality().equals(other._images, _images) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.salesName, salesName) ||
                other.salesName == salesName) &&
            (identical(other.discountPercentage, discountPercentage) ||
                other.discountPercentage == discountPercentage) &&
            (identical(other.salesDescription, salesDescription) ||
                other.salesDescription == salesDescription) &&
            (identical(other.fromDate, fromDate) ||
                other.fromDate == fromDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock) &&
            (identical(other.discountedPrice, discountedPrice) ||
                other.discountedPrice == discountedPrice) &&
            (identical(other.originalPrice, originalPrice) ||
                other.originalPrice == originalPrice));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        category,
        subcategories,
        casetypes,
        status,
        sku,
        brandName,
        const DeepCollectionEquality().hash(_images),
        mainImage,
        numberOfUnit,
        productName,
        itemsWeight,
        createdBy,
        updatedBy,
        createdAt,
        updatedAt,
        salesName,
        discountPercentage,
        salesDescription,
        fromDate,
        endDate,
        isPesach,
        nmMashlim,
        lowStock,
        discountedPrice,
        originalPrice
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductSaleImplCopyWith<_$ProductSaleImpl> get copyWith =>
      __$$ProductSaleImplCopyWithImpl<_$ProductSaleImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductSaleImplToJson(
      this,
    );
  }
}

abstract class _ProductSale implements ProductSale {
  const factory _ProductSale(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "category") final String? category,
      @JsonKey(name: "subcategories") final String? subcategories,
      @JsonKey(name: "casetypes") final String? casetypes,
      @JsonKey(name: "status") final String? status,
      @JsonKey(name: "sku") final String? sku,
      @JsonKey(name: "brandName") final String? brandName,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "numberOfUnit") final String? numberOfUnit,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "itemsWeight") final String? itemsWeight,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "salesName") final String? salesName,
      @JsonKey(name: "discountPercentage") final String? discountPercentage,
      @JsonKey(name: "salesDescription") final String? salesDescription,
      @JsonKey(name: "fromDate") final String? fromDate,
      @JsonKey(name: "endDate") final String? endDate,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim") final String? nmMashlim,
      @JsonKey(name: "lowStock") final String? lowStock,
      final double? discountedPrice,
      final double? originalPrice}) = _$ProductSaleImpl;

  factory _ProductSale.fromJson(Map<String, dynamic> json) =
      _$ProductSaleImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "category")
  String? get category;
  @override
  @JsonKey(name: "subcategories")
  String? get subcategories;
  @override //  @JsonKey(name: "subsubcategories") String? subsubcategories,
  @JsonKey(name: "casetypes")
  String? get casetypes;
  @override
  @JsonKey(name: "status")
  String? get status;
  @override
  @JsonKey(name: "sku")
  String? get sku;
  @override
  @JsonKey(name: "brandName")
  String? get brandName;
  @override
  @JsonKey(name: "images")
  List<Image>? get images;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "salesName")
  String? get salesName;
  @override
  @JsonKey(name: "discountPercentage")
  String? get discountPercentage;
  @override
  @JsonKey(name: "salesDescription")
  String? get salesDescription;
  @override
  @JsonKey(name: "fromDate")
  String? get fromDate;
  @override
  @JsonKey(name: "endDate")
  String? get endDate;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  @JsonKey(name: "lowStock")
  String? get lowStock;
  @override
  double? get discountedPrice;
  @override
  double? get originalPrice;
  @override
  @JsonKey(ignore: true)
  _$$ProductSaleImplCopyWith<_$ProductSaleImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Image _$ImageFromJson(Map<String, dynamic> json) {
  return _Image.fromJson(json);
}

/// @nodoc
mixin _$Image {
  @JsonKey(name: "imageUrl")
  String? get imageUrl => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ImageCopyWith<Image> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ImageCopyWith<$Res> {
  factory $ImageCopyWith(Image value, $Res Function(Image) then) =
      _$ImageCopyWithImpl<$Res, Image>;
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class _$ImageCopyWithImpl<$Res, $Val extends Image>
    implements $ImageCopyWith<$Res> {
  _$ImageCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_value.copyWith(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ImageImplCopyWith<$Res> implements $ImageCopyWith<$Res> {
  factory _$$ImageImplCopyWith(
          _$ImageImpl value, $Res Function(_$ImageImpl) then) =
      __$$ImageImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class __$$ImageImplCopyWithImpl<$Res>
    extends _$ImageCopyWithImpl<$Res, _$ImageImpl>
    implements _$$ImageImplCopyWith<$Res> {
  __$$ImageImplCopyWithImpl(
      _$ImageImpl _value, $Res Function(_$ImageImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_$ImageImpl(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ImageImpl implements _Image {
  const _$ImageImpl(
      {@JsonKey(name: "imageUrl") this.imageUrl,
      @JsonKey(name: "order") this.order});

  factory _$ImageImpl.fromJson(Map<String, dynamic> json) =>
      _$$ImageImplFromJson(json);

  @override
  @JsonKey(name: "imageUrl")
  final String? imageUrl;
  @override
  @JsonKey(name: "order")
  final int? order;

  @override
  String toString() {
    return 'Image(imageUrl: $imageUrl, order: $order)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ImageImpl &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.order, order) || other.order == order));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, imageUrl, order);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      __$$ImageImplCopyWithImpl<_$ImageImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ImageImplToJson(
      this,
    );
  }
}

abstract class _Image implements Image {
  const factory _Image(
      {@JsonKey(name: "imageUrl") final String? imageUrl,
      @JsonKey(name: "order") final int? order}) = _$ImageImpl;

  factory _Image.fromJson(Map<String, dynamic> json) = _$ImageImpl.fromJson;

  @override
  @JsonKey(name: "imageUrl")
  String? get imageUrl;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(ignore: true)
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalFilteredCount") this.totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  final int? totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
          {@JsonKey(name: "currentPage") final int? currentPage,
          @JsonKey(name: "totalFilteredCount") final int? totalFilteredCount,
          @JsonKey(name: "totalFilteredPage") final int? totalFilteredPage}) =
      _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
