// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_sales_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProductSalesResModelImpl _$$ProductSalesResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProductSalesResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => ProductSale.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$ProductSalesResModelImplToJson(
        _$ProductSalesResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
    };

_$ProductSaleImpl _$$ProductSaleImplFromJson(Map<String, dynamic> json) =>
    _$ProductSaleImpl(
      id: json['_id'] as String?,
      category: json['category'] as String?,
      subcategories: json['subcategories'] as String?,
      casetypes: json['casetypes'] as String?,
      status: json['status'] as String?,
      sku: json['sku'] as String?,
      brandName: json['brandName'] as String?,
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => Image.fromJson(e as Map<String, dynamic>))
          .toList(),
      mainImage: json['mainImage'] as String?,
      numberOfUnit: json['numberOfUnit'] as String?,
      productName: json['productName'] as String?,
      itemsWeight: json['itemsWeight'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      salesName: json['salesName'] as String?,
      discountPercentage: json['discountPercentage'] as String?,
      salesDescription: json['salesDescription'] as String?,
      fromDate: json['fromDate'] as String?,
      endDate: json['endDate'] as String?,
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
      lowStock: json['lowStock'] as String?,
      discountedPrice: (json['discountedPrice'] as num?)?.toDouble(),
      originalPrice: (json['originalPrice'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$$ProductSaleImplToJson(_$ProductSaleImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'category': instance.category,
      'subcategories': instance.subcategories,
      'casetypes': instance.casetypes,
      'status': instance.status,
      'sku': instance.sku,
      'brandName': instance.brandName,
      'images': instance.images,
      'mainImage': instance.mainImage,
      'numberOfUnit': instance.numberOfUnit,
      'productName': instance.productName,
      'itemsWeight': instance.itemsWeight,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      'salesName': instance.salesName,
      'discountPercentage': instance.discountPercentage,
      'salesDescription': instance.salesDescription,
      'fromDate': instance.fromDate,
      'endDate': instance.endDate,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
      'lowStock': instance.lowStock,
      'discountedPrice': instance.discountedPrice,
      'originalPrice': instance.originalPrice,
    };

_$ImageImpl _$$ImageImplFromJson(Map<String, dynamic> json) => _$ImageImpl(
      imageUrl: json['imageUrl'] as String?,
      order: json['order'] as int?,
    );

Map<String, dynamic> _$$ImageImplToJson(_$ImageImpl instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'order': instance.order,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
