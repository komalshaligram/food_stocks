// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_app_content_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAppContentResModelImpl _$$GetAppContentResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetAppContentResModelImpl(
      status: json['status'] as int?,
      contents: (json['contents'] as List<dynamic>?)
          ?.map((e) => Content.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$GetAppContentResModelImplToJson(
        _$GetAppContentResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'contents': instance.contents,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$ContentImpl _$$ContentImplFromJson(Map<String, dynamic> json) =>
    _$ContentImpl(
      id: json['_id'] as String?,
      contentName: json['contentName'] as String?,
      updatedBy: json['updatedBy'] as String?,
      updatedAt: json['updatedAt'] as String?,
      createdAt: json['createdAt'] as String?,
      createdBy: json['createdBy'] as String?,
    );

Map<String, dynamic> _$$ContentImplToJson(_$ContentImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'contentName': instance.contentName,
      'updatedBy': instance.updatedBy,
      'updatedAt': instance.updatedAt,
      'createdAt': instance.createdAt,
      'createdBy': instance.createdBy,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalPages: json['totalPages'] as int?,
      totalRecords: json['totalRecords'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalPages': instance.totalPages,
      'totalRecords': instance.totalRecords,
    };
