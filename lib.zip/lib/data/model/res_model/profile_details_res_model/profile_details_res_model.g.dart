// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_details_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProfileDetailsResModelImpl _$$ProfileDetailsResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProfileDetailsResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$ProfileDetailsResModelImplToJson(
        _$ProfileDetailsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      clients: (json['clients'] as List<dynamic>?)
          ?.map((e) => Client.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalRecords: json['totalRecords'] as int?,
      totalPages: json['totalPages'] as int?,
      currentPage: json['currentPage'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'clients': instance.clients,
      'totalRecords': instance.totalRecords,
      'totalPages': instance.totalPages,
      'currentPage': instance.currentPage,
    };

_$ClientImpl _$$ClientImplFromJson(Map<String, dynamic> json) => _$ClientImpl(
      id: json['_id'] as String?,
      email: json['email'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      address: json['address'] as String?,
      contactName: json['contactName'] as String?,
      logo: json['logo'] as String?,
      profileImage: json['profileImage'] as String?,
      adminTypeId: json['adminTypeId'] as String?,
      clientDetail: json['clientDetail'] == null
          ? null
          : ClientDetail.fromJson(json['clientDetail'] as Map<String, dynamic>),
      roleDetails: json['roleDetails'] == null
          ? null
          : RoleDetails.fromJson(json['roleDetails'] as Map<String, dynamic>),
      city: json['city'] == null
          ? null
          : City.fromJson(json['city'] as Map<String, dynamic>),
      status: json['status'] == null
          ? null
          : Status.fromJson(json['status'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$ClientImplToJson(_$ClientImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'email': instance.email,
      'phoneNumber': instance.phoneNumber,
      'address': instance.address,
      'contactName': instance.contactName,
      'logo': instance.logo,
      'profileImage': instance.profileImage,
      'adminTypeId': instance.adminTypeId,
      'clientDetail': instance.clientDetail,
      'roleDetails': instance.roleDetails,
      'city': instance.city,
      'status': instance.status,
    };

_$CityImpl _$$CityImplFromJson(Map<String, dynamic> json) => _$CityImpl(
      id: json['_id'] as String?,
      cityName: json['cityName'] as String?,
    );

Map<String, dynamic> _$$CityImplToJson(_$CityImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'cityName': instance.cityName,
    };

_$ClientDetailImpl _$$ClientDetailImplFromJson(Map<String, dynamic> json) =>
    _$ClientDetailImpl(
      bussinessId: json['bussinessId'] as int?,
      bussinessName: json['bussinessName'] as String?,
      ownerName: json['ownerName'] as String?,
      clientTypeId: json['clientTypeId'] as String?,
      israelId: json['israelId'] as String?,
      tokenId: json['tokenId'] as String?,
      fax: json['fax'] as String?,
      monthlyCredits: json['monthlyCredits'] as String?,
      applicationVersion: json['applicationVersion'] as String?,
      deviceType: json['deviceType'] as String?,
      operationTime: (json['operationTime'] as List<dynamic>?)
          ?.map((e) => OperationTime.fromJson(e as Map<String, dynamic>))
          .toList(),
      personalGuarantee: json['personalGuarantee'] as String?,
      promissoryNote: json['promissoryNote'] as String?,
      businessCertificate: json['businessCertificate'] as String?,
      israelIdImage: json['israelIdImage'] as String?,
      forms: json['forms'],
      files: json['files'],
      id: json['_id'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      clientTypes: (json['clientTypes'] as List<dynamic>?)
          ?.map((e) => ClientType.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalExpense: json['totalExpense'] as String?,
      expenseByMonth: json['expenseByMonth'] as String?,
      streetName: json['streetName'] as String?,
      streetNumber: json['streetNumber'] as String?,
      zip: json['zip'] as String?,
    );

Map<String, dynamic> _$$ClientDetailImplToJson(_$ClientDetailImpl instance) =>
    <String, dynamic>{
      'bussinessId': instance.bussinessId,
      'bussinessName': instance.bussinessName,
      'ownerName': instance.ownerName,
      'clientTypeId': instance.clientTypeId,
      'israelId': instance.israelId,
      'tokenId': instance.tokenId,
      'fax': instance.fax,
      'monthlyCredits': instance.monthlyCredits,
      'applicationVersion': instance.applicationVersion,
      'deviceType': instance.deviceType,
      'operationTime': instance.operationTime,
      'personalGuarantee': instance.personalGuarantee,
      'promissoryNote': instance.promissoryNote,
      'businessCertificate': instance.businessCertificate,
      'israelIdImage': instance.israelIdImage,
      'forms': instance.forms,
      'files': instance.files,
      '_id': instance.id,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      'clientTypes': instance.clientTypes,
      'totalExpense': instance.totalExpense,
      'expenseByMonth': instance.expenseByMonth,
      'streetName': instance.streetName,
      'streetNumber': instance.streetNumber,
      'zip': instance.zip,
    };

_$ClientTypeImpl _$$ClientTypeImplFromJson(Map<String, dynamic> json) =>
    _$ClientTypeImpl(
      id: json['_id'] as String?,
      businessType: json['businessType'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$ClientTypeImplToJson(_$ClientTypeImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'businessType': instance.businessType,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
    };

_$RoleDetailsImpl _$$RoleDetailsImplFromJson(Map<String, dynamic> json) =>
    _$RoleDetailsImpl(
      adminType: json['adminType'] as String?,
    );

Map<String, dynamic> _$$RoleDetailsImplToJson(_$RoleDetailsImpl instance) =>
    <String, dynamic>{
      'adminType': instance.adminType,
    };

_$StatusImpl _$$StatusImplFromJson(Map<String, dynamic> json) => _$StatusImpl(
      id: json['_id'] as String?,
      statusName: json['statusName'] as String?,
    );

Map<String, dynamic> _$$StatusImplToJson(_$StatusImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'statusName': instance.statusName,
    };
