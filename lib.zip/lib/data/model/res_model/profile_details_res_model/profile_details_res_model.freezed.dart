// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_details_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProfileDetailsResModel _$ProfileDetailsResModelFromJson(
    Map<String, dynamic> json) {
  return _ProfileDetailsResModel.fromJson(json);
}

/// @nodoc
mixin _$ProfileDetailsResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfileDetailsResModelCopyWith<ProfileDetailsResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileDetailsResModelCopyWith<$Res> {
  factory $ProfileDetailsResModelCopyWith(ProfileDetailsResModel value,
          $Res Function(ProfileDetailsResModel) then) =
      _$ProfileDetailsResModelCopyWithImpl<$Res, ProfileDetailsResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$ProfileDetailsResModelCopyWithImpl<$Res,
        $Val extends ProfileDetailsResModel>
    implements $ProfileDetailsResModelCopyWith<$Res> {
  _$ProfileDetailsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProfileDetailsResModelImplCopyWith<$Res>
    implements $ProfileDetailsResModelCopyWith<$Res> {
  factory _$$ProfileDetailsResModelImplCopyWith(
          _$ProfileDetailsResModelImpl value,
          $Res Function(_$ProfileDetailsResModelImpl) then) =
      __$$ProfileDetailsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$ProfileDetailsResModelImplCopyWithImpl<$Res>
    extends _$ProfileDetailsResModelCopyWithImpl<$Res,
        _$ProfileDetailsResModelImpl>
    implements _$$ProfileDetailsResModelImplCopyWith<$Res> {
  __$$ProfileDetailsResModelImplCopyWithImpl(
      _$ProfileDetailsResModelImpl _value,
      $Res Function(_$ProfileDetailsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$ProfileDetailsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileDetailsResModelImpl implements _ProfileDetailsResModel {
  const _$ProfileDetailsResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$ProfileDetailsResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfileDetailsResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'ProfileDetailsResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileDetailsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileDetailsResModelImplCopyWith<_$ProfileDetailsResModelImpl>
      get copyWith => __$$ProfileDetailsResModelImplCopyWithImpl<
          _$ProfileDetailsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileDetailsResModelImplToJson(
      this,
    );
  }
}

abstract class _ProfileDetailsResModel implements ProfileDetailsResModel {
  const factory _ProfileDetailsResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final Data? data,
          @JsonKey(name: "message") final String? message}) =
      _$ProfileDetailsResModelImpl;

  factory _ProfileDetailsResModel.fromJson(Map<String, dynamic> json) =
      _$ProfileDetailsResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$ProfileDetailsResModelImplCopyWith<_$ProfileDetailsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "clients")
  List<Client>? get clients => throw _privateConstructorUsedError;
  @JsonKey(name: "totalRecords")
  int? get totalRecords => throw _privateConstructorUsedError;
  @JsonKey(name: "totalPages")
  int? get totalPages => throw _privateConstructorUsedError;
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "clients") List<Client>? clients,
      @JsonKey(name: "totalRecords") int? totalRecords,
      @JsonKey(name: "totalPages") int? totalPages,
      @JsonKey(name: "currentPage") int? currentPage});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? clients = freezed,
    Object? totalRecords = freezed,
    Object? totalPages = freezed,
    Object? currentPage = freezed,
  }) {
    return _then(_value.copyWith(
      clients: freezed == clients
          ? _value.clients
          : clients // ignore: cast_nullable_to_non_nullable
              as List<Client>?,
      totalRecords: freezed == totalRecords
          ? _value.totalRecords
          : totalRecords // ignore: cast_nullable_to_non_nullable
              as int?,
      totalPages: freezed == totalPages
          ? _value.totalPages
          : totalPages // ignore: cast_nullable_to_non_nullable
              as int?,
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "clients") List<Client>? clients,
      @JsonKey(name: "totalRecords") int? totalRecords,
      @JsonKey(name: "totalPages") int? totalPages,
      @JsonKey(name: "currentPage") int? currentPage});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? clients = freezed,
    Object? totalRecords = freezed,
    Object? totalPages = freezed,
    Object? currentPage = freezed,
  }) {
    return _then(_$DataImpl(
      clients: freezed == clients
          ? _value._clients
          : clients // ignore: cast_nullable_to_non_nullable
              as List<Client>?,
      totalRecords: freezed == totalRecords
          ? _value.totalRecords
          : totalRecords // ignore: cast_nullable_to_non_nullable
              as int?,
      totalPages: freezed == totalPages
          ? _value.totalPages
          : totalPages // ignore: cast_nullable_to_non_nullable
              as int?,
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "clients") final List<Client>? clients,
      @JsonKey(name: "totalRecords") this.totalRecords,
      @JsonKey(name: "totalPages") this.totalPages,
      @JsonKey(name: "currentPage") this.currentPage})
      : _clients = clients;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  final List<Client>? _clients;
  @override
  @JsonKey(name: "clients")
  List<Client>? get clients {
    final value = _clients;
    if (value == null) return null;
    if (_clients is EqualUnmodifiableListView) return _clients;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "totalRecords")
  final int? totalRecords;
  @override
  @JsonKey(name: "totalPages")
  final int? totalPages;
  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;

  @override
  String toString() {
    return 'Data(clients: $clients, totalRecords: $totalRecords, totalPages: $totalPages, currentPage: $currentPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            const DeepCollectionEquality().equals(other._clients, _clients) &&
            (identical(other.totalRecords, totalRecords) ||
                other.totalRecords == totalRecords) &&
            (identical(other.totalPages, totalPages) ||
                other.totalPages == totalPages) &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_clients),
      totalRecords,
      totalPages,
      currentPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "clients") final List<Client>? clients,
      @JsonKey(name: "totalRecords") final int? totalRecords,
      @JsonKey(name: "totalPages") final int? totalPages,
      @JsonKey(name: "currentPage") final int? currentPage}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "clients")
  List<Client>? get clients;
  @override
  @JsonKey(name: "totalRecords")
  int? get totalRecords;
  @override
  @JsonKey(name: "totalPages")
  int? get totalPages;
  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Client _$ClientFromJson(Map<String, dynamic> json) {
  return _Client.fromJson(json);
}

/// @nodoc
mixin _$Client {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "address")
  String? get address => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;
  @JsonKey(name: "logo")
  String? get logo => throw _privateConstructorUsedError;
  @JsonKey(name: "profileImage")
  String? get profileImage => throw _privateConstructorUsedError;
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail => throw _privateConstructorUsedError;
  @JsonKey(name: "roleDetails")
  RoleDetails? get roleDetails => throw _privateConstructorUsedError;
  @JsonKey(name: "city")
  City? get city => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  Status? get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientCopyWith<Client> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientCopyWith<$Res> {
  factory $ClientCopyWith(Client value, $Res Function(Client) then) =
      _$ClientCopyWithImpl<$Res, Client>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "roleDetails") RoleDetails? roleDetails,
      @JsonKey(name: "city") City? city,
      @JsonKey(name: "status") Status? status});

  $ClientDetailCopyWith<$Res>? get clientDetail;
  $RoleDetailsCopyWith<$Res>? get roleDetails;
  $CityCopyWith<$Res>? get city;
  $StatusCopyWith<$Res>? get status;
}

/// @nodoc
class _$ClientCopyWithImpl<$Res, $Val extends Client>
    implements $ClientCopyWith<$Res> {
  _$ClientCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? contactName = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? roleDetails = freezed,
    Object? city = freezed,
    Object? status = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      roleDetails: freezed == roleDetails
          ? _value.roleDetails
          : roleDetails // ignore: cast_nullable_to_non_nullable
              as RoleDetails?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as City?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as Status?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientDetailCopyWith<$Res>? get clientDetail {
    if (_value.clientDetail == null) {
      return null;
    }

    return $ClientDetailCopyWith<$Res>(_value.clientDetail!, (value) {
      return _then(_value.copyWith(clientDetail: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $RoleDetailsCopyWith<$Res>? get roleDetails {
    if (_value.roleDetails == null) {
      return null;
    }

    return $RoleDetailsCopyWith<$Res>(_value.roleDetails!, (value) {
      return _then(_value.copyWith(roleDetails: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $CityCopyWith<$Res>? get city {
    if (_value.city == null) {
      return null;
    }

    return $CityCopyWith<$Res>(_value.city!, (value) {
      return _then(_value.copyWith(city: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $StatusCopyWith<$Res>? get status {
    if (_value.status == null) {
      return null;
    }

    return $StatusCopyWith<$Res>(_value.status!, (value) {
      return _then(_value.copyWith(status: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ClientImplCopyWith<$Res> implements $ClientCopyWith<$Res> {
  factory _$$ClientImplCopyWith(
          _$ClientImpl value, $Res Function(_$ClientImpl) then) =
      __$$ClientImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "roleDetails") RoleDetails? roleDetails,
      @JsonKey(name: "city") City? city,
      @JsonKey(name: "status") Status? status});

  @override
  $ClientDetailCopyWith<$Res>? get clientDetail;
  @override
  $RoleDetailsCopyWith<$Res>? get roleDetails;
  @override
  $CityCopyWith<$Res>? get city;
  @override
  $StatusCopyWith<$Res>? get status;
}

/// @nodoc
class __$$ClientImplCopyWithImpl<$Res>
    extends _$ClientCopyWithImpl<$Res, _$ClientImpl>
    implements _$$ClientImplCopyWith<$Res> {
  __$$ClientImplCopyWithImpl(
      _$ClientImpl _value, $Res Function(_$ClientImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? contactName = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? roleDetails = freezed,
    Object? city = freezed,
    Object? status = freezed,
  }) {
    return _then(_$ClientImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      roleDetails: freezed == roleDetails
          ? _value.roleDetails
          : roleDetails // ignore: cast_nullable_to_non_nullable
              as RoleDetails?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as City?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as Status?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientImpl implements _Client {
  const _$ClientImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "email") this.email,
      @JsonKey(name: "phoneNumber") this.phoneNumber,
      @JsonKey(name: "address") this.address,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "logo") this.logo,
      @JsonKey(name: "profileImage") this.profileImage,
      @JsonKey(name: "adminTypeId") this.adminTypeId,
      @JsonKey(name: "clientDetail") this.clientDetail,
      @JsonKey(name: "roleDetails") this.roleDetails,
      @JsonKey(name: "city") this.city,
      @JsonKey(name: "status") this.status});

  factory _$ClientImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "phoneNumber")
  final String? phoneNumber;
  @override
  @JsonKey(name: "address")
  final String? address;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
  @override
  @JsonKey(name: "logo")
  final String? logo;
  @override
  @JsonKey(name: "profileImage")
  final String? profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  final String? adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  final ClientDetail? clientDetail;
  @override
  @JsonKey(name: "roleDetails")
  final RoleDetails? roleDetails;
  @override
  @JsonKey(name: "city")
  final City? city;
  @override
  @JsonKey(name: "status")
  final Status? status;

  @override
  String toString() {
    return 'Client(id: $id, email: $email, phoneNumber: $phoneNumber, address: $address, contactName: $contactName, logo: $logo, profileImage: $profileImage, adminTypeId: $adminTypeId, clientDetail: $clientDetail, roleDetails: $roleDetails, city: $city, status: $status)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.profileImage, profileImage) ||
                other.profileImage == profileImage) &&
            (identical(other.adminTypeId, adminTypeId) ||
                other.adminTypeId == adminTypeId) &&
            (identical(other.clientDetail, clientDetail) ||
                other.clientDetail == clientDetail) &&
            (identical(other.roleDetails, roleDetails) ||
                other.roleDetails == roleDetails) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      email,
      phoneNumber,
      address,
      contactName,
      logo,
      profileImage,
      adminTypeId,
      clientDetail,
      roleDetails,
      city,
      status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      __$$ClientImplCopyWithImpl<_$ClientImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientImplToJson(
      this,
    );
  }
}

abstract class _Client implements Client {
  const factory _Client(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "email") final String? email,
      @JsonKey(name: "phoneNumber") final String? phoneNumber,
      @JsonKey(name: "address") final String? address,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "logo") final String? logo,
      @JsonKey(name: "profileImage") final String? profileImage,
      @JsonKey(name: "adminTypeId") final String? adminTypeId,
      @JsonKey(name: "clientDetail") final ClientDetail? clientDetail,
      @JsonKey(name: "roleDetails") final RoleDetails? roleDetails,
      @JsonKey(name: "city") final City? city,
      @JsonKey(name: "status") final Status? status}) = _$ClientImpl;

  factory _Client.fromJson(Map<String, dynamic> json) = _$ClientImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber;
  @override
  @JsonKey(name: "address")
  String? get address;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(name: "logo")
  String? get logo;
  @override
  @JsonKey(name: "profileImage")
  String? get profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail;
  @override
  @JsonKey(name: "roleDetails")
  RoleDetails? get roleDetails;
  @override
  @JsonKey(name: "city")
  City? get city;
  @override
  @JsonKey(name: "status")
  Status? get status;
  @override
  @JsonKey(ignore: true)
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

City _$CityFromJson(Map<String, dynamic> json) {
  return _City.fromJson(json);
}

/// @nodoc
mixin _$City {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "cityName")
  String? get cityName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CityCopyWith<City> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CityCopyWith<$Res> {
  factory $CityCopyWith(City value, $Res Function(City) then) =
      _$CityCopyWithImpl<$Res, City>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "cityName") String? cityName});
}

/// @nodoc
class _$CityCopyWithImpl<$Res, $Val extends City>
    implements $CityCopyWith<$Res> {
  _$CityCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? cityName = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      cityName: freezed == cityName
          ? _value.cityName
          : cityName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CityImplCopyWith<$Res> implements $CityCopyWith<$Res> {
  factory _$$CityImplCopyWith(
          _$CityImpl value, $Res Function(_$CityImpl) then) =
      __$$CityImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "cityName") String? cityName});
}

/// @nodoc
class __$$CityImplCopyWithImpl<$Res>
    extends _$CityCopyWithImpl<$Res, _$CityImpl>
    implements _$$CityImplCopyWith<$Res> {
  __$$CityImplCopyWithImpl(_$CityImpl _value, $Res Function(_$CityImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? cityName = freezed,
  }) {
    return _then(_$CityImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      cityName: freezed == cityName
          ? _value.cityName
          : cityName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CityImpl implements _City {
  const _$CityImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "cityName") this.cityName});

  factory _$CityImpl.fromJson(Map<String, dynamic> json) =>
      _$$CityImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "cityName")
  final String? cityName;

  @override
  String toString() {
    return 'City(id: $id, cityName: $cityName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CityImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.cityName, cityName) ||
                other.cityName == cityName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, cityName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CityImplCopyWith<_$CityImpl> get copyWith =>
      __$$CityImplCopyWithImpl<_$CityImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CityImplToJson(
      this,
    );
  }
}

abstract class _City implements City {
  const factory _City(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "cityName") final String? cityName}) = _$CityImpl;

  factory _City.fromJson(Map<String, dynamic> json) = _$CityImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "cityName")
  String? get cityName;
  @override
  @JsonKey(ignore: true)
  _$$CityImplCopyWith<_$CityImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientDetail _$ClientDetailFromJson(Map<String, dynamic> json) {
  return _ClientDetail.fromJson(json);
}

/// @nodoc
mixin _$ClientDetail {
  @JsonKey(name: "bussinessId")
  int? get bussinessId => throw _privateConstructorUsedError;
  @JsonKey(name: "bussinessName")
  String? get bussinessName => throw _privateConstructorUsedError;
  @JsonKey(name: "ownerName")
  String? get ownerName => throw _privateConstructorUsedError;
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "israelId")
  String? get israelId => throw _privateConstructorUsedError;
  @JsonKey(name: "tokenId")
  String? get tokenId => throw _privateConstructorUsedError;
  @JsonKey(name: "fax")
  String? get fax =>
      throw _privateConstructorUsedError; // @JsonKey(name: "lastSeen") DateTime? lastSeen,
  @JsonKey(name: "monthlyCredits")
  String? get monthlyCredits => throw _privateConstructorUsedError;
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion => throw _privateConstructorUsedError;
  @JsonKey(name: "deviceType")
  String? get deviceType => throw _privateConstructorUsedError;
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime => throw _privateConstructorUsedError;
  @JsonKey(name: "personalGuarantee")
  String? get personalGuarantee => throw _privateConstructorUsedError;
  @JsonKey(name: "promissoryNote")
  String? get promissoryNote => throw _privateConstructorUsedError;
  @JsonKey(name: "businessCertificate")
  String? get businessCertificate => throw _privateConstructorUsedError;
  @JsonKey(name: "israelIdImage")
  String? get israelIdImage => throw _privateConstructorUsedError;
  @JsonKey(name: "forms")
  dynamic get forms => throw _privateConstructorUsedError;
  @JsonKey(name: "files")
  dynamic get files => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "clientTypes")
  List<ClientType>? get clientTypes => throw _privateConstructorUsedError;
  @JsonKey(name: "totalExpense")
  String? get totalExpense => throw _privateConstructorUsedError;
  @JsonKey(name: "expenseByMonth")
  String? get expenseByMonth => throw _privateConstructorUsedError;
  String? get streetName => throw _privateConstructorUsedError;
  String? get streetNumber => throw _privateConstructorUsedError;
  String? get zip => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientDetailCopyWith<ClientDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientDetailCopyWith<$Res> {
  factory $ClientDetailCopyWith(
          ClientDetail value, $Res Function(ClientDetail) then) =
      _$ClientDetailCopyWithImpl<$Res, ClientDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "monthlyCredits") String? monthlyCredits,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<OperationTime>? operationTime,
      @JsonKey(name: "personalGuarantee") String? personalGuarantee,
      @JsonKey(name: "promissoryNote") String? promissoryNote,
      @JsonKey(name: "businessCertificate") String? businessCertificate,
      @JsonKey(name: "israelIdImage") String? israelIdImage,
      @JsonKey(name: "forms") dynamic forms,
      @JsonKey(name: "files") dynamic files,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "clientTypes") List<ClientType>? clientTypes,
      @JsonKey(name: "totalExpense") String? totalExpense,
      @JsonKey(name: "expenseByMonth") String? expenseByMonth,
      String? streetName,
      String? streetNumber,
      String? zip});
}

/// @nodoc
class _$ClientDetailCopyWithImpl<$Res, $Val extends ClientDetail>
    implements $ClientDetailCopyWith<$Res> {
  _$ClientDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? personalGuarantee = freezed,
    Object? promissoryNote = freezed,
    Object? businessCertificate = freezed,
    Object? israelIdImage = freezed,
    Object? forms = freezed,
    Object? files = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? clientTypes = freezed,
    Object? totalExpense = freezed,
    Object? expenseByMonth = freezed,
    Object? streetName = freezed,
    Object? streetNumber = freezed,
    Object? zip = freezed,
  }) {
    return _then(_value.copyWith(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as String?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value.operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      personalGuarantee: freezed == personalGuarantee
          ? _value.personalGuarantee
          : personalGuarantee // ignore: cast_nullable_to_non_nullable
              as String?,
      promissoryNote: freezed == promissoryNote
          ? _value.promissoryNote
          : promissoryNote // ignore: cast_nullable_to_non_nullable
              as String?,
      businessCertificate: freezed == businessCertificate
          ? _value.businessCertificate
          : businessCertificate // ignore: cast_nullable_to_non_nullable
              as String?,
      israelIdImage: freezed == israelIdImage
          ? _value.israelIdImage
          : israelIdImage // ignore: cast_nullable_to_non_nullable
              as String?,
      forms: freezed == forms
          ? _value.forms
          : forms // ignore: cast_nullable_to_non_nullable
              as dynamic,
      files: freezed == files
          ? _value.files
          : files // ignore: cast_nullable_to_non_nullable
              as dynamic,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      clientTypes: freezed == clientTypes
          ? _value.clientTypes
          : clientTypes // ignore: cast_nullable_to_non_nullable
              as List<ClientType>?,
      totalExpense: freezed == totalExpense
          ? _value.totalExpense
          : totalExpense // ignore: cast_nullable_to_non_nullable
              as String?,
      expenseByMonth: freezed == expenseByMonth
          ? _value.expenseByMonth
          : expenseByMonth // ignore: cast_nullable_to_non_nullable
              as String?,
      streetName: freezed == streetName
          ? _value.streetName
          : streetName // ignore: cast_nullable_to_non_nullable
              as String?,
      streetNumber: freezed == streetNumber
          ? _value.streetNumber
          : streetNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      zip: freezed == zip
          ? _value.zip
          : zip // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientDetailImplCopyWith<$Res>
    implements $ClientDetailCopyWith<$Res> {
  factory _$$ClientDetailImplCopyWith(
          _$ClientDetailImpl value, $Res Function(_$ClientDetailImpl) then) =
      __$$ClientDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "monthlyCredits") String? monthlyCredits,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<OperationTime>? operationTime,
      @JsonKey(name: "personalGuarantee") String? personalGuarantee,
      @JsonKey(name: "promissoryNote") String? promissoryNote,
      @JsonKey(name: "businessCertificate") String? businessCertificate,
      @JsonKey(name: "israelIdImage") String? israelIdImage,
      @JsonKey(name: "forms") dynamic forms,
      @JsonKey(name: "files") dynamic files,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "clientTypes") List<ClientType>? clientTypes,
      @JsonKey(name: "totalExpense") String? totalExpense,
      @JsonKey(name: "expenseByMonth") String? expenseByMonth,
      String? streetName,
      String? streetNumber,
      String? zip});
}

/// @nodoc
class __$$ClientDetailImplCopyWithImpl<$Res>
    extends _$ClientDetailCopyWithImpl<$Res, _$ClientDetailImpl>
    implements _$$ClientDetailImplCopyWith<$Res> {
  __$$ClientDetailImplCopyWithImpl(
      _$ClientDetailImpl _value, $Res Function(_$ClientDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? personalGuarantee = freezed,
    Object? promissoryNote = freezed,
    Object? businessCertificate = freezed,
    Object? israelIdImage = freezed,
    Object? forms = freezed,
    Object? files = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? clientTypes = freezed,
    Object? totalExpense = freezed,
    Object? expenseByMonth = freezed,
    Object? streetName = freezed,
    Object? streetNumber = freezed,
    Object? zip = freezed,
  }) {
    return _then(_$ClientDetailImpl(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as String?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value._operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      personalGuarantee: freezed == personalGuarantee
          ? _value.personalGuarantee
          : personalGuarantee // ignore: cast_nullable_to_non_nullable
              as String?,
      promissoryNote: freezed == promissoryNote
          ? _value.promissoryNote
          : promissoryNote // ignore: cast_nullable_to_non_nullable
              as String?,
      businessCertificate: freezed == businessCertificate
          ? _value.businessCertificate
          : businessCertificate // ignore: cast_nullable_to_non_nullable
              as String?,
      israelIdImage: freezed == israelIdImage
          ? _value.israelIdImage
          : israelIdImage // ignore: cast_nullable_to_non_nullable
              as String?,
      forms: freezed == forms
          ? _value.forms
          : forms // ignore: cast_nullable_to_non_nullable
              as dynamic,
      files: freezed == files
          ? _value.files
          : files // ignore: cast_nullable_to_non_nullable
              as dynamic,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      clientTypes: freezed == clientTypes
          ? _value._clientTypes
          : clientTypes // ignore: cast_nullable_to_non_nullable
              as List<ClientType>?,
      totalExpense: freezed == totalExpense
          ? _value.totalExpense
          : totalExpense // ignore: cast_nullable_to_non_nullable
              as String?,
      expenseByMonth: freezed == expenseByMonth
          ? _value.expenseByMonth
          : expenseByMonth // ignore: cast_nullable_to_non_nullable
              as String?,
      streetName: freezed == streetName
          ? _value.streetName
          : streetName // ignore: cast_nullable_to_non_nullable
              as String?,
      streetNumber: freezed == streetNumber
          ? _value.streetNumber
          : streetNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      zip: freezed == zip
          ? _value.zip
          : zip // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientDetailImpl implements _ClientDetail {
  const _$ClientDetailImpl(
      {@JsonKey(name: "bussinessId") this.bussinessId,
      @JsonKey(name: "bussinessName") this.bussinessName,
      @JsonKey(name: "ownerName") this.ownerName,
      @JsonKey(name: "clientTypeId") this.clientTypeId,
      @JsonKey(name: "israelId") this.israelId,
      @JsonKey(name: "tokenId") this.tokenId,
      @JsonKey(name: "fax") this.fax,
      @JsonKey(name: "monthlyCredits") this.monthlyCredits,
      @JsonKey(name: "applicationVersion") this.applicationVersion,
      @JsonKey(name: "deviceType") this.deviceType,
      @JsonKey(name: "operationTime") final List<OperationTime>? operationTime,
      @JsonKey(name: "personalGuarantee") this.personalGuarantee,
      @JsonKey(name: "promissoryNote") this.promissoryNote,
      @JsonKey(name: "businessCertificate") this.businessCertificate,
      @JsonKey(name: "israelIdImage") this.israelIdImage,
      @JsonKey(name: "forms") this.forms,
      @JsonKey(name: "files") this.files,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "clientTypes") final List<ClientType>? clientTypes,
      @JsonKey(name: "totalExpense") this.totalExpense,
      @JsonKey(name: "expenseByMonth") this.expenseByMonth,
      this.streetName,
      this.streetNumber,
      this.zip})
      : _operationTime = operationTime,
        _clientTypes = clientTypes;

  factory _$ClientDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientDetailImplFromJson(json);

  @override
  @JsonKey(name: "bussinessId")
  final int? bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  final String? bussinessName;
  @override
  @JsonKey(name: "ownerName")
  final String? ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  final String? clientTypeId;
  @override
  @JsonKey(name: "israelId")
  final String? israelId;
  @override
  @JsonKey(name: "tokenId")
  final String? tokenId;
  @override
  @JsonKey(name: "fax")
  final String? fax;
// @JsonKey(name: "lastSeen") DateTime? lastSeen,
  @override
  @JsonKey(name: "monthlyCredits")
  final String? monthlyCredits;
  @override
  @JsonKey(name: "applicationVersion")
  final String? applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  final String? deviceType;
  final List<OperationTime>? _operationTime;
  @override
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime {
    final value = _operationTime;
    if (value == null) return null;
    if (_operationTime is EqualUnmodifiableListView) return _operationTime;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "personalGuarantee")
  final String? personalGuarantee;
  @override
  @JsonKey(name: "promissoryNote")
  final String? promissoryNote;
  @override
  @JsonKey(name: "businessCertificate")
  final String? businessCertificate;
  @override
  @JsonKey(name: "israelIdImage")
  final String? israelIdImage;
  @override
  @JsonKey(name: "forms")
  final dynamic forms;
  @override
  @JsonKey(name: "files")
  final dynamic files;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  final List<ClientType>? _clientTypes;
  @override
  @JsonKey(name: "clientTypes")
  List<ClientType>? get clientTypes {
    final value = _clientTypes;
    if (value == null) return null;
    if (_clientTypes is EqualUnmodifiableListView) return _clientTypes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "totalExpense")
  final String? totalExpense;
  @override
  @JsonKey(name: "expenseByMonth")
  final String? expenseByMonth;
  @override
  final String? streetName;
  @override
  final String? streetNumber;
  @override
  final String? zip;

  @override
  String toString() {
    return 'ClientDetail(bussinessId: $bussinessId, bussinessName: $bussinessName, ownerName: $ownerName, clientTypeId: $clientTypeId, israelId: $israelId, tokenId: $tokenId, fax: $fax, monthlyCredits: $monthlyCredits, applicationVersion: $applicationVersion, deviceType: $deviceType, operationTime: $operationTime, personalGuarantee: $personalGuarantee, promissoryNote: $promissoryNote, businessCertificate: $businessCertificate, israelIdImage: $israelIdImage, forms: $forms, files: $files, id: $id, createdAt: $createdAt, updatedAt: $updatedAt, clientTypes: $clientTypes, totalExpense: $totalExpense, expenseByMonth: $expenseByMonth, streetName: $streetName, streetNumber: $streetNumber, zip: $zip)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientDetailImpl &&
            (identical(other.bussinessId, bussinessId) ||
                other.bussinessId == bussinessId) &&
            (identical(other.bussinessName, bussinessName) ||
                other.bussinessName == bussinessName) &&
            (identical(other.ownerName, ownerName) ||
                other.ownerName == ownerName) &&
            (identical(other.clientTypeId, clientTypeId) ||
                other.clientTypeId == clientTypeId) &&
            (identical(other.israelId, israelId) ||
                other.israelId == israelId) &&
            (identical(other.tokenId, tokenId) || other.tokenId == tokenId) &&
            (identical(other.fax, fax) || other.fax == fax) &&
            (identical(other.monthlyCredits, monthlyCredits) ||
                other.monthlyCredits == monthlyCredits) &&
            (identical(other.applicationVersion, applicationVersion) ||
                other.applicationVersion == applicationVersion) &&
            (identical(other.deviceType, deviceType) ||
                other.deviceType == deviceType) &&
            const DeepCollectionEquality()
                .equals(other._operationTime, _operationTime) &&
            (identical(other.personalGuarantee, personalGuarantee) ||
                other.personalGuarantee == personalGuarantee) &&
            (identical(other.promissoryNote, promissoryNote) ||
                other.promissoryNote == promissoryNote) &&
            (identical(other.businessCertificate, businessCertificate) ||
                other.businessCertificate == businessCertificate) &&
            (identical(other.israelIdImage, israelIdImage) ||
                other.israelIdImage == israelIdImage) &&
            const DeepCollectionEquality().equals(other.forms, forms) &&
            const DeepCollectionEquality().equals(other.files, files) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            const DeepCollectionEquality()
                .equals(other._clientTypes, _clientTypes) &&
            (identical(other.totalExpense, totalExpense) ||
                other.totalExpense == totalExpense) &&
            (identical(other.expenseByMonth, expenseByMonth) ||
                other.expenseByMonth == expenseByMonth) &&
            (identical(other.streetName, streetName) ||
                other.streetName == streetName) &&
            (identical(other.streetNumber, streetNumber) ||
                other.streetNumber == streetNumber) &&
            (identical(other.zip, zip) || other.zip == zip));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        bussinessId,
        bussinessName,
        ownerName,
        clientTypeId,
        israelId,
        tokenId,
        fax,
        monthlyCredits,
        applicationVersion,
        deviceType,
        const DeepCollectionEquality().hash(_operationTime),
        personalGuarantee,
        promissoryNote,
        businessCertificate,
        israelIdImage,
        const DeepCollectionEquality().hash(forms),
        const DeepCollectionEquality().hash(files),
        id,
        createdAt,
        updatedAt,
        const DeepCollectionEquality().hash(_clientTypes),
        totalExpense,
        expenseByMonth,
        streetName,
        streetNumber,
        zip
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      __$$ClientDetailImplCopyWithImpl<_$ClientDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientDetailImplToJson(
      this,
    );
  }
}

abstract class _ClientDetail implements ClientDetail {
  const factory _ClientDetail(
      {@JsonKey(name: "bussinessId") final int? bussinessId,
      @JsonKey(name: "bussinessName") final String? bussinessName,
      @JsonKey(name: "ownerName") final String? ownerName,
      @JsonKey(name: "clientTypeId") final String? clientTypeId,
      @JsonKey(name: "israelId") final String? israelId,
      @JsonKey(name: "tokenId") final String? tokenId,
      @JsonKey(name: "fax") final String? fax,
      @JsonKey(name: "monthlyCredits") final String? monthlyCredits,
      @JsonKey(name: "applicationVersion") final String? applicationVersion,
      @JsonKey(name: "deviceType") final String? deviceType,
      @JsonKey(name: "operationTime") final List<OperationTime>? operationTime,
      @JsonKey(name: "personalGuarantee") final String? personalGuarantee,
      @JsonKey(name: "promissoryNote") final String? promissoryNote,
      @JsonKey(name: "businessCertificate") final String? businessCertificate,
      @JsonKey(name: "israelIdImage") final String? israelIdImage,
      @JsonKey(name: "forms") final dynamic forms,
      @JsonKey(name: "files") final dynamic files,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "clientTypes") final List<ClientType>? clientTypes,
      @JsonKey(name: "totalExpense") final String? totalExpense,
      @JsonKey(name: "expenseByMonth") final String? expenseByMonth,
      final String? streetName,
      final String? streetNumber,
      final String? zip}) = _$ClientDetailImpl;

  factory _ClientDetail.fromJson(Map<String, dynamic> json) =
      _$ClientDetailImpl.fromJson;

  @override
  @JsonKey(name: "bussinessId")
  int? get bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  String? get bussinessName;
  @override
  @JsonKey(name: "ownerName")
  String? get ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId;
  @override
  @JsonKey(name: "israelId")
  String? get israelId;
  @override
  @JsonKey(name: "tokenId")
  String? get tokenId;
  @override
  @JsonKey(name: "fax")
  String? get fax;
  @override // @JsonKey(name: "lastSeen") DateTime? lastSeen,
  @JsonKey(name: "monthlyCredits")
  String? get monthlyCredits;
  @override
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  String? get deviceType;
  @override
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime;
  @override
  @JsonKey(name: "personalGuarantee")
  String? get personalGuarantee;
  @override
  @JsonKey(name: "promissoryNote")
  String? get promissoryNote;
  @override
  @JsonKey(name: "businessCertificate")
  String? get businessCertificate;
  @override
  @JsonKey(name: "israelIdImage")
  String? get israelIdImage;
  @override
  @JsonKey(name: "forms")
  dynamic get forms;
  @override
  @JsonKey(name: "files")
  dynamic get files;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "clientTypes")
  List<ClientType>? get clientTypes;
  @override
  @JsonKey(name: "totalExpense")
  String? get totalExpense;
  @override
  @JsonKey(name: "expenseByMonth")
  String? get expenseByMonth;
  @override
  String? get streetName;
  @override
  String? get streetNumber;
  @override
  String? get zip;
  @override
  @JsonKey(ignore: true)
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientType _$ClientTypeFromJson(Map<String, dynamic> json) {
  return _ClientType.fromJson(json);
}

/// @nodoc
mixin _$ClientType {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "businessType")
  String? get businessType => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientTypeCopyWith<ClientType> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientTypeCopyWith<$Res> {
  factory $ClientTypeCopyWith(
          ClientType value, $Res Function(ClientType) then) =
      _$ClientTypeCopyWithImpl<$Res, ClientType>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "businessType") String? businessType,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class _$ClientTypeCopyWithImpl<$Res, $Val extends ClientType>
    implements $ClientTypeCopyWith<$Res> {
  _$ClientTypeCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? businessType = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      businessType: freezed == businessType
          ? _value.businessType
          : businessType // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientTypeImplCopyWith<$Res>
    implements $ClientTypeCopyWith<$Res> {
  factory _$$ClientTypeImplCopyWith(
          _$ClientTypeImpl value, $Res Function(_$ClientTypeImpl) then) =
      __$$ClientTypeImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "businessType") String? businessType,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class __$$ClientTypeImplCopyWithImpl<$Res>
    extends _$ClientTypeCopyWithImpl<$Res, _$ClientTypeImpl>
    implements _$$ClientTypeImplCopyWith<$Res> {
  __$$ClientTypeImplCopyWithImpl(
      _$ClientTypeImpl _value, $Res Function(_$ClientTypeImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? businessType = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$ClientTypeImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      businessType: freezed == businessType
          ? _value.businessType
          : businessType // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientTypeImpl implements _ClientType {
  const _$ClientTypeImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "businessType") this.businessType,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$ClientTypeImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientTypeImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "businessType")
  final String? businessType;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'ClientType(id: $id, businessType: $businessType, createdBy: $createdBy, updatedBy: $updatedBy, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientTypeImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.businessType, businessType) ||
                other.businessType == businessType) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, businessType, createdBy,
      updatedBy, createdAt, updatedAt, v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientTypeImplCopyWith<_$ClientTypeImpl> get copyWith =>
      __$$ClientTypeImplCopyWithImpl<_$ClientTypeImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientTypeImplToJson(
      this,
    );
  }
}

abstract class _ClientType implements ClientType {
  const factory _ClientType(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "businessType") final String? businessType,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$ClientTypeImpl;

  factory _ClientType.fromJson(Map<String, dynamic> json) =
      _$ClientTypeImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "businessType")
  String? get businessType;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$ClientTypeImplCopyWith<_$ClientTypeImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

RoleDetails _$RoleDetailsFromJson(Map<String, dynamic> json) {
  return _RoleDetails.fromJson(json);
}

/// @nodoc
mixin _$RoleDetails {
  @JsonKey(name: "adminType")
  String? get adminType => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RoleDetailsCopyWith<RoleDetails> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RoleDetailsCopyWith<$Res> {
  factory $RoleDetailsCopyWith(
          RoleDetails value, $Res Function(RoleDetails) then) =
      _$RoleDetailsCopyWithImpl<$Res, RoleDetails>;
  @useResult
  $Res call({@JsonKey(name: "adminType") String? adminType});
}

/// @nodoc
class _$RoleDetailsCopyWithImpl<$Res, $Val extends RoleDetails>
    implements $RoleDetailsCopyWith<$Res> {
  _$RoleDetailsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adminType = freezed,
  }) {
    return _then(_value.copyWith(
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RoleDetailsImplCopyWith<$Res>
    implements $RoleDetailsCopyWith<$Res> {
  factory _$$RoleDetailsImplCopyWith(
          _$RoleDetailsImpl value, $Res Function(_$RoleDetailsImpl) then) =
      __$$RoleDetailsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({@JsonKey(name: "adminType") String? adminType});
}

/// @nodoc
class __$$RoleDetailsImplCopyWithImpl<$Res>
    extends _$RoleDetailsCopyWithImpl<$Res, _$RoleDetailsImpl>
    implements _$$RoleDetailsImplCopyWith<$Res> {
  __$$RoleDetailsImplCopyWithImpl(
      _$RoleDetailsImpl _value, $Res Function(_$RoleDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adminType = freezed,
  }) {
    return _then(_$RoleDetailsImpl(
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RoleDetailsImpl implements _RoleDetails {
  const _$RoleDetailsImpl({@JsonKey(name: "adminType") this.adminType});

  factory _$RoleDetailsImpl.fromJson(Map<String, dynamic> json) =>
      _$$RoleDetailsImplFromJson(json);

  @override
  @JsonKey(name: "adminType")
  final String? adminType;

  @override
  String toString() {
    return 'RoleDetails(adminType: $adminType)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RoleDetailsImpl &&
            (identical(other.adminType, adminType) ||
                other.adminType == adminType));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, adminType);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RoleDetailsImplCopyWith<_$RoleDetailsImpl> get copyWith =>
      __$$RoleDetailsImplCopyWithImpl<_$RoleDetailsImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RoleDetailsImplToJson(
      this,
    );
  }
}

abstract class _RoleDetails implements RoleDetails {
  const factory _RoleDetails(
          {@JsonKey(name: "adminType") final String? adminType}) =
      _$RoleDetailsImpl;

  factory _RoleDetails.fromJson(Map<String, dynamic> json) =
      _$RoleDetailsImpl.fromJson;

  @override
  @JsonKey(name: "adminType")
  String? get adminType;
  @override
  @JsonKey(ignore: true)
  _$$RoleDetailsImplCopyWith<_$RoleDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Status _$StatusFromJson(Map<String, dynamic> json) {
  return _Status.fromJson(json);
}

/// @nodoc
mixin _$Status {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "statusName")
  String? get statusName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StatusCopyWith<Status> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StatusCopyWith<$Res> {
  factory $StatusCopyWith(Status value, $Res Function(Status) then) =
      _$StatusCopyWithImpl<$Res, Status>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName});
}

/// @nodoc
class _$StatusCopyWithImpl<$Res, $Val extends Status>
    implements $StatusCopyWith<$Res> {
  _$StatusCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StatusImplCopyWith<$Res> implements $StatusCopyWith<$Res> {
  factory _$$StatusImplCopyWith(
          _$StatusImpl value, $Res Function(_$StatusImpl) then) =
      __$$StatusImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName});
}

/// @nodoc
class __$$StatusImplCopyWithImpl<$Res>
    extends _$StatusCopyWithImpl<$Res, _$StatusImpl>
    implements _$$StatusImplCopyWith<$Res> {
  __$$StatusImplCopyWithImpl(
      _$StatusImpl _value, $Res Function(_$StatusImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
  }) {
    return _then(_$StatusImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StatusImpl implements _Status {
  const _$StatusImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "statusName") this.statusName});

  factory _$StatusImpl.fromJson(Map<String, dynamic> json) =>
      _$$StatusImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "statusName")
  final String? statusName;

  @override
  String toString() {
    return 'Status(id: $id, statusName: $statusName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StatusImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.statusName, statusName) ||
                other.statusName == statusName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, statusName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      __$$StatusImplCopyWithImpl<_$StatusImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StatusImplToJson(
      this,
    );
  }
}

abstract class _Status implements Status {
  const factory _Status(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "statusName") final String? statusName}) = _$StatusImpl;

  factory _Status.fromJson(Map<String, dynamic> json) = _$StatusImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "statusName")
  String? get statusName;
  @override
  @JsonKey(ignore: true)
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
