// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sub_user_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SubUserResModel _$SubUserResModelFromJson(Map<String, dynamic> json) {
  return _SubUserResModel.fromJson(json);
}

/// @nodoc
mixin _$SubUserResModel {
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SubUserResModelCopyWith<SubUserResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubUserResModelCopyWith<$Res> {
  factory $SubUserResModelCopyWith(
          SubUserResModel value, $Res Function(SubUserResModel) then) =
      _$SubUserResModelCopyWithImpl<$Res, SubUserResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "data") Data? data,
      @JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$SubUserResModelCopyWithImpl<$Res, $Val extends SubUserResModel>
    implements $SubUserResModelCopyWith<$Res> {
  _$SubUserResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = freezed,
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SubUserResModelImplCopyWith<$Res>
    implements $SubUserResModelCopyWith<$Res> {
  factory _$$SubUserResModelImplCopyWith(_$SubUserResModelImpl value,
          $Res Function(_$SubUserResModelImpl) then) =
      __$$SubUserResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "data") Data? data,
      @JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$SubUserResModelImplCopyWithImpl<$Res>
    extends _$SubUserResModelCopyWithImpl<$Res, _$SubUserResModelImpl>
    implements _$$SubUserResModelImplCopyWith<$Res> {
  __$$SubUserResModelImplCopyWithImpl(
      _$SubUserResModelImpl _value, $Res Function(_$SubUserResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = freezed,
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_$SubUserResModelImpl(
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SubUserResModelImpl implements _SubUserResModel {
  const _$SubUserResModelImpl(
      {@JsonKey(name: "data") this.data,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message});

  factory _$SubUserResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SubUserResModelImplFromJson(json);

  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'SubUserResModel(data: $data, status: $status, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubUserResModelImpl &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, data, status, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubUserResModelImplCopyWith<_$SubUserResModelImpl> get copyWith =>
      __$$SubUserResModelImplCopyWithImpl<_$SubUserResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SubUserResModelImplToJson(
      this,
    );
  }
}

abstract class _SubUserResModel implements SubUserResModel {
  const factory _SubUserResModel(
      {@JsonKey(name: "data") final Data? data,
      @JsonKey(name: "status") final int? status,
      @JsonKey(name: "message") final String? message}) = _$SubUserResModelImpl;

  factory _SubUserResModel.fromJson(Map<String, dynamic> json) =
      _$SubUserResModelImpl.fromJson;

  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$SubUserResModelImplCopyWith<_$SubUserResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "password")
  dynamic get password => throw _privateConstructorUsedError;
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "userNumber")
  int? get userNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "isClientFormEmailSend")
  bool? get isClientFormEmailSend => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "password") dynamic password,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "userNumber") int? userNumber,
      @JsonKey(name: "isClientFormEmailSend") bool? isClientFormEmailSend,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? password = freezed,
    Object? phoneNumber = freezed,
    Object? contactName = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? isDeleted = freezed,
    Object? userNumber = freezed,
    Object? isClientFormEmailSend = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as dynamic,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      userNumber: freezed == userNumber
          ? _value.userNumber
          : userNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      isClientFormEmailSend: freezed == isClientFormEmailSend
          ? _value.isClientFormEmailSend
          : isClientFormEmailSend // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientDetailCopyWith<$Res>? get clientDetail {
    if (_value.clientDetail == null) {
      return null;
    }

    return $ClientDetailCopyWith<$Res>(_value.clientDetail!, (value) {
      return _then(_value.copyWith(clientDetail: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "password") dynamic password,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "userNumber") int? userNumber,
      @JsonKey(name: "isClientFormEmailSend") bool? isClientFormEmailSend,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  @override
  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? password = freezed,
    Object? phoneNumber = freezed,
    Object? contactName = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? isDeleted = freezed,
    Object? userNumber = freezed,
    Object? isClientFormEmailSend = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$DataImpl(
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as dynamic,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      userNumber: freezed == userNumber
          ? _value.userNumber
          : userNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      isClientFormEmailSend: freezed == isClientFormEmailSend
          ? _value.isClientFormEmailSend
          : isClientFormEmailSend // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "password") this.password,
      @JsonKey(name: "phoneNumber") this.phoneNumber,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "adminTypeId") this.adminTypeId,
      @JsonKey(name: "clientDetail") this.clientDetail,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "userNumber") this.userNumber,
      @JsonKey(name: "isClientFormEmailSend") this.isClientFormEmailSend,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  @JsonKey(name: "password")
  final dynamic password;
  @override
  @JsonKey(name: "phoneNumber")
  final String? phoneNumber;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
  @override
  @JsonKey(name: "adminTypeId")
  final String? adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  final ClientDetail? clientDetail;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "userNumber")
  final int? userNumber;
  @override
  @JsonKey(name: "isClientFormEmailSend")
  final bool? isClientFormEmailSend;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Data(password: $password, phoneNumber: $phoneNumber, contactName: $contactName, adminTypeId: $adminTypeId, clientDetail: $clientDetail, createdBy: $createdBy, isDeleted: $isDeleted, userNumber: $userNumber, isClientFormEmailSend: $isClientFormEmailSend, id: $id, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            const DeepCollectionEquality().equals(other.password, password) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.adminTypeId, adminTypeId) ||
                other.adminTypeId == adminTypeId) &&
            (identical(other.clientDetail, clientDetail) ||
                other.clientDetail == clientDetail) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.userNumber, userNumber) ||
                other.userNumber == userNumber) &&
            (identical(other.isClientFormEmailSend, isClientFormEmailSend) ||
                other.isClientFormEmailSend == isClientFormEmailSend) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(password),
      phoneNumber,
      contactName,
      adminTypeId,
      clientDetail,
      createdBy,
      isDeleted,
      userNumber,
      isClientFormEmailSend,
      id,
      createdAt,
      updatedAt,
      v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "password") final dynamic password,
      @JsonKey(name: "phoneNumber") final String? phoneNumber,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "adminTypeId") final String? adminTypeId,
      @JsonKey(name: "clientDetail") final ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "userNumber") final int? userNumber,
      @JsonKey(name: "isClientFormEmailSend") final bool? isClientFormEmailSend,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "password")
  dynamic get password;
  @override
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "userNumber")
  int? get userNumber;
  @override
  @JsonKey(name: "isClientFormEmailSend")
  bool? get isClientFormEmailSend;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientDetail _$ClientDetailFromJson(Map<String, dynamic> json) {
  return _ClientDetail.fromJson(json);
}

/// @nodoc
mixin _$ClientDetail {
  @JsonKey(name: "israelId")
  String? get israelId => throw _privateConstructorUsedError;
  @JsonKey(name: "operationTime")
  List<dynamic>? get operationTime => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientDetailCopyWith<ClientDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientDetailCopyWith<$Res> {
  factory $ClientDetailCopyWith(
          ClientDetail value, $Res Function(ClientDetail) then) =
      _$ClientDetailCopyWithImpl<$Res, ClientDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "operationTime") List<dynamic>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt});
}

/// @nodoc
class _$ClientDetailCopyWithImpl<$Res, $Val extends ClientDetail>
    implements $ClientDetailCopyWith<$Res> {
  _$ClientDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? israelId = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_value.copyWith(
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value.operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientDetailImplCopyWith<$Res>
    implements $ClientDetailCopyWith<$Res> {
  factory _$$ClientDetailImplCopyWith(
          _$ClientDetailImpl value, $Res Function(_$ClientDetailImpl) then) =
      __$$ClientDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "operationTime") List<dynamic>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt});
}

/// @nodoc
class __$$ClientDetailImplCopyWithImpl<$Res>
    extends _$ClientDetailCopyWithImpl<$Res, _$ClientDetailImpl>
    implements _$$ClientDetailImplCopyWith<$Res> {
  __$$ClientDetailImplCopyWithImpl(
      _$ClientDetailImpl _value, $Res Function(_$ClientDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? israelId = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_$ClientDetailImpl(
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value._operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<dynamic>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientDetailImpl implements _ClientDetail {
  const _$ClientDetailImpl(
      {@JsonKey(name: "israelId") this.israelId,
      @JsonKey(name: "operationTime") final List<dynamic>? operationTime,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt})
      : _operationTime = operationTime;

  factory _$ClientDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientDetailImplFromJson(json);

  @override
  @JsonKey(name: "israelId")
  final String? israelId;
  final List<dynamic>? _operationTime;
  @override
  @JsonKey(name: "operationTime")
  List<dynamic>? get operationTime {
    final value = _operationTime;
    if (value == null) return null;
    if (_operationTime is EqualUnmodifiableListView) return _operationTime;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;

  @override
  String toString() {
    return 'ClientDetail(israelId: $israelId, operationTime: $operationTime, id: $id, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientDetailImpl &&
            (identical(other.israelId, israelId) ||
                other.israelId == israelId) &&
            const DeepCollectionEquality()
                .equals(other._operationTime, _operationTime) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      israelId,
      const DeepCollectionEquality().hash(_operationTime),
      id,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      __$$ClientDetailImplCopyWithImpl<_$ClientDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientDetailImplToJson(
      this,
    );
  }
}

abstract class _ClientDetail implements ClientDetail {
  const factory _ClientDetail(
          {@JsonKey(name: "israelId") final String? israelId,
          @JsonKey(name: "operationTime") final List<dynamic>? operationTime,
          @JsonKey(name: "_id") final String? id,
          @JsonKey(name: "createdAt") final String? createdAt,
          @JsonKey(name: "updatedAt") final String? updatedAt}) =
      _$ClientDetailImpl;

  factory _ClientDetail.fromJson(Map<String, dynamic> json) =
      _$ClientDetailImpl.fromJson;

  @override
  @JsonKey(name: "israelId")
  String? get israelId;
  @override
  @JsonKey(name: "operationTime")
  List<dynamic>? get operationTime;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
