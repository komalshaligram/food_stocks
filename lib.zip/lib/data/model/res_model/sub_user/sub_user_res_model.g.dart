// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sub_user_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SubUserResModelImpl _$$SubUserResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$SubUserResModelImpl(
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      status: json['status'] as int?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$SubUserResModelImplToJson(
        _$SubUserResModelImpl instance) =>
    <String, dynamic>{
      'data': instance.data,
      'status': instance.status,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      password: json['password'],
      phoneNumber: json['phoneNumber'] as String?,
      contactName: json['contactName'] as String?,
      adminTypeId: json['adminTypeId'] as String?,
      clientDetail: json['clientDetail'] == null
          ? null
          : ClientDetail.fromJson(json['clientDetail'] as Map<String, dynamic>),
      createdBy: json['createdBy'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      userNumber: json['userNumber'] as int?,
      isClientFormEmailSend: json['isClientFormEmailSend'] as bool?,
      id: json['_id'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'password': instance.password,
      'phoneNumber': instance.phoneNumber,
      'contactName': instance.contactName,
      'adminTypeId': instance.adminTypeId,
      'clientDetail': instance.clientDetail,
      'createdBy': instance.createdBy,
      'isDeleted': instance.isDeleted,
      'userNumber': instance.userNumber,
      'isClientFormEmailSend': instance.isClientFormEmailSend,
      '_id': instance.id,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
    };

_$ClientDetailImpl _$$ClientDetailImplFromJson(Map<String, dynamic> json) =>
    _$ClientDetailImpl(
      israelId: json['israelId'] as String?,
      operationTime: json['operationTime'] as List<dynamic>?,
      id: json['_id'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
    );

Map<String, dynamic> _$$ClientDetailImplToJson(_$ClientDetailImpl instance) =>
    <String, dynamic>{
      'israelId': instance.israelId,
      'operationTime': instance.operationTime,
      '_id': instance.id,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
    };
