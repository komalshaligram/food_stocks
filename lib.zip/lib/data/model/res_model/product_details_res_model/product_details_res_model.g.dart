// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_details_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProductDetailsResModelImpl _$$ProductDetailsResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProductDetailsResModelImpl(
      status: json['status'] as int?,
      product: (json['product'] as List<dynamic>?)
          ?.map((e) => Product.fromJson(e as Map<String, dynamic>))
          .toList(),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$ProductDetailsResModelImplToJson(
        _$ProductDetailsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'product': instance.product,
      'message': instance.message,
    };

_$ProductImpl _$$ProductImplFromJson(Map<String, dynamic> json) =>
    _$ProductImpl(
      id: json['_id'] as String?,
      productName: json['productName'] as String?,
      brandName: json['brandName'] as String?,
      healthAndLifestye: json['healthAndLifestye'] as String?,
      productDescription: json['productDescription'] as String?,
      component: json['component'] as String?,
      nutritionalValue: json['nutritionalValue'] as String?,
      sku: json['sku'] as String?,
      kosharMilk: json['kosharMilk'] as bool?,
      dairyMeatyAndFur: json['dairyMeatyAndFur'] as String?,
      categoryId: json['categoryId'] as String?,
      subCategoryId: json['subCategoryId'] as String?,
      subSubCategoryId: json['subSubCategoryId'] as String?,
      manufacturingCountryId: json['manufacturingCountryId'] as String?,
      status: json['status'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => Image.fromJson(e as Map<String, dynamic>))
          .toList(),
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
      qrcode: json['qrcode'] as String?,
      mainImage: json['mainImage'] as String?,
      itemsWeight: (json['itemsWeight'] as num?)?.toDouble(),
      totalWeight: json['totalWeight'] as int?,
      totalWeightCardboard: (json['totalWeightCardboard'] as num?)?.toDouble(),
      totalWeightSurface: (json['totalWeightSurface'] as num?)?.toDouble(),
      numberOfUnit: json['numberOfUnit'] as int?,
      scaleId: json['scaleId'] as String?,
      scales: json['scales'] == null
          ? null
          : Scales.fromJson(json['scales'] as Map<String, dynamic>),
      supplierSales: (json['supplierSales'] as List<dynamic>?)
          ?.map((e) => SupplierSale.fromJson(e as Map<String, dynamic>))
          .toList(),
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
      isBottle: json['isBottle'] as bool?,
    );

Map<String, dynamic> _$$ProductImplToJson(_$ProductImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productName': instance.productName,
      'brandName': instance.brandName,
      'healthAndLifestye': instance.healthAndLifestye,
      'productDescription': instance.productDescription,
      'component': instance.component,
      'nutritionalValue': instance.nutritionalValue,
      'sku': instance.sku,
      'kosharMilk': instance.kosharMilk,
      'dairyMeatyAndFur': instance.dairyMeatyAndFur,
      'categoryId': instance.categoryId,
      'subCategoryId': instance.subCategoryId,
      'subSubCategoryId': instance.subSubCategoryId,
      'manufacturingCountryId': instance.manufacturingCountryId,
      'status': instance.status,
      'isDeleted': instance.isDeleted,
      'images': instance.images,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
      'qrcode': instance.qrcode,
      'mainImage': instance.mainImage,
      'itemsWeight': instance.itemsWeight,
      'totalWeight': instance.totalWeight,
      'totalWeightCardboard': instance.totalWeightCardboard,
      'totalWeightSurface': instance.totalWeightSurface,
      'numberOfUnit': instance.numberOfUnit,
      'scaleId': instance.scaleId,
      'scales': instance.scales,
      'supplierSales': instance.supplierSales,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
      'isBottle': instance.isBottle,
    };

_$ImageImpl _$$ImageImplFromJson(Map<String, dynamic> json) => _$ImageImpl(
      imageUrl: json['imageUrl'] as String?,
      order: json['order'] as int?,
    );

Map<String, dynamic> _$$ImageImplToJson(_$ImageImpl instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'order': instance.order,
    };

_$ScalesImpl _$$ScalesImplFromJson(Map<String, dynamic> json) => _$ScalesImpl(
      id: json['_id'] as String?,
      scaleType: json['scaleType'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$ScalesImplToJson(_$ScalesImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'scaleType': instance.scaleType,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
    };

_$SupplierSaleImpl _$$SupplierSaleImplFromJson(Map<String, dynamic> json) =>
    _$SupplierSaleImpl(
      id: json['_id'] == null
          ? null
          : Id.fromJson(json['_id'] as Map<String, dynamic>),
      supplierId: json['supplierId'] as String?,
      supplierName: json['supplierName'] as String?,
      supplierCompanyName: json['supplierCompanyName'] as String?,
      productPrice: json['productPrice'] as String?,
      productStock: json['productStock'] as String?,
      saleProduct: (json['saleProduct'] as List<dynamic>?)
          ?.map((e) => SaleProduct.fromJson(e as Map<String, dynamic>))
          .toList(),
      lowStock: json['lowStock'] as String?,
    );

Map<String, dynamic> _$$SupplierSaleImplToJson(_$SupplierSaleImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'supplierId': instance.supplierId,
      'supplierName': instance.supplierName,
      'supplierCompanyName': instance.supplierCompanyName,
      'productPrice': instance.productPrice,
      'productStock': instance.productStock,
      'saleProduct': instance.saleProduct,
      'lowStock': instance.lowStock,
    };

_$IdImpl _$$IdImplFromJson(Map<String, dynamic> json) => _$IdImpl(
      supplierId: json['supplierId'] as String?,
      productId: json['productId'] as String?,
    );

Map<String, dynamic> _$$IdImplToJson(_$IdImpl instance) => <String, dynamic>{
      'supplierId': instance.supplierId,
      'productId': instance.productId,
    };

_$SaleProductImpl _$$SaleProductImplFromJson(Map<String, dynamic> json) =>
    _$SaleProductImpl(
      id: json['_id'] as String?,
      price: json['price'] as String?,
      discountPercentage: json['discountPercentage'] as String?,
      discountedPrice: json['discountedPrice'] as String?,
      saleId: json['saleId'] as String?,
      saleName: json['saleName'] as String?,
      salesDescription: json['salesDescription'] as String?,
    );

Map<String, dynamic> _$$SaleProductImplToJson(_$SaleProductImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'price': instance.price,
      'discountPercentage': instance.discountPercentage,
      'discountedPrice': instance.discountedPrice,
      'saleId': instance.saleId,
      'saleName': instance.saleName,
      'salesDescription': instance.salesDescription,
    };
