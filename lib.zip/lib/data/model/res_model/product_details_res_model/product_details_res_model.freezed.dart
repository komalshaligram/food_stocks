// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_details_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProductDetailsResModel _$ProductDetailsResModelFromJson(
    Map<String, dynamic> json) {
  return _ProductDetailsResModel.fromJson(json);
}

/// @nodoc
mixin _$ProductDetailsResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "product")
  List<Product>? get product => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductDetailsResModelCopyWith<ProductDetailsResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductDetailsResModelCopyWith<$Res> {
  factory $ProductDetailsResModelCopyWith(ProductDetailsResModel value,
          $Res Function(ProductDetailsResModel) then) =
      _$ProductDetailsResModelCopyWithImpl<$Res, ProductDetailsResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "product") List<Product>? product,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class _$ProductDetailsResModelCopyWithImpl<$Res,
        $Val extends ProductDetailsResModel>
    implements $ProductDetailsResModelCopyWith<$Res> {
  _$ProductDetailsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? product = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      product: freezed == product
          ? _value.product
          : product // ignore: cast_nullable_to_non_nullable
              as List<Product>?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductDetailsResModelImplCopyWith<$Res>
    implements $ProductDetailsResModelCopyWith<$Res> {
  factory _$$ProductDetailsResModelImplCopyWith(
          _$ProductDetailsResModelImpl value,
          $Res Function(_$ProductDetailsResModelImpl) then) =
      __$$ProductDetailsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "product") List<Product>? product,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class __$$ProductDetailsResModelImplCopyWithImpl<$Res>
    extends _$ProductDetailsResModelCopyWithImpl<$Res,
        _$ProductDetailsResModelImpl>
    implements _$$ProductDetailsResModelImplCopyWith<$Res> {
  __$$ProductDetailsResModelImplCopyWithImpl(
      _$ProductDetailsResModelImpl _value,
      $Res Function(_$ProductDetailsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? product = freezed,
    Object? message = freezed,
  }) {
    return _then(_$ProductDetailsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      product: freezed == product
          ? _value._product
          : product // ignore: cast_nullable_to_non_nullable
              as List<Product>?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductDetailsResModelImpl implements _ProductDetailsResModel {
  const _$ProductDetailsResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "product") final List<Product>? product,
      @JsonKey(name: "message") this.message})
      : _product = product;

  factory _$ProductDetailsResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductDetailsResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<Product>? _product;
  @override
  @JsonKey(name: "product")
  List<Product>? get product {
    final value = _product;
    if (value == null) return null;
    if (_product is EqualUnmodifiableListView) return _product;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'ProductDetailsResModel(status: $status, product: $product, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductDetailsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._product, _product) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_product), message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductDetailsResModelImplCopyWith<_$ProductDetailsResModelImpl>
      get copyWith => __$$ProductDetailsResModelImplCopyWithImpl<
          _$ProductDetailsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductDetailsResModelImplToJson(
      this,
    );
  }
}

abstract class _ProductDetailsResModel implements ProductDetailsResModel {
  const factory _ProductDetailsResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "product") final List<Product>? product,
          @JsonKey(name: "message") final String? message}) =
      _$ProductDetailsResModelImpl;

  factory _ProductDetailsResModel.fromJson(Map<String, dynamic> json) =
      _$ProductDetailsResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "product")
  List<Product>? get product;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$ProductDetailsResModelImplCopyWith<_$ProductDetailsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Product _$ProductFromJson(Map<String, dynamic> json) {
  return _Product.fromJson(json);
}

/// @nodoc
mixin _$Product {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "brandName")
  String? get brandName => throw _privateConstructorUsedError;
  @JsonKey(name: "healthAndLifestye")
  String? get healthAndLifestye => throw _privateConstructorUsedError;
  @JsonKey(name: "productDescription")
  String? get productDescription => throw _privateConstructorUsedError;
  @JsonKey(name: "component")
  String? get component => throw _privateConstructorUsedError;
  @JsonKey(name: "nutritionalValue")
  String? get nutritionalValue => throw _privateConstructorUsedError;
  @JsonKey(name: "sku")
  String? get sku => throw _privateConstructorUsedError;
  @JsonKey(name: "kosharMilk")
  bool? get kosharMilk => throw _privateConstructorUsedError;
  @JsonKey(name: "dairyMeatyAndFur")
  String? get dairyMeatyAndFur => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryId")
  String? get categoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "subSubCategoryId")
  String? get subSubCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "manufacturingCountryId")
  String? get manufacturingCountryId => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "images")
  List<Image>? get images => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "qrcode")
  String? get qrcode => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  double? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  int? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeightCardboard")
  double? get totalWeightCardboard => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeightSurface")
  double? get totalWeightSurface => throw _privateConstructorUsedError;
  @JsonKey(name: "numberOfUnit")
  int? get numberOfUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "scaleId")
  String? get scaleId => throw _privateConstructorUsedError;
  @JsonKey(name: "scales")
  Scales? get scales => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierSales")
  List<SupplierSale>? get supplierSales => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;
  @JsonKey(name: "isBottle")
  bool? get isBottle => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductCopyWith<Product> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductCopyWith<$Res> {
  factory $ProductCopyWith(Product value, $Res Function(Product) then) =
      _$ProductCopyWithImpl<$Res, Product>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "healthAndLifestye") String? healthAndLifestye,
      @JsonKey(name: "productDescription") String? productDescription,
      @JsonKey(name: "component") String? component,
      @JsonKey(name: "nutritionalValue") String? nutritionalValue,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "kosharMilk") bool? kosharMilk,
      @JsonKey(name: "dairyMeatyAndFur") String? dairyMeatyAndFur,
      @JsonKey(name: "categoryId") String? categoryId,
      @JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "subSubCategoryId") String? subSubCategoryId,
      @JsonKey(name: "manufacturingCountryId") String? manufacturingCountryId,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") double? itemsWeight,
      @JsonKey(name: "totalWeight") int? totalWeight,
      @JsonKey(name: "totalWeightCardboard") double? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") double? totalWeightSurface,
      @JsonKey(name: "numberOfUnit") int? numberOfUnit,
      @JsonKey(name: "scaleId") String? scaleId,
      @JsonKey(name: "scales") Scales? scales,
      @JsonKey(name: "supplierSales") List<SupplierSale>? supplierSales,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      @JsonKey(name: "isBottle") bool? isBottle});

  $ScalesCopyWith<$Res>? get scales;
}

/// @nodoc
class _$ProductCopyWithImpl<$Res, $Val extends Product>
    implements $ProductCopyWith<$Res> {
  _$ProductCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productName = freezed,
    Object? brandName = freezed,
    Object? healthAndLifestye = freezed,
    Object? productDescription = freezed,
    Object? component = freezed,
    Object? nutritionalValue = freezed,
    Object? sku = freezed,
    Object? kosharMilk = freezed,
    Object? dairyMeatyAndFur = freezed,
    Object? categoryId = freezed,
    Object? subCategoryId = freezed,
    Object? subSubCategoryId = freezed,
    Object? manufacturingCountryId = freezed,
    Object? status = freezed,
    Object? isDeleted = freezed,
    Object? images = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? qrcode = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? totalWeightCardboard = freezed,
    Object? totalWeightSurface = freezed,
    Object? numberOfUnit = freezed,
    Object? scaleId = freezed,
    Object? scales = freezed,
    Object? supplierSales = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? isBottle = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      healthAndLifestye: freezed == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String?,
      productDescription: freezed == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      component: freezed == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String?,
      nutritionalValue: freezed == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      kosharMilk: freezed == kosharMilk
          ? _value.kosharMilk
          : kosharMilk // ignore: cast_nullable_to_non_nullable
              as bool?,
      dairyMeatyAndFur: freezed == dairyMeatyAndFur
          ? _value.dairyMeatyAndFur
          : dairyMeatyAndFur // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subSubCategoryId: freezed == subSubCategoryId
          ? _value.subSubCategoryId
          : subSubCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      manufacturingCountryId: freezed == manufacturingCountryId
          ? _value.manufacturingCountryId
          : manufacturingCountryId // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      images: freezed == images
          ? _value.images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as int?,
      totalWeightCardboard: freezed == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as double?,
      totalWeightSurface: freezed == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as double?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      scaleId: freezed == scaleId
          ? _value.scaleId
          : scaleId // ignore: cast_nullable_to_non_nullable
              as String?,
      scales: freezed == scales
          ? _value.scales
          : scales // ignore: cast_nullable_to_non_nullable
              as Scales?,
      supplierSales: freezed == supplierSales
          ? _value.supplierSales
          : supplierSales // ignore: cast_nullable_to_non_nullable
              as List<SupplierSale>?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      isBottle: freezed == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ScalesCopyWith<$Res>? get scales {
    if (_value.scales == null) {
      return null;
    }

    return $ScalesCopyWith<$Res>(_value.scales!, (value) {
      return _then(_value.copyWith(scales: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProductImplCopyWith<$Res> implements $ProductCopyWith<$Res> {
  factory _$$ProductImplCopyWith(
          _$ProductImpl value, $Res Function(_$ProductImpl) then) =
      __$$ProductImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "brandName") String? brandName,
      @JsonKey(name: "healthAndLifestye") String? healthAndLifestye,
      @JsonKey(name: "productDescription") String? productDescription,
      @JsonKey(name: "component") String? component,
      @JsonKey(name: "nutritionalValue") String? nutritionalValue,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "kosharMilk") bool? kosharMilk,
      @JsonKey(name: "dairyMeatyAndFur") String? dairyMeatyAndFur,
      @JsonKey(name: "categoryId") String? categoryId,
      @JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "subSubCategoryId") String? subSubCategoryId,
      @JsonKey(name: "manufacturingCountryId") String? manufacturingCountryId,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "itemsWeight") double? itemsWeight,
      @JsonKey(name: "totalWeight") int? totalWeight,
      @JsonKey(name: "totalWeightCardboard") double? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") double? totalWeightSurface,
      @JsonKey(name: "numberOfUnit") int? numberOfUnit,
      @JsonKey(name: "scaleId") String? scaleId,
      @JsonKey(name: "scales") Scales? scales,
      @JsonKey(name: "supplierSales") List<SupplierSale>? supplierSales,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      @JsonKey(name: "isBottle") bool? isBottle});

  @override
  $ScalesCopyWith<$Res>? get scales;
}

/// @nodoc
class __$$ProductImplCopyWithImpl<$Res>
    extends _$ProductCopyWithImpl<$Res, _$ProductImpl>
    implements _$$ProductImplCopyWith<$Res> {
  __$$ProductImplCopyWithImpl(
      _$ProductImpl _value, $Res Function(_$ProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productName = freezed,
    Object? brandName = freezed,
    Object? healthAndLifestye = freezed,
    Object? productDescription = freezed,
    Object? component = freezed,
    Object? nutritionalValue = freezed,
    Object? sku = freezed,
    Object? kosharMilk = freezed,
    Object? dairyMeatyAndFur = freezed,
    Object? categoryId = freezed,
    Object? subCategoryId = freezed,
    Object? subSubCategoryId = freezed,
    Object? manufacturingCountryId = freezed,
    Object? status = freezed,
    Object? isDeleted = freezed,
    Object? images = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? qrcode = freezed,
    Object? mainImage = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeight = freezed,
    Object? totalWeightCardboard = freezed,
    Object? totalWeightSurface = freezed,
    Object? numberOfUnit = freezed,
    Object? scaleId = freezed,
    Object? scales = freezed,
    Object? supplierSales = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? isBottle = freezed,
  }) {
    return _then(_$ProductImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandName: freezed == brandName
          ? _value.brandName
          : brandName // ignore: cast_nullable_to_non_nullable
              as String?,
      healthAndLifestye: freezed == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String?,
      productDescription: freezed == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      component: freezed == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String?,
      nutritionalValue: freezed == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      kosharMilk: freezed == kosharMilk
          ? _value.kosharMilk
          : kosharMilk // ignore: cast_nullable_to_non_nullable
              as bool?,
      dairyMeatyAndFur: freezed == dairyMeatyAndFur
          ? _value.dairyMeatyAndFur
          : dairyMeatyAndFur // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subSubCategoryId: freezed == subSubCategoryId
          ? _value.subSubCategoryId
          : subSubCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      manufacturingCountryId: freezed == manufacturingCountryId
          ? _value.manufacturingCountryId
          : manufacturingCountryId // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      images: freezed == images
          ? _value._images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as int?,
      totalWeightCardboard: freezed == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as double?,
      totalWeightSurface: freezed == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as double?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      scaleId: freezed == scaleId
          ? _value.scaleId
          : scaleId // ignore: cast_nullable_to_non_nullable
              as String?,
      scales: freezed == scales
          ? _value.scales
          : scales // ignore: cast_nullable_to_non_nullable
              as Scales?,
      supplierSales: freezed == supplierSales
          ? _value._supplierSales
          : supplierSales // ignore: cast_nullable_to_non_nullable
              as List<SupplierSale>?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      isBottle: freezed == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductImpl implements _Product {
  const _$ProductImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "brandName") this.brandName,
      @JsonKey(name: "healthAndLifestye") this.healthAndLifestye,
      @JsonKey(name: "productDescription") this.productDescription,
      @JsonKey(name: "component") this.component,
      @JsonKey(name: "nutritionalValue") this.nutritionalValue,
      @JsonKey(name: "sku") this.sku,
      @JsonKey(name: "kosharMilk") this.kosharMilk,
      @JsonKey(name: "dairyMeatyAndFur") this.dairyMeatyAndFur,
      @JsonKey(name: "categoryId") this.categoryId,
      @JsonKey(name: "subCategoryId") this.subCategoryId,
      @JsonKey(name: "subSubCategoryId") this.subSubCategoryId,
      @JsonKey(name: "manufacturingCountryId") this.manufacturingCountryId,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "qrcode") this.qrcode,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "totalWeightCardboard") this.totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") this.totalWeightSurface,
      @JsonKey(name: "numberOfUnit") this.numberOfUnit,
      @JsonKey(name: "scaleId") this.scaleId,
      @JsonKey(name: "scales") this.scales,
      @JsonKey(name: "supplierSales") final List<SupplierSale>? supplierSales,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim,
      @JsonKey(name: "isBottle") this.isBottle})
      : _images = images,
        _supplierSales = supplierSales;

  factory _$ProductImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "brandName")
  final String? brandName;
  @override
  @JsonKey(name: "healthAndLifestye")
  final String? healthAndLifestye;
  @override
  @JsonKey(name: "productDescription")
  final String? productDescription;
  @override
  @JsonKey(name: "component")
  final String? component;
  @override
  @JsonKey(name: "nutritionalValue")
  final String? nutritionalValue;
  @override
  @JsonKey(name: "sku")
  final String? sku;
  @override
  @JsonKey(name: "kosharMilk")
  final bool? kosharMilk;
  @override
  @JsonKey(name: "dairyMeatyAndFur")
  final String? dairyMeatyAndFur;
  @override
  @JsonKey(name: "categoryId")
  final String? categoryId;
  @override
  @JsonKey(name: "subCategoryId")
  final String? subCategoryId;
  @override
  @JsonKey(name: "subSubCategoryId")
  final String? subSubCategoryId;
  @override
  @JsonKey(name: "manufacturingCountryId")
  final String? manufacturingCountryId;
  @override
  @JsonKey(name: "status")
  final String? status;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  final List<Image>? _images;
  @override
  @JsonKey(name: "images")
  List<Image>? get images {
    final value = _images;
    if (value == null) return null;
    if (_images is EqualUnmodifiableListView) return _images;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "qrcode")
  final String? qrcode;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  final double? itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  final int? totalWeight;
  @override
  @JsonKey(name: "totalWeightCardboard")
  final double? totalWeightCardboard;
  @override
  @JsonKey(name: "totalWeightSurface")
  final double? totalWeightSurface;
  @override
  @JsonKey(name: "numberOfUnit")
  final int? numberOfUnit;
  @override
  @JsonKey(name: "scaleId")
  final String? scaleId;
  @override
  @JsonKey(name: "scales")
  final Scales? scales;
  final List<SupplierSale>? _supplierSales;
  @override
  @JsonKey(name: "supplierSales")
  List<SupplierSale>? get supplierSales {
    final value = _supplierSales;
    if (value == null) return null;
    if (_supplierSales is EqualUnmodifiableListView) return _supplierSales;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;
  @override
  @JsonKey(name: "isBottle")
  final bool? isBottle;

  @override
  String toString() {
    return 'Product(id: $id, productName: $productName, brandName: $brandName, healthAndLifestye: $healthAndLifestye, productDescription: $productDescription, component: $component, nutritionalValue: $nutritionalValue, sku: $sku, kosharMilk: $kosharMilk, dairyMeatyAndFur: $dairyMeatyAndFur, categoryId: $categoryId, subCategoryId: $subCategoryId, subSubCategoryId: $subSubCategoryId, manufacturingCountryId: $manufacturingCountryId, status: $status, isDeleted: $isDeleted, images: $images, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, qrcode: $qrcode, mainImage: $mainImage, itemsWeight: $itemsWeight, totalWeight: $totalWeight, totalWeightCardboard: $totalWeightCardboard, totalWeightSurface: $totalWeightSurface, numberOfUnit: $numberOfUnit, scaleId: $scaleId, scales: $scales, supplierSales: $supplierSales, isPesach: $isPesach, nmMashlim: $nmMashlim, isBottle: $isBottle)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.brandName, brandName) ||
                other.brandName == brandName) &&
            (identical(other.healthAndLifestye, healthAndLifestye) ||
                other.healthAndLifestye == healthAndLifestye) &&
            (identical(other.productDescription, productDescription) ||
                other.productDescription == productDescription) &&
            (identical(other.component, component) ||
                other.component == component) &&
            (identical(other.nutritionalValue, nutritionalValue) ||
                other.nutritionalValue == nutritionalValue) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            (identical(other.kosharMilk, kosharMilk) ||
                other.kosharMilk == kosharMilk) &&
            (identical(other.dairyMeatyAndFur, dairyMeatyAndFur) ||
                other.dairyMeatyAndFur == dairyMeatyAndFur) &&
            (identical(other.categoryId, categoryId) ||
                other.categoryId == categoryId) &&
            (identical(other.subCategoryId, subCategoryId) ||
                other.subCategoryId == subCategoryId) &&
            (identical(other.subSubCategoryId, subSubCategoryId) ||
                other.subSubCategoryId == subSubCategoryId) &&
            (identical(other.manufacturingCountryId, manufacturingCountryId) ||
                other.manufacturingCountryId == manufacturingCountryId) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            const DeepCollectionEquality().equals(other._images, _images) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.qrcode, qrcode) || other.qrcode == qrcode) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.totalWeightCardboard, totalWeightCardboard) ||
                other.totalWeightCardboard == totalWeightCardboard) &&
            (identical(other.totalWeightSurface, totalWeightSurface) ||
                other.totalWeightSurface == totalWeightSurface) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.scaleId, scaleId) || other.scaleId == scaleId) &&
            (identical(other.scales, scales) || other.scales == scales) &&
            const DeepCollectionEquality()
                .equals(other._supplierSales, _supplierSales) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim) &&
            (identical(other.isBottle, isBottle) ||
                other.isBottle == isBottle));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        productName,
        brandName,
        healthAndLifestye,
        productDescription,
        component,
        nutritionalValue,
        sku,
        kosharMilk,
        dairyMeatyAndFur,
        categoryId,
        subCategoryId,
        subSubCategoryId,
        manufacturingCountryId,
        status,
        isDeleted,
        const DeepCollectionEquality().hash(_images),
        createdAt,
        updatedAt,
        v,
        qrcode,
        mainImage,
        itemsWeight,
        totalWeight,
        totalWeightCardboard,
        totalWeightSurface,
        numberOfUnit,
        scaleId,
        scales,
        const DeepCollectionEquality().hash(_supplierSales),
        isPesach,
        nmMashlim,
        isBottle
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductImplCopyWith<_$ProductImpl> get copyWith =>
      __$$ProductImplCopyWithImpl<_$ProductImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductImplToJson(
      this,
    );
  }
}

abstract class _Product implements Product {
  const factory _Product(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "brandName") final String? brandName,
      @JsonKey(name: "healthAndLifestye") final String? healthAndLifestye,
      @JsonKey(name: "productDescription") final String? productDescription,
      @JsonKey(name: "component") final String? component,
      @JsonKey(name: "nutritionalValue") final String? nutritionalValue,
      @JsonKey(name: "sku") final String? sku,
      @JsonKey(name: "kosharMilk") final bool? kosharMilk,
      @JsonKey(name: "dairyMeatyAndFur") final String? dairyMeatyAndFur,
      @JsonKey(name: "categoryId") final String? categoryId,
      @JsonKey(name: "subCategoryId") final String? subCategoryId,
      @JsonKey(name: "subSubCategoryId") final String? subSubCategoryId,
      @JsonKey(name: "manufacturingCountryId")
      final String? manufacturingCountryId,
      @JsonKey(name: "status") final String? status,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v,
      @JsonKey(name: "qrcode") final String? qrcode,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "itemsWeight") final double? itemsWeight,
      @JsonKey(name: "totalWeight") final int? totalWeight,
      @JsonKey(name: "totalWeightCardboard") final double? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") final double? totalWeightSurface,
      @JsonKey(name: "numberOfUnit") final int? numberOfUnit,
      @JsonKey(name: "scaleId") final String? scaleId,
      @JsonKey(name: "scales") final Scales? scales,
      @JsonKey(name: "supplierSales") final List<SupplierSale>? supplierSales,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim") final String? nmMashlim,
      @JsonKey(name: "isBottle") final bool? isBottle}) = _$ProductImpl;

  factory _Product.fromJson(Map<String, dynamic> json) = _$ProductImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "brandName")
  String? get brandName;
  @override
  @JsonKey(name: "healthAndLifestye")
  String? get healthAndLifestye;
  @override
  @JsonKey(name: "productDescription")
  String? get productDescription;
  @override
  @JsonKey(name: "component")
  String? get component;
  @override
  @JsonKey(name: "nutritionalValue")
  String? get nutritionalValue;
  @override
  @JsonKey(name: "sku")
  String? get sku;
  @override
  @JsonKey(name: "kosharMilk")
  bool? get kosharMilk;
  @override
  @JsonKey(name: "dairyMeatyAndFur")
  String? get dairyMeatyAndFur;
  @override
  @JsonKey(name: "categoryId")
  String? get categoryId;
  @override
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId;
  @override
  @JsonKey(name: "subSubCategoryId")
  String? get subSubCategoryId;
  @override
  @JsonKey(name: "manufacturingCountryId")
  String? get manufacturingCountryId;
  @override
  @JsonKey(name: "status")
  String? get status;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "images")
  List<Image>? get images;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "qrcode")
  String? get qrcode;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "itemsWeight")
  double? get itemsWeight;
  @override
  @JsonKey(name: "totalWeight")
  int? get totalWeight;
  @override
  @JsonKey(name: "totalWeightCardboard")
  double? get totalWeightCardboard;
  @override
  @JsonKey(name: "totalWeightSurface")
  double? get totalWeightSurface;
  @override
  @JsonKey(name: "numberOfUnit")
  int? get numberOfUnit;
  @override
  @JsonKey(name: "scaleId")
  String? get scaleId;
  @override
  @JsonKey(name: "scales")
  Scales? get scales;
  @override
  @JsonKey(name: "supplierSales")
  List<SupplierSale>? get supplierSales;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  @JsonKey(name: "isBottle")
  bool? get isBottle;
  @override
  @JsonKey(ignore: true)
  _$$ProductImplCopyWith<_$ProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Image _$ImageFromJson(Map<String, dynamic> json) {
  return _Image.fromJson(json);
}

/// @nodoc
mixin _$Image {
  @JsonKey(name: "imageUrl")
  String? get imageUrl => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ImageCopyWith<Image> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ImageCopyWith<$Res> {
  factory $ImageCopyWith(Image value, $Res Function(Image) then) =
      _$ImageCopyWithImpl<$Res, Image>;
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class _$ImageCopyWithImpl<$Res, $Val extends Image>
    implements $ImageCopyWith<$Res> {
  _$ImageCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_value.copyWith(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ImageImplCopyWith<$Res> implements $ImageCopyWith<$Res> {
  factory _$$ImageImplCopyWith(
          _$ImageImpl value, $Res Function(_$ImageImpl) then) =
      __$$ImageImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class __$$ImageImplCopyWithImpl<$Res>
    extends _$ImageCopyWithImpl<$Res, _$ImageImpl>
    implements _$$ImageImplCopyWith<$Res> {
  __$$ImageImplCopyWithImpl(
      _$ImageImpl _value, $Res Function(_$ImageImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_$ImageImpl(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ImageImpl implements _Image {
  const _$ImageImpl(
      {@JsonKey(name: "imageUrl") this.imageUrl,
      @JsonKey(name: "order") this.order});

  factory _$ImageImpl.fromJson(Map<String, dynamic> json) =>
      _$$ImageImplFromJson(json);

  @override
  @JsonKey(name: "imageUrl")
  final String? imageUrl;
  @override
  @JsonKey(name: "order")
  final int? order;

  @override
  String toString() {
    return 'Image(imageUrl: $imageUrl, order: $order)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ImageImpl &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.order, order) || other.order == order));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, imageUrl, order);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      __$$ImageImplCopyWithImpl<_$ImageImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ImageImplToJson(
      this,
    );
  }
}

abstract class _Image implements Image {
  const factory _Image(
      {@JsonKey(name: "imageUrl") final String? imageUrl,
      @JsonKey(name: "order") final int? order}) = _$ImageImpl;

  factory _Image.fromJson(Map<String, dynamic> json) = _$ImageImpl.fromJson;

  @override
  @JsonKey(name: "imageUrl")
  String? get imageUrl;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(ignore: true)
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Scales _$ScalesFromJson(Map<String, dynamic> json) {
  return _Scales.fromJson(json);
}

/// @nodoc
mixin _$Scales {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "scaleType")
  String? get scaleType => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ScalesCopyWith<Scales> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ScalesCopyWith<$Res> {
  factory $ScalesCopyWith(Scales value, $Res Function(Scales) then) =
      _$ScalesCopyWithImpl<$Res, Scales>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "scaleType") String? scaleType,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class _$ScalesCopyWithImpl<$Res, $Val extends Scales>
    implements $ScalesCopyWith<$Res> {
  _$ScalesCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? scaleType = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      scaleType: freezed == scaleType
          ? _value.scaleType
          : scaleType // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ScalesImplCopyWith<$Res> implements $ScalesCopyWith<$Res> {
  factory _$$ScalesImplCopyWith(
          _$ScalesImpl value, $Res Function(_$ScalesImpl) then) =
      __$$ScalesImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "scaleType") String? scaleType,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class __$$ScalesImplCopyWithImpl<$Res>
    extends _$ScalesCopyWithImpl<$Res, _$ScalesImpl>
    implements _$$ScalesImplCopyWith<$Res> {
  __$$ScalesImplCopyWithImpl(
      _$ScalesImpl _value, $Res Function(_$ScalesImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? scaleType = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$ScalesImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      scaleType: freezed == scaleType
          ? _value.scaleType
          : scaleType // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ScalesImpl implements _Scales {
  const _$ScalesImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "scaleType") this.scaleType,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$ScalesImpl.fromJson(Map<String, dynamic> json) =>
      _$$ScalesImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "scaleType")
  final String? scaleType;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Scales(id: $id, scaleType: $scaleType, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ScalesImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.scaleType, scaleType) ||
                other.scaleType == scaleType) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, scaleType, createdAt, updatedAt, v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ScalesImplCopyWith<_$ScalesImpl> get copyWith =>
      __$$ScalesImplCopyWithImpl<_$ScalesImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ScalesImplToJson(
      this,
    );
  }
}

abstract class _Scales implements Scales {
  const factory _Scales(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "scaleType") final String? scaleType,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$ScalesImpl;

  factory _Scales.fromJson(Map<String, dynamic> json) = _$ScalesImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "scaleType")
  String? get scaleType;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$ScalesImplCopyWith<_$ScalesImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SupplierSale _$SupplierSaleFromJson(Map<String, dynamic> json) {
  return _SupplierSale.fromJson(json);
}

/// @nodoc
mixin _$SupplierSale {
  @JsonKey(name: "_id")
  Id? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierId")
  String? get supplierId => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierName")
  String? get supplierName => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierCompanyName")
  String? get supplierCompanyName => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  String? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  String? get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "saleProduct")
  List<SaleProduct>? get saleProduct => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierSaleCopyWith<SupplierSale> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierSaleCopyWith<$Res> {
  factory $SupplierSaleCopyWith(
          SupplierSale value, $Res Function(SupplierSale) then) =
      _$SupplierSaleCopyWithImpl<$Res, SupplierSale>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") Id? id,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "supplierName") String? supplierName,
      @JsonKey(name: "supplierCompanyName") String? supplierCompanyName,
      @JsonKey(name: "productPrice") String? productPrice,
      @JsonKey(name: "productStock") String? productStock,
      @JsonKey(name: "saleProduct") List<SaleProduct>? saleProduct,
      String? lowStock});

  $IdCopyWith<$Res>? get id;
}

/// @nodoc
class _$SupplierSaleCopyWithImpl<$Res, $Val extends SupplierSale>
    implements $SupplierSaleCopyWith<$Res> {
  _$SupplierSaleCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? supplierId = freezed,
    Object? supplierName = freezed,
    Object? supplierCompanyName = freezed,
    Object? productPrice = freezed,
    Object? productStock = freezed,
    Object? saleProduct = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as Id?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierName: freezed == supplierName
          ? _value.supplierName
          : supplierName // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierCompanyName: freezed == supplierCompanyName
          ? _value.supplierCompanyName
          : supplierCompanyName // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String?,
      saleProduct: freezed == saleProduct
          ? _value.saleProduct
          : saleProduct // ignore: cast_nullable_to_non_nullable
              as List<SaleProduct>?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $IdCopyWith<$Res>? get id {
    if (_value.id == null) {
      return null;
    }

    return $IdCopyWith<$Res>(_value.id!, (value) {
      return _then(_value.copyWith(id: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SupplierSaleImplCopyWith<$Res>
    implements $SupplierSaleCopyWith<$Res> {
  factory _$$SupplierSaleImplCopyWith(
          _$SupplierSaleImpl value, $Res Function(_$SupplierSaleImpl) then) =
      __$$SupplierSaleImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") Id? id,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "supplierName") String? supplierName,
      @JsonKey(name: "supplierCompanyName") String? supplierCompanyName,
      @JsonKey(name: "productPrice") String? productPrice,
      @JsonKey(name: "productStock") String? productStock,
      @JsonKey(name: "saleProduct") List<SaleProduct>? saleProduct,
      String? lowStock});

  @override
  $IdCopyWith<$Res>? get id;
}

/// @nodoc
class __$$SupplierSaleImplCopyWithImpl<$Res>
    extends _$SupplierSaleCopyWithImpl<$Res, _$SupplierSaleImpl>
    implements _$$SupplierSaleImplCopyWith<$Res> {
  __$$SupplierSaleImplCopyWithImpl(
      _$SupplierSaleImpl _value, $Res Function(_$SupplierSaleImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? supplierId = freezed,
    Object? supplierName = freezed,
    Object? supplierCompanyName = freezed,
    Object? productPrice = freezed,
    Object? productStock = freezed,
    Object? saleProduct = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_$SupplierSaleImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as Id?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierName: freezed == supplierName
          ? _value.supplierName
          : supplierName // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierCompanyName: freezed == supplierCompanyName
          ? _value.supplierCompanyName
          : supplierCompanyName // ignore: cast_nullable_to_non_nullable
              as String?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String?,
      saleProduct: freezed == saleProduct
          ? _value._saleProduct
          : saleProduct // ignore: cast_nullable_to_non_nullable
              as List<SaleProduct>?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierSaleImpl implements _SupplierSale {
  const _$SupplierSaleImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "supplierId") this.supplierId,
      @JsonKey(name: "supplierName") this.supplierName,
      @JsonKey(name: "supplierCompanyName") this.supplierCompanyName,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "saleProduct") final List<SaleProduct>? saleProduct,
      this.lowStock})
      : _saleProduct = saleProduct;

  factory _$SupplierSaleImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierSaleImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final Id? id;
  @override
  @JsonKey(name: "supplierId")
  final String? supplierId;
  @override
  @JsonKey(name: "supplierName")
  final String? supplierName;
  @override
  @JsonKey(name: "supplierCompanyName")
  final String? supplierCompanyName;
  @override
  @JsonKey(name: "productPrice")
  final String? productPrice;
  @override
  @JsonKey(name: "productStock")
  final String? productStock;
  final List<SaleProduct>? _saleProduct;
  @override
  @JsonKey(name: "saleProduct")
  List<SaleProduct>? get saleProduct {
    final value = _saleProduct;
    if (value == null) return null;
    if (_saleProduct is EqualUnmodifiableListView) return _saleProduct;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final String? lowStock;

  @override
  String toString() {
    return 'SupplierSale(id: $id, supplierId: $supplierId, supplierName: $supplierName, supplierCompanyName: $supplierCompanyName, productPrice: $productPrice, productStock: $productStock, saleProduct: $saleProduct, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSaleImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.supplierName, supplierName) ||
                other.supplierName == supplierName) &&
            (identical(other.supplierCompanyName, supplierCompanyName) ||
                other.supplierCompanyName == supplierCompanyName) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            const DeepCollectionEquality()
                .equals(other._saleProduct, _saleProduct) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      supplierId,
      supplierName,
      supplierCompanyName,
      productPrice,
      productStock,
      const DeepCollectionEquality().hash(_saleProduct),
      lowStock);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSaleImplCopyWith<_$SupplierSaleImpl> get copyWith =>
      __$$SupplierSaleImplCopyWithImpl<_$SupplierSaleImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierSaleImplToJson(
      this,
    );
  }
}

abstract class _SupplierSale implements SupplierSale {
  const factory _SupplierSale(
      {@JsonKey(name: "_id") final Id? id,
      @JsonKey(name: "supplierId") final String? supplierId,
      @JsonKey(name: "supplierName") final String? supplierName,
      @JsonKey(name: "supplierCompanyName") final String? supplierCompanyName,
      @JsonKey(name: "productPrice") final String? productPrice,
      @JsonKey(name: "productStock") final String? productStock,
      @JsonKey(name: "saleProduct") final List<SaleProduct>? saleProduct,
      final String? lowStock}) = _$SupplierSaleImpl;

  factory _SupplierSale.fromJson(Map<String, dynamic> json) =
      _$SupplierSaleImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  Id? get id;
  @override
  @JsonKey(name: "supplierId")
  String? get supplierId;
  @override
  @JsonKey(name: "supplierName")
  String? get supplierName;
  @override
  @JsonKey(name: "supplierCompanyName")
  String? get supplierCompanyName;
  @override
  @JsonKey(name: "productPrice")
  String? get productPrice;
  @override
  @JsonKey(name: "productStock")
  String? get productStock;
  @override
  @JsonKey(name: "saleProduct")
  List<SaleProduct>? get saleProduct;
  @override
  String? get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$SupplierSaleImplCopyWith<_$SupplierSaleImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Id _$IdFromJson(Map<String, dynamic> json) {
  return _Id.fromJson(json);
}

/// @nodoc
mixin _$Id {
  @JsonKey(name: "supplierId")
  String? get supplierId => throw _privateConstructorUsedError;
  @JsonKey(name: "productId")
  String? get productId => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $IdCopyWith<Id> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IdCopyWith<$Res> {
  factory $IdCopyWith(Id value, $Res Function(Id) then) =
      _$IdCopyWithImpl<$Res, Id>;
  @useResult
  $Res call(
      {@JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "productId") String? productId});
}

/// @nodoc
class _$IdCopyWithImpl<$Res, $Val extends Id> implements $IdCopyWith<$Res> {
  _$IdCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierId = freezed,
    Object? productId = freezed,
  }) {
    return _then(_value.copyWith(
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IdImplCopyWith<$Res> implements $IdCopyWith<$Res> {
  factory _$$IdImplCopyWith(_$IdImpl value, $Res Function(_$IdImpl) then) =
      __$$IdImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "productId") String? productId});
}

/// @nodoc
class __$$IdImplCopyWithImpl<$Res> extends _$IdCopyWithImpl<$Res, _$IdImpl>
    implements _$$IdImplCopyWith<$Res> {
  __$$IdImplCopyWithImpl(_$IdImpl _value, $Res Function(_$IdImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierId = freezed,
    Object? productId = freezed,
  }) {
    return _then(_$IdImpl(
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$IdImpl implements _Id {
  const _$IdImpl(
      {@JsonKey(name: "supplierId") this.supplierId,
      @JsonKey(name: "productId") this.productId});

  factory _$IdImpl.fromJson(Map<String, dynamic> json) =>
      _$$IdImplFromJson(json);

  @override
  @JsonKey(name: "supplierId")
  final String? supplierId;
  @override
  @JsonKey(name: "productId")
  final String? productId;

  @override
  String toString() {
    return 'Id(supplierId: $supplierId, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IdImpl &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, supplierId, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IdImplCopyWith<_$IdImpl> get copyWith =>
      __$$IdImplCopyWithImpl<_$IdImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$IdImplToJson(
      this,
    );
  }
}

abstract class _Id implements Id {
  const factory _Id(
      {@JsonKey(name: "supplierId") final String? supplierId,
      @JsonKey(name: "productId") final String? productId}) = _$IdImpl;

  factory _Id.fromJson(Map<String, dynamic> json) = _$IdImpl.fromJson;

  @override
  @JsonKey(name: "supplierId")
  String? get supplierId;
  @override
  @JsonKey(name: "productId")
  String? get productId;
  @override
  @JsonKey(ignore: true)
  _$$IdImplCopyWith<_$IdImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SaleProduct _$SaleProductFromJson(Map<String, dynamic> json) {
  return _SaleProduct.fromJson(json);
}

/// @nodoc
mixin _$SaleProduct {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "price")
  String? get price => throw _privateConstructorUsedError;
  @JsonKey(name: "discountPercentage")
  String? get discountPercentage => throw _privateConstructorUsedError;
  @JsonKey(name: "discountedPrice")
  String? get discountedPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "saleId")
  String? get saleId => throw _privateConstructorUsedError;
  @JsonKey(name: "saleName")
  String? get saleName => throw _privateConstructorUsedError;
  @JsonKey(name: "salesDescription")
  String? get salesDescription => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SaleProductCopyWith<SaleProduct> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SaleProductCopyWith<$Res> {
  factory $SaleProductCopyWith(
          SaleProduct value, $Res Function(SaleProduct) then) =
      _$SaleProductCopyWithImpl<$Res, SaleProduct>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "price") String? price,
      @JsonKey(name: "discountPercentage") String? discountPercentage,
      @JsonKey(name: "discountedPrice") String? discountedPrice,
      @JsonKey(name: "saleId") String? saleId,
      @JsonKey(name: "saleName") String? saleName,
      @JsonKey(name: "salesDescription") String? salesDescription});
}

/// @nodoc
class _$SaleProductCopyWithImpl<$Res, $Val extends SaleProduct>
    implements $SaleProductCopyWith<$Res> {
  _$SaleProductCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? price = freezed,
    Object? discountPercentage = freezed,
    Object? discountedPrice = freezed,
    Object? saleId = freezed,
    Object? saleName = freezed,
    Object? salesDescription = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      price: freezed == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as String?,
      discountedPrice: freezed == discountedPrice
          ? _value.discountedPrice
          : discountedPrice // ignore: cast_nullable_to_non_nullable
              as String?,
      saleId: freezed == saleId
          ? _value.saleId
          : saleId // ignore: cast_nullable_to_non_nullable
              as String?,
      saleName: freezed == saleName
          ? _value.saleName
          : saleName // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SaleProductImplCopyWith<$Res>
    implements $SaleProductCopyWith<$Res> {
  factory _$$SaleProductImplCopyWith(
          _$SaleProductImpl value, $Res Function(_$SaleProductImpl) then) =
      __$$SaleProductImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "price") String? price,
      @JsonKey(name: "discountPercentage") String? discountPercentage,
      @JsonKey(name: "discountedPrice") String? discountedPrice,
      @JsonKey(name: "saleId") String? saleId,
      @JsonKey(name: "saleName") String? saleName,
      @JsonKey(name: "salesDescription") String? salesDescription});
}

/// @nodoc
class __$$SaleProductImplCopyWithImpl<$Res>
    extends _$SaleProductCopyWithImpl<$Res, _$SaleProductImpl>
    implements _$$SaleProductImplCopyWith<$Res> {
  __$$SaleProductImplCopyWithImpl(
      _$SaleProductImpl _value, $Res Function(_$SaleProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? price = freezed,
    Object? discountPercentage = freezed,
    Object? discountedPrice = freezed,
    Object? saleId = freezed,
    Object? saleName = freezed,
    Object? salesDescription = freezed,
  }) {
    return _then(_$SaleProductImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      price: freezed == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as String?,
      discountPercentage: freezed == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as String?,
      discountedPrice: freezed == discountedPrice
          ? _value.discountedPrice
          : discountedPrice // ignore: cast_nullable_to_non_nullable
              as String?,
      saleId: freezed == saleId
          ? _value.saleId
          : saleId // ignore: cast_nullable_to_non_nullable
              as String?,
      saleName: freezed == saleName
          ? _value.saleName
          : saleName // ignore: cast_nullable_to_non_nullable
              as String?,
      salesDescription: freezed == salesDescription
          ? _value.salesDescription
          : salesDescription // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SaleProductImpl implements _SaleProduct {
  const _$SaleProductImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "price") this.price,
      @JsonKey(name: "discountPercentage") this.discountPercentage,
      @JsonKey(name: "discountedPrice") this.discountedPrice,
      @JsonKey(name: "saleId") this.saleId,
      @JsonKey(name: "saleName") this.saleName,
      @JsonKey(name: "salesDescription") this.salesDescription});

  factory _$SaleProductImpl.fromJson(Map<String, dynamic> json) =>
      _$$SaleProductImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "price")
  final String? price;
  @override
  @JsonKey(name: "discountPercentage")
  final String? discountPercentage;
  @override
  @JsonKey(name: "discountedPrice")
  final String? discountedPrice;
  @override
  @JsonKey(name: "saleId")
  final String? saleId;
  @override
  @JsonKey(name: "saleName")
  final String? saleName;
  @override
  @JsonKey(name: "salesDescription")
  final String? salesDescription;

  @override
  String toString() {
    return 'SaleProduct(id: $id, price: $price, discountPercentage: $discountPercentage, discountedPrice: $discountedPrice, saleId: $saleId, saleName: $saleName, salesDescription: $salesDescription)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SaleProductImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.price, price) || other.price == price) &&
            (identical(other.discountPercentage, discountPercentage) ||
                other.discountPercentage == discountPercentage) &&
            (identical(other.discountedPrice, discountedPrice) ||
                other.discountedPrice == discountedPrice) &&
            (identical(other.saleId, saleId) || other.saleId == saleId) &&
            (identical(other.saleName, saleName) ||
                other.saleName == saleName) &&
            (identical(other.salesDescription, salesDescription) ||
                other.salesDescription == salesDescription));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, price, discountPercentage,
      discountedPrice, saleId, saleName, salesDescription);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SaleProductImplCopyWith<_$SaleProductImpl> get copyWith =>
      __$$SaleProductImplCopyWithImpl<_$SaleProductImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SaleProductImplToJson(
      this,
    );
  }
}

abstract class _SaleProduct implements SaleProduct {
  const factory _SaleProduct(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "price") final String? price,
          @JsonKey(name: "discountPercentage") final String? discountPercentage,
          @JsonKey(name: "discountedPrice") final String? discountedPrice,
          @JsonKey(name: "saleId") final String? saleId,
          @JsonKey(name: "saleName") final String? saleName,
          @JsonKey(name: "salesDescription") final String? salesDescription}) =
      _$SaleProductImpl;

  factory _SaleProduct.fromJson(Map<String, dynamic> json) =
      _$SaleProductImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "price")
  String? get price;
  @override
  @JsonKey(name: "discountPercentage")
  String? get discountPercentage;
  @override
  @JsonKey(name: "discountedPrice")
  String? get discountedPrice;
  @override
  @JsonKey(name: "saleId")
  String? get saleId;
  @override
  @JsonKey(name: "saleName")
  String? get saleName;
  @override
  @JsonKey(name: "salesDescription")
  String? get salesDescription;
  @override
  @JsonKey(ignore: true)
  _$$SaleProductImplCopyWith<_$SaleProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
