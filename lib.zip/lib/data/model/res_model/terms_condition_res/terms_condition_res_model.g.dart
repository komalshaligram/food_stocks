// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'terms_condition_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$TermsConditionResModelImpl _$$TermsConditionResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$TermsConditionResModelImpl(
      status: json['status'] as int?,
      data: json['data'] as String?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$TermsConditionResModelImplToJson(
        _$TermsConditionResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };
