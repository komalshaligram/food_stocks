// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'terms_condition_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

TermsConditionResModel _$TermsConditionResModelFromJson(
    Map<String, dynamic> json) {
  return _TermsConditionResModel.fromJson(json);
}

/// @nodoc
mixin _$TermsConditionResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  String? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $TermsConditionResModelCopyWith<TermsConditionResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TermsConditionResModelCopyWith<$Res> {
  factory $TermsConditionResModelCopyWith(TermsConditionResModel value,
          $Res Function(TermsConditionResModel) then) =
      _$TermsConditionResModelCopyWithImpl<$Res, TermsConditionResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") String? data,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class _$TermsConditionResModelCopyWithImpl<$Res,
        $Val extends TermsConditionResModel>
    implements $TermsConditionResModelCopyWith<$Res> {
  _$TermsConditionResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$TermsConditionResModelImplCopyWith<$Res>
    implements $TermsConditionResModelCopyWith<$Res> {
  factory _$$TermsConditionResModelImplCopyWith(
          _$TermsConditionResModelImpl value,
          $Res Function(_$TermsConditionResModelImpl) then) =
      __$$TermsConditionResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") String? data,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class __$$TermsConditionResModelImplCopyWithImpl<$Res>
    extends _$TermsConditionResModelCopyWithImpl<$Res,
        _$TermsConditionResModelImpl>
    implements _$$TermsConditionResModelImplCopyWith<$Res> {
  __$$TermsConditionResModelImplCopyWithImpl(
      _$TermsConditionResModelImpl _value,
      $Res Function(_$TermsConditionResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$TermsConditionResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$TermsConditionResModelImpl implements _TermsConditionResModel {
  const _$TermsConditionResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$TermsConditionResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$TermsConditionResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final String? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'TermsConditionResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TermsConditionResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TermsConditionResModelImplCopyWith<_$TermsConditionResModelImpl>
      get copyWith => __$$TermsConditionResModelImplCopyWithImpl<
          _$TermsConditionResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$TermsConditionResModelImplToJson(
      this,
    );
  }
}

abstract class _TermsConditionResModel implements TermsConditionResModel {
  const factory _TermsConditionResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final String? data,
          @JsonKey(name: "message") final String? message}) =
      _$TermsConditionResModelImpl;

  factory _TermsConditionResModel.fromJson(Map<String, dynamic> json) =
      _$TermsConditionResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  String? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$TermsConditionResModelImplCopyWith<_$TermsConditionResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
