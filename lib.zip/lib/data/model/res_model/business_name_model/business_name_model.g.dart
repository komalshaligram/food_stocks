// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'business_name_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$BusinessNameModelImpl _$$BusinessNameModelImplFromJson(
        Map<String, dynamic> json) =>
    _$BusinessNameModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$BusinessNameModelImplToJson(
        _$BusinessNameModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      businessType: (json['BusinessType'] as List<dynamic>?)
          ?.map((e) => BusinessType.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'BusinessType': instance.businessType,
    };

_$BusinessTypeImpl _$$BusinessTypeImplFromJson(Map<String, dynamic> json) =>
    _$BusinessTypeImpl(
      id: json['_id'] as String?,
      businessTypeName: json['businessTypeName'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      businessTypeNumber: json['businessTypeNumber'] as int?,
      haveMultiple: json['haveMultiple'] as bool?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      lowerField: json['lowerField'] as String?,
    );

Map<String, dynamic> _$$BusinessTypeImplToJson(_$BusinessTypeImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'businessTypeName': instance.businessTypeName,
      'isDeleted': instance.isDeleted,
      'businessTypeNumber': instance.businessTypeNumber,
      'haveMultiple': instance.haveMultiple,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'lowerField': instance.lowerField,
    };
