// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'business_name_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

BusinessNameModel _$BusinessNameModelFromJson(Map<String, dynamic> json) {
  return _BusinessNameModel.fromJson(json);
}

/// @nodoc
mixin _$BusinessNameModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BusinessNameModelCopyWith<BusinessNameModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BusinessNameModelCopyWith<$Res> {
  factory $BusinessNameModelCopyWith(
          BusinessNameModel value, $Res Function(BusinessNameModel) then) =
      _$BusinessNameModelCopyWithImpl<$Res, BusinessNameModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$BusinessNameModelCopyWithImpl<$Res, $Val extends BusinessNameModel>
    implements $BusinessNameModelCopyWith<$Res> {
  _$BusinessNameModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$BusinessNameModelImplCopyWith<$Res>
    implements $BusinessNameModelCopyWith<$Res> {
  factory _$$BusinessNameModelImplCopyWith(_$BusinessNameModelImpl value,
          $Res Function(_$BusinessNameModelImpl) then) =
      __$$BusinessNameModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$BusinessNameModelImplCopyWithImpl<$Res>
    extends _$BusinessNameModelCopyWithImpl<$Res, _$BusinessNameModelImpl>
    implements _$$BusinessNameModelImplCopyWith<$Res> {
  __$$BusinessNameModelImplCopyWithImpl(_$BusinessNameModelImpl _value,
      $Res Function(_$BusinessNameModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$BusinessNameModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BusinessNameModelImpl implements _BusinessNameModel {
  const _$BusinessNameModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$BusinessNameModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$BusinessNameModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'BusinessNameModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BusinessNameModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BusinessNameModelImplCopyWith<_$BusinessNameModelImpl> get copyWith =>
      __$$BusinessNameModelImplCopyWithImpl<_$BusinessNameModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BusinessNameModelImplToJson(
      this,
    );
  }
}

abstract class _BusinessNameModel implements BusinessNameModel {
  const factory _BusinessNameModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final Data? data,
          @JsonKey(name: "message") final String? message}) =
      _$BusinessNameModelImpl;

  factory _BusinessNameModel.fromJson(Map<String, dynamic> json) =
      _$BusinessNameModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$BusinessNameModelImplCopyWith<_$BusinessNameModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "BusinessType")
  List<BusinessType>? get businessType => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call({@JsonKey(name: "BusinessType") List<BusinessType>? businessType});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? businessType = freezed,
  }) {
    return _then(_value.copyWith(
      businessType: freezed == businessType
          ? _value.businessType
          : businessType // ignore: cast_nullable_to_non_nullable
              as List<BusinessType>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({@JsonKey(name: "BusinessType") List<BusinessType>? businessType});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? businessType = freezed,
  }) {
    return _then(_$DataImpl(
      businessType: freezed == businessType
          ? _value._businessType
          : businessType // ignore: cast_nullable_to_non_nullable
              as List<BusinessType>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "BusinessType") final List<BusinessType>? businessType})
      : _businessType = businessType;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  final List<BusinessType>? _businessType;
  @override
  @JsonKey(name: "BusinessType")
  List<BusinessType>? get businessType {
    final value = _businessType;
    if (value == null) return null;
    if (_businessType is EqualUnmodifiableListView) return _businessType;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'Data(businessType: $businessType)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            const DeepCollectionEquality()
                .equals(other._businessType, _businessType));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_businessType));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "BusinessType")
      final List<BusinessType>? businessType}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "BusinessType")
  List<BusinessType>? get businessType;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

BusinessType _$BusinessTypeFromJson(Map<String, dynamic> json) {
  return _BusinessType.fromJson(json);
}

/// @nodoc
mixin _$BusinessType {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "businessTypeName")
  String? get businessTypeName => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "businessTypeNumber")
  int? get businessTypeNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "haveMultiple")
  bool? get haveMultiple => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "lowerField")
  String? get lowerField => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BusinessTypeCopyWith<BusinessType> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BusinessTypeCopyWith<$Res> {
  factory $BusinessTypeCopyWith(
          BusinessType value, $Res Function(BusinessType) then) =
      _$BusinessTypeCopyWithImpl<$Res, BusinessType>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "businessTypeName") String? businessTypeName,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "businessTypeNumber") int? businessTypeNumber,
      @JsonKey(name: "haveMultiple") bool? haveMultiple,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "lowerField") String? lowerField});
}

/// @nodoc
class _$BusinessTypeCopyWithImpl<$Res, $Val extends BusinessType>
    implements $BusinessTypeCopyWith<$Res> {
  _$BusinessTypeCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? businessTypeName = freezed,
    Object? isDeleted = freezed,
    Object? businessTypeNumber = freezed,
    Object? haveMultiple = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? lowerField = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      businessTypeName: freezed == businessTypeName
          ? _value.businessTypeName
          : businessTypeName // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      businessTypeNumber: freezed == businessTypeNumber
          ? _value.businessTypeNumber
          : businessTypeNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      haveMultiple: freezed == haveMultiple
          ? _value.haveMultiple
          : haveMultiple // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      lowerField: freezed == lowerField
          ? _value.lowerField
          : lowerField // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$BusinessTypeImplCopyWith<$Res>
    implements $BusinessTypeCopyWith<$Res> {
  factory _$$BusinessTypeImplCopyWith(
          _$BusinessTypeImpl value, $Res Function(_$BusinessTypeImpl) then) =
      __$$BusinessTypeImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "businessTypeName") String? businessTypeName,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "businessTypeNumber") int? businessTypeNumber,
      @JsonKey(name: "haveMultiple") bool? haveMultiple,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "lowerField") String? lowerField});
}

/// @nodoc
class __$$BusinessTypeImplCopyWithImpl<$Res>
    extends _$BusinessTypeCopyWithImpl<$Res, _$BusinessTypeImpl>
    implements _$$BusinessTypeImplCopyWith<$Res> {
  __$$BusinessTypeImplCopyWithImpl(
      _$BusinessTypeImpl _value, $Res Function(_$BusinessTypeImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? businessTypeName = freezed,
    Object? isDeleted = freezed,
    Object? businessTypeNumber = freezed,
    Object? haveMultiple = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? lowerField = freezed,
  }) {
    return _then(_$BusinessTypeImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      businessTypeName: freezed == businessTypeName
          ? _value.businessTypeName
          : businessTypeName // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      businessTypeNumber: freezed == businessTypeNumber
          ? _value.businessTypeNumber
          : businessTypeNumber // ignore: cast_nullable_to_non_nullable
              as int?,
      haveMultiple: freezed == haveMultiple
          ? _value.haveMultiple
          : haveMultiple // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      lowerField: freezed == lowerField
          ? _value.lowerField
          : lowerField // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BusinessTypeImpl implements _BusinessType {
  const _$BusinessTypeImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "businessTypeName") this.businessTypeName,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "businessTypeNumber") this.businessTypeNumber,
      @JsonKey(name: "haveMultiple") this.haveMultiple,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "lowerField") this.lowerField});

  factory _$BusinessTypeImpl.fromJson(Map<String, dynamic> json) =>
      _$$BusinessTypeImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "businessTypeName")
  final String? businessTypeName;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "businessTypeNumber")
  final int? businessTypeNumber;
  @override
  @JsonKey(name: "haveMultiple")
  final bool? haveMultiple;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "lowerField")
  final String? lowerField;

  @override
  String toString() {
    return 'BusinessType(id: $id, businessTypeName: $businessTypeName, isDeleted: $isDeleted, businessTypeNumber: $businessTypeNumber, haveMultiple: $haveMultiple, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, lowerField: $lowerField)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BusinessTypeImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.businessTypeName, businessTypeName) ||
                other.businessTypeName == businessTypeName) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.businessTypeNumber, businessTypeNumber) ||
                other.businessTypeNumber == businessTypeNumber) &&
            (identical(other.haveMultiple, haveMultiple) ||
                other.haveMultiple == haveMultiple) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.lowerField, lowerField) ||
                other.lowerField == lowerField));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, businessTypeName, isDeleted,
      businessTypeNumber, haveMultiple, createdAt, updatedAt, v, lowerField);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BusinessTypeImplCopyWith<_$BusinessTypeImpl> get copyWith =>
      __$$BusinessTypeImplCopyWithImpl<_$BusinessTypeImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BusinessTypeImplToJson(
      this,
    );
  }
}

abstract class _BusinessType implements BusinessType {
  const factory _BusinessType(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "businessTypeName") final String? businessTypeName,
          @JsonKey(name: "isDeleted") final bool? isDeleted,
          @JsonKey(name: "businessTypeNumber") final int? businessTypeNumber,
          @JsonKey(name: "haveMultiple") final bool? haveMultiple,
          @JsonKey(name: "createdAt") final String? createdAt,
          @JsonKey(name: "updatedAt") final String? updatedAt,
          @JsonKey(name: "__v") final int? v,
          @JsonKey(name: "lowerField") final String? lowerField}) =
      _$BusinessTypeImpl;

  factory _BusinessType.fromJson(Map<String, dynamic> json) =
      _$BusinessTypeImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "businessTypeName")
  String? get businessTypeName;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "businessTypeNumber")
  int? get businessTypeNumber;
  @override
  @JsonKey(name: "haveMultiple")
  bool? get haveMultiple;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "lowerField")
  String? get lowerField;
  @override
  @JsonKey(ignore: true)
  _$$BusinessTypeImplCopyWith<_$BusinessTypeImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
