// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_record_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

WalletRecordResModel _$WalletRecordResModelFromJson(Map<String, dynamic> json) {
  return _WalletRecordResModel.fromJson(json);
}

/// @nodoc
mixin _$WalletRecordResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalletRecordResModelCopyWith<WalletRecordResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRecordResModelCopyWith<$Res> {
  factory $WalletRecordResModelCopyWith(WalletRecordResModel value,
          $Res Function(WalletRecordResModel) then) =
      _$WalletRecordResModelCopyWithImpl<$Res, WalletRecordResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$WalletRecordResModelCopyWithImpl<$Res,
        $Val extends WalletRecordResModel>
    implements $WalletRecordResModelCopyWith<$Res> {
  _$WalletRecordResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$WalletRecordResModelImplCopyWith<$Res>
    implements $WalletRecordResModelCopyWith<$Res> {
  factory _$$WalletRecordResModelImplCopyWith(_$WalletRecordResModelImpl value,
          $Res Function(_$WalletRecordResModelImpl) then) =
      __$$WalletRecordResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$WalletRecordResModelImplCopyWithImpl<$Res>
    extends _$WalletRecordResModelCopyWithImpl<$Res, _$WalletRecordResModelImpl>
    implements _$$WalletRecordResModelImplCopyWith<$Res> {
  __$$WalletRecordResModelImplCopyWithImpl(_$WalletRecordResModelImpl _value,
      $Res Function(_$WalletRecordResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$WalletRecordResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$WalletRecordResModelImpl implements _WalletRecordResModel {
  const _$WalletRecordResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$WalletRecordResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$WalletRecordResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'WalletRecordResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$WalletRecordResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$WalletRecordResModelImplCopyWith<_$WalletRecordResModelImpl>
      get copyWith =>
          __$$WalletRecordResModelImplCopyWithImpl<_$WalletRecordResModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$WalletRecordResModelImplToJson(
      this,
    );
  }
}

abstract class _WalletRecordResModel implements WalletRecordResModel {
  const factory _WalletRecordResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final Data? data,
          @JsonKey(name: "message") final String? message}) =
      _$WalletRecordResModelImpl;

  factory _WalletRecordResModel.fromJson(Map<String, dynamic> json) =
      _$WalletRecordResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$WalletRecordResModelImplCopyWith<_$WalletRecordResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "currentMonth")
  Month? get currentMonth => throw _privateConstructorUsedError;
  @JsonKey(name: "previousMonth")
  Month? get previousMonth => throw _privateConstructorUsedError;
  @JsonKey(name: "balanceAmount")
  double? get balanceAmount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalCredit")
  double? get totalCredit => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentMonth") Month? currentMonth,
      @JsonKey(name: "previousMonth") Month? previousMonth,
      @JsonKey(name: "balanceAmount") double? balanceAmount,
      @JsonKey(name: "totalCredit") double? totalCredit});

  $MonthCopyWith<$Res>? get currentMonth;
  $MonthCopyWith<$Res>? get previousMonth;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentMonth = freezed,
    Object? previousMonth = freezed,
    Object? balanceAmount = freezed,
    Object? totalCredit = freezed,
  }) {
    return _then(_value.copyWith(
      currentMonth: freezed == currentMonth
          ? _value.currentMonth
          : currentMonth // ignore: cast_nullable_to_non_nullable
              as Month?,
      previousMonth: freezed == previousMonth
          ? _value.previousMonth
          : previousMonth // ignore: cast_nullable_to_non_nullable
              as Month?,
      balanceAmount: freezed == balanceAmount
          ? _value.balanceAmount
          : balanceAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      totalCredit: freezed == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MonthCopyWith<$Res>? get currentMonth {
    if (_value.currentMonth == null) {
      return null;
    }

    return $MonthCopyWith<$Res>(_value.currentMonth!, (value) {
      return _then(_value.copyWith(currentMonth: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $MonthCopyWith<$Res>? get previousMonth {
    if (_value.previousMonth == null) {
      return null;
    }

    return $MonthCopyWith<$Res>(_value.previousMonth!, (value) {
      return _then(_value.copyWith(previousMonth: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentMonth") Month? currentMonth,
      @JsonKey(name: "previousMonth") Month? previousMonth,
      @JsonKey(name: "balanceAmount") double? balanceAmount,
      @JsonKey(name: "totalCredit") double? totalCredit});

  @override
  $MonthCopyWith<$Res>? get currentMonth;
  @override
  $MonthCopyWith<$Res>? get previousMonth;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentMonth = freezed,
    Object? previousMonth = freezed,
    Object? balanceAmount = freezed,
    Object? totalCredit = freezed,
  }) {
    return _then(_$DataImpl(
      currentMonth: freezed == currentMonth
          ? _value.currentMonth
          : currentMonth // ignore: cast_nullable_to_non_nullable
              as Month?,
      previousMonth: freezed == previousMonth
          ? _value.previousMonth
          : previousMonth // ignore: cast_nullable_to_non_nullable
              as Month?,
      balanceAmount: freezed == balanceAmount
          ? _value.balanceAmount
          : balanceAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      totalCredit: freezed == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "currentMonth") this.currentMonth,
      @JsonKey(name: "previousMonth") this.previousMonth,
      @JsonKey(name: "balanceAmount") this.balanceAmount,
      @JsonKey(name: "totalCredit") this.totalCredit});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  @JsonKey(name: "currentMonth")
  final Month? currentMonth;
  @override
  @JsonKey(name: "previousMonth")
  final Month? previousMonth;
  @override
  @JsonKey(name: "balanceAmount")
  final double? balanceAmount;
  @override
  @JsonKey(name: "totalCredit")
  final double? totalCredit;

  @override
  String toString() {
    return 'Data(currentMonth: $currentMonth, previousMonth: $previousMonth, balanceAmount: $balanceAmount, totalCredit: $totalCredit)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.currentMonth, currentMonth) ||
                other.currentMonth == currentMonth) &&
            (identical(other.previousMonth, previousMonth) ||
                other.previousMonth == previousMonth) &&
            (identical(other.balanceAmount, balanceAmount) ||
                other.balanceAmount == balanceAmount) &&
            (identical(other.totalCredit, totalCredit) ||
                other.totalCredit == totalCredit));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentMonth, previousMonth, balanceAmount, totalCredit);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "currentMonth") final Month? currentMonth,
      @JsonKey(name: "previousMonth") final Month? previousMonth,
      @JsonKey(name: "balanceAmount") final double? balanceAmount,
      @JsonKey(name: "totalCredit") final double? totalCredit}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "currentMonth")
  Month? get currentMonth;
  @override
  @JsonKey(name: "previousMonth")
  Month? get previousMonth;
  @override
  @JsonKey(name: "balanceAmount")
  double? get balanceAmount;
  @override
  @JsonKey(name: "totalCredit")
  double? get totalCredit;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Month _$MonthFromJson(Map<String, dynamic> json) {
  return _Month.fromJson(json);
}

/// @nodoc
mixin _$Month {
  @JsonKey(name: "year")
  int? get year => throw _privateConstructorUsedError;
  @JsonKey(name: "month")
  int? get month => throw _privateConstructorUsedError;
  @JsonKey(name: "totalExpenses")
  double? get totalExpenses => throw _privateConstructorUsedError;
  @JsonKey(name: "expensePercentage")
  String? get expensePercentage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MonthCopyWith<Month> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MonthCopyWith<$Res> {
  factory $MonthCopyWith(Month value, $Res Function(Month) then) =
      _$MonthCopyWithImpl<$Res, Month>;
  @useResult
  $Res call(
      {@JsonKey(name: "year") int? year,
      @JsonKey(name: "month") int? month,
      @JsonKey(name: "totalExpenses") double? totalExpenses,
      @JsonKey(name: "expensePercentage") String? expensePercentage});
}

/// @nodoc
class _$MonthCopyWithImpl<$Res, $Val extends Month>
    implements $MonthCopyWith<$Res> {
  _$MonthCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = freezed,
    Object? month = freezed,
    Object? totalExpenses = freezed,
    Object? expensePercentage = freezed,
  }) {
    return _then(_value.copyWith(
      year: freezed == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int?,
      month: freezed == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as int?,
      totalExpenses: freezed == totalExpenses
          ? _value.totalExpenses
          : totalExpenses // ignore: cast_nullable_to_non_nullable
              as double?,
      expensePercentage: freezed == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MonthImplCopyWith<$Res> implements $MonthCopyWith<$Res> {
  factory _$$MonthImplCopyWith(
          _$MonthImpl value, $Res Function(_$MonthImpl) then) =
      __$$MonthImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "year") int? year,
      @JsonKey(name: "month") int? month,
      @JsonKey(name: "totalExpenses") double? totalExpenses,
      @JsonKey(name: "expensePercentage") String? expensePercentage});
}

/// @nodoc
class __$$MonthImplCopyWithImpl<$Res>
    extends _$MonthCopyWithImpl<$Res, _$MonthImpl>
    implements _$$MonthImplCopyWith<$Res> {
  __$$MonthImplCopyWithImpl(
      _$MonthImpl _value, $Res Function(_$MonthImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = freezed,
    Object? month = freezed,
    Object? totalExpenses = freezed,
    Object? expensePercentage = freezed,
  }) {
    return _then(_$MonthImpl(
      year: freezed == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int?,
      month: freezed == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as int?,
      totalExpenses: freezed == totalExpenses
          ? _value.totalExpenses
          : totalExpenses // ignore: cast_nullable_to_non_nullable
              as double?,
      expensePercentage: freezed == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MonthImpl implements _Month {
  const _$MonthImpl(
      {@JsonKey(name: "year") this.year,
      @JsonKey(name: "month") this.month,
      @JsonKey(name: "totalExpenses") this.totalExpenses,
      @JsonKey(name: "expensePercentage") this.expensePercentage});

  factory _$MonthImpl.fromJson(Map<String, dynamic> json) =>
      _$$MonthImplFromJson(json);

  @override
  @JsonKey(name: "year")
  final int? year;
  @override
  @JsonKey(name: "month")
  final int? month;
  @override
  @JsonKey(name: "totalExpenses")
  final double? totalExpenses;
  @override
  @JsonKey(name: "expensePercentage")
  final String? expensePercentage;

  @override
  String toString() {
    return 'Month(year: $year, month: $month, totalExpenses: $totalExpenses, expensePercentage: $expensePercentage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MonthImpl &&
            (identical(other.year, year) || other.year == year) &&
            (identical(other.month, month) || other.month == month) &&
            (identical(other.totalExpenses, totalExpenses) ||
                other.totalExpenses == totalExpenses) &&
            (identical(other.expensePercentage, expensePercentage) ||
                other.expensePercentage == expensePercentage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, year, month, totalExpenses, expensePercentage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MonthImplCopyWith<_$MonthImpl> get copyWith =>
      __$$MonthImplCopyWithImpl<_$MonthImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MonthImplToJson(
      this,
    );
  }
}

abstract class _Month implements Month {
  const factory _Month(
      {@JsonKey(name: "year") final int? year,
      @JsonKey(name: "month") final int? month,
      @JsonKey(name: "totalExpenses") final double? totalExpenses,
      @JsonKey(name: "expensePercentage")
      final String? expensePercentage}) = _$MonthImpl;

  factory _Month.fromJson(Map<String, dynamic> json) = _$MonthImpl.fromJson;

  @override
  @JsonKey(name: "year")
  int? get year;
  @override
  @JsonKey(name: "month")
  int? get month;
  @override
  @JsonKey(name: "totalExpenses")
  double? get totalExpenses;
  @override
  @JsonKey(name: "expensePercentage")
  String? get expensePercentage;
  @override
  @JsonKey(ignore: true)
  _$$MonthImplCopyWith<_$MonthImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
