// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_record_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$WalletRecordResModelImpl _$$WalletRecordResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$WalletRecordResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$WalletRecordResModelImplToJson(
        _$WalletRecordResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      currentMonth: json['currentMonth'] == null
          ? null
          : Month.fromJson(json['currentMonth'] as Map<String, dynamic>),
      previousMonth: json['previousMonth'] == null
          ? null
          : Month.fromJson(json['previousMonth'] as Map<String, dynamic>),
      balanceAmount: (json['balanceAmount'] as num?)?.toDouble(),
      totalCredit: (json['totalCredit'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'currentMonth': instance.currentMonth,
      'previousMonth': instance.previousMonth,
      'balanceAmount': instance.balanceAmount,
      'totalCredit': instance.totalCredit,
    };

_$MonthImpl _$$MonthImplFromJson(Map<String, dynamic> json) => _$MonthImpl(
      year: json['year'] as int?,
      month: json['month'] as int?,
      totalExpenses: (json['totalExpenses'] as num?)?.toDouble(),
      expensePercentage: json['expensePercentage'] as String?,
    );

Map<String, dynamic> _$$MonthImplToJson(_$MonthImpl instance) =>
    <String, dynamic>{
      'year': instance.year,
      'month': instance.month,
      'totalExpenses': instance.totalExpenses,
      'expensePercentage': instance.expensePercentage,
    };
