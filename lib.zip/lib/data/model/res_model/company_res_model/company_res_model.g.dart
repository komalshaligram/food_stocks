// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'company_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CompanyResModelImpl _$$CompanyResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$CompanyResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$CompanyResModelImplToJson(
        _$CompanyResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      brandList: (json['BrandList'] as List<dynamic>?)
          ?.map((e) => Brand.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalRecords: json['totalRecords'] as int?,
      totalPages: json['totalPages'] as int?,
      currentPage: json['currentPage'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'BrandList': instance.brandList,
      'totalRecords': instance.totalRecords,
      'totalPages': instance.totalPages,
      'currentPage': instance.currentPage,
    };

_$BrandImpl _$$BrandImplFromJson(Map<String, dynamic> json) => _$BrandImpl(
      id: json['_id'] as String?,
      brandName: json['brandName'] as String?,
      brandLogo: json['brandLogo'] as String?,
      isHomePreference: json['isHomePreference'] as bool?,
      order: json['order'] as int?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$BrandImplToJson(_$BrandImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'brandName': instance.brandName,
      'brandLogo': instance.brandLogo,
      'isHomePreference': instance.isHomePreference,
      'order': instance.order,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
    };
