// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'insert_cart_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$InsertCartResModelImpl _$$InsertCartResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$InsertCartResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$InsertCartResModelImplToJson(
        _$InsertCartResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl();

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{};
