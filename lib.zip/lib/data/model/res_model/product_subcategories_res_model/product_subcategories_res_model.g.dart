// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_subcategories_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProductSubcategoriesResModelImpl _$$ProductSubcategoriesResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProductSubcategoriesResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$ProductSubcategoriesResModelImplToJson(
        _$ProductSubcategoriesResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      subCategories: (json['subCategories'] as List<dynamic>?)
          ?.map((e) => SubCategory.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalRecords: json['totalRecords'] as int?,
      totalPages: json['totalPages'] as int?,
      currentPage: json['currentPage'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'subCategories': instance.subCategories,
      'totalRecords': instance.totalRecords,
      'totalPages': instance.totalPages,
      'currentPage': instance.currentPage,
    };

_$SubCategoryImpl _$$SubCategoryImplFromJson(Map<String, dynamic> json) =>
    _$SubCategoryImpl(
      id: json['_id'] as String?,
      subCategoryName: json['subCategoryName'] as String?,
      parentCategoryId: json['parentCategoryId'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
      parentCategoryName: json['parentCategoryName'] as String?,
    );

Map<String, dynamic> _$$SubCategoryImplToJson(_$SubCategoryImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'subCategoryName': instance.subCategoryName,
      'parentCategoryId': instance.parentCategoryId,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
      'parentCategoryName': instance.parentCategoryName,
    };
