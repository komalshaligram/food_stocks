// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order_send_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$OrderSendResModelImpl _$$OrderSendResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$OrderSendResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$OrderSendResModelImplToJson(
        _$OrderSendResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      clientId: json['clientId'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      id: json['_id'] as String?,
      statusId: json['statusId'] as String?,
      totalAmount: json['totalAmount'] == null
          ? null
          : SurfaceWeight.fromJson(json['totalAmount'] as Map<String, dynamic>),
      totalWeight: json['totalWeight'] == null
          ? null
          : SurfaceWeight.fromJson(json['totalWeight'] as Map<String, dynamic>),
      surfaceWeight: json['surfaceWeight'] == null
          ? null
          : SurfaceWeight.fromJson(
              json['surfaceWeight'] as Map<String, dynamic>),
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'clientId': instance.clientId,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      '_id': instance.id,
      'statusId': instance.statusId,
      'totalAmount': instance.totalAmount,
      'totalWeight': instance.totalWeight,
      'surfaceWeight': instance.surfaceWeight,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
    };

_$SurfaceWeightImpl _$$SurfaceWeightImplFromJson(Map<String, dynamic> json) =>
    _$SurfaceWeightImpl(
      numberDecimal: json['numberDecimal'] as String?,
    );

Map<String, dynamic> _$$SurfaceWeightImplToJson(_$SurfaceWeightImpl instance) =>
    <String, dynamic>{
      'numberDecimal': instance.numberDecimal,
    };
