// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'order_send_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

OrderSendResModel _$OrderSendResModelFromJson(Map<String, dynamic> json) {
  return _OrderSendResModel.fromJson(json);
}

/// @nodoc
mixin _$OrderSendResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $OrderSendResModelCopyWith<OrderSendResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderSendResModelCopyWith<$Res> {
  factory $OrderSendResModelCopyWith(
          OrderSendResModel value, $Res Function(OrderSendResModel) then) =
      _$OrderSendResModelCopyWithImpl<$Res, OrderSendResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") Data? data});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$OrderSendResModelCopyWithImpl<$Res, $Val extends OrderSendResModel>
    implements $OrderSendResModelCopyWith<$Res> {
  _$OrderSendResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$OrderSendResModelImplCopyWith<$Res>
    implements $OrderSendResModelCopyWith<$Res> {
  factory _$$OrderSendResModelImplCopyWith(_$OrderSendResModelImpl value,
          $Res Function(_$OrderSendResModelImpl) then) =
      __$$OrderSendResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") Data? data});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$OrderSendResModelImplCopyWithImpl<$Res>
    extends _$OrderSendResModelCopyWithImpl<$Res, _$OrderSendResModelImpl>
    implements _$$OrderSendResModelImplCopyWith<$Res> {
  __$$OrderSendResModelImplCopyWithImpl(_$OrderSendResModelImpl _value,
      $Res Function(_$OrderSendResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_$OrderSendResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$OrderSendResModelImpl implements _OrderSendResModel {
  const _$OrderSendResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message,
      @JsonKey(name: "data") this.data});

  factory _$OrderSendResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$OrderSendResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;
  @override
  @JsonKey(name: "data")
  final Data? data;

  @override
  String toString() {
    return 'OrderSendResModel(status: $status, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OrderSendResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.data, data) || other.data == data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OrderSendResModelImplCopyWith<_$OrderSendResModelImpl> get copyWith =>
      __$$OrderSendResModelImplCopyWithImpl<_$OrderSendResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$OrderSendResModelImplToJson(
      this,
    );
  }
}

abstract class _OrderSendResModel implements OrderSendResModel {
  const factory _OrderSendResModel(
      {@JsonKey(name: "status") final int? status,
      @JsonKey(name: "message") final String? message,
      @JsonKey(name: "data") final Data? data}) = _$OrderSendResModelImpl;

  factory _OrderSendResModel.fromJson(Map<String, dynamic> json) =
      _$OrderSendResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(ignore: true)
  _$$OrderSendResModelImplCopyWith<_$OrderSendResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "clientId")
  String? get clientId => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "statusId")
  String? get statusId => throw _privateConstructorUsedError;
  @JsonKey(name: "totalAmount")
  SurfaceWeight? get totalAmount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  SurfaceWeight? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "surfaceWeight")
  SurfaceWeight? get surfaceWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "clientId") String? clientId,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "totalAmount") SurfaceWeight? totalAmount,
      @JsonKey(name: "totalWeight") SurfaceWeight? totalWeight,
      @JsonKey(name: "surfaceWeight") SurfaceWeight? surfaceWeight,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  $SurfaceWeightCopyWith<$Res>? get totalAmount;
  $SurfaceWeightCopyWith<$Res>? get totalWeight;
  $SurfaceWeightCopyWith<$Res>? get surfaceWeight;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? clientId = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? id = freezed,
    Object? statusId = freezed,
    Object? totalAmount = freezed,
    Object? totalWeight = freezed,
    Object? surfaceWeight = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      clientId: freezed == clientId
          ? _value.clientId
          : clientId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as SurfaceWeight?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as SurfaceWeight?,
      surfaceWeight: freezed == surfaceWeight
          ? _value.surfaceWeight
          : surfaceWeight // ignore: cast_nullable_to_non_nullable
              as SurfaceWeight?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $SurfaceWeightCopyWith<$Res>? get totalAmount {
    if (_value.totalAmount == null) {
      return null;
    }

    return $SurfaceWeightCopyWith<$Res>(_value.totalAmount!, (value) {
      return _then(_value.copyWith(totalAmount: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $SurfaceWeightCopyWith<$Res>? get totalWeight {
    if (_value.totalWeight == null) {
      return null;
    }

    return $SurfaceWeightCopyWith<$Res>(_value.totalWeight!, (value) {
      return _then(_value.copyWith(totalWeight: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $SurfaceWeightCopyWith<$Res>? get surfaceWeight {
    if (_value.surfaceWeight == null) {
      return null;
    }

    return $SurfaceWeightCopyWith<$Res>(_value.surfaceWeight!, (value) {
      return _then(_value.copyWith(surfaceWeight: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "clientId") String? clientId,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "totalAmount") SurfaceWeight? totalAmount,
      @JsonKey(name: "totalWeight") SurfaceWeight? totalWeight,
      @JsonKey(name: "surfaceWeight") SurfaceWeight? surfaceWeight,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v});

  @override
  $SurfaceWeightCopyWith<$Res>? get totalAmount;
  @override
  $SurfaceWeightCopyWith<$Res>? get totalWeight;
  @override
  $SurfaceWeightCopyWith<$Res>? get surfaceWeight;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? clientId = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? id = freezed,
    Object? statusId = freezed,
    Object? totalAmount = freezed,
    Object? totalWeight = freezed,
    Object? surfaceWeight = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$DataImpl(
      clientId: freezed == clientId
          ? _value.clientId
          : clientId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as SurfaceWeight?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as SurfaceWeight?,
      surfaceWeight: freezed == surfaceWeight
          ? _value.surfaceWeight
          : surfaceWeight // ignore: cast_nullable_to_non_nullable
              as SurfaceWeight?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "clientId") this.clientId,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "statusId") this.statusId,
      @JsonKey(name: "totalAmount") this.totalAmount,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "surfaceWeight") this.surfaceWeight,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  @JsonKey(name: "clientId")
  final String? clientId;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "statusId")
  final String? statusId;
  @override
  @JsonKey(name: "totalAmount")
  final SurfaceWeight? totalAmount;
  @override
  @JsonKey(name: "totalWeight")
  final SurfaceWeight? totalWeight;
  @override
  @JsonKey(name: "surfaceWeight")
  final SurfaceWeight? surfaceWeight;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Data(clientId: $clientId, createdBy: $createdBy, updatedBy: $updatedBy, id: $id, statusId: $statusId, totalAmount: $totalAmount, totalWeight: $totalWeight, surfaceWeight: $surfaceWeight, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.clientId, clientId) ||
                other.clientId == clientId) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.statusId, statusId) ||
                other.statusId == statusId) &&
            (identical(other.totalAmount, totalAmount) ||
                other.totalAmount == totalAmount) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.surfaceWeight, surfaceWeight) ||
                other.surfaceWeight == surfaceWeight) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      clientId,
      createdBy,
      updatedBy,
      id,
      statusId,
      totalAmount,
      totalWeight,
      surfaceWeight,
      createdAt,
      updatedAt,
      v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "clientId") final String? clientId,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "statusId") final String? statusId,
      @JsonKey(name: "totalAmount") final SurfaceWeight? totalAmount,
      @JsonKey(name: "totalWeight") final SurfaceWeight? totalWeight,
      @JsonKey(name: "surfaceWeight") final SurfaceWeight? surfaceWeight,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "clientId")
  String? get clientId;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "statusId")
  String? get statusId;
  @override
  @JsonKey(name: "totalAmount")
  SurfaceWeight? get totalAmount;
  @override
  @JsonKey(name: "totalWeight")
  SurfaceWeight? get totalWeight;
  @override
  @JsonKey(name: "surfaceWeight")
  SurfaceWeight? get surfaceWeight;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SurfaceWeight _$SurfaceWeightFromJson(Map<String, dynamic> json) {
  return _SurfaceWeight.fromJson(json);
}

/// @nodoc
mixin _$SurfaceWeight {
  String? get numberDecimal => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SurfaceWeightCopyWith<SurfaceWeight> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SurfaceWeightCopyWith<$Res> {
  factory $SurfaceWeightCopyWith(
          SurfaceWeight value, $Res Function(SurfaceWeight) then) =
      _$SurfaceWeightCopyWithImpl<$Res, SurfaceWeight>;
  @useResult
  $Res call({String? numberDecimal});
}

/// @nodoc
class _$SurfaceWeightCopyWithImpl<$Res, $Val extends SurfaceWeight>
    implements $SurfaceWeightCopyWith<$Res> {
  _$SurfaceWeightCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberDecimal = freezed,
  }) {
    return _then(_value.copyWith(
      numberDecimal: freezed == numberDecimal
          ? _value.numberDecimal
          : numberDecimal // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SurfaceWeightImplCopyWith<$Res>
    implements $SurfaceWeightCopyWith<$Res> {
  factory _$$SurfaceWeightImplCopyWith(
          _$SurfaceWeightImpl value, $Res Function(_$SurfaceWeightImpl) then) =
      __$$SurfaceWeightImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String? numberDecimal});
}

/// @nodoc
class __$$SurfaceWeightImplCopyWithImpl<$Res>
    extends _$SurfaceWeightCopyWithImpl<$Res, _$SurfaceWeightImpl>
    implements _$$SurfaceWeightImplCopyWith<$Res> {
  __$$SurfaceWeightImplCopyWithImpl(
      _$SurfaceWeightImpl _value, $Res Function(_$SurfaceWeightImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberDecimal = freezed,
  }) {
    return _then(_$SurfaceWeightImpl(
      numberDecimal: freezed == numberDecimal
          ? _value.numberDecimal
          : numberDecimal // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SurfaceWeightImpl implements _SurfaceWeight {
  _$SurfaceWeightImpl({this.numberDecimal});

  factory _$SurfaceWeightImpl.fromJson(Map<String, dynamic> json) =>
      _$$SurfaceWeightImplFromJson(json);

  @override
  final String? numberDecimal;

  @override
  String toString() {
    return 'SurfaceWeight(numberDecimal: $numberDecimal)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SurfaceWeightImpl &&
            (identical(other.numberDecimal, numberDecimal) ||
                other.numberDecimal == numberDecimal));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, numberDecimal);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SurfaceWeightImplCopyWith<_$SurfaceWeightImpl> get copyWith =>
      __$$SurfaceWeightImplCopyWithImpl<_$SurfaceWeightImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SurfaceWeightImplToJson(
      this,
    );
  }
}

abstract class _SurfaceWeight implements SurfaceWeight {
  factory _SurfaceWeight({final String? numberDecimal}) = _$SurfaceWeightImpl;

  factory _SurfaceWeight.fromJson(Map<String, dynamic> json) =
      _$SurfaceWeightImpl.fromJson;

  @override
  String? get numberDecimal;
  @override
  @JsonKey(ignore: true)
  _$$SurfaceWeightImplCopyWith<_$SurfaceWeightImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
