// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'recommendation_products_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

RecommendationProductsResModel _$RecommendationProductsResModelFromJson(
    Map<String, dynamic> json) {
  return _RecommendationProductsResModel.fromJson(json);
}

/// @nodoc
mixin _$RecommendationProductsResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<RecommendationData>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RecommendationProductsResModelCopyWith<RecommendationProductsResModel>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RecommendationProductsResModelCopyWith<$Res> {
  factory $RecommendationProductsResModelCopyWith(
          RecommendationProductsResModel value,
          $Res Function(RecommendationProductsResModel) then) =
      _$RecommendationProductsResModelCopyWithImpl<$Res,
          RecommendationProductsResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") List<RecommendationData>? data,
      @JsonKey(name: "metaData") MetaData? metaData});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$RecommendationProductsResModelCopyWithImpl<$Res,
        $Val extends RecommendationProductsResModel>
    implements $RecommendationProductsResModelCopyWith<$Res> {
  _$RecommendationProductsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<RecommendationData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$RecommendationProductsResModelImplCopyWith<$Res>
    implements $RecommendationProductsResModelCopyWith<$Res> {
  factory _$$RecommendationProductsResModelImplCopyWith(
          _$RecommendationProductsResModelImpl value,
          $Res Function(_$RecommendationProductsResModelImpl) then) =
      __$$RecommendationProductsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") List<RecommendationData>? data,
      @JsonKey(name: "metaData") MetaData? metaData});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$RecommendationProductsResModelImplCopyWithImpl<$Res>
    extends _$RecommendationProductsResModelCopyWithImpl<$Res,
        _$RecommendationProductsResModelImpl>
    implements _$$RecommendationProductsResModelImplCopyWith<$Res> {
  __$$RecommendationProductsResModelImplCopyWithImpl(
      _$RecommendationProductsResModelImpl _value,
      $Res Function(_$RecommendationProductsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
  }) {
    return _then(_$RecommendationProductsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<RecommendationData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RecommendationProductsResModelImpl
    implements _RecommendationProductsResModel {
  const _$RecommendationProductsResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message,
      @JsonKey(name: "data") final List<RecommendationData>? data,
      @JsonKey(name: "metaData") this.metaData})
      : _data = data;

  factory _$RecommendationProductsResModelImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$RecommendationProductsResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;
  final List<RecommendationData>? _data;
  @override
  @JsonKey(name: "data")
  List<RecommendationData>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;

  @override
  String toString() {
    return 'RecommendationProductsResModel(status: $status, message: $message, data: $data, metaData: $metaData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RecommendationProductsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message,
      const DeepCollectionEquality().hash(_data), metaData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RecommendationProductsResModelImplCopyWith<
          _$RecommendationProductsResModelImpl>
      get copyWith => __$$RecommendationProductsResModelImplCopyWithImpl<
          _$RecommendationProductsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RecommendationProductsResModelImplToJson(
      this,
    );
  }
}

abstract class _RecommendationProductsResModel
    implements RecommendationProductsResModel {
  const factory _RecommendationProductsResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "message") final String? message,
          @JsonKey(name: "data") final List<RecommendationData>? data,
          @JsonKey(name: "metaData") final MetaData? metaData}) =
      _$RecommendationProductsResModelImpl;

  factory _RecommendationProductsResModel.fromJson(Map<String, dynamic> json) =
      _$RecommendationProductsResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(name: "data")
  List<RecommendationData>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(ignore: true)
  _$$RecommendationProductsResModelImplCopyWith<
          _$RecommendationProductsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

RecommendationData _$RecommendationDataFromJson(Map<String, dynamic> json) {
  return _RecommendationData.fromJson(json);
}

/// @nodoc
mixin _$RecommendationData {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  double? get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "totalSale")
  int? get totalSale => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  double? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;
  int? get numberOfUnit => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RecommendationDataCopyWith<RecommendationData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RecommendationDataCopyWith<$Res> {
  factory $RecommendationDataCopyWith(
          RecommendationData value, $Res Function(RecommendationData) then) =
      _$RecommendationDataCopyWithImpl<$Res, RecommendationData>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productStock") double? productStock,
      @JsonKey(name: "totalSale") int? totalSale,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      int? numberOfUnit,
      String? lowStock});
}

/// @nodoc
class _$RecommendationDataCopyWithImpl<$Res, $Val extends RecommendationData>
    implements $RecommendationDataCopyWith<$Res> {
  _$RecommendationDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? totalSale = freezed,
    Object? productPrice = freezed,
    Object? mainImage = freezed,
    Object? productName = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? numberOfUnit = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RecommendationDataImplCopyWith<$Res>
    implements $RecommendationDataCopyWith<$Res> {
  factory _$$RecommendationDataImplCopyWith(_$RecommendationDataImpl value,
          $Res Function(_$RecommendationDataImpl) then) =
      __$$RecommendationDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productStock") double? productStock,
      @JsonKey(name: "totalSale") int? totalSale,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      int? numberOfUnit,
      String? lowStock});
}

/// @nodoc
class __$$RecommendationDataImplCopyWithImpl<$Res>
    extends _$RecommendationDataCopyWithImpl<$Res, _$RecommendationDataImpl>
    implements _$$RecommendationDataImplCopyWith<$Res> {
  __$$RecommendationDataImplCopyWithImpl(_$RecommendationDataImpl _value,
      $Res Function(_$RecommendationDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? totalSale = freezed,
    Object? productPrice = freezed,
    Object? mainImage = freezed,
    Object? productName = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? numberOfUnit = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_$RecommendationDataImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as double?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RecommendationDataImpl implements _RecommendationData {
  const _$RecommendationDataImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "totalSale") this.totalSale,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim,
      this.numberOfUnit,
      this.lowStock});

  factory _$RecommendationDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$RecommendationDataImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productStock")
  final double? productStock;
  @override
  @JsonKey(name: "totalSale")
  final int? totalSale;
  @override
  @JsonKey(name: "productPrice")
  final double? productPrice;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;
  @override
  final int? numberOfUnit;
  @override
  final String? lowStock;

  @override
  String toString() {
    return 'RecommendationData(id: $id, productStock: $productStock, totalSale: $totalSale, productPrice: $productPrice, mainImage: $mainImage, productName: $productName, isPesach: $isPesach, nmMashlim: $nmMashlim, numberOfUnit: $numberOfUnit, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RecommendationDataImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.totalSale, totalSale) ||
                other.totalSale == totalSale) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      productStock,
      totalSale,
      productPrice,
      mainImage,
      productName,
      isPesach,
      nmMashlim,
      numberOfUnit,
      lowStock);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RecommendationDataImplCopyWith<_$RecommendationDataImpl> get copyWith =>
      __$$RecommendationDataImplCopyWithImpl<_$RecommendationDataImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RecommendationDataImplToJson(
      this,
    );
  }
}

abstract class _RecommendationData implements RecommendationData {
  const factory _RecommendationData(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "productStock") final double? productStock,
      @JsonKey(name: "totalSale") final int? totalSale,
      @JsonKey(name: "productPrice") final double? productPrice,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim") final String? nmMashlim,
      final int? numberOfUnit,
      final String? lowStock}) = _$RecommendationDataImpl;

  factory _RecommendationData.fromJson(Map<String, dynamic> json) =
      _$RecommendationDataImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productStock")
  double? get productStock;
  @override
  @JsonKey(name: "totalSale")
  int? get totalSale;
  @override
  @JsonKey(name: "productPrice")
  double? get productPrice;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  int? get numberOfUnit;
  @override
  String? get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$RecommendationDataImplCopyWith<_$RecommendationDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalFilteredCount") this.totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  final int? totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
          {@JsonKey(name: "currentPage") final int? currentPage,
          @JsonKey(name: "totalFilteredCount") final int? totalFilteredCount,
          @JsonKey(name: "totalFilteredPage") final int? totalFilteredPage}) =
      _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
