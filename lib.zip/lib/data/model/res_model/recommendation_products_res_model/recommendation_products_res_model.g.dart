// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'recommendation_products_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RecommendationProductsResModelImpl
    _$$RecommendationProductsResModelImplFromJson(Map<String, dynamic> json) =>
        _$RecommendationProductsResModelImpl(
          status: json['status'] as int?,
          message: json['message'] as String?,
          data: (json['data'] as List<dynamic>?)
              ?.map(
                  (e) => RecommendationData.fromJson(e as Map<String, dynamic>))
              .toList(),
          metaData: json['metaData'] == null
              ? null
              : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
        );

Map<String, dynamic> _$$RecommendationProductsResModelImplToJson(
        _$RecommendationProductsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
      'metaData': instance.metaData,
    };

_$RecommendationDataImpl _$$RecommendationDataImplFromJson(
        Map<String, dynamic> json) =>
    _$RecommendationDataImpl(
      id: json['_id'] as String?,
      productStock: (json['productStock'] as num?)?.toDouble(),
      totalSale: json['totalSale'] as int?,
      productPrice: (json['productPrice'] as num?)?.toDouble(),
      mainImage: json['mainImage'] as String?,
      productName: json['productName'] as String?,
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
      numberOfUnit: json['numberOfUnit'] as int?,
      lowStock: json['lowStock'] as String?,
    );

Map<String, dynamic> _$$RecommendationDataImplToJson(
        _$RecommendationDataImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productStock': instance.productStock,
      'totalSale': instance.totalSale,
      'productPrice': instance.productPrice,
      'mainImage': instance.mainImage,
      'productName': instance.productName,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
      'numberOfUnit': instance.numberOfUnit,
      'lowStock': instance.lowStock,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
