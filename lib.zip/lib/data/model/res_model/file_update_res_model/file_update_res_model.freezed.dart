// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'file_update_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

FileUpdateResModel _$FileUpdateResModelFromJson(Map<String, dynamic> json) {
  return _FileUpdateResModel.fromJson(json);
}

/// @nodoc
mixin _$FileUpdateResModel {
  int? get status => throw _privateConstructorUsedError;
  Data? get data => throw _privateConstructorUsedError;
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $FileUpdateResModelCopyWith<FileUpdateResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FileUpdateResModelCopyWith<$Res> {
  factory $FileUpdateResModelCopyWith(
          FileUpdateResModel value, $Res Function(FileUpdateResModel) then) =
      _$FileUpdateResModelCopyWithImpl<$Res, FileUpdateResModel>;
  @useResult
  $Res call({int? status, Data? data, String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$FileUpdateResModelCopyWithImpl<$Res, $Val extends FileUpdateResModel>
    implements $FileUpdateResModelCopyWith<$Res> {
  _$FileUpdateResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$FileUpdateResModelImplCopyWith<$Res>
    implements $FileUpdateResModelCopyWith<$Res> {
  factory _$$FileUpdateResModelImplCopyWith(_$FileUpdateResModelImpl value,
          $Res Function(_$FileUpdateResModelImpl) then) =
      __$$FileUpdateResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int? status, Data? data, String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$FileUpdateResModelImplCopyWithImpl<$Res>
    extends _$FileUpdateResModelCopyWithImpl<$Res, _$FileUpdateResModelImpl>
    implements _$$FileUpdateResModelImplCopyWith<$Res> {
  __$$FileUpdateResModelImplCopyWithImpl(_$FileUpdateResModelImpl _value,
      $Res Function(_$FileUpdateResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$FileUpdateResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$FileUpdateResModelImpl implements _FileUpdateResModel {
  const _$FileUpdateResModelImpl({this.status, this.data, this.message});

  factory _$FileUpdateResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$FileUpdateResModelImplFromJson(json);

  @override
  final int? status;
  @override
  final Data? data;
  @override
  final String? message;

  @override
  String toString() {
    return 'FileUpdateResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FileUpdateResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FileUpdateResModelImplCopyWith<_$FileUpdateResModelImpl> get copyWith =>
      __$$FileUpdateResModelImplCopyWithImpl<_$FileUpdateResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$FileUpdateResModelImplToJson(
      this,
    );
  }
}

abstract class _FileUpdateResModel implements FileUpdateResModel {
  const factory _FileUpdateResModel(
      {final int? status,
      final Data? data,
      final String? message}) = _$FileUpdateResModelImpl;

  factory _FileUpdateResModel.fromJson(Map<String, dynamic> json) =
      _$FileUpdateResModelImpl.fromJson;

  @override
  int? get status;
  @override
  Data? get data;
  @override
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$FileUpdateResModelImplCopyWith<_$FileUpdateResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "client")
  Client? get client => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call({@JsonKey(name: "client") Client? client});

  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? client = freezed,
  }) {
    return _then(_value.copyWith(
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientCopyWith<$Res>? get client {
    if (_value.client == null) {
      return null;
    }

    return $ClientCopyWith<$Res>(_value.client!, (value) {
      return _then(_value.copyWith(client: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({@JsonKey(name: "client") Client? client});

  @override
  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? client = freezed,
  }) {
    return _then(_$DataImpl(
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl({@JsonKey(name: "client") this.client});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  @JsonKey(name: "client")
  final Client? client;

  @override
  String toString() {
    return 'Data(client: $client)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.client, client) || other.client == client));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, client);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data({@JsonKey(name: "client") final Client? client}) =
      _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "client")
  Client? get client;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Client _$ClientFromJson(Map<String, dynamic> json) {
  return _Client.fromJson(json);
}

/// @nodoc
mixin _$Client {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "password")
  dynamic get password => throw _privateConstructorUsedError;
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "address")
  String? get address => throw _privateConstructorUsedError;
  @JsonKey(name: "cityId")
  String? get cityId => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;
  @JsonKey(name: "statusId")
  String? get statusId => throw _privateConstructorUsedError;
  @JsonKey(name: "logo")
  String? get logo => throw _privateConstructorUsedError;
  @JsonKey(name: "profileImage")
  String? get profileImage => throw _privateConstructorUsedError;
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientCopyWith<Client> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientCopyWith<$Res> {
  factory $ClientCopyWith(Client value, $Res Function(Client) then) =
      _$ClientCopyWithImpl<$Res, Client>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "password") dynamic password,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});

  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class _$ClientCopyWithImpl<$Res, $Val extends Client>
    implements $ClientCopyWith<$Res> {
  _$ClientCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as dynamic,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientDetailCopyWith<$Res>? get clientDetail {
    if (_value.clientDetail == null) {
      return null;
    }

    return $ClientDetailCopyWith<$Res>(_value.clientDetail!, (value) {
      return _then(_value.copyWith(clientDetail: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ClientImplCopyWith<$Res> implements $ClientCopyWith<$Res> {
  factory _$$ClientImplCopyWith(
          _$ClientImpl value, $Res Function(_$ClientImpl) then) =
      __$$ClientImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "password") dynamic password,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});

  @override
  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class __$$ClientImplCopyWithImpl<$Res>
    extends _$ClientCopyWithImpl<$Res, _$ClientImpl>
    implements _$$ClientImplCopyWith<$Res> {
  __$$ClientImplCopyWithImpl(
      _$ClientImpl _value, $Res Function(_$ClientImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$ClientImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as dynamic,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientImpl implements _Client {
  const _$ClientImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "email") this.email,
      @JsonKey(name: "password") this.password,
      @JsonKey(name: "phoneNumber") this.phoneNumber,
      @JsonKey(name: "address") this.address,
      @JsonKey(name: "cityId") this.cityId,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "statusId") this.statusId,
      @JsonKey(name: "logo") this.logo,
      @JsonKey(name: "profileImage") this.profileImage,
      @JsonKey(name: "adminTypeId") this.adminTypeId,
      @JsonKey(name: "clientDetail") this.clientDetail,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$ClientImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "password")
  final dynamic password;
  @override
  @JsonKey(name: "phoneNumber")
  final String? phoneNumber;
  @override
  @JsonKey(name: "address")
  final String? address;
  @override
  @JsonKey(name: "cityId")
  final String? cityId;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
  @override
  @JsonKey(name: "statusId")
  final String? statusId;
  @override
  @JsonKey(name: "logo")
  final String? logo;
  @override
  @JsonKey(name: "profileImage")
  final String? profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  final String? adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  final ClientDetail? clientDetail;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Client(id: $id, email: $email, password: $password, phoneNumber: $phoneNumber, address: $address, cityId: $cityId, contactName: $contactName, statusId: $statusId, logo: $logo, profileImage: $profileImage, adminTypeId: $adminTypeId, clientDetail: $clientDetail, createdBy: $createdBy, updatedBy: $updatedBy, isDeleted: $isDeleted, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.email, email) || other.email == email) &&
            const DeepCollectionEquality().equals(other.password, password) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.cityId, cityId) || other.cityId == cityId) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.statusId, statusId) ||
                other.statusId == statusId) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.profileImage, profileImage) ||
                other.profileImage == profileImage) &&
            (identical(other.adminTypeId, adminTypeId) ||
                other.adminTypeId == adminTypeId) &&
            (identical(other.clientDetail, clientDetail) ||
                other.clientDetail == clientDetail) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      email,
      const DeepCollectionEquality().hash(password),
      phoneNumber,
      address,
      cityId,
      contactName,
      statusId,
      logo,
      profileImage,
      adminTypeId,
      clientDetail,
      createdBy,
      updatedBy,
      isDeleted,
      createdAt,
      updatedAt,
      v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      __$$ClientImplCopyWithImpl<_$ClientImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientImplToJson(
      this,
    );
  }
}

abstract class _Client implements Client {
  const factory _Client(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "email") final String? email,
      @JsonKey(name: "password") final dynamic password,
      @JsonKey(name: "phoneNumber") final String? phoneNumber,
      @JsonKey(name: "address") final String? address,
      @JsonKey(name: "cityId") final String? cityId,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "statusId") final String? statusId,
      @JsonKey(name: "logo") final String? logo,
      @JsonKey(name: "profileImage") final String? profileImage,
      @JsonKey(name: "adminTypeId") final String? adminTypeId,
      @JsonKey(name: "clientDetail") final ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$ClientImpl;

  factory _Client.fromJson(Map<String, dynamic> json) = _$ClientImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "password")
  dynamic get password;
  @override
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber;
  @override
  @JsonKey(name: "address")
  String? get address;
  @override
  @JsonKey(name: "cityId")
  String? get cityId;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(name: "statusId")
  String? get statusId;
  @override
  @JsonKey(name: "logo")
  String? get logo;
  @override
  @JsonKey(name: "profileImage")
  String? get profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientDetail _$ClientDetailFromJson(Map<String, dynamic> json) {
  return _ClientDetail.fromJson(json);
}

/// @nodoc
mixin _$ClientDetail {
  @JsonKey(name: "bussinessId")
  int? get bussinessId => throw _privateConstructorUsedError;
  @JsonKey(name: "bussinessName")
  String? get bussinessName => throw _privateConstructorUsedError;
  @JsonKey(name: "ownerName")
  String? get ownerName => throw _privateConstructorUsedError;
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "israelId")
  String? get israelId => throw _privateConstructorUsedError;
  @JsonKey(name: "tokenId")
  String? get tokenId => throw _privateConstructorUsedError;
  @JsonKey(name: "fax")
  String? get fax => throw _privateConstructorUsedError;
  @JsonKey(name: "lastSeen")
  DateTime? get lastSeen => throw _privateConstructorUsedError;
  @JsonKey(name: "monthlyCredits")
  int? get monthlyCredits => throw _privateConstructorUsedError;
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion => throw _privateConstructorUsedError;
  @JsonKey(name: "deviceType")
  String? get deviceType => throw _privateConstructorUsedError;
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientDetailCopyWith<ClientDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientDetailCopyWith<$Res> {
  factory $ClientDetailCopyWith(
          ClientDetail value, $Res Function(ClientDetail) then) =
      _$ClientDetailCopyWithImpl<$Res, ClientDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "lastSeen") DateTime? lastSeen,
      @JsonKey(name: "monthlyCredits") int? monthlyCredits,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<OperationTime>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt});
}

/// @nodoc
class _$ClientDetailCopyWithImpl<$Res, $Val extends ClientDetail>
    implements $ClientDetailCopyWith<$Res> {
  _$ClientDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_value.copyWith(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as int?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value.operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientDetailImplCopyWith<$Res>
    implements $ClientDetailCopyWith<$Res> {
  factory _$$ClientDetailImplCopyWith(
          _$ClientDetailImpl value, $Res Function(_$ClientDetailImpl) then) =
      __$$ClientDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "lastSeen") DateTime? lastSeen,
      @JsonKey(name: "monthlyCredits") int? monthlyCredits,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<OperationTime>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt});
}

/// @nodoc
class __$$ClientDetailImplCopyWithImpl<$Res>
    extends _$ClientDetailCopyWithImpl<$Res, _$ClientDetailImpl>
    implements _$$ClientDetailImplCopyWith<$Res> {
  __$$ClientDetailImplCopyWithImpl(
      _$ClientDetailImpl _value, $Res Function(_$ClientDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_$ClientDetailImpl(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as int?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value._operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientDetailImpl implements _ClientDetail {
  const _$ClientDetailImpl(
      {@JsonKey(name: "bussinessId") this.bussinessId,
      @JsonKey(name: "bussinessName") this.bussinessName,
      @JsonKey(name: "ownerName") this.ownerName,
      @JsonKey(name: "clientTypeId") this.clientTypeId,
      @JsonKey(name: "israelId") this.israelId,
      @JsonKey(name: "tokenId") this.tokenId,
      @JsonKey(name: "fax") this.fax,
      @JsonKey(name: "lastSeen") this.lastSeen,
      @JsonKey(name: "monthlyCredits") this.monthlyCredits,
      @JsonKey(name: "applicationVersion") this.applicationVersion,
      @JsonKey(name: "deviceType") this.deviceType,
      @JsonKey(name: "operationTime") final List<OperationTime>? operationTime,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt})
      : _operationTime = operationTime;

  factory _$ClientDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientDetailImplFromJson(json);

  @override
  @JsonKey(name: "bussinessId")
  final int? bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  final String? bussinessName;
  @override
  @JsonKey(name: "ownerName")
  final String? ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  final String? clientTypeId;
  @override
  @JsonKey(name: "israelId")
  final String? israelId;
  @override
  @JsonKey(name: "tokenId")
  final String? tokenId;
  @override
  @JsonKey(name: "fax")
  final String? fax;
  @override
  @JsonKey(name: "lastSeen")
  final DateTime? lastSeen;
  @override
  @JsonKey(name: "monthlyCredits")
  final int? monthlyCredits;
  @override
  @JsonKey(name: "applicationVersion")
  final String? applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  final String? deviceType;
  final List<OperationTime>? _operationTime;
  @override
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime {
    final value = _operationTime;
    if (value == null) return null;
    if (_operationTime is EqualUnmodifiableListView) return _operationTime;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;

  @override
  String toString() {
    return 'ClientDetail(bussinessId: $bussinessId, bussinessName: $bussinessName, ownerName: $ownerName, clientTypeId: $clientTypeId, israelId: $israelId, tokenId: $tokenId, fax: $fax, lastSeen: $lastSeen, monthlyCredits: $monthlyCredits, applicationVersion: $applicationVersion, deviceType: $deviceType, operationTime: $operationTime, id: $id, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientDetailImpl &&
            (identical(other.bussinessId, bussinessId) ||
                other.bussinessId == bussinessId) &&
            (identical(other.bussinessName, bussinessName) ||
                other.bussinessName == bussinessName) &&
            (identical(other.ownerName, ownerName) ||
                other.ownerName == ownerName) &&
            (identical(other.clientTypeId, clientTypeId) ||
                other.clientTypeId == clientTypeId) &&
            (identical(other.israelId, israelId) ||
                other.israelId == israelId) &&
            (identical(other.tokenId, tokenId) || other.tokenId == tokenId) &&
            (identical(other.fax, fax) || other.fax == fax) &&
            (identical(other.lastSeen, lastSeen) ||
                other.lastSeen == lastSeen) &&
            (identical(other.monthlyCredits, monthlyCredits) ||
                other.monthlyCredits == monthlyCredits) &&
            (identical(other.applicationVersion, applicationVersion) ||
                other.applicationVersion == applicationVersion) &&
            (identical(other.deviceType, deviceType) ||
                other.deviceType == deviceType) &&
            const DeepCollectionEquality()
                .equals(other._operationTime, _operationTime) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      bussinessId,
      bussinessName,
      ownerName,
      clientTypeId,
      israelId,
      tokenId,
      fax,
      lastSeen,
      monthlyCredits,
      applicationVersion,
      deviceType,
      const DeepCollectionEquality().hash(_operationTime),
      id,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      __$$ClientDetailImplCopyWithImpl<_$ClientDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientDetailImplToJson(
      this,
    );
  }
}

abstract class _ClientDetail implements ClientDetail {
  const factory _ClientDetail(
      {@JsonKey(name: "bussinessId") final int? bussinessId,
      @JsonKey(name: "bussinessName") final String? bussinessName,
      @JsonKey(name: "ownerName") final String? ownerName,
      @JsonKey(name: "clientTypeId") final String? clientTypeId,
      @JsonKey(name: "israelId") final String? israelId,
      @JsonKey(name: "tokenId") final String? tokenId,
      @JsonKey(name: "fax") final String? fax,
      @JsonKey(name: "lastSeen") final DateTime? lastSeen,
      @JsonKey(name: "monthlyCredits") final int? monthlyCredits,
      @JsonKey(name: "applicationVersion") final String? applicationVersion,
      @JsonKey(name: "deviceType") final String? deviceType,
      @JsonKey(name: "operationTime") final List<OperationTime>? operationTime,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt")
      final DateTime? updatedAt}) = _$ClientDetailImpl;

  factory _ClientDetail.fromJson(Map<String, dynamic> json) =
      _$ClientDetailImpl.fromJson;

  @override
  @JsonKey(name: "bussinessId")
  int? get bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  String? get bussinessName;
  @override
  @JsonKey(name: "ownerName")
  String? get ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId;
  @override
  @JsonKey(name: "israelId")
  String? get israelId;
  @override
  @JsonKey(name: "tokenId")
  String? get tokenId;
  @override
  @JsonKey(name: "fax")
  String? get fax;
  @override
  @JsonKey(name: "lastSeen")
  DateTime? get lastSeen;
  @override
  @JsonKey(name: "monthlyCredits")
  int? get monthlyCredits;
  @override
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  String? get deviceType;
  @override
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

OperationTime _$OperationTimeFromJson(Map<String, dynamic> json) {
  return _OperationTime.fromJson(json);
}

/// @nodoc
mixin _$OperationTime {
  @JsonKey(name: "Monday")
  dynamic get monday => throw _privateConstructorUsedError;
  @JsonKey(name: "Tuesday")
  dynamic get tuesday => throw _privateConstructorUsedError;
  @JsonKey(name: "Wednesday")
  dynamic get wednesday => throw _privateConstructorUsedError;
  @JsonKey(name: "Thursday")
  dynamic get thursday => throw _privateConstructorUsedError;
  @JsonKey(name: "Friday")
  dynamic get fridayAndHolidayEves => throw _privateConstructorUsedError;
  @JsonKey(name: "Saturday")
  dynamic get saturdayAndHolidays => throw _privateConstructorUsedError;
  @JsonKey(name: "Sunday")
  dynamic get sunday => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $OperationTimeCopyWith<OperationTime> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OperationTimeCopyWith<$Res> {
  factory $OperationTimeCopyWith(
          OperationTime value, $Res Function(OperationTime) then) =
      _$OperationTimeCopyWithImpl<$Res, OperationTime>;
  @useResult
  $Res call(
      {@JsonKey(name: "Monday") dynamic monday,
      @JsonKey(name: "Tuesday") dynamic tuesday,
      @JsonKey(name: "Wednesday") dynamic wednesday,
      @JsonKey(name: "Thursday") dynamic thursday,
      @JsonKey(name: "Friday") dynamic fridayAndHolidayEves,
      @JsonKey(name: "Saturday") dynamic saturdayAndHolidays,
      @JsonKey(name: "Sunday") dynamic sunday});
}

/// @nodoc
class _$OperationTimeCopyWithImpl<$Res, $Val extends OperationTime>
    implements $OperationTimeCopyWith<$Res> {
  _$OperationTimeCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? monday = freezed,
    Object? tuesday = freezed,
    Object? wednesday = freezed,
    Object? thursday = freezed,
    Object? fridayAndHolidayEves = freezed,
    Object? saturdayAndHolidays = freezed,
    Object? sunday = freezed,
  }) {
    return _then(_value.copyWith(
      monday: freezed == monday
          ? _value.monday
          : monday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      tuesday: freezed == tuesday
          ? _value.tuesday
          : tuesday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      wednesday: freezed == wednesday
          ? _value.wednesday
          : wednesday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      thursday: freezed == thursday
          ? _value.thursday
          : thursday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      fridayAndHolidayEves: freezed == fridayAndHolidayEves
          ? _value.fridayAndHolidayEves
          : fridayAndHolidayEves // ignore: cast_nullable_to_non_nullable
              as dynamic,
      saturdayAndHolidays: freezed == saturdayAndHolidays
          ? _value.saturdayAndHolidays
          : saturdayAndHolidays // ignore: cast_nullable_to_non_nullable
              as dynamic,
      sunday: freezed == sunday
          ? _value.sunday
          : sunday // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$OperationTimeImplCopyWith<$Res>
    implements $OperationTimeCopyWith<$Res> {
  factory _$$OperationTimeImplCopyWith(
          _$OperationTimeImpl value, $Res Function(_$OperationTimeImpl) then) =
      __$$OperationTimeImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "Monday") dynamic monday,
      @JsonKey(name: "Tuesday") dynamic tuesday,
      @JsonKey(name: "Wednesday") dynamic wednesday,
      @JsonKey(name: "Thursday") dynamic thursday,
      @JsonKey(name: "Friday") dynamic fridayAndHolidayEves,
      @JsonKey(name: "Saturday") dynamic saturdayAndHolidays,
      @JsonKey(name: "Sunday") dynamic sunday});
}

/// @nodoc
class __$$OperationTimeImplCopyWithImpl<$Res>
    extends _$OperationTimeCopyWithImpl<$Res, _$OperationTimeImpl>
    implements _$$OperationTimeImplCopyWith<$Res> {
  __$$OperationTimeImplCopyWithImpl(
      _$OperationTimeImpl _value, $Res Function(_$OperationTimeImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? monday = freezed,
    Object? tuesday = freezed,
    Object? wednesday = freezed,
    Object? thursday = freezed,
    Object? fridayAndHolidayEves = freezed,
    Object? saturdayAndHolidays = freezed,
    Object? sunday = freezed,
  }) {
    return _then(_$OperationTimeImpl(
      monday: freezed == monday
          ? _value.monday
          : monday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      tuesday: freezed == tuesday
          ? _value.tuesday
          : tuesday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      wednesday: freezed == wednesday
          ? _value.wednesday
          : wednesday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      thursday: freezed == thursday
          ? _value.thursday
          : thursday // ignore: cast_nullable_to_non_nullable
              as dynamic,
      fridayAndHolidayEves: freezed == fridayAndHolidayEves
          ? _value.fridayAndHolidayEves
          : fridayAndHolidayEves // ignore: cast_nullable_to_non_nullable
              as dynamic,
      saturdayAndHolidays: freezed == saturdayAndHolidays
          ? _value.saturdayAndHolidays
          : saturdayAndHolidays // ignore: cast_nullable_to_non_nullable
              as dynamic,
      sunday: freezed == sunday
          ? _value.sunday
          : sunday // ignore: cast_nullable_to_non_nullable
              as dynamic,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$OperationTimeImpl implements _OperationTime {
  const _$OperationTimeImpl(
      {@JsonKey(name: "Monday") this.monday,
      @JsonKey(name: "Tuesday") this.tuesday,
      @JsonKey(name: "Wednesday") this.wednesday,
      @JsonKey(name: "Thursday") this.thursday,
      @JsonKey(name: "Friday") this.fridayAndHolidayEves,
      @JsonKey(name: "Saturday") this.saturdayAndHolidays,
      @JsonKey(name: "Sunday") this.sunday});

  factory _$OperationTimeImpl.fromJson(Map<String, dynamic> json) =>
      _$$OperationTimeImplFromJson(json);

  @override
  @JsonKey(name: "Monday")
  final dynamic monday;
  @override
  @JsonKey(name: "Tuesday")
  final dynamic tuesday;
  @override
  @JsonKey(name: "Wednesday")
  final dynamic wednesday;
  @override
  @JsonKey(name: "Thursday")
  final dynamic thursday;
  @override
  @JsonKey(name: "Friday")
  final dynamic fridayAndHolidayEves;
  @override
  @JsonKey(name: "Saturday")
  final dynamic saturdayAndHolidays;
  @override
  @JsonKey(name: "Sunday")
  final dynamic sunday;

  @override
  String toString() {
    return 'OperationTime(monday: $monday, tuesday: $tuesday, wednesday: $wednesday, thursday: $thursday, fridayAndHolidayEves: $fridayAndHolidayEves, saturdayAndHolidays: $saturdayAndHolidays, sunday: $sunday)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OperationTimeImpl &&
            const DeepCollectionEquality().equals(other.monday, monday) &&
            const DeepCollectionEquality().equals(other.tuesday, tuesday) &&
            const DeepCollectionEquality().equals(other.wednesday, wednesday) &&
            const DeepCollectionEquality().equals(other.thursday, thursday) &&
            const DeepCollectionEquality()
                .equals(other.fridayAndHolidayEves, fridayAndHolidayEves) &&
            const DeepCollectionEquality()
                .equals(other.saturdayAndHolidays, saturdayAndHolidays) &&
            const DeepCollectionEquality().equals(other.sunday, sunday));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(monday),
      const DeepCollectionEquality().hash(tuesday),
      const DeepCollectionEquality().hash(wednesday),
      const DeepCollectionEquality().hash(thursday),
      const DeepCollectionEquality().hash(fridayAndHolidayEves),
      const DeepCollectionEquality().hash(saturdayAndHolidays),
      const DeepCollectionEquality().hash(sunday));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OperationTimeImplCopyWith<_$OperationTimeImpl> get copyWith =>
      __$$OperationTimeImplCopyWithImpl<_$OperationTimeImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$OperationTimeImplToJson(
      this,
    );
  }
}

abstract class _OperationTime implements OperationTime {
  const factory _OperationTime(
      {@JsonKey(name: "Monday") final dynamic monday,
      @JsonKey(name: "Tuesday") final dynamic tuesday,
      @JsonKey(name: "Wednesday") final dynamic wednesday,
      @JsonKey(name: "Thursday") final dynamic thursday,
      @JsonKey(name: "Friday") final dynamic fridayAndHolidayEves,
      @JsonKey(name: "Saturday") final dynamic saturdayAndHolidays,
      @JsonKey(name: "Sunday") final dynamic sunday}) = _$OperationTimeImpl;

  factory _OperationTime.fromJson(Map<String, dynamic> json) =
      _$OperationTimeImpl.fromJson;

  @override
  @JsonKey(name: "Monday")
  dynamic get monday;
  @override
  @JsonKey(name: "Tuesday")
  dynamic get tuesday;
  @override
  @JsonKey(name: "Wednesday")
  dynamic get wednesday;
  @override
  @JsonKey(name: "Thursday")
  dynamic get thursday;
  @override
  @JsonKey(name: "Friday")
  dynamic get fridayAndHolidayEves;
  @override
  @JsonKey(name: "Saturday")
  dynamic get saturdayAndHolidays;
  @override
  @JsonKey(name: "Sunday")
  dynamic get sunday;
  @override
  @JsonKey(ignore: true)
  _$$OperationTimeImplCopyWith<_$OperationTimeImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
