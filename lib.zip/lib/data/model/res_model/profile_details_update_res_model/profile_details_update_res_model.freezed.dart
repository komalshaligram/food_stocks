// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_details_update_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProfileDetailsUpdateResModel _$ProfileDetailsUpdateResModelFromJson(
    Map<String, dynamic> json) {
  return _ProfileDetailsUpdateResModel.fromJson(json);
}

/// @nodoc
mixin _$ProfileDetailsUpdateResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfileDetailsUpdateResModelCopyWith<ProfileDetailsUpdateResModel>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileDetailsUpdateResModelCopyWith<$Res> {
  factory $ProfileDetailsUpdateResModelCopyWith(
          ProfileDetailsUpdateResModel value,
          $Res Function(ProfileDetailsUpdateResModel) then) =
      _$ProfileDetailsUpdateResModelCopyWithImpl<$Res,
          ProfileDetailsUpdateResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$ProfileDetailsUpdateResModelCopyWithImpl<$Res,
        $Val extends ProfileDetailsUpdateResModel>
    implements $ProfileDetailsUpdateResModelCopyWith<$Res> {
  _$ProfileDetailsUpdateResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProfileDetailsUpdateResModelImplCopyWith<$Res>
    implements $ProfileDetailsUpdateResModelCopyWith<$Res> {
  factory _$$ProfileDetailsUpdateResModelImplCopyWith(
          _$ProfileDetailsUpdateResModelImpl value,
          $Res Function(_$ProfileDetailsUpdateResModelImpl) then) =
      __$$ProfileDetailsUpdateResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$ProfileDetailsUpdateResModelImplCopyWithImpl<$Res>
    extends _$ProfileDetailsUpdateResModelCopyWithImpl<$Res,
        _$ProfileDetailsUpdateResModelImpl>
    implements _$$ProfileDetailsUpdateResModelImplCopyWith<$Res> {
  __$$ProfileDetailsUpdateResModelImplCopyWithImpl(
      _$ProfileDetailsUpdateResModelImpl _value,
      $Res Function(_$ProfileDetailsUpdateResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$ProfileDetailsUpdateResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileDetailsUpdateResModelImpl
    implements _ProfileDetailsUpdateResModel {
  const _$ProfileDetailsUpdateResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$ProfileDetailsUpdateResModelImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$ProfileDetailsUpdateResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'ProfileDetailsUpdateResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileDetailsUpdateResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileDetailsUpdateResModelImplCopyWith<
          _$ProfileDetailsUpdateResModelImpl>
      get copyWith => __$$ProfileDetailsUpdateResModelImplCopyWithImpl<
          _$ProfileDetailsUpdateResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileDetailsUpdateResModelImplToJson(
      this,
    );
  }
}

abstract class _ProfileDetailsUpdateResModel
    implements ProfileDetailsUpdateResModel {
  const factory _ProfileDetailsUpdateResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final Data? data,
          @JsonKey(name: "message") final String? message}) =
      _$ProfileDetailsUpdateResModelImpl;

  factory _ProfileDetailsUpdateResModel.fromJson(Map<String, dynamic> json) =
      _$ProfileDetailsUpdateResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$ProfileDetailsUpdateResModelImplCopyWith<
          _$ProfileDetailsUpdateResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "client")
  Client? get client => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call({@JsonKey(name: "client") Client? client});

  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? client = freezed,
  }) {
    return _then(_value.copyWith(
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientCopyWith<$Res>? get client {
    if (_value.client == null) {
      return null;
    }

    return $ClientCopyWith<$Res>(_value.client!, (value) {
      return _then(_value.copyWith(client: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({@JsonKey(name: "client") Client? client});

  @override
  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? client = freezed,
  }) {
    return _then(_$DataImpl(
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl({@JsonKey(name: "client") this.client});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  @JsonKey(name: "client")
  final Client? client;

  @override
  String toString() {
    return 'Data(client: $client)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.client, client) || other.client == client));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, client);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data({@JsonKey(name: "client") final Client? client}) =
      _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "client")
  Client? get client;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Client _$ClientFromJson(Map<String, dynamic> json) {
  return _Client.fromJson(json);
}

/// @nodoc
mixin _$Client {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "address")
  String? get address => throw _privateConstructorUsedError;
  @JsonKey(name: "cityId")
  String? get cityId => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;
  @JsonKey(name: "statusId")
  String? get statusId => throw _privateConstructorUsedError;
  @JsonKey(name: "logo")
  String? get logo => throw _privateConstructorUsedError;
  @JsonKey(name: "profileImage")
  String? get profileImage => throw _privateConstructorUsedError;
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientCopyWith<Client> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientCopyWith<$Res> {
  factory $ClientCopyWith(Client value, $Res Function(Client) then) =
      _$ClientCopyWithImpl<$Res, Client>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});

  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class _$ClientCopyWithImpl<$Res, $Val extends Client>
    implements $ClientCopyWith<$Res> {
  _$ClientCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientDetailCopyWith<$Res>? get clientDetail {
    if (_value.clientDetail == null) {
      return null;
    }

    return $ClientDetailCopyWith<$Res>(_value.clientDetail!, (value) {
      return _then(_value.copyWith(clientDetail: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ClientImplCopyWith<$Res> implements $ClientCopyWith<$Res> {
  factory _$$ClientImplCopyWith(
          _$ClientImpl value, $Res Function(_$ClientImpl) then) =
      __$$ClientImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "address") String? address,
      @JsonKey(name: "cityId") String? cityId,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "statusId") String? statusId,
      @JsonKey(name: "logo") String? logo,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "adminTypeId") String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});

  @override
  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class __$$ClientImplCopyWithImpl<$Res>
    extends _$ClientCopyWithImpl<$Res, _$ClientImpl>
    implements _$$ClientImplCopyWith<$Res> {
  __$$ClientImplCopyWithImpl(
      _$ClientImpl _value, $Res Function(_$ClientImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? email = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? profileImage = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$ClientImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientImpl implements _Client {
  const _$ClientImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "email") this.email,
      @JsonKey(name: "phoneNumber") this.phoneNumber,
      @JsonKey(name: "address") this.address,
      @JsonKey(name: "cityId") this.cityId,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "statusId") this.statusId,
      @JsonKey(name: "logo") this.logo,
      @JsonKey(name: "profileImage") this.profileImage,
      @JsonKey(name: "adminTypeId") this.adminTypeId,
      @JsonKey(name: "clientDetail") this.clientDetail,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$ClientImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "phoneNumber")
  final String? phoneNumber;
  @override
  @JsonKey(name: "address")
  final String? address;
  @override
  @JsonKey(name: "cityId")
  final String? cityId;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
  @override
  @JsonKey(name: "statusId")
  final String? statusId;
  @override
  @JsonKey(name: "logo")
  final String? logo;
  @override
  @JsonKey(name: "profileImage")
  final String? profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  final String? adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  final ClientDetail? clientDetail;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Client(id: $id, email: $email, phoneNumber: $phoneNumber, address: $address, cityId: $cityId, contactName: $contactName, statusId: $statusId, logo: $logo, profileImage: $profileImage, adminTypeId: $adminTypeId, clientDetail: $clientDetail, createdBy: $createdBy, updatedBy: $updatedBy, isDeleted: $isDeleted, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.cityId, cityId) || other.cityId == cityId) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.statusId, statusId) ||
                other.statusId == statusId) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.profileImage, profileImage) ||
                other.profileImage == profileImage) &&
            (identical(other.adminTypeId, adminTypeId) ||
                other.adminTypeId == adminTypeId) &&
            (identical(other.clientDetail, clientDetail) ||
                other.clientDetail == clientDetail) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      email,
      phoneNumber,
      address,
      cityId,
      contactName,
      statusId,
      logo,
      profileImage,
      adminTypeId,
      clientDetail,
      createdBy,
      updatedBy,
      isDeleted,
      createdAt,
      updatedAt,
      v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      __$$ClientImplCopyWithImpl<_$ClientImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientImplToJson(
      this,
    );
  }
}

abstract class _Client implements Client {
  const factory _Client(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "email") final String? email,
      @JsonKey(name: "phoneNumber") final String? phoneNumber,
      @JsonKey(name: "address") final String? address,
      @JsonKey(name: "cityId") final String? cityId,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "statusId") final String? statusId,
      @JsonKey(name: "logo") final String? logo,
      @JsonKey(name: "profileImage") final String? profileImage,
      @JsonKey(name: "adminTypeId") final String? adminTypeId,
      @JsonKey(name: "clientDetail") final ClientDetail? clientDetail,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$ClientImpl;

  factory _Client.fromJson(Map<String, dynamic> json) = _$ClientImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber;
  @override
  @JsonKey(name: "address")
  String? get address;
  @override
  @JsonKey(name: "cityId")
  String? get cityId;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(name: "statusId")
  String? get statusId;
  @override
  @JsonKey(name: "logo")
  String? get logo;
  @override
  @JsonKey(name: "profileImage")
  String? get profileImage;
  @override
  @JsonKey(name: "adminTypeId")
  String? get adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientDetail _$ClientDetailFromJson(Map<String, dynamic> json) {
  return _ClientDetail.fromJson(json);
}

/// @nodoc
mixin _$ClientDetail {
  @JsonKey(name: "bussinessId")
  int? get bussinessId => throw _privateConstructorUsedError;
  @JsonKey(name: "bussinessName")
  String? get bussinessName => throw _privateConstructorUsedError;
  @JsonKey(name: "ownerName")
  String? get ownerName => throw _privateConstructorUsedError;
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "israelId")
  String? get israelId => throw _privateConstructorUsedError;
  @JsonKey(name: "tokenId")
  String? get tokenId => throw _privateConstructorUsedError;
  @JsonKey(name: "fax")
  String? get fax => throw _privateConstructorUsedError;
  @JsonKey(name: "lastSeen")
  DateTime? get lastSeen => throw _privateConstructorUsedError;
  @JsonKey(name: "monthlyCredits")
  int? get monthlyCredits => throw _privateConstructorUsedError;
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion => throw _privateConstructorUsedError;
  @JsonKey(name: "deviceType")
  String? get deviceType => throw _privateConstructorUsedError;
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientDetailCopyWith<ClientDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientDetailCopyWith<$Res> {
  factory $ClientDetailCopyWith(
          ClientDetail value, $Res Function(ClientDetail) then) =
      _$ClientDetailCopyWithImpl<$Res, ClientDetail>;
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "lastSeen") DateTime? lastSeen,
      @JsonKey(name: "monthlyCredits") int? monthlyCredits,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<OperationTime>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt});
}

/// @nodoc
class _$ClientDetailCopyWithImpl<$Res, $Val extends ClientDetail>
    implements $ClientDetailCopyWith<$Res> {
  _$ClientDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_value.copyWith(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as int?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value.operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientDetailImplCopyWith<$Res>
    implements $ClientDetailCopyWith<$Res> {
  factory _$$ClientDetailImplCopyWith(
          _$ClientDetailImpl value, $Res Function(_$ClientDetailImpl) then) =
      __$$ClientDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "bussinessId") int? bussinessId,
      @JsonKey(name: "bussinessName") String? bussinessName,
      @JsonKey(name: "ownerName") String? ownerName,
      @JsonKey(name: "clientTypeId") String? clientTypeId,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "fax") String? fax,
      @JsonKey(name: "lastSeen") DateTime? lastSeen,
      @JsonKey(name: "monthlyCredits") int? monthlyCredits,
      @JsonKey(name: "applicationVersion") String? applicationVersion,
      @JsonKey(name: "deviceType") String? deviceType,
      @JsonKey(name: "operationTime") List<OperationTime>? operationTime,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt});
}

/// @nodoc
class __$$ClientDetailImplCopyWithImpl<$Res>
    extends _$ClientDetailCopyWithImpl<$Res, _$ClientDetailImpl>
    implements _$$ClientDetailImplCopyWith<$Res> {
  __$$ClientDetailImplCopyWithImpl(
      _$ClientDetailImpl _value, $Res Function(_$ClientDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_$ClientDetailImpl(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as int?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value._operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientDetailImpl implements _ClientDetail {
  const _$ClientDetailImpl(
      {@JsonKey(name: "bussinessId") this.bussinessId,
      @JsonKey(name: "bussinessName") this.bussinessName,
      @JsonKey(name: "ownerName") this.ownerName,
      @JsonKey(name: "clientTypeId") this.clientTypeId,
      @JsonKey(name: "israelId") this.israelId,
      @JsonKey(name: "tokenId") this.tokenId,
      @JsonKey(name: "fax") this.fax,
      @JsonKey(name: "lastSeen") this.lastSeen,
      @JsonKey(name: "monthlyCredits") this.monthlyCredits,
      @JsonKey(name: "applicationVersion") this.applicationVersion,
      @JsonKey(name: "deviceType") this.deviceType,
      @JsonKey(name: "operationTime") final List<OperationTime>? operationTime,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt})
      : _operationTime = operationTime;

  factory _$ClientDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientDetailImplFromJson(json);

  @override
  @JsonKey(name: "bussinessId")
  final int? bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  final String? bussinessName;
  @override
  @JsonKey(name: "ownerName")
  final String? ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  final String? clientTypeId;
  @override
  @JsonKey(name: "israelId")
  final String? israelId;
  @override
  @JsonKey(name: "tokenId")
  final String? tokenId;
  @override
  @JsonKey(name: "fax")
  final String? fax;
  @override
  @JsonKey(name: "lastSeen")
  final DateTime? lastSeen;
  @override
  @JsonKey(name: "monthlyCredits")
  final int? monthlyCredits;
  @override
  @JsonKey(name: "applicationVersion")
  final String? applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  final String? deviceType;
  final List<OperationTime>? _operationTime;
  @override
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime {
    final value = _operationTime;
    if (value == null) return null;
    if (_operationTime is EqualUnmodifiableListView) return _operationTime;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;

  @override
  String toString() {
    return 'ClientDetail(bussinessId: $bussinessId, bussinessName: $bussinessName, ownerName: $ownerName, clientTypeId: $clientTypeId, israelId: $israelId, tokenId: $tokenId, fax: $fax, lastSeen: $lastSeen, monthlyCredits: $monthlyCredits, applicationVersion: $applicationVersion, deviceType: $deviceType, operationTime: $operationTime, id: $id, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientDetailImpl &&
            (identical(other.bussinessId, bussinessId) ||
                other.bussinessId == bussinessId) &&
            (identical(other.bussinessName, bussinessName) ||
                other.bussinessName == bussinessName) &&
            (identical(other.ownerName, ownerName) ||
                other.ownerName == ownerName) &&
            (identical(other.clientTypeId, clientTypeId) ||
                other.clientTypeId == clientTypeId) &&
            (identical(other.israelId, israelId) ||
                other.israelId == israelId) &&
            (identical(other.tokenId, tokenId) || other.tokenId == tokenId) &&
            (identical(other.fax, fax) || other.fax == fax) &&
            (identical(other.lastSeen, lastSeen) ||
                other.lastSeen == lastSeen) &&
            (identical(other.monthlyCredits, monthlyCredits) ||
                other.monthlyCredits == monthlyCredits) &&
            (identical(other.applicationVersion, applicationVersion) ||
                other.applicationVersion == applicationVersion) &&
            (identical(other.deviceType, deviceType) ||
                other.deviceType == deviceType) &&
            const DeepCollectionEquality()
                .equals(other._operationTime, _operationTime) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      bussinessId,
      bussinessName,
      ownerName,
      clientTypeId,
      israelId,
      tokenId,
      fax,
      lastSeen,
      monthlyCredits,
      applicationVersion,
      deviceType,
      const DeepCollectionEquality().hash(_operationTime),
      id,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      __$$ClientDetailImplCopyWithImpl<_$ClientDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientDetailImplToJson(
      this,
    );
  }
}

abstract class _ClientDetail implements ClientDetail {
  const factory _ClientDetail(
      {@JsonKey(name: "bussinessId") final int? bussinessId,
      @JsonKey(name: "bussinessName") final String? bussinessName,
      @JsonKey(name: "ownerName") final String? ownerName,
      @JsonKey(name: "clientTypeId") final String? clientTypeId,
      @JsonKey(name: "israelId") final String? israelId,
      @JsonKey(name: "tokenId") final String? tokenId,
      @JsonKey(name: "fax") final String? fax,
      @JsonKey(name: "lastSeen") final DateTime? lastSeen,
      @JsonKey(name: "monthlyCredits") final int? monthlyCredits,
      @JsonKey(name: "applicationVersion") final String? applicationVersion,
      @JsonKey(name: "deviceType") final String? deviceType,
      @JsonKey(name: "operationTime") final List<OperationTime>? operationTime,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt")
      final DateTime? updatedAt}) = _$ClientDetailImpl;

  factory _ClientDetail.fromJson(Map<String, dynamic> json) =
      _$ClientDetailImpl.fromJson;

  @override
  @JsonKey(name: "bussinessId")
  int? get bussinessId;
  @override
  @JsonKey(name: "bussinessName")
  String? get bussinessName;
  @override
  @JsonKey(name: "ownerName")
  String? get ownerName;
  @override
  @JsonKey(name: "clientTypeId")
  String? get clientTypeId;
  @override
  @JsonKey(name: "israelId")
  String? get israelId;
  @override
  @JsonKey(name: "tokenId")
  String? get tokenId;
  @override
  @JsonKey(name: "fax")
  String? get fax;
  @override
  @JsonKey(name: "lastSeen")
  DateTime? get lastSeen;
  @override
  @JsonKey(name: "monthlyCredits")
  int? get monthlyCredits;
  @override
  @JsonKey(name: "applicationVersion")
  String? get applicationVersion;
  @override
  @JsonKey(name: "deviceType")
  String? get deviceType;
  @override
  @JsonKey(name: "operationTime")
  List<OperationTime>? get operationTime;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

OperationTime _$OperationTimeFromJson(Map<String, dynamic> json) {
  return _OperationTime.fromJson(json);
}

/// @nodoc
mixin _$OperationTime {
  List<Day>? get sunday => throw _privateConstructorUsedError;
  List<Day>? get monday => throw _privateConstructorUsedError;
  List<Day>? get tuesday => throw _privateConstructorUsedError;
  List<Day>? get wednesday => throw _privateConstructorUsedError;
  List<Day>? get thursday => throw _privateConstructorUsedError;
  List<Day>? get fridayAndHolidayEves => throw _privateConstructorUsedError;
  List<Day>? get saturdayAndHolidays => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $OperationTimeCopyWith<OperationTime> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OperationTimeCopyWith<$Res> {
  factory $OperationTimeCopyWith(
          OperationTime value, $Res Function(OperationTime) then) =
      _$OperationTimeCopyWithImpl<$Res, OperationTime>;
  @useResult
  $Res call(
      {List<Day>? sunday,
      List<Day>? monday,
      List<Day>? tuesday,
      List<Day>? wednesday,
      List<Day>? thursday,
      List<Day>? fridayAndHolidayEves,
      List<Day>? saturdayAndHolidays});
}

/// @nodoc
class _$OperationTimeCopyWithImpl<$Res, $Val extends OperationTime>
    implements $OperationTimeCopyWith<$Res> {
  _$OperationTimeCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sunday = freezed,
    Object? monday = freezed,
    Object? tuesday = freezed,
    Object? wednesday = freezed,
    Object? thursday = freezed,
    Object? fridayAndHolidayEves = freezed,
    Object? saturdayAndHolidays = freezed,
  }) {
    return _then(_value.copyWith(
      sunday: freezed == sunday
          ? _value.sunday
          : sunday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      monday: freezed == monday
          ? _value.monday
          : monday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      tuesday: freezed == tuesday
          ? _value.tuesday
          : tuesday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      wednesday: freezed == wednesday
          ? _value.wednesday
          : wednesday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      thursday: freezed == thursday
          ? _value.thursday
          : thursday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      fridayAndHolidayEves: freezed == fridayAndHolidayEves
          ? _value.fridayAndHolidayEves
          : fridayAndHolidayEves // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      saturdayAndHolidays: freezed == saturdayAndHolidays
          ? _value.saturdayAndHolidays
          : saturdayAndHolidays // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$OperationTimeImplCopyWith<$Res>
    implements $OperationTimeCopyWith<$Res> {
  factory _$$OperationTimeImplCopyWith(
          _$OperationTimeImpl value, $Res Function(_$OperationTimeImpl) then) =
      __$$OperationTimeImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Day>? sunday,
      List<Day>? monday,
      List<Day>? tuesday,
      List<Day>? wednesday,
      List<Day>? thursday,
      List<Day>? fridayAndHolidayEves,
      List<Day>? saturdayAndHolidays});
}

/// @nodoc
class __$$OperationTimeImplCopyWithImpl<$Res>
    extends _$OperationTimeCopyWithImpl<$Res, _$OperationTimeImpl>
    implements _$$OperationTimeImplCopyWith<$Res> {
  __$$OperationTimeImplCopyWithImpl(
      _$OperationTimeImpl _value, $Res Function(_$OperationTimeImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sunday = freezed,
    Object? monday = freezed,
    Object? tuesday = freezed,
    Object? wednesday = freezed,
    Object? thursday = freezed,
    Object? fridayAndHolidayEves = freezed,
    Object? saturdayAndHolidays = freezed,
  }) {
    return _then(_$OperationTimeImpl(
      sunday: freezed == sunday
          ? _value._sunday
          : sunday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      monday: freezed == monday
          ? _value._monday
          : monday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      tuesday: freezed == tuesday
          ? _value._tuesday
          : tuesday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      wednesday: freezed == wednesday
          ? _value._wednesday
          : wednesday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      thursday: freezed == thursday
          ? _value._thursday
          : thursday // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      fridayAndHolidayEves: freezed == fridayAndHolidayEves
          ? _value._fridayAndHolidayEves
          : fridayAndHolidayEves // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
      saturdayAndHolidays: freezed == saturdayAndHolidays
          ? _value._saturdayAndHolidays
          : saturdayAndHolidays // ignore: cast_nullable_to_non_nullable
              as List<Day>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$OperationTimeImpl implements _OperationTime {
  const _$OperationTimeImpl(
      {final List<Day>? sunday,
      final List<Day>? monday,
      final List<Day>? tuesday,
      final List<Day>? wednesday,
      final List<Day>? thursday,
      final List<Day>? fridayAndHolidayEves,
      final List<Day>? saturdayAndHolidays})
      : _sunday = sunday,
        _monday = monday,
        _tuesday = tuesday,
        _wednesday = wednesday,
        _thursday = thursday,
        _fridayAndHolidayEves = fridayAndHolidayEves,
        _saturdayAndHolidays = saturdayAndHolidays;

  factory _$OperationTimeImpl.fromJson(Map<String, dynamic> json) =>
      _$$OperationTimeImplFromJson(json);

  final List<Day>? _sunday;
  @override
  List<Day>? get sunday {
    final value = _sunday;
    if (value == null) return null;
    if (_sunday is EqualUnmodifiableListView) return _sunday;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Day>? _monday;
  @override
  List<Day>? get monday {
    final value = _monday;
    if (value == null) return null;
    if (_monday is EqualUnmodifiableListView) return _monday;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Day>? _tuesday;
  @override
  List<Day>? get tuesday {
    final value = _tuesday;
    if (value == null) return null;
    if (_tuesday is EqualUnmodifiableListView) return _tuesday;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Day>? _wednesday;
  @override
  List<Day>? get wednesday {
    final value = _wednesday;
    if (value == null) return null;
    if (_wednesday is EqualUnmodifiableListView) return _wednesday;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Day>? _thursday;
  @override
  List<Day>? get thursday {
    final value = _thursday;
    if (value == null) return null;
    if (_thursday is EqualUnmodifiableListView) return _thursday;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Day>? _fridayAndHolidayEves;
  @override
  List<Day>? get fridayAndHolidayEves {
    final value = _fridayAndHolidayEves;
    if (value == null) return null;
    if (_fridayAndHolidayEves is EqualUnmodifiableListView)
      return _fridayAndHolidayEves;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Day>? _saturdayAndHolidays;
  @override
  List<Day>? get saturdayAndHolidays {
    final value = _saturdayAndHolidays;
    if (value == null) return null;
    if (_saturdayAndHolidays is EqualUnmodifiableListView)
      return _saturdayAndHolidays;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'OperationTime(sunday: $sunday, monday: $monday, tuesday: $tuesday, wednesday: $wednesday, thursday: $thursday, fridayAndHolidayEves: $fridayAndHolidayEves, saturdayAndHolidays: $saturdayAndHolidays)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OperationTimeImpl &&
            const DeepCollectionEquality().equals(other._sunday, _sunday) &&
            const DeepCollectionEquality().equals(other._monday, _monday) &&
            const DeepCollectionEquality().equals(other._tuesday, _tuesday) &&
            const DeepCollectionEquality()
                .equals(other._wednesday, _wednesday) &&
            const DeepCollectionEquality().equals(other._thursday, _thursday) &&
            const DeepCollectionEquality()
                .equals(other._fridayAndHolidayEves, _fridayAndHolidayEves) &&
            const DeepCollectionEquality()
                .equals(other._saturdayAndHolidays, _saturdayAndHolidays));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_sunday),
      const DeepCollectionEquality().hash(_monday),
      const DeepCollectionEquality().hash(_tuesday),
      const DeepCollectionEquality().hash(_wednesday),
      const DeepCollectionEquality().hash(_thursday),
      const DeepCollectionEquality().hash(_fridayAndHolidayEves),
      const DeepCollectionEquality().hash(_saturdayAndHolidays));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OperationTimeImplCopyWith<_$OperationTimeImpl> get copyWith =>
      __$$OperationTimeImplCopyWithImpl<_$OperationTimeImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$OperationTimeImplToJson(
      this,
    );
  }
}

abstract class _OperationTime implements OperationTime {
  const factory _OperationTime(
      {final List<Day>? sunday,
      final List<Day>? monday,
      final List<Day>? tuesday,
      final List<Day>? wednesday,
      final List<Day>? thursday,
      final List<Day>? fridayAndHolidayEves,
      final List<Day>? saturdayAndHolidays}) = _$OperationTimeImpl;

  factory _OperationTime.fromJson(Map<String, dynamic> json) =
      _$OperationTimeImpl.fromJson;

  @override
  List<Day>? get sunday;
  @override
  List<Day>? get monday;
  @override
  List<Day>? get tuesday;
  @override
  List<Day>? get wednesday;
  @override
  List<Day>? get thursday;
  @override
  List<Day>? get fridayAndHolidayEves;
  @override
  List<Day>? get saturdayAndHolidays;
  @override
  @JsonKey(ignore: true)
  _$$OperationTimeImplCopyWith<_$OperationTimeImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Day _$DayFromJson(Map<String, dynamic> json) {
  return _Day.fromJson(json);
}

/// @nodoc
mixin _$Day {
  @JsonKey(name: "from")
  String? get from => throw _privateConstructorUsedError;
  @JsonKey(name: "until")
  String? get until => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DayCopyWith<Day> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DayCopyWith<$Res> {
  factory $DayCopyWith(Day value, $Res Function(Day) then) =
      _$DayCopyWithImpl<$Res, Day>;
  @useResult
  $Res call(
      {@JsonKey(name: "from") String? from,
      @JsonKey(name: "until") String? until});
}

/// @nodoc
class _$DayCopyWithImpl<$Res, $Val extends Day> implements $DayCopyWith<$Res> {
  _$DayCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? from = freezed,
    Object? until = freezed,
  }) {
    return _then(_value.copyWith(
      from: freezed == from
          ? _value.from
          : from // ignore: cast_nullable_to_non_nullable
              as String?,
      until: freezed == until
          ? _value.until
          : until // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DayImplCopyWith<$Res> implements $DayCopyWith<$Res> {
  factory _$$DayImplCopyWith(_$DayImpl value, $Res Function(_$DayImpl) then) =
      __$$DayImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "from") String? from,
      @JsonKey(name: "until") String? until});
}

/// @nodoc
class __$$DayImplCopyWithImpl<$Res> extends _$DayCopyWithImpl<$Res, _$DayImpl>
    implements _$$DayImplCopyWith<$Res> {
  __$$DayImplCopyWithImpl(_$DayImpl _value, $Res Function(_$DayImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? from = freezed,
    Object? until = freezed,
  }) {
    return _then(_$DayImpl(
      from: freezed == from
          ? _value.from
          : from // ignore: cast_nullable_to_non_nullable
              as String?,
      until: freezed == until
          ? _value.until
          : until // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DayImpl implements _Day {
  const _$DayImpl(
      {@JsonKey(name: "from") this.from, @JsonKey(name: "until") this.until});

  factory _$DayImpl.fromJson(Map<String, dynamic> json) =>
      _$$DayImplFromJson(json);

  @override
  @JsonKey(name: "from")
  final String? from;
  @override
  @JsonKey(name: "until")
  final String? until;

  @override
  String toString() {
    return 'Day(from: $from, until: $until)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DayImpl &&
            (identical(other.from, from) || other.from == from) &&
            (identical(other.until, until) || other.until == until));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, from, until);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DayImplCopyWith<_$DayImpl> get copyWith =>
      __$$DayImplCopyWithImpl<_$DayImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DayImplToJson(
      this,
    );
  }
}

abstract class _Day implements Day {
  const factory _Day(
      {@JsonKey(name: "from") final String? from,
      @JsonKey(name: "until") final String? until}) = _$DayImpl;

  factory _Day.fromJson(Map<String, dynamic> json) = _$DayImpl.fromJson;

  @override
  @JsonKey(name: "from")
  String? get from;
  @override
  @JsonKey(name: "until")
  String? get until;
  @override
  @JsonKey(ignore: true)
  _$$DayImplCopyWith<_$DayImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
