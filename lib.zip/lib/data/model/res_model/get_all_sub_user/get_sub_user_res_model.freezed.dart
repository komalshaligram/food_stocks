// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_sub_user_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetSubUserResModel _$GetSubUserResModelFromJson(Map<String, dynamic> json) {
  return _GetSubUserResModel.fromJson(json);
}

/// @nodoc
mixin _$GetSubUserResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetSubUserResModelCopyWith<GetSubUserResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetSubUserResModelCopyWith<$Res> {
  factory $GetSubUserResModelCopyWith(
          GetSubUserResModel value, $Res Function(GetSubUserResModel) then) =
      _$GetSubUserResModelCopyWithImpl<$Res, GetSubUserResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$GetSubUserResModelCopyWithImpl<$Res, $Val extends GetSubUserResModel>
    implements $GetSubUserResModelCopyWith<$Res> {
  _$GetSubUserResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GetSubUserResModelImplCopyWith<$Res>
    implements $GetSubUserResModelCopyWith<$Res> {
  factory _$$GetSubUserResModelImplCopyWith(_$GetSubUserResModelImpl value,
          $Res Function(_$GetSubUserResModelImpl) then) =
      __$$GetSubUserResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") Data? data,
      @JsonKey(name: "message") String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$GetSubUserResModelImplCopyWithImpl<$Res>
    extends _$GetSubUserResModelCopyWithImpl<$Res, _$GetSubUserResModelImpl>
    implements _$$GetSubUserResModelImplCopyWith<$Res> {
  __$$GetSubUserResModelImplCopyWithImpl(_$GetSubUserResModelImpl _value,
      $Res Function(_$GetSubUserResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$GetSubUserResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetSubUserResModelImpl implements _GetSubUserResModel {
  const _$GetSubUserResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$GetSubUserResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetSubUserResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final Data? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'GetSubUserResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetSubUserResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetSubUserResModelImplCopyWith<_$GetSubUserResModelImpl> get copyWith =>
      __$$GetSubUserResModelImplCopyWithImpl<_$GetSubUserResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetSubUserResModelImplToJson(
      this,
    );
  }
}

abstract class _GetSubUserResModel implements GetSubUserResModel {
  const factory _GetSubUserResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final Data? data,
          @JsonKey(name: "message") final String? message}) =
      _$GetSubUserResModelImpl;

  factory _GetSubUserResModel.fromJson(Map<String, dynamic> json) =
      _$GetSubUserResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$GetSubUserResModelImplCopyWith<_$GetSubUserResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "users")
  List<User>? get users => throw _privateConstructorUsedError;
  @JsonKey(name: "totalRecords")
  int? get totalRecords => throw _privateConstructorUsedError;
  @JsonKey(name: "totalPages")
  int? get totalPages => throw _privateConstructorUsedError;
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "users") List<User>? users,
      @JsonKey(name: "totalRecords") int? totalRecords,
      @JsonKey(name: "totalPages") int? totalPages,
      @JsonKey(name: "currentPage") int? currentPage});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? users = freezed,
    Object? totalRecords = freezed,
    Object? totalPages = freezed,
    Object? currentPage = freezed,
  }) {
    return _then(_value.copyWith(
      users: freezed == users
          ? _value.users
          : users // ignore: cast_nullable_to_non_nullable
              as List<User>?,
      totalRecords: freezed == totalRecords
          ? _value.totalRecords
          : totalRecords // ignore: cast_nullable_to_non_nullable
              as int?,
      totalPages: freezed == totalPages
          ? _value.totalPages
          : totalPages // ignore: cast_nullable_to_non_nullable
              as int?,
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "users") List<User>? users,
      @JsonKey(name: "totalRecords") int? totalRecords,
      @JsonKey(name: "totalPages") int? totalPages,
      @JsonKey(name: "currentPage") int? currentPage});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? users = freezed,
    Object? totalRecords = freezed,
    Object? totalPages = freezed,
    Object? currentPage = freezed,
  }) {
    return _then(_$DataImpl(
      users: freezed == users
          ? _value._users
          : users // ignore: cast_nullable_to_non_nullable
              as List<User>?,
      totalRecords: freezed == totalRecords
          ? _value.totalRecords
          : totalRecords // ignore: cast_nullable_to_non_nullable
              as int?,
      totalPages: freezed == totalPages
          ? _value.totalPages
          : totalPages // ignore: cast_nullable_to_non_nullable
              as int?,
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "users") final List<User>? users,
      @JsonKey(name: "totalRecords") this.totalRecords,
      @JsonKey(name: "totalPages") this.totalPages,
      @JsonKey(name: "currentPage") this.currentPage})
      : _users = users;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  final List<User>? _users;
  @override
  @JsonKey(name: "users")
  List<User>? get users {
    final value = _users;
    if (value == null) return null;
    if (_users is EqualUnmodifiableListView) return _users;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "totalRecords")
  final int? totalRecords;
  @override
  @JsonKey(name: "totalPages")
  final int? totalPages;
  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;

  @override
  String toString() {
    return 'Data(users: $users, totalRecords: $totalRecords, totalPages: $totalPages, currentPage: $currentPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            const DeepCollectionEquality().equals(other._users, _users) &&
            (identical(other.totalRecords, totalRecords) ||
                other.totalRecords == totalRecords) &&
            (identical(other.totalPages, totalPages) ||
                other.totalPages == totalPages) &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_users),
      totalRecords,
      totalPages,
      currentPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "users") final List<User>? users,
      @JsonKey(name: "totalRecords") final int? totalRecords,
      @JsonKey(name: "totalPages") final int? totalPages,
      @JsonKey(name: "currentPage") final int? currentPage}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "users")
  List<User>? get users;
  @override
  @JsonKey(name: "totalRecords")
  int? get totalRecords;
  @override
  @JsonKey(name: "totalPages")
  int? get totalPages;
  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

User _$UserFromJson(Map<String, dynamic> json) {
  return _User.fromJson(json);
}

/// @nodoc
mixin _$User {
  @JsonKey(name: "adminType")
  AdminType? get adminType => throw _privateConstructorUsedError;
  @JsonKey(name: "lastSeen")
  String? get lastSeen => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "createdBy")
  String? get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedBy")
  String? get updatedBy => throw _privateConstructorUsedError;
  @JsonKey(name: "israelId")
  String? get israelId => throw _privateConstructorUsedError;
  @JsonKey(name: "userNumber")
  String? get userNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "profileImage")
  String? get profileImage => throw _privateConstructorUsedError;
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "tokenId")
  String? get tokenId => throw _privateConstructorUsedError;
  @JsonKey(name: "lastSentOTP")
  String? get lastSentOtp => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $UserCopyWith<User> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserCopyWith<$Res> {
  factory $UserCopyWith(User value, $Res Function(User) then) =
      _$UserCopyWithImpl<$Res, User>;
  @useResult
  $Res call(
      {@JsonKey(name: "adminType") AdminType? adminType,
      @JsonKey(name: "lastSeen") String? lastSeen,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "userNumber") String? userNumber,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "lastSentOTP") String? lastSentOtp});

  $AdminTypeCopyWith<$Res>? get adminType;
}

/// @nodoc
class _$UserCopyWithImpl<$Res, $Val extends User>
    implements $UserCopyWith<$Res> {
  _$UserCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adminType = freezed,
    Object? lastSeen = freezed,
    Object? id = freezed,
    Object? email = freezed,
    Object? contactName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? israelId = freezed,
    Object? userNumber = freezed,
    Object? profileImage = freezed,
    Object? phoneNumber = freezed,
    Object? tokenId = freezed,
    Object? lastSentOtp = freezed,
  }) {
    return _then(_value.copyWith(
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as AdminType?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      userNumber: freezed == userNumber
          ? _value.userNumber
          : userNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSentOtp: freezed == lastSentOtp
          ? _value.lastSentOtp
          : lastSentOtp // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $AdminTypeCopyWith<$Res>? get adminType {
    if (_value.adminType == null) {
      return null;
    }

    return $AdminTypeCopyWith<$Res>(_value.adminType!, (value) {
      return _then(_value.copyWith(adminType: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$UserImplCopyWith<$Res> implements $UserCopyWith<$Res> {
  factory _$$UserImplCopyWith(
          _$UserImpl value, $Res Function(_$UserImpl) then) =
      __$$UserImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "adminType") AdminType? adminType,
      @JsonKey(name: "lastSeen") String? lastSeen,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "contactName") String? contactName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "createdBy") String? createdBy,
      @JsonKey(name: "updatedBy") String? updatedBy,
      @JsonKey(name: "israelId") String? israelId,
      @JsonKey(name: "userNumber") String? userNumber,
      @JsonKey(name: "profileImage") String? profileImage,
      @JsonKey(name: "phoneNumber") String? phoneNumber,
      @JsonKey(name: "tokenId") String? tokenId,
      @JsonKey(name: "lastSentOTP") String? lastSentOtp});

  @override
  $AdminTypeCopyWith<$Res>? get adminType;
}

/// @nodoc
class __$$UserImplCopyWithImpl<$Res>
    extends _$UserCopyWithImpl<$Res, _$UserImpl>
    implements _$$UserImplCopyWith<$Res> {
  __$$UserImplCopyWithImpl(_$UserImpl _value, $Res Function(_$UserImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? adminType = freezed,
    Object? lastSeen = freezed,
    Object? id = freezed,
    Object? email = freezed,
    Object? contactName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? israelId = freezed,
    Object? userNumber = freezed,
    Object? profileImage = freezed,
    Object? phoneNumber = freezed,
    Object? tokenId = freezed,
    Object? lastSentOtp = freezed,
  }) {
    return _then(_$UserImpl(
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as AdminType?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      userNumber: freezed == userNumber
          ? _value.userNumber
          : userNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      profileImage: freezed == profileImage
          ? _value.profileImage
          : profileImage // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSentOtp: freezed == lastSentOtp
          ? _value.lastSentOtp
          : lastSentOtp // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$UserImpl implements _User {
  const _$UserImpl(
      {@JsonKey(name: "adminType") this.adminType,
      @JsonKey(name: "lastSeen") this.lastSeen,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "email") this.email,
      @JsonKey(name: "contactName") this.contactName,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "createdBy") this.createdBy,
      @JsonKey(name: "updatedBy") this.updatedBy,
      @JsonKey(name: "israelId") this.israelId,
      @JsonKey(name: "userNumber") this.userNumber,
      @JsonKey(name: "profileImage") this.profileImage,
      @JsonKey(name: "phoneNumber") this.phoneNumber,
      @JsonKey(name: "tokenId") this.tokenId,
      @JsonKey(name: "lastSentOTP") this.lastSentOtp});

  factory _$UserImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserImplFromJson(json);

  @override
  @JsonKey(name: "adminType")
  final AdminType? adminType;
  @override
  @JsonKey(name: "lastSeen")
  final String? lastSeen;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "createdBy")
  final String? createdBy;
  @override
  @JsonKey(name: "updatedBy")
  final String? updatedBy;
  @override
  @JsonKey(name: "israelId")
  final String? israelId;
  @override
  @JsonKey(name: "userNumber")
  final String? userNumber;
  @override
  @JsonKey(name: "profileImage")
  final String? profileImage;
  @override
  @JsonKey(name: "phoneNumber")
  final String? phoneNumber;
  @override
  @JsonKey(name: "tokenId")
  final String? tokenId;
  @override
  @JsonKey(name: "lastSentOTP")
  final String? lastSentOtp;

  @override
  String toString() {
    return 'User(adminType: $adminType, lastSeen: $lastSeen, id: $id, email: $email, contactName: $contactName, createdAt: $createdAt, updatedAt: $updatedAt, createdBy: $createdBy, updatedBy: $updatedBy, israelId: $israelId, userNumber: $userNumber, profileImage: $profileImage, phoneNumber: $phoneNumber, tokenId: $tokenId, lastSentOtp: $lastSentOtp)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserImpl &&
            (identical(other.adminType, adminType) ||
                other.adminType == adminType) &&
            (identical(other.lastSeen, lastSeen) ||
                other.lastSeen == lastSeen) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.israelId, israelId) ||
                other.israelId == israelId) &&
            (identical(other.userNumber, userNumber) ||
                other.userNumber == userNumber) &&
            (identical(other.profileImage, profileImage) ||
                other.profileImage == profileImage) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.tokenId, tokenId) || other.tokenId == tokenId) &&
            (identical(other.lastSentOtp, lastSentOtp) ||
                other.lastSentOtp == lastSentOtp));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      adminType,
      lastSeen,
      id,
      email,
      contactName,
      createdAt,
      updatedAt,
      createdBy,
      updatedBy,
      israelId,
      userNumber,
      profileImage,
      phoneNumber,
      tokenId,
      lastSentOtp);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UserImplCopyWith<_$UserImpl> get copyWith =>
      __$$UserImplCopyWithImpl<_$UserImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserImplToJson(
      this,
    );
  }
}

abstract class _User implements User {
  const factory _User(
      {@JsonKey(name: "adminType") final AdminType? adminType,
      @JsonKey(name: "lastSeen") final String? lastSeen,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "email") final String? email,
      @JsonKey(name: "contactName") final String? contactName,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "createdBy") final String? createdBy,
      @JsonKey(name: "updatedBy") final String? updatedBy,
      @JsonKey(name: "israelId") final String? israelId,
      @JsonKey(name: "userNumber") final String? userNumber,
      @JsonKey(name: "profileImage") final String? profileImage,
      @JsonKey(name: "phoneNumber") final String? phoneNumber,
      @JsonKey(name: "tokenId") final String? tokenId,
      @JsonKey(name: "lastSentOTP") final String? lastSentOtp}) = _$UserImpl;

  factory _User.fromJson(Map<String, dynamic> json) = _$UserImpl.fromJson;

  @override
  @JsonKey(name: "adminType")
  AdminType? get adminType;
  @override
  @JsonKey(name: "lastSeen")
  String? get lastSeen;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "createdBy")
  String? get createdBy;
  @override
  @JsonKey(name: "updatedBy")
  String? get updatedBy;
  @override
  @JsonKey(name: "israelId")
  String? get israelId;
  @override
  @JsonKey(name: "userNumber")
  String? get userNumber;
  @override
  @JsonKey(name: "profileImage")
  String? get profileImage;
  @override
  @JsonKey(name: "phoneNumber")
  String? get phoneNumber;
  @override
  @JsonKey(name: "tokenId")
  String? get tokenId;
  @override
  @JsonKey(name: "lastSentOTP")
  String? get lastSentOtp;
  @override
  @JsonKey(ignore: true)
  _$$UserImplCopyWith<_$UserImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

AdminType _$AdminTypeFromJson(Map<String, dynamic> json) {
  return _AdminType.fromJson(json);
}

/// @nodoc
mixin _$AdminType {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "adminTypeName")
  String? get adminTypeName => throw _privateConstructorUsedError;
  @JsonKey(name: "adminType")
  String? get adminType => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AdminTypeCopyWith<AdminType> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AdminTypeCopyWith<$Res> {
  factory $AdminTypeCopyWith(AdminType value, $Res Function(AdminType) then) =
      _$AdminTypeCopyWithImpl<$Res, AdminType>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "adminTypeName") String? adminTypeName,
      @JsonKey(name: "adminType") String? adminType});
}

/// @nodoc
class _$AdminTypeCopyWithImpl<$Res, $Val extends AdminType>
    implements $AdminTypeCopyWith<$Res> {
  _$AdminTypeCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? adminTypeName = freezed,
    Object? adminType = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeName: freezed == adminTypeName
          ? _value.adminTypeName
          : adminTypeName // ignore: cast_nullable_to_non_nullable
              as String?,
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AdminTypeImplCopyWith<$Res>
    implements $AdminTypeCopyWith<$Res> {
  factory _$$AdminTypeImplCopyWith(
          _$AdminTypeImpl value, $Res Function(_$AdminTypeImpl) then) =
      __$$AdminTypeImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "adminTypeName") String? adminTypeName,
      @JsonKey(name: "adminType") String? adminType});
}

/// @nodoc
class __$$AdminTypeImplCopyWithImpl<$Res>
    extends _$AdminTypeCopyWithImpl<$Res, _$AdminTypeImpl>
    implements _$$AdminTypeImplCopyWith<$Res> {
  __$$AdminTypeImplCopyWithImpl(
      _$AdminTypeImpl _value, $Res Function(_$AdminTypeImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? adminTypeName = freezed,
    Object? adminType = freezed,
  }) {
    return _then(_$AdminTypeImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeName: freezed == adminTypeName
          ? _value.adminTypeName
          : adminTypeName // ignore: cast_nullable_to_non_nullable
              as String?,
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AdminTypeImpl implements _AdminType {
  const _$AdminTypeImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "adminTypeName") this.adminTypeName,
      @JsonKey(name: "adminType") this.adminType});

  factory _$AdminTypeImpl.fromJson(Map<String, dynamic> json) =>
      _$$AdminTypeImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "adminTypeName")
  final String? adminTypeName;
  @override
  @JsonKey(name: "adminType")
  final String? adminType;

  @override
  String toString() {
    return 'AdminType(id: $id, adminTypeName: $adminTypeName, adminType: $adminType)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AdminTypeImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.adminTypeName, adminTypeName) ||
                other.adminTypeName == adminTypeName) &&
            (identical(other.adminType, adminType) ||
                other.adminType == adminType));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, adminTypeName, adminType);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AdminTypeImplCopyWith<_$AdminTypeImpl> get copyWith =>
      __$$AdminTypeImplCopyWithImpl<_$AdminTypeImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AdminTypeImplToJson(
      this,
    );
  }
}

abstract class _AdminType implements AdminType {
  const factory _AdminType(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "adminTypeName") final String? adminTypeName,
      @JsonKey(name: "adminType") final String? adminType}) = _$AdminTypeImpl;

  factory _AdminType.fromJson(Map<String, dynamic> json) =
      _$AdminTypeImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "adminTypeName")
  String? get adminTypeName;
  @override
  @JsonKey(name: "adminType")
  String? get adminType;
  @override
  @JsonKey(ignore: true)
  _$$AdminTypeImplCopyWith<_$AdminTypeImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
