// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_sub_user_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetSubUserResModelImpl _$$GetSubUserResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetSubUserResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$GetSubUserResModelImplToJson(
        _$GetSubUserResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      users: (json['users'] as List<dynamic>?)
          ?.map((e) => User.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalRecords: json['totalRecords'] as int?,
      totalPages: json['totalPages'] as int?,
      currentPage: json['currentPage'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'users': instance.users,
      'totalRecords': instance.totalRecords,
      'totalPages': instance.totalPages,
      'currentPage': instance.currentPage,
    };

_$UserImpl _$$UserImplFromJson(Map<String, dynamic> json) => _$UserImpl(
      adminType: json['adminType'] == null
          ? null
          : AdminType.fromJson(json['adminType'] as Map<String, dynamic>),
      lastSeen: json['lastSeen'] as String?,
      id: json['_id'] as String?,
      email: json['email'] as String?,
      contactName: json['contactName'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      israelId: json['israelId'] as String?,
      userNumber: json['userNumber'] as String?,
      profileImage: json['profileImage'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      tokenId: json['tokenId'] as String?,
      lastSentOtp: json['lastSentOTP'] as String?,
    );

Map<String, dynamic> _$$UserImplToJson(_$UserImpl instance) =>
    <String, dynamic>{
      'adminType': instance.adminType,
      'lastSeen': instance.lastSeen,
      '_id': instance.id,
      'email': instance.email,
      'contactName': instance.contactName,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'israelId': instance.israelId,
      'userNumber': instance.userNumber,
      'profileImage': instance.profileImage,
      'phoneNumber': instance.phoneNumber,
      'tokenId': instance.tokenId,
      'lastSentOTP': instance.lastSentOtp,
    };

_$AdminTypeImpl _$$AdminTypeImplFromJson(Map<String, dynamic> json) =>
    _$AdminTypeImpl(
      id: json['_id'] as String?,
      adminTypeName: json['adminTypeName'] as String?,
      adminType: json['adminType'] as String?,
    );

Map<String, dynamic> _$$AdminTypeImplToJson(_$AdminTypeImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'adminTypeName': instance.adminTypeName,
      'adminType': instance.adminType,
    };
