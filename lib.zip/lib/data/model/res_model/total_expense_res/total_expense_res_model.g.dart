// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'total_expense_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$TotalExpenseResModelImpl _$$TotalExpenseResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$TotalExpenseResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => Datum.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalYearlyExpenses: (json['totalYearlyExpenses'] as num?)?.toDouble(),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$TotalExpenseResModelImplToJson(
        _$TotalExpenseResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'totalYearlyExpenses': instance.totalYearlyExpenses,
      'message': instance.message,
    };

_$DatumImpl _$$DatumImplFromJson(Map<String, dynamic> json) => _$DatumImpl(
      year: json['year'] as int?,
      month: json['month'] as int?,
      totalExpenses: (json['totalExpenses'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$$DatumImplToJson(_$DatumImpl instance) =>
    <String, dynamic>{
      'year': instance.year,
      'month': instance.month,
      'totalExpenses': instance.totalExpenses,
    };
