// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'total_expense_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

TotalExpenseResModel _$TotalExpenseResModelFromJson(Map<String, dynamic> json) {
  return _TotalExpenseResModel.fromJson(json);
}

/// @nodoc
mixin _$TotalExpenseResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<Datum>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "totalYearlyExpenses")
  double? get totalYearlyExpenses => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $TotalExpenseResModelCopyWith<TotalExpenseResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TotalExpenseResModelCopyWith<$Res> {
  factory $TotalExpenseResModelCopyWith(TotalExpenseResModel value,
          $Res Function(TotalExpenseResModel) then) =
      _$TotalExpenseResModelCopyWithImpl<$Res, TotalExpenseResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<Datum>? data,
      @JsonKey(name: "totalYearlyExpenses") double? totalYearlyExpenses,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class _$TotalExpenseResModelCopyWithImpl<$Res,
        $Val extends TotalExpenseResModel>
    implements $TotalExpenseResModelCopyWith<$Res> {
  _$TotalExpenseResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? totalYearlyExpenses = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      totalYearlyExpenses: freezed == totalYearlyExpenses
          ? _value.totalYearlyExpenses
          : totalYearlyExpenses // ignore: cast_nullable_to_non_nullable
              as double?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$TotalExpenseResModelImplCopyWith<$Res>
    implements $TotalExpenseResModelCopyWith<$Res> {
  factory _$$TotalExpenseResModelImplCopyWith(_$TotalExpenseResModelImpl value,
          $Res Function(_$TotalExpenseResModelImpl) then) =
      __$$TotalExpenseResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<Datum>? data,
      @JsonKey(name: "totalYearlyExpenses") double? totalYearlyExpenses,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class __$$TotalExpenseResModelImplCopyWithImpl<$Res>
    extends _$TotalExpenseResModelCopyWithImpl<$Res, _$TotalExpenseResModelImpl>
    implements _$$TotalExpenseResModelImplCopyWith<$Res> {
  __$$TotalExpenseResModelImplCopyWithImpl(_$TotalExpenseResModelImpl _value,
      $Res Function(_$TotalExpenseResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? totalYearlyExpenses = freezed,
    Object? message = freezed,
  }) {
    return _then(_$TotalExpenseResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      totalYearlyExpenses: freezed == totalYearlyExpenses
          ? _value.totalYearlyExpenses
          : totalYearlyExpenses // ignore: cast_nullable_to_non_nullable
              as double?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$TotalExpenseResModelImpl implements _TotalExpenseResModel {
  const _$TotalExpenseResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<Datum>? data,
      @JsonKey(name: "totalYearlyExpenses") this.totalYearlyExpenses,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$TotalExpenseResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$TotalExpenseResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<Datum>? _data;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "totalYearlyExpenses")
  final double? totalYearlyExpenses;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'TotalExpenseResModel(status: $status, data: $data, totalYearlyExpenses: $totalYearlyExpenses, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TotalExpenseResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.totalYearlyExpenses, totalYearlyExpenses) ||
                other.totalYearlyExpenses == totalYearlyExpenses) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), totalYearlyExpenses, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TotalExpenseResModelImplCopyWith<_$TotalExpenseResModelImpl>
      get copyWith =>
          __$$TotalExpenseResModelImplCopyWithImpl<_$TotalExpenseResModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$TotalExpenseResModelImplToJson(
      this,
    );
  }
}

abstract class _TotalExpenseResModel implements TotalExpenseResModel {
  const factory _TotalExpenseResModel(
      {@JsonKey(name: "status") final int? status,
      @JsonKey(name: "data") final List<Datum>? data,
      @JsonKey(name: "totalYearlyExpenses") final double? totalYearlyExpenses,
      @JsonKey(name: "message")
      final String? message}) = _$TotalExpenseResModelImpl;

  factory _TotalExpenseResModel.fromJson(Map<String, dynamic> json) =
      _$TotalExpenseResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data;
  @override
  @JsonKey(name: "totalYearlyExpenses")
  double? get totalYearlyExpenses;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$TotalExpenseResModelImplCopyWith<_$TotalExpenseResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Datum _$DatumFromJson(Map<String, dynamic> json) {
  return _Datum.fromJson(json);
}

/// @nodoc
mixin _$Datum {
  @JsonKey(name: "year")
  int? get year => throw _privateConstructorUsedError;
  @JsonKey(name: "month")
  int? get month => throw _privateConstructorUsedError;
  @JsonKey(name: "totalExpenses")
  double? get totalExpenses => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DatumCopyWith<Datum> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DatumCopyWith<$Res> {
  factory $DatumCopyWith(Datum value, $Res Function(Datum) then) =
      _$DatumCopyWithImpl<$Res, Datum>;
  @useResult
  $Res call(
      {@JsonKey(name: "year") int? year,
      @JsonKey(name: "month") int? month,
      @JsonKey(name: "totalExpenses") double? totalExpenses});
}

/// @nodoc
class _$DatumCopyWithImpl<$Res, $Val extends Datum>
    implements $DatumCopyWith<$Res> {
  _$DatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = freezed,
    Object? month = freezed,
    Object? totalExpenses = freezed,
  }) {
    return _then(_value.copyWith(
      year: freezed == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int?,
      month: freezed == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as int?,
      totalExpenses: freezed == totalExpenses
          ? _value.totalExpenses
          : totalExpenses // ignore: cast_nullable_to_non_nullable
              as double?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DatumImplCopyWith<$Res> implements $DatumCopyWith<$Res> {
  factory _$$DatumImplCopyWith(
          _$DatumImpl value, $Res Function(_$DatumImpl) then) =
      __$$DatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "year") int? year,
      @JsonKey(name: "month") int? month,
      @JsonKey(name: "totalExpenses") double? totalExpenses});
}

/// @nodoc
class __$$DatumImplCopyWithImpl<$Res>
    extends _$DatumCopyWithImpl<$Res, _$DatumImpl>
    implements _$$DatumImplCopyWith<$Res> {
  __$$DatumImplCopyWithImpl(
      _$DatumImpl _value, $Res Function(_$DatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = freezed,
    Object? month = freezed,
    Object? totalExpenses = freezed,
  }) {
    return _then(_$DatumImpl(
      year: freezed == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int?,
      month: freezed == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as int?,
      totalExpenses: freezed == totalExpenses
          ? _value.totalExpenses
          : totalExpenses // ignore: cast_nullable_to_non_nullable
              as double?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DatumImpl implements _Datum {
  const _$DatumImpl(
      {@JsonKey(name: "year") this.year,
      @JsonKey(name: "month") this.month,
      @JsonKey(name: "totalExpenses") this.totalExpenses});

  factory _$DatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$DatumImplFromJson(json);

  @override
  @JsonKey(name: "year")
  final int? year;
  @override
  @JsonKey(name: "month")
  final int? month;
  @override
  @JsonKey(name: "totalExpenses")
  final double? totalExpenses;

  @override
  String toString() {
    return 'Datum(year: $year, month: $month, totalExpenses: $totalExpenses)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DatumImpl &&
            (identical(other.year, year) || other.year == year) &&
            (identical(other.month, month) || other.month == month) &&
            (identical(other.totalExpenses, totalExpenses) ||
                other.totalExpenses == totalExpenses));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, year, month, totalExpenses);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      __$$DatumImplCopyWithImpl<_$DatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DatumImplToJson(
      this,
    );
  }
}

abstract class _Datum implements Datum {
  const factory _Datum(
          {@JsonKey(name: "year") final int? year,
          @JsonKey(name: "month") final int? month,
          @JsonKey(name: "totalExpenses") final double? totalExpenses}) =
      _$DatumImpl;

  factory _Datum.fromJson(Map<String, dynamic> json) = _$DatumImpl.fromJson;

  @override
  @JsonKey(name: "year")
  int? get year;
  @override
  @JsonKey(name: "month")
  int? get month;
  @override
  @JsonKey(name: "totalExpenses")
  double? get totalExpenses;
  @override
  @JsonKey(ignore: true)
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
