// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'logout_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$LogoutResModelImpl _$$LogoutResModelImplFromJson(Map<String, dynamic> json) =>
    _$LogoutResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$LogoutResModelImplToJson(
        _$LogoutResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
    };
