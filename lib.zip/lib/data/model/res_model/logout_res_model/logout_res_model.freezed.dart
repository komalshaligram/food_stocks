// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'logout_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

LogoutResModel _$LogoutResModelFromJson(Map<String, dynamic> json) {
  return _LogoutResModel.fromJson(json);
}

/// @nodoc
mixin _$LogoutResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $LogoutResModelCopyWith<LogoutResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LogoutResModelCopyWith<$Res> {
  factory $LogoutResModelCopyWith(
          LogoutResModel value, $Res Function(LogoutResModel) then) =
      _$LogoutResModelCopyWithImpl<$Res, LogoutResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class _$LogoutResModelCopyWithImpl<$Res, $Val extends LogoutResModel>
    implements $LogoutResModelCopyWith<$Res> {
  _$LogoutResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$LogoutResModelImplCopyWith<$Res>
    implements $LogoutResModelCopyWith<$Res> {
  factory _$$LogoutResModelImplCopyWith(_$LogoutResModelImpl value,
          $Res Function(_$LogoutResModelImpl) then) =
      __$$LogoutResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class __$$LogoutResModelImplCopyWithImpl<$Res>
    extends _$LogoutResModelCopyWithImpl<$Res, _$LogoutResModelImpl>
    implements _$$LogoutResModelImplCopyWith<$Res> {
  __$$LogoutResModelImplCopyWithImpl(
      _$LogoutResModelImpl _value, $Res Function(_$LogoutResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_$LogoutResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$LogoutResModelImpl implements _LogoutResModel {
  const _$LogoutResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message});

  factory _$LogoutResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$LogoutResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'LogoutResModel(status: $status, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LogoutResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LogoutResModelImplCopyWith<_$LogoutResModelImpl> get copyWith =>
      __$$LogoutResModelImplCopyWithImpl<_$LogoutResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$LogoutResModelImplToJson(
      this,
    );
  }
}

abstract class _LogoutResModel implements LogoutResModel {
  const factory _LogoutResModel(
      {@JsonKey(name: "status") final int? status,
      @JsonKey(name: "message") final String? message}) = _$LogoutResModelImpl;

  factory _LogoutResModel.fromJson(Map<String, dynamic> json) =
      _$LogoutResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$LogoutResModelImplCopyWith<_$LogoutResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
