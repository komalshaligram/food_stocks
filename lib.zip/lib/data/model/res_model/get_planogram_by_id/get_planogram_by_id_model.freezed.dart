// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_planogram_by_id_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetPlanogramByIdModel _$GetPlanogramByIdModelFromJson(
    Map<String, dynamic> json) {
  return _GetPlanogramByIdModel.fromJson(json);
}

/// @nodoc
mixin _$GetPlanogramByIdModel {
  int? get status => throw _privateConstructorUsedError;
  Data? get data => throw _privateConstructorUsedError;
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetPlanogramByIdModelCopyWith<GetPlanogramByIdModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetPlanogramByIdModelCopyWith<$Res> {
  factory $GetPlanogramByIdModelCopyWith(GetPlanogramByIdModel value,
          $Res Function(GetPlanogramByIdModel) then) =
      _$GetPlanogramByIdModelCopyWithImpl<$Res, GetPlanogramByIdModel>;
  @useResult
  $Res call({int? status, Data? data, String? message});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$GetPlanogramByIdModelCopyWithImpl<$Res,
        $Val extends GetPlanogramByIdModel>
    implements $GetPlanogramByIdModelCopyWith<$Res> {
  _$GetPlanogramByIdModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GetPlanogramByIdModelImplCopyWith<$Res>
    implements $GetPlanogramByIdModelCopyWith<$Res> {
  factory _$$GetPlanogramByIdModelImplCopyWith(
          _$GetPlanogramByIdModelImpl value,
          $Res Function(_$GetPlanogramByIdModelImpl) then) =
      __$$GetPlanogramByIdModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int? status, Data? data, String? message});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$GetPlanogramByIdModelImplCopyWithImpl<$Res>
    extends _$GetPlanogramByIdModelCopyWithImpl<$Res,
        _$GetPlanogramByIdModelImpl>
    implements _$$GetPlanogramByIdModelImplCopyWith<$Res> {
  __$$GetPlanogramByIdModelImplCopyWithImpl(_$GetPlanogramByIdModelImpl _value,
      $Res Function(_$GetPlanogramByIdModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$GetPlanogramByIdModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetPlanogramByIdModelImpl implements _GetPlanogramByIdModel {
  const _$GetPlanogramByIdModelImpl({this.status, this.data, this.message});

  factory _$GetPlanogramByIdModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetPlanogramByIdModelImplFromJson(json);

  @override
  final int? status;
  @override
  final Data? data;
  @override
  final String? message;

  @override
  String toString() {
    return 'GetPlanogramByIdModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetPlanogramByIdModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetPlanogramByIdModelImplCopyWith<_$GetPlanogramByIdModelImpl>
      get copyWith => __$$GetPlanogramByIdModelImplCopyWithImpl<
          _$GetPlanogramByIdModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetPlanogramByIdModelImplToJson(
      this,
    );
  }
}

abstract class _GetPlanogramByIdModel implements GetPlanogramByIdModel {
  const factory _GetPlanogramByIdModel(
      {final int? status,
      final Data? data,
      final String? message}) = _$GetPlanogramByIdModelImpl;

  factory _GetPlanogramByIdModel.fromJson(Map<String, dynamic> json) =
      _$GetPlanogramByIdModelImpl.fromJson;

  @override
  int? get status;
  @override
  Data? get data;
  @override
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$GetPlanogramByIdModelImplCopyWith<_$GetPlanogramByIdModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  Planogram? get planogram => throw _privateConstructorUsedError;
  List<PlanogramProduct>? get planogramProducts =>
      throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call({Planogram? planogram, List<PlanogramProduct>? planogramProducts});

  $PlanogramCopyWith<$Res>? get planogram;
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? planogram = freezed,
    Object? planogramProducts = freezed,
  }) {
    return _then(_value.copyWith(
      planogram: freezed == planogram
          ? _value.planogram
          : planogram // ignore: cast_nullable_to_non_nullable
              as Planogram?,
      planogramProducts: freezed == planogramProducts
          ? _value.planogramProducts
          : planogramProducts // ignore: cast_nullable_to_non_nullable
              as List<PlanogramProduct>?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $PlanogramCopyWith<$Res>? get planogram {
    if (_value.planogram == null) {
      return null;
    }

    return $PlanogramCopyWith<$Res>(_value.planogram!, (value) {
      return _then(_value.copyWith(planogram: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Planogram? planogram, List<PlanogramProduct>? planogramProducts});

  @override
  $PlanogramCopyWith<$Res>? get planogram;
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? planogram = freezed,
    Object? planogramProducts = freezed,
  }) {
    return _then(_$DataImpl(
      planogram: freezed == planogram
          ? _value.planogram
          : planogram // ignore: cast_nullable_to_non_nullable
              as Planogram?,
      planogramProducts: freezed == planogramProducts
          ? _value._planogramProducts
          : planogramProducts // ignore: cast_nullable_to_non_nullable
              as List<PlanogramProduct>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {this.planogram, final List<PlanogramProduct>? planogramProducts})
      : _planogramProducts = planogramProducts;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  final Planogram? planogram;
  final List<PlanogramProduct>? _planogramProducts;
  @override
  List<PlanogramProduct>? get planogramProducts {
    final value = _planogramProducts;
    if (value == null) return null;
    if (_planogramProducts is EqualUnmodifiableListView)
      return _planogramProducts;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'Data(planogram: $planogram, planogramProducts: $planogramProducts)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.planogram, planogram) ||
                other.planogram == planogram) &&
            const DeepCollectionEquality()
                .equals(other._planogramProducts, _planogramProducts));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, planogram,
      const DeepCollectionEquality().hash(_planogramProducts));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {final Planogram? planogram,
      final List<PlanogramProduct>? planogramProducts}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  Planogram? get planogram;
  @override
  List<PlanogramProduct>? get planogramProducts;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Planogram _$PlanogramFromJson(Map<String, dynamic> json) {
  return _Planogram.fromJson(json);
}

/// @nodoc
mixin _$Planogram {
  String? get id => throw _privateConstructorUsedError;
  String? get planogramName => throw _privateConstructorUsedError;
  DateTime? get fromDate => throw _privateConstructorUsedError;
  DateTime? get untilDate => throw _privateConstructorUsedError;
  String? get categoryId => throw _privateConstructorUsedError;
  String? get subCategoryId => throw _privateConstructorUsedError;
  bool? get isDeleted => throw _privateConstructorUsedError;
  String? get createdBy => throw _privateConstructorUsedError;
  String? get updatedBy => throw _privateConstructorUsedError;
  DateTime? get createdAt => throw _privateConstructorUsedError;
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  int? get v => throw _privateConstructorUsedError;
  String? get categoryName => throw _privateConstructorUsedError;
  String? get subCategoryName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PlanogramCopyWith<Planogram> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramCopyWith<$Res> {
  factory $PlanogramCopyWith(Planogram value, $Res Function(Planogram) then) =
      _$PlanogramCopyWithImpl<$Res, Planogram>;
  @useResult
  $Res call(
      {String? id,
      String? planogramName,
      DateTime? fromDate,
      DateTime? untilDate,
      String? categoryId,
      String? subCategoryId,
      bool? isDeleted,
      String? createdBy,
      String? updatedBy,
      DateTime? createdAt,
      DateTime? updatedAt,
      int? v,
      String? categoryName,
      String? subCategoryName});
}

/// @nodoc
class _$PlanogramCopyWithImpl<$Res, $Val extends Planogram>
    implements $PlanogramCopyWith<$Res> {
  _$PlanogramCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? planogramName = freezed,
    Object? fromDate = freezed,
    Object? untilDate = freezed,
    Object? categoryId = freezed,
    Object? subCategoryId = freezed,
    Object? isDeleted = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? categoryName = freezed,
    Object? subCategoryName = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      planogramName: freezed == planogramName
          ? _value.planogramName
          : planogramName // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      untilDate: freezed == untilDate
          ? _value.untilDate
          : untilDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PlanogramImplCopyWith<$Res>
    implements $PlanogramCopyWith<$Res> {
  factory _$$PlanogramImplCopyWith(
          _$PlanogramImpl value, $Res Function(_$PlanogramImpl) then) =
      __$$PlanogramImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? planogramName,
      DateTime? fromDate,
      DateTime? untilDate,
      String? categoryId,
      String? subCategoryId,
      bool? isDeleted,
      String? createdBy,
      String? updatedBy,
      DateTime? createdAt,
      DateTime? updatedAt,
      int? v,
      String? categoryName,
      String? subCategoryName});
}

/// @nodoc
class __$$PlanogramImplCopyWithImpl<$Res>
    extends _$PlanogramCopyWithImpl<$Res, _$PlanogramImpl>
    implements _$$PlanogramImplCopyWith<$Res> {
  __$$PlanogramImplCopyWithImpl(
      _$PlanogramImpl _value, $Res Function(_$PlanogramImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? planogramName = freezed,
    Object? fromDate = freezed,
    Object? untilDate = freezed,
    Object? categoryId = freezed,
    Object? subCategoryId = freezed,
    Object? isDeleted = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? categoryName = freezed,
    Object? subCategoryName = freezed,
  }) {
    return _then(_$PlanogramImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      planogramName: freezed == planogramName
          ? _value.planogramName
          : planogramName // ignore: cast_nullable_to_non_nullable
              as String?,
      fromDate: freezed == fromDate
          ? _value.fromDate
          : fromDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      untilDate: freezed == untilDate
          ? _value.untilDate
          : untilDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlanogramImpl implements _Planogram {
  const _$PlanogramImpl(
      {this.id,
      this.planogramName,
      this.fromDate,
      this.untilDate,
      this.categoryId,
      this.subCategoryId,
      this.isDeleted,
      this.createdBy,
      this.updatedBy,
      this.createdAt,
      this.updatedAt,
      this.v,
      this.categoryName,
      this.subCategoryName});

  factory _$PlanogramImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlanogramImplFromJson(json);

  @override
  final String? id;
  @override
  final String? planogramName;
  @override
  final DateTime? fromDate;
  @override
  final DateTime? untilDate;
  @override
  final String? categoryId;
  @override
  final String? subCategoryId;
  @override
  final bool? isDeleted;
  @override
  final String? createdBy;
  @override
  final String? updatedBy;
  @override
  final DateTime? createdAt;
  @override
  final DateTime? updatedAt;
  @override
  final int? v;
  @override
  final String? categoryName;
  @override
  final String? subCategoryName;

  @override
  String toString() {
    return 'Planogram(id: $id, planogramName: $planogramName, fromDate: $fromDate, untilDate: $untilDate, categoryId: $categoryId, subCategoryId: $subCategoryId, isDeleted: $isDeleted, createdBy: $createdBy, updatedBy: $updatedBy, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, categoryName: $categoryName, subCategoryName: $subCategoryName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.planogramName, planogramName) ||
                other.planogramName == planogramName) &&
            (identical(other.fromDate, fromDate) ||
                other.fromDate == fromDate) &&
            (identical(other.untilDate, untilDate) ||
                other.untilDate == untilDate) &&
            (identical(other.categoryId, categoryId) ||
                other.categoryId == categoryId) &&
            (identical(other.subCategoryId, subCategoryId) ||
                other.subCategoryId == subCategoryId) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.categoryName, categoryName) ||
                other.categoryName == categoryName) &&
            (identical(other.subCategoryName, subCategoryName) ||
                other.subCategoryName == subCategoryName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      planogramName,
      fromDate,
      untilDate,
      categoryId,
      subCategoryId,
      isDeleted,
      createdBy,
      updatedBy,
      createdAt,
      updatedAt,
      v,
      categoryName,
      subCategoryName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramImplCopyWith<_$PlanogramImpl> get copyWith =>
      __$$PlanogramImplCopyWithImpl<_$PlanogramImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlanogramImplToJson(
      this,
    );
  }
}

abstract class _Planogram implements Planogram {
  const factory _Planogram(
      {final String? id,
      final String? planogramName,
      final DateTime? fromDate,
      final DateTime? untilDate,
      final String? categoryId,
      final String? subCategoryId,
      final bool? isDeleted,
      final String? createdBy,
      final String? updatedBy,
      final DateTime? createdAt,
      final DateTime? updatedAt,
      final int? v,
      final String? categoryName,
      final String? subCategoryName}) = _$PlanogramImpl;

  factory _Planogram.fromJson(Map<String, dynamic> json) =
      _$PlanogramImpl.fromJson;

  @override
  String? get id;
  @override
  String? get planogramName;
  @override
  DateTime? get fromDate;
  @override
  DateTime? get untilDate;
  @override
  String? get categoryId;
  @override
  String? get subCategoryId;
  @override
  bool? get isDeleted;
  @override
  String? get createdBy;
  @override
  String? get updatedBy;
  @override
  DateTime? get createdAt;
  @override
  DateTime? get updatedAt;
  @override
  int? get v;
  @override
  String? get categoryName;
  @override
  String? get subCategoryName;
  @override
  @JsonKey(ignore: true)
  _$$PlanogramImplCopyWith<_$PlanogramImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

PlanogramProduct _$PlanogramProductFromJson(Map<String, dynamic> json) {
  return _PlanogramProduct.fromJson(json);
}

/// @nodoc
mixin _$PlanogramProduct {
  String? get id => throw _privateConstructorUsedError;
  int? get order => throw _privateConstructorUsedError;
  String? get productId => throw _privateConstructorUsedError;
  String? get image => throw _privateConstructorUsedError;
  String? get productName => throw _privateConstructorUsedError;
  bool? get isPesach => throw _privateConstructorUsedError;
  String? get nmMashlim => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PlanogramProductCopyWith<PlanogramProduct> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramProductCopyWith<$Res> {
  factory $PlanogramProductCopyWith(
          PlanogramProduct value, $Res Function(PlanogramProduct) then) =
      _$PlanogramProductCopyWithImpl<$Res, PlanogramProduct>;
  @useResult
  $Res call(
      {String? id,
      int? order,
      String? productId,
      String? image,
      String? productName,
      bool? isPesach,
      String? nmMashlim});
}

/// @nodoc
class _$PlanogramProductCopyWithImpl<$Res, $Val extends PlanogramProduct>
    implements $PlanogramProductCopyWith<$Res> {
  _$PlanogramProductCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? order = freezed,
    Object? productId = freezed,
    Object? image = freezed,
    Object? productName = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      image: freezed == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PlanogramProductImplCopyWith<$Res>
    implements $PlanogramProductCopyWith<$Res> {
  factory _$$PlanogramProductImplCopyWith(_$PlanogramProductImpl value,
          $Res Function(_$PlanogramProductImpl) then) =
      __$$PlanogramProductImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      int? order,
      String? productId,
      String? image,
      String? productName,
      bool? isPesach,
      String? nmMashlim});
}

/// @nodoc
class __$$PlanogramProductImplCopyWithImpl<$Res>
    extends _$PlanogramProductCopyWithImpl<$Res, _$PlanogramProductImpl>
    implements _$$PlanogramProductImplCopyWith<$Res> {
  __$$PlanogramProductImplCopyWithImpl(_$PlanogramProductImpl _value,
      $Res Function(_$PlanogramProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? order = freezed,
    Object? productId = freezed,
    Object? image = freezed,
    Object? productName = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
  }) {
    return _then(_$PlanogramProductImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      image: freezed == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlanogramProductImpl implements _PlanogramProduct {
  const _$PlanogramProductImpl(
      {this.id,
      this.order,
      this.productId,
      this.image,
      this.productName,
      this.isPesach,
      this.nmMashlim});

  factory _$PlanogramProductImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlanogramProductImplFromJson(json);

  @override
  final String? id;
  @override
  final int? order;
  @override
  final String? productId;
  @override
  final String? image;
  @override
  final String? productName;
  @override
  final bool? isPesach;
  @override
  final String? nmMashlim;

  @override
  String toString() {
    return 'PlanogramProduct(id: $id, order: $order, productId: $productId, image: $image, productName: $productName, isPesach: $isPesach, nmMashlim: $nmMashlim)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramProductImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.order, order) || other.order == order) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, order, productId, image,
      productName, isPesach, nmMashlim);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramProductImplCopyWith<_$PlanogramProductImpl> get copyWith =>
      __$$PlanogramProductImplCopyWithImpl<_$PlanogramProductImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlanogramProductImplToJson(
      this,
    );
  }
}

abstract class _PlanogramProduct implements PlanogramProduct {
  const factory _PlanogramProduct(
      {final String? id,
      final int? order,
      final String? productId,
      final String? image,
      final String? productName,
      final bool? isPesach,
      final String? nmMashlim}) = _$PlanogramProductImpl;

  factory _PlanogramProduct.fromJson(Map<String, dynamic> json) =
      _$PlanogramProductImpl.fromJson;

  @override
  String? get id;
  @override
  int? get order;
  @override
  String? get productId;
  @override
  String? get image;
  @override
  String? get productName;
  @override
  bool? get isPesach;
  @override
  String? get nmMashlim;
  @override
  @JsonKey(ignore: true)
  _$$PlanogramProductImplCopyWith<_$PlanogramProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
