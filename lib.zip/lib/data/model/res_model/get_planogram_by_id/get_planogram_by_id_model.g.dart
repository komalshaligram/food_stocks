// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_planogram_by_id_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetPlanogramByIdModelImpl _$$GetPlanogramByIdModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetPlanogramByIdModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$GetPlanogramByIdModelImplToJson(
        _$GetPlanogramByIdModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      planogram: json['planogram'] == null
          ? null
          : Planogram.fromJson(json['planogram'] as Map<String, dynamic>),
      planogramProducts: (json['planogramProducts'] as List<dynamic>?)
          ?.map((e) => PlanogramProduct.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'planogram': instance.planogram,
      'planogramProducts': instance.planogramProducts,
    };

_$PlanogramImpl _$$PlanogramImplFromJson(Map<String, dynamic> json) =>
    _$PlanogramImpl(
      id: json['id'] as String?,
      planogramName: json['planogramName'] as String?,
      fromDate: json['fromDate'] == null
          ? null
          : DateTime.parse(json['fromDate'] as String),
      untilDate: json['untilDate'] == null
          ? null
          : DateTime.parse(json['untilDate'] as String),
      categoryId: json['categoryId'] as String?,
      subCategoryId: json['subCategoryId'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['v'] as int?,
      categoryName: json['categoryName'] as String?,
      subCategoryName: json['subCategoryName'] as String?,
    );

Map<String, dynamic> _$$PlanogramImplToJson(_$PlanogramImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'planogramName': instance.planogramName,
      'fromDate': instance.fromDate?.toIso8601String(),
      'untilDate': instance.untilDate?.toIso8601String(),
      'categoryId': instance.categoryId,
      'subCategoryId': instance.subCategoryId,
      'isDeleted': instance.isDeleted,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      'v': instance.v,
      'categoryName': instance.categoryName,
      'subCategoryName': instance.subCategoryName,
    };

_$PlanogramProductImpl _$$PlanogramProductImplFromJson(
        Map<String, dynamic> json) =>
    _$PlanogramProductImpl(
      id: json['id'] as String?,
      order: json['order'] as int?,
      productId: json['productId'] as String?,
      image: json['image'] as String?,
      productName: json['productName'] as String?,
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
    );

Map<String, dynamic> _$$PlanogramProductImplToJson(
        _$PlanogramProductImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'order': instance.order,
      'productId': instance.productId,
      'image': instance.image,
      'productName': instance.productName,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
    };
