// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'company_products_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CompanyProductsResModel _$CompanyProductsResModelFromJson(
    Map<String, dynamic> json) {
  return _CompanyProductsResModel.fromJson(json);
}

/// @nodoc
mixin _$CompanyProductsResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<CompanyData>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompanyProductsResModelCopyWith<CompanyProductsResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompanyProductsResModelCopyWith<$Res> {
  factory $CompanyProductsResModelCopyWith(CompanyProductsResModel value,
          $Res Function(CompanyProductsResModel) then) =
      _$CompanyProductsResModelCopyWithImpl<$Res, CompanyProductsResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<CompanyData>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$CompanyProductsResModelCopyWithImpl<$Res,
        $Val extends CompanyProductsResModel>
    implements $CompanyProductsResModelCopyWith<$Res> {
  _$CompanyProductsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<CompanyData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$CompanyProductsResModelImplCopyWith<$Res>
    implements $CompanyProductsResModelCopyWith<$Res> {
  factory _$$CompanyProductsResModelImplCopyWith(
          _$CompanyProductsResModelImpl value,
          $Res Function(_$CompanyProductsResModelImpl) then) =
      __$$CompanyProductsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<CompanyData>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$CompanyProductsResModelImplCopyWithImpl<$Res>
    extends _$CompanyProductsResModelCopyWithImpl<$Res,
        _$CompanyProductsResModelImpl>
    implements _$$CompanyProductsResModelImplCopyWith<$Res> {
  __$$CompanyProductsResModelImplCopyWithImpl(
      _$CompanyProductsResModelImpl _value,
      $Res Function(_$CompanyProductsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_$CompanyProductsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<CompanyData>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CompanyProductsResModelImpl implements _CompanyProductsResModel {
  const _$CompanyProductsResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<CompanyData>? data,
      @JsonKey(name: "metaData") this.metaData,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$CompanyProductsResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$CompanyProductsResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<CompanyData>? _data;
  @override
  @JsonKey(name: "data")
  List<CompanyData>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'CompanyProductsResModel(status: $status, data: $data, metaData: $metaData, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CompanyProductsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), metaData, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CompanyProductsResModelImplCopyWith<_$CompanyProductsResModelImpl>
      get copyWith => __$$CompanyProductsResModelImplCopyWithImpl<
          _$CompanyProductsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CompanyProductsResModelImplToJson(
      this,
    );
  }
}

abstract class _CompanyProductsResModel implements CompanyProductsResModel {
  const factory _CompanyProductsResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final List<CompanyData>? data,
          @JsonKey(name: "metaData") final MetaData? metaData,
          @JsonKey(name: "message") final String? message}) =
      _$CompanyProductsResModelImpl;

  factory _CompanyProductsResModel.fromJson(Map<String, dynamic> json) =
      _$CompanyProductsResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<CompanyData>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$CompanyProductsResModelImplCopyWith<_$CompanyProductsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

CompanyData _$CompanyDataFromJson(Map<String, dynamic> json) {
  return _CompanyData.fromJson(json);
}

/// @nodoc
mixin _$CompanyData {
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeightCardboard")
  String? get totalWeightCardboard => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeightSurface")
  String? get totalWeightSurface => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  String? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "brandId")
  String? get brandId => throw _privateConstructorUsedError;
  @JsonKey(name: "brandLogo")
  String? get brandLogo => throw _privateConstructorUsedError;
  @JsonKey(name: "manufactureName")
  String? get manufactureName => throw _privateConstructorUsedError;
  @JsonKey(name: "healthAndLifestye")
  String? get healthAndLifestye => throw _privateConstructorUsedError;
  @JsonKey(name: "productDescription")
  String? get productDescription => throw _privateConstructorUsedError;
  @JsonKey(name: "component")
  String? get component => throw _privateConstructorUsedError;
  @JsonKey(name: "nutritionalValue")
  String? get nutritionalValue => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  @JsonKey(name: "images")
  List<Image>? get images => throw _privateConstructorUsedError;
  @JsonKey(name: "qrcode")
  String? get qrcode => throw _privateConstructorUsedError;
  @JsonKey(name: "sku")
  String? get sku => throw _privateConstructorUsedError;
  @JsonKey(name: "categories")
  String? get categories => throw _privateConstructorUsedError;
  @JsonKey(name: "subcategories")
  String? get subcategories =>
      throw _privateConstructorUsedError; // @JsonKey(name: "subsubcategories") String? subsubcategories,
  @JsonKey(name: "manufacturingCountry")
  String? get manufacturingCountry => throw _privateConstructorUsedError;
  @JsonKey(name: "productType")
  String? get productType => throw _privateConstructorUsedError;
  @JsonKey(name: "caseType")
  String? get caseType => throw _privateConstructorUsedError;
  @JsonKey(name: "scale")
  String? get scale => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "totalSale")
  int? get totalSale => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  dynamic get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  double? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "isPesach")
  bool? get isPesach => throw _privateConstructorUsedError;
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim => throw _privateConstructorUsedError;
  String? get lowStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CompanyDataCopyWith<CompanyData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompanyDataCopyWith<$Res> {
  factory $CompanyDataCopyWith(
          CompanyData value, $Res Function(CompanyData) then) =
      _$CompanyDataCopyWithImpl<$Res, CompanyData>;
  @useResult
  $Res call(
      {@JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeightCardboard") String? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") String? totalWeightSurface,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "brandId") String? brandId,
      @JsonKey(name: "brandLogo") String? brandLogo,
      @JsonKey(name: "manufactureName") String? manufactureName,
      @JsonKey(name: "healthAndLifestye") String? healthAndLifestye,
      @JsonKey(name: "productDescription") String? productDescription,
      @JsonKey(name: "component") String? component,
      @JsonKey(name: "nutritionalValue") String? nutritionalValue,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "categories") String? categories,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "manufacturingCountry") String? manufacturingCountry,
      @JsonKey(name: "productType") String? productType,
      @JsonKey(name: "caseType") String? caseType,
      @JsonKey(name: "scale") String? scale,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "totalSale") int? totalSale,
      @JsonKey(name: "productStock") dynamic productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      String? lowStock});
}

/// @nodoc
class _$CompanyDataCopyWithImpl<$Res, $Val extends CompanyData>
    implements $CompanyDataCopyWith<$Res> {
  _$CompanyDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberOfUnit = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeightCardboard = freezed,
    Object? totalWeightSurface = freezed,
    Object? totalWeight = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? id = freezed,
    Object? productName = freezed,
    Object? brandId = freezed,
    Object? brandLogo = freezed,
    Object? manufactureName = freezed,
    Object? healthAndLifestye = freezed,
    Object? productDescription = freezed,
    Object? component = freezed,
    Object? nutritionalValue = freezed,
    Object? mainImage = freezed,
    Object? images = freezed,
    Object? qrcode = freezed,
    Object? sku = freezed,
    Object? categories = freezed,
    Object? subcategories = freezed,
    Object? manufacturingCountry = freezed,
    Object? productType = freezed,
    Object? caseType = freezed,
    Object? scale = freezed,
    Object? status = freezed,
    Object? totalSale = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_value.copyWith(
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightCardboard: freezed == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightSurface: freezed == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandId: freezed == brandId
          ? _value.brandId
          : brandId // ignore: cast_nullable_to_non_nullable
              as String?,
      brandLogo: freezed == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String?,
      manufactureName: freezed == manufactureName
          ? _value.manufactureName
          : manufactureName // ignore: cast_nullable_to_non_nullable
              as String?,
      healthAndLifestye: freezed == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String?,
      productDescription: freezed == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      component: freezed == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String?,
      nutritionalValue: freezed == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value.images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      categories: freezed == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      manufacturingCountry: freezed == manufacturingCountry
          ? _value.manufacturingCountry
          : manufacturingCountry // ignore: cast_nullable_to_non_nullable
              as String?,
      productType: freezed == productType
          ? _value.productType
          : productType // ignore: cast_nullable_to_non_nullable
              as String?,
      caseType: freezed == caseType
          ? _value.caseType
          : caseType // ignore: cast_nullable_to_non_nullable
              as String?,
      scale: freezed == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as dynamic,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CompanyDataImplCopyWith<$Res>
    implements $CompanyDataCopyWith<$Res> {
  factory _$$CompanyDataImplCopyWith(
          _$CompanyDataImpl value, $Res Function(_$CompanyDataImpl) then) =
      __$$CompanyDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "numberOfUnit") String? numberOfUnit,
      @JsonKey(name: "itemsWeight") String? itemsWeight,
      @JsonKey(name: "totalWeightCardboard") String? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") String? totalWeightSurface,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "_id") String? id,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "brandId") String? brandId,
      @JsonKey(name: "brandLogo") String? brandLogo,
      @JsonKey(name: "manufactureName") String? manufactureName,
      @JsonKey(name: "healthAndLifestye") String? healthAndLifestye,
      @JsonKey(name: "productDescription") String? productDescription,
      @JsonKey(name: "component") String? component,
      @JsonKey(name: "nutritionalValue") String? nutritionalValue,
      @JsonKey(name: "mainImage") String? mainImage,
      @JsonKey(name: "images") List<Image>? images,
      @JsonKey(name: "qrcode") String? qrcode,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "categories") String? categories,
      @JsonKey(name: "subcategories") String? subcategories,
      @JsonKey(name: "manufacturingCountry") String? manufacturingCountry,
      @JsonKey(name: "productType") String? productType,
      @JsonKey(name: "caseType") String? caseType,
      @JsonKey(name: "scale") String? scale,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "totalSale") int? totalSale,
      @JsonKey(name: "productStock") dynamic productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "isPesach") bool? isPesach,
      @JsonKey(name: "nmMashlim") String? nmMashlim,
      String? lowStock});
}

/// @nodoc
class __$$CompanyDataImplCopyWithImpl<$Res>
    extends _$CompanyDataCopyWithImpl<$Res, _$CompanyDataImpl>
    implements _$$CompanyDataImplCopyWith<$Res> {
  __$$CompanyDataImplCopyWithImpl(
      _$CompanyDataImpl _value, $Res Function(_$CompanyDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? numberOfUnit = freezed,
    Object? itemsWeight = freezed,
    Object? totalWeightCardboard = freezed,
    Object? totalWeightSurface = freezed,
    Object? totalWeight = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? id = freezed,
    Object? productName = freezed,
    Object? brandId = freezed,
    Object? brandLogo = freezed,
    Object? manufactureName = freezed,
    Object? healthAndLifestye = freezed,
    Object? productDescription = freezed,
    Object? component = freezed,
    Object? nutritionalValue = freezed,
    Object? mainImage = freezed,
    Object? images = freezed,
    Object? qrcode = freezed,
    Object? sku = freezed,
    Object? categories = freezed,
    Object? subcategories = freezed,
    Object? manufacturingCountry = freezed,
    Object? productType = freezed,
    Object? caseType = freezed,
    Object? scale = freezed,
    Object? status = freezed,
    Object? totalSale = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? isPesach = freezed,
    Object? nmMashlim = freezed,
    Object? lowStock = freezed,
  }) {
    return _then(_$CompanyDataImpl(
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as String?,
      itemsWeight: freezed == itemsWeight
          ? _value.itemsWeight
          : itemsWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightCardboard: freezed == totalWeightCardboard
          ? _value.totalWeightCardboard
          : totalWeightCardboard // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeightSurface: freezed == totalWeightSurface
          ? _value.totalWeightSurface
          : totalWeightSurface // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      brandId: freezed == brandId
          ? _value.brandId
          : brandId // ignore: cast_nullable_to_non_nullable
              as String?,
      brandLogo: freezed == brandLogo
          ? _value.brandLogo
          : brandLogo // ignore: cast_nullable_to_non_nullable
              as String?,
      manufactureName: freezed == manufactureName
          ? _value.manufactureName
          : manufactureName // ignore: cast_nullable_to_non_nullable
              as String?,
      healthAndLifestye: freezed == healthAndLifestye
          ? _value.healthAndLifestye
          : healthAndLifestye // ignore: cast_nullable_to_non_nullable
              as String?,
      productDescription: freezed == productDescription
          ? _value.productDescription
          : productDescription // ignore: cast_nullable_to_non_nullable
              as String?,
      component: freezed == component
          ? _value.component
          : component // ignore: cast_nullable_to_non_nullable
              as String?,
      nutritionalValue: freezed == nutritionalValue
          ? _value.nutritionalValue
          : nutritionalValue // ignore: cast_nullable_to_non_nullable
              as String?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      images: freezed == images
          ? _value._images
          : images // ignore: cast_nullable_to_non_nullable
              as List<Image>?,
      qrcode: freezed == qrcode
          ? _value.qrcode
          : qrcode // ignore: cast_nullable_to_non_nullable
              as String?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      categories: freezed == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as String?,
      subcategories: freezed == subcategories
          ? _value.subcategories
          : subcategories // ignore: cast_nullable_to_non_nullable
              as String?,
      manufacturingCountry: freezed == manufacturingCountry
          ? _value.manufacturingCountry
          : manufacturingCountry // ignore: cast_nullable_to_non_nullable
              as String?,
      productType: freezed == productType
          ? _value.productType
          : productType // ignore: cast_nullable_to_non_nullable
              as String?,
      caseType: freezed == caseType
          ? _value.caseType
          : caseType // ignore: cast_nullable_to_non_nullable
              as String?,
      scale: freezed == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      totalSale: freezed == totalSale
          ? _value.totalSale
          : totalSale // ignore: cast_nullable_to_non_nullable
              as int?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as dynamic,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      isPesach: freezed == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool?,
      nmMashlim: freezed == nmMashlim
          ? _value.nmMashlim
          : nmMashlim // ignore: cast_nullable_to_non_nullable
              as String?,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CompanyDataImpl implements _CompanyData {
  const _$CompanyDataImpl(
      {@JsonKey(name: "numberOfUnit") this.numberOfUnit,
      @JsonKey(name: "itemsWeight") this.itemsWeight,
      @JsonKey(name: "totalWeightCardboard") this.totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") this.totalWeightSurface,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "_id") this.id,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "brandId") this.brandId,
      @JsonKey(name: "brandLogo") this.brandLogo,
      @JsonKey(name: "manufactureName") this.manufactureName,
      @JsonKey(name: "healthAndLifestye") this.healthAndLifestye,
      @JsonKey(name: "productDescription") this.productDescription,
      @JsonKey(name: "component") this.component,
      @JsonKey(name: "nutritionalValue") this.nutritionalValue,
      @JsonKey(name: "mainImage") this.mainImage,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "qrcode") this.qrcode,
      @JsonKey(name: "sku") this.sku,
      @JsonKey(name: "categories") this.categories,
      @JsonKey(name: "subcategories") this.subcategories,
      @JsonKey(name: "manufacturingCountry") this.manufacturingCountry,
      @JsonKey(name: "productType") this.productType,
      @JsonKey(name: "caseType") this.caseType,
      @JsonKey(name: "scale") this.scale,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "totalSale") this.totalSale,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "isPesach") this.isPesach,
      @JsonKey(name: "nmMashlim") this.nmMashlim,
      this.lowStock})
      : _images = images;

  factory _$CompanyDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$CompanyDataImplFromJson(json);

  @override
  @JsonKey(name: "numberOfUnit")
  final String? numberOfUnit;
  @override
  @JsonKey(name: "itemsWeight")
  final String? itemsWeight;
  @override
  @JsonKey(name: "totalWeightCardboard")
  final String? totalWeightCardboard;
  @override
  @JsonKey(name: "totalWeightSurface")
  final String? totalWeightSurface;
  @override
  @JsonKey(name: "totalWeight")
  final String? totalWeight;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "brandId")
  final String? brandId;
  @override
  @JsonKey(name: "brandLogo")
  final String? brandLogo;
  @override
  @JsonKey(name: "manufactureName")
  final String? manufactureName;
  @override
  @JsonKey(name: "healthAndLifestye")
  final String? healthAndLifestye;
  @override
  @JsonKey(name: "productDescription")
  final String? productDescription;
  @override
  @JsonKey(name: "component")
  final String? component;
  @override
  @JsonKey(name: "nutritionalValue")
  final String? nutritionalValue;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  final List<Image>? _images;
  @override
  @JsonKey(name: "images")
  List<Image>? get images {
    final value = _images;
    if (value == null) return null;
    if (_images is EqualUnmodifiableListView) return _images;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "qrcode")
  final String? qrcode;
  @override
  @JsonKey(name: "sku")
  final String? sku;
  @override
  @JsonKey(name: "categories")
  final String? categories;
  @override
  @JsonKey(name: "subcategories")
  final String? subcategories;
// @JsonKey(name: "subsubcategories") String? subsubcategories,
  @override
  @JsonKey(name: "manufacturingCountry")
  final String? manufacturingCountry;
  @override
  @JsonKey(name: "productType")
  final String? productType;
  @override
  @JsonKey(name: "caseType")
  final String? caseType;
  @override
  @JsonKey(name: "scale")
  final String? scale;
  @override
  @JsonKey(name: "status")
  final String? status;
  @override
  @JsonKey(name: "totalSale")
  final int? totalSale;
  @override
  @JsonKey(name: "productStock")
  final dynamic productStock;
  @override
  @JsonKey(name: "productPrice")
  final double? productPrice;
  @override
  @JsonKey(name: "isPesach")
  final bool? isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  final String? nmMashlim;
  @override
  final String? lowStock;

  @override
  String toString() {
    return 'CompanyData(numberOfUnit: $numberOfUnit, itemsWeight: $itemsWeight, totalWeightCardboard: $totalWeightCardboard, totalWeightSurface: $totalWeightSurface, totalWeight: $totalWeight, createdAt: $createdAt, updatedAt: $updatedAt, id: $id, productName: $productName, brandId: $brandId, brandLogo: $brandLogo, manufactureName: $manufactureName, healthAndLifestye: $healthAndLifestye, productDescription: $productDescription, component: $component, nutritionalValue: $nutritionalValue, mainImage: $mainImage, images: $images, qrcode: $qrcode, sku: $sku, categories: $categories, subcategories: $subcategories, manufacturingCountry: $manufacturingCountry, productType: $productType, caseType: $caseType, scale: $scale, status: $status, totalSale: $totalSale, productStock: $productStock, productPrice: $productPrice, isPesach: $isPesach, nmMashlim: $nmMashlim, lowStock: $lowStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CompanyDataImpl &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit) &&
            (identical(other.itemsWeight, itemsWeight) ||
                other.itemsWeight == itemsWeight) &&
            (identical(other.totalWeightCardboard, totalWeightCardboard) ||
                other.totalWeightCardboard == totalWeightCardboard) &&
            (identical(other.totalWeightSurface, totalWeightSurface) ||
                other.totalWeightSurface == totalWeightSurface) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.brandId, brandId) || other.brandId == brandId) &&
            (identical(other.brandLogo, brandLogo) ||
                other.brandLogo == brandLogo) &&
            (identical(other.manufactureName, manufactureName) ||
                other.manufactureName == manufactureName) &&
            (identical(other.healthAndLifestye, healthAndLifestye) ||
                other.healthAndLifestye == healthAndLifestye) &&
            (identical(other.productDescription, productDescription) ||
                other.productDescription == productDescription) &&
            (identical(other.component, component) ||
                other.component == component) &&
            (identical(other.nutritionalValue, nutritionalValue) ||
                other.nutritionalValue == nutritionalValue) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            const DeepCollectionEquality().equals(other._images, _images) &&
            (identical(other.qrcode, qrcode) || other.qrcode == qrcode) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            (identical(other.categories, categories) ||
                other.categories == categories) &&
            (identical(other.subcategories, subcategories) ||
                other.subcategories == subcategories) &&
            (identical(other.manufacturingCountry, manufacturingCountry) ||
                other.manufacturingCountry == manufacturingCountry) &&
            (identical(other.productType, productType) ||
                other.productType == productType) &&
            (identical(other.caseType, caseType) ||
                other.caseType == caseType) &&
            (identical(other.scale, scale) || other.scale == scale) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.totalSale, totalSale) ||
                other.totalSale == totalSale) &&
            const DeepCollectionEquality()
                .equals(other.productStock, productStock) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach) &&
            (identical(other.nmMashlim, nmMashlim) ||
                other.nmMashlim == nmMashlim) &&
            (identical(other.lowStock, lowStock) ||
                other.lowStock == lowStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        numberOfUnit,
        itemsWeight,
        totalWeightCardboard,
        totalWeightSurface,
        totalWeight,
        createdAt,
        updatedAt,
        id,
        productName,
        brandId,
        brandLogo,
        manufactureName,
        healthAndLifestye,
        productDescription,
        component,
        nutritionalValue,
        mainImage,
        const DeepCollectionEquality().hash(_images),
        qrcode,
        sku,
        categories,
        subcategories,
        manufacturingCountry,
        productType,
        caseType,
        scale,
        status,
        totalSale,
        const DeepCollectionEquality().hash(productStock),
        productPrice,
        isPesach,
        nmMashlim,
        lowStock
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CompanyDataImplCopyWith<_$CompanyDataImpl> get copyWith =>
      __$$CompanyDataImplCopyWithImpl<_$CompanyDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CompanyDataImplToJson(
      this,
    );
  }
}

abstract class _CompanyData implements CompanyData {
  const factory _CompanyData(
      {@JsonKey(name: "numberOfUnit") final String? numberOfUnit,
      @JsonKey(name: "itemsWeight") final String? itemsWeight,
      @JsonKey(name: "totalWeightCardboard") final String? totalWeightCardboard,
      @JsonKey(name: "totalWeightSurface") final String? totalWeightSurface,
      @JsonKey(name: "totalWeight") final String? totalWeight,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "_id") final String? id,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "brandId") final String? brandId,
      @JsonKey(name: "brandLogo") final String? brandLogo,
      @JsonKey(name: "manufactureName") final String? manufactureName,
      @JsonKey(name: "healthAndLifestye") final String? healthAndLifestye,
      @JsonKey(name: "productDescription") final String? productDescription,
      @JsonKey(name: "component") final String? component,
      @JsonKey(name: "nutritionalValue") final String? nutritionalValue,
      @JsonKey(name: "mainImage") final String? mainImage,
      @JsonKey(name: "images") final List<Image>? images,
      @JsonKey(name: "qrcode") final String? qrcode,
      @JsonKey(name: "sku") final String? sku,
      @JsonKey(name: "categories") final String? categories,
      @JsonKey(name: "subcategories") final String? subcategories,
      @JsonKey(name: "manufacturingCountry") final String? manufacturingCountry,
      @JsonKey(name: "productType") final String? productType,
      @JsonKey(name: "caseType") final String? caseType,
      @JsonKey(name: "scale") final String? scale,
      @JsonKey(name: "status") final String? status,
      @JsonKey(name: "totalSale") final int? totalSale,
      @JsonKey(name: "productStock") final dynamic productStock,
      @JsonKey(name: "productPrice") final double? productPrice,
      @JsonKey(name: "isPesach") final bool? isPesach,
      @JsonKey(name: "nmMashlim") final String? nmMashlim,
      final String? lowStock}) = _$CompanyDataImpl;

  factory _CompanyData.fromJson(Map<String, dynamic> json) =
      _$CompanyDataImpl.fromJson;

  @override
  @JsonKey(name: "numberOfUnit")
  String? get numberOfUnit;
  @override
  @JsonKey(name: "itemsWeight")
  String? get itemsWeight;
  @override
  @JsonKey(name: "totalWeightCardboard")
  String? get totalWeightCardboard;
  @override
  @JsonKey(name: "totalWeightSurface")
  String? get totalWeightSurface;
  @override
  @JsonKey(name: "totalWeight")
  String? get totalWeight;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "brandId")
  String? get brandId;
  @override
  @JsonKey(name: "brandLogo")
  String? get brandLogo;
  @override
  @JsonKey(name: "manufactureName")
  String? get manufactureName;
  @override
  @JsonKey(name: "healthAndLifestye")
  String? get healthAndLifestye;
  @override
  @JsonKey(name: "productDescription")
  String? get productDescription;
  @override
  @JsonKey(name: "component")
  String? get component;
  @override
  @JsonKey(name: "nutritionalValue")
  String? get nutritionalValue;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  @JsonKey(name: "images")
  List<Image>? get images;
  @override
  @JsonKey(name: "qrcode")
  String? get qrcode;
  @override
  @JsonKey(name: "sku")
  String? get sku;
  @override
  @JsonKey(name: "categories")
  String? get categories;
  @override
  @JsonKey(name: "subcategories")
  String? get subcategories;
  @override // @JsonKey(name: "subsubcategories") String? subsubcategories,
  @JsonKey(name: "manufacturingCountry")
  String? get manufacturingCountry;
  @override
  @JsonKey(name: "productType")
  String? get productType;
  @override
  @JsonKey(name: "caseType")
  String? get caseType;
  @override
  @JsonKey(name: "scale")
  String? get scale;
  @override
  @JsonKey(name: "status")
  String? get status;
  @override
  @JsonKey(name: "totalSale")
  int? get totalSale;
  @override
  @JsonKey(name: "productStock")
  dynamic get productStock;
  @override
  @JsonKey(name: "productPrice")
  double? get productPrice;
  @override
  @JsonKey(name: "isPesach")
  bool? get isPesach;
  @override
  @JsonKey(name: "nmMashlim")
  String? get nmMashlim;
  @override
  String? get lowStock;
  @override
  @JsonKey(ignore: true)
  _$$CompanyDataImplCopyWith<_$CompanyDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Image _$ImageFromJson(Map<String, dynamic> json) {
  return _Image.fromJson(json);
}

/// @nodoc
mixin _$Image {
  @JsonKey(name: "imageUrl")
  String? get imageUrl => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ImageCopyWith<Image> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ImageCopyWith<$Res> {
  factory $ImageCopyWith(Image value, $Res Function(Image) then) =
      _$ImageCopyWithImpl<$Res, Image>;
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class _$ImageCopyWithImpl<$Res, $Val extends Image>
    implements $ImageCopyWith<$Res> {
  _$ImageCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_value.copyWith(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ImageImplCopyWith<$Res> implements $ImageCopyWith<$Res> {
  factory _$$ImageImplCopyWith(
          _$ImageImpl value, $Res Function(_$ImageImpl) then) =
      __$$ImageImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "imageUrl") String? imageUrl,
      @JsonKey(name: "order") int? order});
}

/// @nodoc
class __$$ImageImplCopyWithImpl<$Res>
    extends _$ImageCopyWithImpl<$Res, _$ImageImpl>
    implements _$$ImageImplCopyWith<$Res> {
  __$$ImageImplCopyWithImpl(
      _$ImageImpl _value, $Res Function(_$ImageImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = freezed,
    Object? order = freezed,
  }) {
    return _then(_$ImageImpl(
      imageUrl: freezed == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ImageImpl implements _Image {
  const _$ImageImpl(
      {@JsonKey(name: "imageUrl") this.imageUrl,
      @JsonKey(name: "order") this.order});

  factory _$ImageImpl.fromJson(Map<String, dynamic> json) =>
      _$$ImageImplFromJson(json);

  @override
  @JsonKey(name: "imageUrl")
  final String? imageUrl;
  @override
  @JsonKey(name: "order")
  final int? order;

  @override
  String toString() {
    return 'Image(imageUrl: $imageUrl, order: $order)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ImageImpl &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl) &&
            (identical(other.order, order) || other.order == order));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, imageUrl, order);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      __$$ImageImplCopyWithImpl<_$ImageImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ImageImplToJson(
      this,
    );
  }
}

abstract class _Image implements Image {
  const factory _Image(
      {@JsonKey(name: "imageUrl") final String? imageUrl,
      @JsonKey(name: "order") final int? order}) = _$ImageImpl;

  factory _Image.fromJson(Map<String, dynamic> json) = _$ImageImpl.fromJson;

  @override
  @JsonKey(name: "imageUrl")
  String? get imageUrl;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(ignore: true)
  _$$ImageImplCopyWith<_$ImageImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalFilteredCount") this.totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  final int? totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
          {@JsonKey(name: "currentPage") final int? currentPage,
          @JsonKey(name: "totalFilteredCount") final int? totalFilteredCount,
          @JsonKey(name: "totalFilteredPage") final int? totalFilteredPage}) =
      _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
