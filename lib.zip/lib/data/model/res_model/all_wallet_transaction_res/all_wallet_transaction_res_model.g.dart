// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'all_wallet_transaction_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AllWalletTransactionResModelImpl _$$AllWalletTransactionResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$AllWalletTransactionResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => Datum.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$AllWalletTransactionResModelImplToJson(
        _$AllWalletTransactionResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$DatumImpl _$$DatumImplFromJson(Map<String, dynamic> json) => _$DatumImpl(
      id: json['_id'] as String?,
      amount: json['amount'] as String?,
      username: json['username'] as String?,
      orderId: json['orderId'] as String?,
      type: json['type'] as String?,
      income: json['income'] as String?,
      outcome: json['outcome'] as String?,
      balance: json['balance'] as String?,
      createdAt: json['createdAt'] as String?,
    );

Map<String, dynamic> _$$DatumImplToJson(_$DatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'amount': instance.amount,
      'username': instance.username,
      'orderId': instance.orderId,
      'type': instance.type,
      'income': instance.income,
      'outcome': instance.outcome,
      'balance': instance.balance,
      'createdAt': instance.createdAt,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
