// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'remove_form_and_file_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

RemoveFormAndFileResModel _$RemoveFormAndFileResModelFromJson(
    Map<String, dynamic> json) {
  return _RemoveFormAndFileResModel.fromJson(json);
}

/// @nodoc
mixin _$RemoveFormAndFileResModel {
  int? get status => throw _privateConstructorUsedError;
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RemoveFormAndFileResModelCopyWith<RemoveFormAndFileResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RemoveFormAndFileResModelCopyWith<$Res> {
  factory $RemoveFormAndFileResModelCopyWith(RemoveFormAndFileResModel value,
          $Res Function(RemoveFormAndFileResModel) then) =
      _$RemoveFormAndFileResModelCopyWithImpl<$Res, RemoveFormAndFileResModel>;
  @useResult
  $Res call({int? status, String? message});
}

/// @nodoc
class _$RemoveFormAndFileResModelCopyWithImpl<$Res,
        $Val extends RemoveFormAndFileResModel>
    implements $RemoveFormAndFileResModelCopyWith<$Res> {
  _$RemoveFormAndFileResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RemoveFormAndFileResModelImplCopyWith<$Res>
    implements $RemoveFormAndFileResModelCopyWith<$Res> {
  factory _$$RemoveFormAndFileResModelImplCopyWith(
          _$RemoveFormAndFileResModelImpl value,
          $Res Function(_$RemoveFormAndFileResModelImpl) then) =
      __$$RemoveFormAndFileResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int? status, String? message});
}

/// @nodoc
class __$$RemoveFormAndFileResModelImplCopyWithImpl<$Res>
    extends _$RemoveFormAndFileResModelCopyWithImpl<$Res,
        _$RemoveFormAndFileResModelImpl>
    implements _$$RemoveFormAndFileResModelImplCopyWith<$Res> {
  __$$RemoveFormAndFileResModelImplCopyWithImpl(
      _$RemoveFormAndFileResModelImpl _value,
      $Res Function(_$RemoveFormAndFileResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
  }) {
    return _then(_$RemoveFormAndFileResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RemoveFormAndFileResModelImpl implements _RemoveFormAndFileResModel {
  const _$RemoveFormAndFileResModelImpl({this.status, this.message});

  factory _$RemoveFormAndFileResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$RemoveFormAndFileResModelImplFromJson(json);

  @override
  final int? status;
  @override
  final String? message;

  @override
  String toString() {
    return 'RemoveFormAndFileResModel(status: $status, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveFormAndFileResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RemoveFormAndFileResModelImplCopyWith<_$RemoveFormAndFileResModelImpl>
      get copyWith => __$$RemoveFormAndFileResModelImplCopyWithImpl<
          _$RemoveFormAndFileResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RemoveFormAndFileResModelImplToJson(
      this,
    );
  }
}

abstract class _RemoveFormAndFileResModel implements RemoveFormAndFileResModel {
  const factory _RemoveFormAndFileResModel(
      {final int? status,
      final String? message}) = _$RemoveFormAndFileResModelImpl;

  factory _RemoveFormAndFileResModel.fromJson(Map<String, dynamic> json) =
      _$RemoveFormAndFileResModelImpl.fromJson;

  @override
  int? get status;
  @override
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$RemoveFormAndFileResModelImplCopyWith<_$RemoveFormAndFileResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
