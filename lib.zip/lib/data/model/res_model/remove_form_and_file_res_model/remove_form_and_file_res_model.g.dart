// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'remove_form_and_file_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RemoveFormAndFileResModelImpl _$$RemoveFormAndFileResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$RemoveFormAndFileResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$RemoveFormAndFileResModelImplToJson(
        _$RemoveFormAndFileResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
    };
