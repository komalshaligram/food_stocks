// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'invoices_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$InvoicesResModelImpl _$$InvoicesResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$InvoicesResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$InvoicesResModelImplToJson(
        _$InvoicesResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      invoices: (json['invoices'] as List<dynamic>?)
          ?.map((e) => Invoice.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalRecords: json['totalRecords'] as int?,
      totalPages: json['totalPages'] as int?,
      currentPage: json['currentPage'] as int?,
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'invoices': instance.invoices,
      'totalRecords': instance.totalRecords,
      'totalPages': instance.totalPages,
      'currentPage': instance.currentPage,
    };

_$InvoiceImpl _$$InvoiceImplFromJson(Map<String, dynamic> json) =>
    _$InvoiceImpl(
      id: json['_id'] as String?,
      link: json['link'] as String?,
      invoiceNumber: json['invoiceNumber'] as String?,
      invoiceAmount: json['invoiceAmount'] as String?,
      paymentStatus: json['paymentStatus'] as String?,
      invoiceDate: json['invoiceDate'] as String?,
      invoiceType: json['invoiceType'] as String?,
    );

Map<String, dynamic> _$$InvoiceImplToJson(_$InvoiceImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'link': instance.link,
      'invoiceNumber': instance.invoiceNumber,
      'invoiceAmount': instance.invoiceAmount,
      'paymentStatus': instance.paymentStatus,
      'invoiceDate': instance.invoiceDate,
      'invoiceType': instance.invoiceType,
    };
