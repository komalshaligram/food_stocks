// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'setting_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SettingResModelImpl _$$SettingResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$SettingResModelImpl(
      data: Data.fromJson(json['data'] as Map<String, dynamic>),
      status: json['status'] as int,
      message: json['message'] as String,
    );

Map<String, dynamic> _$$SettingResModelImplToJson(
        _$SettingResModelImpl instance) =>
    <String, dynamic>{
      'data': instance.data,
      'status': instance.status,
      'message': instance.message,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      pesachBanner: json['pesachBanner'] as String,
      isShowPesachBanner: json['isShowPesachBanner'] as bool,
      bottlePrice: (json['bottlePrice'] as num).toDouble(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'pesachBanner': instance.pesachBanner,
      'isShowPesachBanner': instance.isShowPesachBanner,
      'bottlePrice': instance.bottlePrice,
    };
