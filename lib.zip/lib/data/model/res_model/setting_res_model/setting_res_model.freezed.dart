// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'setting_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SettingResModel _$SettingResModelFromJson(Map<String, dynamic> json) {
  return _SettingResModel.fromJson(json);
}

/// @nodoc
mixin _$SettingResModel {
  Data get data => throw _privateConstructorUsedError;
  int get status => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SettingResModelCopyWith<SettingResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SettingResModelCopyWith<$Res> {
  factory $SettingResModelCopyWith(
          SettingResModel value, $Res Function(SettingResModel) then) =
      _$SettingResModelCopyWithImpl<$Res, SettingResModel>;
  @useResult
  $Res call({Data data, int status, String message});

  $DataCopyWith<$Res> get data;
}

/// @nodoc
class _$SettingResModelCopyWithImpl<$Res, $Val extends SettingResModel>
    implements $SettingResModelCopyWith<$Res> {
  _$SettingResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = null,
    Object? status = null,
    Object? message = null,
  }) {
    return _then(_value.copyWith(
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res> get data {
    return $DataCopyWith<$Res>(_value.data, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$SettingResModelImplCopyWith<$Res>
    implements $SettingResModelCopyWith<$Res> {
  factory _$$SettingResModelImplCopyWith(_$SettingResModelImpl value,
          $Res Function(_$SettingResModelImpl) then) =
      __$$SettingResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Data data, int status, String message});

  @override
  $DataCopyWith<$Res> get data;
}

/// @nodoc
class __$$SettingResModelImplCopyWithImpl<$Res>
    extends _$SettingResModelCopyWithImpl<$Res, _$SettingResModelImpl>
    implements _$$SettingResModelImplCopyWith<$Res> {
  __$$SettingResModelImplCopyWithImpl(
      _$SettingResModelImpl _value, $Res Function(_$SettingResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? data = null,
    Object? status = null,
    Object? message = null,
  }) {
    return _then(_$SettingResModelImpl(
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SettingResModelImpl implements _SettingResModel {
  const _$SettingResModelImpl(
      {required this.data, required this.status, required this.message});

  factory _$SettingResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SettingResModelImplFromJson(json);

  @override
  final Data data;
  @override
  final int status;
  @override
  final String message;

  @override
  String toString() {
    return 'SettingResModel(data: $data, status: $status, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SettingResModelImpl &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, data, status, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SettingResModelImplCopyWith<_$SettingResModelImpl> get copyWith =>
      __$$SettingResModelImplCopyWithImpl<_$SettingResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SettingResModelImplToJson(
      this,
    );
  }
}

abstract class _SettingResModel implements SettingResModel {
  const factory _SettingResModel(
      {required final Data data,
      required final int status,
      required final String message}) = _$SettingResModelImpl;

  factory _SettingResModel.fromJson(Map<String, dynamic> json) =
      _$SettingResModelImpl.fromJson;

  @override
  Data get data;
  @override
  int get status;
  @override
  String get message;
  @override
  @JsonKey(ignore: true)
  _$$SettingResModelImplCopyWith<_$SettingResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  String get pesachBanner => throw _privateConstructorUsedError;
  bool get isShowPesachBanner => throw _privateConstructorUsedError;
  double get bottlePrice => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call({String pesachBanner, bool isShowPesachBanner, double bottlePrice});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pesachBanner = null,
    Object? isShowPesachBanner = null,
    Object? bottlePrice = null,
  }) {
    return _then(_value.copyWith(
      pesachBanner: null == pesachBanner
          ? _value.pesachBanner
          : pesachBanner // ignore: cast_nullable_to_non_nullable
              as String,
      isShowPesachBanner: null == isShowPesachBanner
          ? _value.isShowPesachBanner
          : isShowPesachBanner // ignore: cast_nullable_to_non_nullable
              as bool,
      bottlePrice: null == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String pesachBanner, bool isShowPesachBanner, double bottlePrice});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pesachBanner = null,
    Object? isShowPesachBanner = null,
    Object? bottlePrice = null,
  }) {
    return _then(_$DataImpl(
      pesachBanner: null == pesachBanner
          ? _value.pesachBanner
          : pesachBanner // ignore: cast_nullable_to_non_nullable
              as String,
      isShowPesachBanner: null == isShowPesachBanner
          ? _value.isShowPesachBanner
          : isShowPesachBanner // ignore: cast_nullable_to_non_nullable
              as bool,
      bottlePrice: null == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {required this.pesachBanner,
      required this.isShowPesachBanner,
      required this.bottlePrice});

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  @override
  final String pesachBanner;
  @override
  final bool isShowPesachBanner;
  @override
  final double bottlePrice;

  @override
  String toString() {
    return 'Data(pesachBanner: $pesachBanner, isShowPesachBanner: $isShowPesachBanner, bottlePrice: $bottlePrice)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            (identical(other.pesachBanner, pesachBanner) ||
                other.pesachBanner == pesachBanner) &&
            (identical(other.isShowPesachBanner, isShowPesachBanner) ||
                other.isShowPesachBanner == isShowPesachBanner) &&
            (identical(other.bottlePrice, bottlePrice) ||
                other.bottlePrice == bottlePrice));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, pesachBanner, isShowPesachBanner, bottlePrice);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {required final String pesachBanner,
      required final bool isShowPesachBanner,
      required final double bottlePrice}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  String get pesachBanner;
  @override
  bool get isShowPesachBanner;
  @override
  double get bottlePrice;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
