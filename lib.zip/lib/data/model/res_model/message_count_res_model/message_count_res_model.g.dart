// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'message_count_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$MessageCountResModelImpl _$$MessageCountResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$MessageCountResModelImpl(
      status: json['status'] as int?,
      data: json['data'] as int?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$MessageCountResModelImplToJson(
        _$MessageCountResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };
