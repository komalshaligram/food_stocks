// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'message_count_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

MessageCountResModel _$MessageCountResModelFromJson(Map<String, dynamic> json) {
  return _MessageCountResModel.fromJson(json);
}

/// @nodoc
mixin _$MessageCountResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  int? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MessageCountResModelCopyWith<MessageCountResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageCountResModelCopyWith<$Res> {
  factory $MessageCountResModelCopyWith(MessageCountResModel value,
          $Res Function(MessageCountResModel) then) =
      _$MessageCountResModelCopyWithImpl<$Res, MessageCountResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") int? data,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class _$MessageCountResModelCopyWithImpl<$Res,
        $Val extends MessageCountResModel>
    implements $MessageCountResModelCopyWith<$Res> {
  _$MessageCountResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MessageCountResModelImplCopyWith<$Res>
    implements $MessageCountResModelCopyWith<$Res> {
  factory _$$MessageCountResModelImplCopyWith(_$MessageCountResModelImpl value,
          $Res Function(_$MessageCountResModelImpl) then) =
      __$$MessageCountResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") int? data,
      @JsonKey(name: "message") String? message});
}

/// @nodoc
class __$$MessageCountResModelImplCopyWithImpl<$Res>
    extends _$MessageCountResModelCopyWithImpl<$Res, _$MessageCountResModelImpl>
    implements _$$MessageCountResModelImplCopyWith<$Res> {
  __$$MessageCountResModelImplCopyWithImpl(_$MessageCountResModelImpl _value,
      $Res Function(_$MessageCountResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$MessageCountResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MessageCountResModelImpl implements _MessageCountResModel {
  const _$MessageCountResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$MessageCountResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$MessageCountResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final int? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'MessageCountResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MessageCountResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MessageCountResModelImplCopyWith<_$MessageCountResModelImpl>
      get copyWith =>
          __$$MessageCountResModelImplCopyWithImpl<_$MessageCountResModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MessageCountResModelImplToJson(
      this,
    );
  }
}

abstract class _MessageCountResModel implements MessageCountResModel {
  const factory _MessageCountResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final int? data,
          @JsonKey(name: "message") final String? message}) =
      _$MessageCountResModelImpl;

  factory _MessageCountResModel.fromJson(Map<String, dynamic> json) =
      _$MessageCountResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  int? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$MessageCountResModelImplCopyWith<_$MessageCountResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
