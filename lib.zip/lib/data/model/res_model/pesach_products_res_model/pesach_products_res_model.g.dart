// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pesach_products_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PesachProductsResModelImpl _$$PesachProductsResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$PesachProductsResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => PesachData.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$PesachProductsResModelImplToJson(
        _$PesachProductsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$PesachDataImpl _$$PesachDataImplFromJson(Map<String, dynamic> json) =>
    _$PesachDataImpl(
      numberOfUnit: json['numberOfUnit'] as String?,
      itemsWeight: json['itemsWeight'] as String?,
      totalWeightCardboard: json['totalWeightCardboard'] as String?,
      totalWeightSurface: json['totalWeightSurface'] as String?,
      totalWeight: json['totalWeight'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      id: json['_id'] as String?,
      productName: json['productName'] as String?,
      brandId: json['brandId'] as String?,
      brandLogo: json['brandLogo'] as String?,
      manufactureName: json['manufactureName'] as String?,
      healthAndLifestye: json['healthAndLifestye'] as String?,
      productDescription: json['productDescription'] as String?,
      component: json['component'] as String?,
      nutritionalValue: json['nutritionalValue'] as String?,
      mainImage: json['mainImage'] as String?,
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => Image.fromJson(e as Map<String, dynamic>))
          .toList(),
      qrcode: json['qrcode'] as String?,
      sku: json['sku'] as String?,
      categories: json['categories'] as String?,
      subcategories: json['subcategories'] as String?,
      manufacturingCountry: json['manufacturingCountry'] as String?,
      productType: json['productType'] as String?,
      caseType: json['caseType'] as String?,
      scale: json['scale'] as String?,
      status: json['status'] as String?,
      totalSale: json['totalSale'] as int?,
      productStock: json['productStock'],
      productPrice: (json['productPrice'] as num?)?.toDouble(),
      isPesach: json['isPesach'] as bool?,
      nmMashlim: json['nmMashlim'] as String?,
      lowStock: json['lowStock'] as String?,
    );

Map<String, dynamic> _$$PesachDataImplToJson(_$PesachDataImpl instance) =>
    <String, dynamic>{
      'numberOfUnit': instance.numberOfUnit,
      'itemsWeight': instance.itemsWeight,
      'totalWeightCardboard': instance.totalWeightCardboard,
      'totalWeightSurface': instance.totalWeightSurface,
      'totalWeight': instance.totalWeight,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '_id': instance.id,
      'productName': instance.productName,
      'brandId': instance.brandId,
      'brandLogo': instance.brandLogo,
      'manufactureName': instance.manufactureName,
      'healthAndLifestye': instance.healthAndLifestye,
      'productDescription': instance.productDescription,
      'component': instance.component,
      'nutritionalValue': instance.nutritionalValue,
      'mainImage': instance.mainImage,
      'images': instance.images,
      'qrcode': instance.qrcode,
      'sku': instance.sku,
      'categories': instance.categories,
      'subcategories': instance.subcategories,
      'manufacturingCountry': instance.manufacturingCountry,
      'productType': instance.productType,
      'caseType': instance.caseType,
      'scale': instance.scale,
      'status': instance.status,
      'totalSale': instance.totalSale,
      'productStock': instance.productStock,
      'productPrice': instance.productPrice,
      'isPesach': instance.isPesach,
      'nmMashlim': instance.nmMashlim,
      'lowStock': instance.lowStock,
    };

_$ImageImpl _$$ImageImplFromJson(Map<String, dynamic> json) => _$ImageImpl(
      imageUrl: json['imageUrl'] as String?,
      order: json['order'] as int?,
    );

Map<String, dynamic> _$$ImageImplToJson(_$ImageImpl instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'order': instance.order,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
