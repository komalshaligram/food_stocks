// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_all_order_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllOrderResModelImpl _$$GetAllOrderResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetAllOrderResModelImpl(
      status: json['status'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => Datum.fromJson(e as Map<String, dynamic>))
          .toList(),
      metaData: json['metaData'] == null
          ? null
          : MetaData.fromJson(json['metaData'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$GetAllOrderResModelImplToJson(
        _$GetAllOrderResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'metaData': instance.metaData,
      'message': instance.message,
    };

_$DatumImpl _$$DatumImplFromJson(Map<String, dynamic> json) => _$DatumImpl(
      id: json['_id'] as String?,
      createdAt: json['createdAt'] as String?,
      status: json['status'] == null
          ? null
          : Status.fromJson(json['status'] as Map<String, dynamic>),
      client: json['client'] == null
          ? null
          : Client.fromJson(json['client'] as Map<String, dynamic>),
      noOfIssues: json['noOfIssues'] as String?,
      orderNumber: json['orderNumber'] as String?,
      totalAmount: json['totalAmount'] as String?,
      totalWeight: json['totalWeight'] as String?,
      surfaceWeight: json['surfaceWeight'] as String?,
      products: json['products'] as int?,
      suppliers: json['suppliers'] as int?,
      isIssue: json['isIssue'] as String?,
      comaxInvoicePrice: json['comaxInvoicePrice'] as String?,
      rivchitInvoicePrice: json['rivchitInvoicePrice'] as String?,
      totalRefundAmount: json['totalRefundAmount'] as String?,
    );

Map<String, dynamic> _$$DatumImplToJson(_$DatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'createdAt': instance.createdAt,
      'status': instance.status,
      'client': instance.client,
      'noOfIssues': instance.noOfIssues,
      'orderNumber': instance.orderNumber,
      'totalAmount': instance.totalAmount,
      'totalWeight': instance.totalWeight,
      'surfaceWeight': instance.surfaceWeight,
      'products': instance.products,
      'suppliers': instance.suppliers,
      'isIssue': instance.isIssue,
      'comaxInvoicePrice': instance.comaxInvoicePrice,
      'rivchitInvoicePrice': instance.rivchitInvoicePrice,
      'totalRefundAmount': instance.totalRefundAmount,
    };

_$ClientImpl _$$ClientImplFromJson(Map<String, dynamic> json) => _$ClientImpl(
      id: json['_id'] as String?,
      clientName: json['clientName'] as String?,
    );

Map<String, dynamic> _$$ClientImplToJson(_$ClientImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'clientName': instance.clientName,
    };

_$StatusImpl _$$StatusImplFromJson(Map<String, dynamic> json) => _$StatusImpl(
      id: json['_id'] as String?,
      statusName: json['statusName'] as String?,
      orderStatusNo: json['orderStatusNumber'] as int?,
    );

Map<String, dynamic> _$$StatusImplToJson(_$StatusImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'statusName': instance.statusName,
      'orderStatusNumber': instance.orderStatusNo,
    };

_$MetaDataImpl _$$MetaDataImplFromJson(Map<String, dynamic> json) =>
    _$MetaDataImpl(
      currentPage: json['currentPage'] as int?,
      totalFilteredCount: json['totalFilteredCount'] as int?,
      totalFilteredPage: json['totalFilteredPage'] as int?,
    );

Map<String, dynamic> _$$MetaDataImplToJson(_$MetaDataImpl instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'totalFilteredCount': instance.totalFilteredCount,
      'totalFilteredPage': instance.totalFilteredPage,
    };
