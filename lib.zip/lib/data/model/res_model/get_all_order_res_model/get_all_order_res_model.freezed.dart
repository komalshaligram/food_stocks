// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_all_order_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAllOrderResModel _$GetAllOrderResModelFromJson(Map<String, dynamic> json) {
  return _GetAllOrderResModel.fromJson(json);
}

/// @nodoc
mixin _$GetAllOrderResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<Datum>? get data => throw _privateConstructorUsedError;
  @JsonKey(name: "metaData")
  MetaData? get metaData => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAllOrderResModelCopyWith<GetAllOrderResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllOrderResModelCopyWith<$Res> {
  factory $GetAllOrderResModelCopyWith(
          GetAllOrderResModel value, $Res Function(GetAllOrderResModel) then) =
      _$GetAllOrderResModelCopyWithImpl<$Res, GetAllOrderResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<Datum>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class _$GetAllOrderResModelCopyWithImpl<$Res, $Val extends GetAllOrderResModel>
    implements $GetAllOrderResModelCopyWith<$Res> {
  _$GetAllOrderResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MetaDataCopyWith<$Res>? get metaData {
    if (_value.metaData == null) {
      return null;
    }

    return $MetaDataCopyWith<$Res>(_value.metaData!, (value) {
      return _then(_value.copyWith(metaData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GetAllOrderResModelImplCopyWith<$Res>
    implements $GetAllOrderResModelCopyWith<$Res> {
  factory _$$GetAllOrderResModelImplCopyWith(_$GetAllOrderResModelImpl value,
          $Res Function(_$GetAllOrderResModelImpl) then) =
      __$$GetAllOrderResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") List<Datum>? data,
      @JsonKey(name: "metaData") MetaData? metaData,
      @JsonKey(name: "message") String? message});

  @override
  $MetaDataCopyWith<$Res>? get metaData;
}

/// @nodoc
class __$$GetAllOrderResModelImplCopyWithImpl<$Res>
    extends _$GetAllOrderResModelCopyWithImpl<$Res, _$GetAllOrderResModelImpl>
    implements _$$GetAllOrderResModelImplCopyWith<$Res> {
  __$$GetAllOrderResModelImplCopyWithImpl(_$GetAllOrderResModelImpl _value,
      $Res Function(_$GetAllOrderResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? metaData = freezed,
    Object? message = freezed,
  }) {
    return _then(_$GetAllOrderResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      metaData: freezed == metaData
          ? _value.metaData
          : metaData // ignore: cast_nullable_to_non_nullable
              as MetaData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAllOrderResModelImpl implements _GetAllOrderResModel {
  const _$GetAllOrderResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") final List<Datum>? data,
      @JsonKey(name: "metaData") this.metaData,
      @JsonKey(name: "message") this.message})
      : _data = data;

  factory _$GetAllOrderResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetAllOrderResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  final List<Datum>? _data;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "metaData")
  final MetaData? metaData;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'GetAllOrderResModel(status: $status, data: $data, metaData: $metaData, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllOrderResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._data, _data) &&
            (identical(other.metaData, metaData) ||
                other.metaData == metaData) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_data), metaData, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllOrderResModelImplCopyWith<_$GetAllOrderResModelImpl> get copyWith =>
      __$$GetAllOrderResModelImplCopyWithImpl<_$GetAllOrderResModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAllOrderResModelImplToJson(
      this,
    );
  }
}

abstract class _GetAllOrderResModel implements GetAllOrderResModel {
  const factory _GetAllOrderResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final List<Datum>? data,
          @JsonKey(name: "metaData") final MetaData? metaData,
          @JsonKey(name: "message") final String? message}) =
      _$GetAllOrderResModelImpl;

  factory _GetAllOrderResModel.fromJson(Map<String, dynamic> json) =
      _$GetAllOrderResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data;
  @override
  @JsonKey(name: "metaData")
  MetaData? get metaData;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$GetAllOrderResModelImplCopyWith<_$GetAllOrderResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Datum _$DatumFromJson(Map<String, dynamic> json) {
  return _Datum.fromJson(json);
}

/// @nodoc
mixin _$Datum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  Status? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "client")
  Client? get client => throw _privateConstructorUsedError;
  @JsonKey(name: "noOfIssues")
  String? get noOfIssues => throw _privateConstructorUsedError;
  @JsonKey(name: "orderNumber")
  String? get orderNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "totalAmount")
  String? get totalAmount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  String? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "surfaceWeight")
  String? get surfaceWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "products")
  int? get products => throw _privateConstructorUsedError;
  @JsonKey(name: "suppliers")
  int? get suppliers => throw _privateConstructorUsedError;
  @JsonKey(name: "isIssue")
  String? get isIssue => throw _privateConstructorUsedError;
  String? get comaxInvoicePrice => throw _privateConstructorUsedError;
  String? get rivchitInvoicePrice => throw _privateConstructorUsedError;
  String? get totalRefundAmount => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DatumCopyWith<Datum> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DatumCopyWith<$Res> {
  factory $DatumCopyWith(Datum value, $Res Function(Datum) then) =
      _$DatumCopyWithImpl<$Res, Datum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "status") Status? status,
      @JsonKey(name: "client") Client? client,
      @JsonKey(name: "noOfIssues") String? noOfIssues,
      @JsonKey(name: "orderNumber") String? orderNumber,
      @JsonKey(name: "totalAmount") String? totalAmount,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "surfaceWeight") String? surfaceWeight,
      @JsonKey(name: "products") int? products,
      @JsonKey(name: "suppliers") int? suppliers,
      @JsonKey(name: "isIssue") String? isIssue,
      String? comaxInvoicePrice,
      String? rivchitInvoicePrice,
      String? totalRefundAmount});

  $StatusCopyWith<$Res>? get status;
  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class _$DatumCopyWithImpl<$Res, $Val extends Datum>
    implements $DatumCopyWith<$Res> {
  _$DatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? status = freezed,
    Object? client = freezed,
    Object? noOfIssues = freezed,
    Object? orderNumber = freezed,
    Object? totalAmount = freezed,
    Object? totalWeight = freezed,
    Object? surfaceWeight = freezed,
    Object? products = freezed,
    Object? suppliers = freezed,
    Object? isIssue = freezed,
    Object? comaxInvoicePrice = freezed,
    Object? rivchitInvoicePrice = freezed,
    Object? totalRefundAmount = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as Status?,
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
      noOfIssues: freezed == noOfIssues
          ? _value.noOfIssues
          : noOfIssues // ignore: cast_nullable_to_non_nullable
              as String?,
      orderNumber: freezed == orderNumber
          ? _value.orderNumber
          : orderNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      surfaceWeight: freezed == surfaceWeight
          ? _value.surfaceWeight
          : surfaceWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      products: freezed == products
          ? _value.products
          : products // ignore: cast_nullable_to_non_nullable
              as int?,
      suppliers: freezed == suppliers
          ? _value.suppliers
          : suppliers // ignore: cast_nullable_to_non_nullable
              as int?,
      isIssue: freezed == isIssue
          ? _value.isIssue
          : isIssue // ignore: cast_nullable_to_non_nullable
              as String?,
      comaxInvoicePrice: freezed == comaxInvoicePrice
          ? _value.comaxInvoicePrice
          : comaxInvoicePrice // ignore: cast_nullable_to_non_nullable
              as String?,
      rivchitInvoicePrice: freezed == rivchitInvoicePrice
          ? _value.rivchitInvoicePrice
          : rivchitInvoicePrice // ignore: cast_nullable_to_non_nullable
              as String?,
      totalRefundAmount: freezed == totalRefundAmount
          ? _value.totalRefundAmount
          : totalRefundAmount // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $StatusCopyWith<$Res>? get status {
    if (_value.status == null) {
      return null;
    }

    return $StatusCopyWith<$Res>(_value.status!, (value) {
      return _then(_value.copyWith(status: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientCopyWith<$Res>? get client {
    if (_value.client == null) {
      return null;
    }

    return $ClientCopyWith<$Res>(_value.client!, (value) {
      return _then(_value.copyWith(client: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DatumImplCopyWith<$Res> implements $DatumCopyWith<$Res> {
  factory _$$DatumImplCopyWith(
          _$DatumImpl value, $Res Function(_$DatumImpl) then) =
      __$$DatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "status") Status? status,
      @JsonKey(name: "client") Client? client,
      @JsonKey(name: "noOfIssues") String? noOfIssues,
      @JsonKey(name: "orderNumber") String? orderNumber,
      @JsonKey(name: "totalAmount") String? totalAmount,
      @JsonKey(name: "totalWeight") String? totalWeight,
      @JsonKey(name: "surfaceWeight") String? surfaceWeight,
      @JsonKey(name: "products") int? products,
      @JsonKey(name: "suppliers") int? suppliers,
      @JsonKey(name: "isIssue") String? isIssue,
      String? comaxInvoicePrice,
      String? rivchitInvoicePrice,
      String? totalRefundAmount});

  @override
  $StatusCopyWith<$Res>? get status;
  @override
  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class __$$DatumImplCopyWithImpl<$Res>
    extends _$DatumCopyWithImpl<$Res, _$DatumImpl>
    implements _$$DatumImplCopyWith<$Res> {
  __$$DatumImplCopyWithImpl(
      _$DatumImpl _value, $Res Function(_$DatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? status = freezed,
    Object? client = freezed,
    Object? noOfIssues = freezed,
    Object? orderNumber = freezed,
    Object? totalAmount = freezed,
    Object? totalWeight = freezed,
    Object? surfaceWeight = freezed,
    Object? products = freezed,
    Object? suppliers = freezed,
    Object? isIssue = freezed,
    Object? comaxInvoicePrice = freezed,
    Object? rivchitInvoicePrice = freezed,
    Object? totalRefundAmount = freezed,
  }) {
    return _then(_$DatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as Status?,
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
      noOfIssues: freezed == noOfIssues
          ? _value.noOfIssues
          : noOfIssues // ignore: cast_nullable_to_non_nullable
              as String?,
      orderNumber: freezed == orderNumber
          ? _value.orderNumber
          : orderNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      surfaceWeight: freezed == surfaceWeight
          ? _value.surfaceWeight
          : surfaceWeight // ignore: cast_nullable_to_non_nullable
              as String?,
      products: freezed == products
          ? _value.products
          : products // ignore: cast_nullable_to_non_nullable
              as int?,
      suppliers: freezed == suppliers
          ? _value.suppliers
          : suppliers // ignore: cast_nullable_to_non_nullable
              as int?,
      isIssue: freezed == isIssue
          ? _value.isIssue
          : isIssue // ignore: cast_nullable_to_non_nullable
              as String?,
      comaxInvoicePrice: freezed == comaxInvoicePrice
          ? _value.comaxInvoicePrice
          : comaxInvoicePrice // ignore: cast_nullable_to_non_nullable
              as String?,
      rivchitInvoicePrice: freezed == rivchitInvoicePrice
          ? _value.rivchitInvoicePrice
          : rivchitInvoicePrice // ignore: cast_nullable_to_non_nullable
              as String?,
      totalRefundAmount: freezed == totalRefundAmount
          ? _value.totalRefundAmount
          : totalRefundAmount // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DatumImpl implements _Datum {
  const _$DatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "status") this.status,
      @JsonKey(name: "client") this.client,
      @JsonKey(name: "noOfIssues") this.noOfIssues,
      @JsonKey(name: "orderNumber") this.orderNumber,
      @JsonKey(name: "totalAmount") this.totalAmount,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "surfaceWeight") this.surfaceWeight,
      @JsonKey(name: "products") this.products,
      @JsonKey(name: "suppliers") this.suppliers,
      @JsonKey(name: "isIssue") this.isIssue,
      this.comaxInvoicePrice,
      this.rivchitInvoicePrice,
      this.totalRefundAmount});

  factory _$DatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$DatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "status")
  final Status? status;
  @override
  @JsonKey(name: "client")
  final Client? client;
  @override
  @JsonKey(name: "noOfIssues")
  final String? noOfIssues;
  @override
  @JsonKey(name: "orderNumber")
  final String? orderNumber;
  @override
  @JsonKey(name: "totalAmount")
  final String? totalAmount;
  @override
  @JsonKey(name: "totalWeight")
  final String? totalWeight;
  @override
  @JsonKey(name: "surfaceWeight")
  final String? surfaceWeight;
  @override
  @JsonKey(name: "products")
  final int? products;
  @override
  @JsonKey(name: "suppliers")
  final int? suppliers;
  @override
  @JsonKey(name: "isIssue")
  final String? isIssue;
  @override
  final String? comaxInvoicePrice;
  @override
  final String? rivchitInvoicePrice;
  @override
  final String? totalRefundAmount;

  @override
  String toString() {
    return 'Datum(id: $id, createdAt: $createdAt, status: $status, client: $client, noOfIssues: $noOfIssues, orderNumber: $orderNumber, totalAmount: $totalAmount, totalWeight: $totalWeight, surfaceWeight: $surfaceWeight, products: $products, suppliers: $suppliers, isIssue: $isIssue, comaxInvoicePrice: $comaxInvoicePrice, rivchitInvoicePrice: $rivchitInvoicePrice, totalRefundAmount: $totalRefundAmount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.client, client) || other.client == client) &&
            (identical(other.noOfIssues, noOfIssues) ||
                other.noOfIssues == noOfIssues) &&
            (identical(other.orderNumber, orderNumber) ||
                other.orderNumber == orderNumber) &&
            (identical(other.totalAmount, totalAmount) ||
                other.totalAmount == totalAmount) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.surfaceWeight, surfaceWeight) ||
                other.surfaceWeight == surfaceWeight) &&
            (identical(other.products, products) ||
                other.products == products) &&
            (identical(other.suppliers, suppliers) ||
                other.suppliers == suppliers) &&
            (identical(other.isIssue, isIssue) || other.isIssue == isIssue) &&
            (identical(other.comaxInvoicePrice, comaxInvoicePrice) ||
                other.comaxInvoicePrice == comaxInvoicePrice) &&
            (identical(other.rivchitInvoicePrice, rivchitInvoicePrice) ||
                other.rivchitInvoicePrice == rivchitInvoicePrice) &&
            (identical(other.totalRefundAmount, totalRefundAmount) ||
                other.totalRefundAmount == totalRefundAmount));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      createdAt,
      status,
      client,
      noOfIssues,
      orderNumber,
      totalAmount,
      totalWeight,
      surfaceWeight,
      products,
      suppliers,
      isIssue,
      comaxInvoicePrice,
      rivchitInvoicePrice,
      totalRefundAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      __$$DatumImplCopyWithImpl<_$DatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DatumImplToJson(
      this,
    );
  }
}

abstract class _Datum implements Datum {
  const factory _Datum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "status") final Status? status,
      @JsonKey(name: "client") final Client? client,
      @JsonKey(name: "noOfIssues") final String? noOfIssues,
      @JsonKey(name: "orderNumber") final String? orderNumber,
      @JsonKey(name: "totalAmount") final String? totalAmount,
      @JsonKey(name: "totalWeight") final String? totalWeight,
      @JsonKey(name: "surfaceWeight") final String? surfaceWeight,
      @JsonKey(name: "products") final int? products,
      @JsonKey(name: "suppliers") final int? suppliers,
      @JsonKey(name: "isIssue") final String? isIssue,
      final String? comaxInvoicePrice,
      final String? rivchitInvoicePrice,
      final String? totalRefundAmount}) = _$DatumImpl;

  factory _Datum.fromJson(Map<String, dynamic> json) = _$DatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "status")
  Status? get status;
  @override
  @JsonKey(name: "client")
  Client? get client;
  @override
  @JsonKey(name: "noOfIssues")
  String? get noOfIssues;
  @override
  @JsonKey(name: "orderNumber")
  String? get orderNumber;
  @override
  @JsonKey(name: "totalAmount")
  String? get totalAmount;
  @override
  @JsonKey(name: "totalWeight")
  String? get totalWeight;
  @override
  @JsonKey(name: "surfaceWeight")
  String? get surfaceWeight;
  @override
  @JsonKey(name: "products")
  int? get products;
  @override
  @JsonKey(name: "suppliers")
  int? get suppliers;
  @override
  @JsonKey(name: "isIssue")
  String? get isIssue;
  @override
  String? get comaxInvoicePrice;
  @override
  String? get rivchitInvoicePrice;
  @override
  String? get totalRefundAmount;
  @override
  @JsonKey(ignore: true)
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Client _$ClientFromJson(Map<String, dynamic> json) {
  return _Client.fromJson(json);
}

/// @nodoc
mixin _$Client {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "clientName")
  String? get clientName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientCopyWith<Client> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientCopyWith<$Res> {
  factory $ClientCopyWith(Client value, $Res Function(Client) then) =
      _$ClientCopyWithImpl<$Res, Client>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "clientName") String? clientName});
}

/// @nodoc
class _$ClientCopyWithImpl<$Res, $Val extends Client>
    implements $ClientCopyWith<$Res> {
  _$ClientCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? clientName = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      clientName: freezed == clientName
          ? _value.clientName
          : clientName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientImplCopyWith<$Res> implements $ClientCopyWith<$Res> {
  factory _$$ClientImplCopyWith(
          _$ClientImpl value, $Res Function(_$ClientImpl) then) =
      __$$ClientImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "clientName") String? clientName});
}

/// @nodoc
class __$$ClientImplCopyWithImpl<$Res>
    extends _$ClientCopyWithImpl<$Res, _$ClientImpl>
    implements _$$ClientImplCopyWith<$Res> {
  __$$ClientImplCopyWithImpl(
      _$ClientImpl _value, $Res Function(_$ClientImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? clientName = freezed,
  }) {
    return _then(_$ClientImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      clientName: freezed == clientName
          ? _value.clientName
          : clientName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientImpl implements _Client {
  const _$ClientImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "clientName") this.clientName});

  factory _$ClientImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "clientName")
  final String? clientName;

  @override
  String toString() {
    return 'Client(id: $id, clientName: $clientName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.clientName, clientName) ||
                other.clientName == clientName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, clientName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      __$$ClientImplCopyWithImpl<_$ClientImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientImplToJson(
      this,
    );
  }
}

abstract class _Client implements Client {
  const factory _Client(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "clientName") final String? clientName}) = _$ClientImpl;

  factory _Client.fromJson(Map<String, dynamic> json) = _$ClientImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "clientName")
  String? get clientName;
  @override
  @JsonKey(ignore: true)
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Status _$StatusFromJson(Map<String, dynamic> json) {
  return _Status.fromJson(json);
}

/// @nodoc
mixin _$Status {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "statusName")
  String? get statusName => throw _privateConstructorUsedError;
  @JsonKey(name: "orderStatusNumber")
  int? get orderStatusNo => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StatusCopyWith<Status> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StatusCopyWith<$Res> {
  factory $StatusCopyWith(Status value, $Res Function(Status) then) =
      _$StatusCopyWithImpl<$Res, Status>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "orderStatusNumber") int? orderStatusNo});
}

/// @nodoc
class _$StatusCopyWithImpl<$Res, $Val extends Status>
    implements $StatusCopyWith<$Res> {
  _$StatusCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? orderStatusNo = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      orderStatusNo: freezed == orderStatusNo
          ? _value.orderStatusNo
          : orderStatusNo // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StatusImplCopyWith<$Res> implements $StatusCopyWith<$Res> {
  factory _$$StatusImplCopyWith(
          _$StatusImpl value, $Res Function(_$StatusImpl) then) =
      __$$StatusImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "orderStatusNumber") int? orderStatusNo});
}

/// @nodoc
class __$$StatusImplCopyWithImpl<$Res>
    extends _$StatusCopyWithImpl<$Res, _$StatusImpl>
    implements _$$StatusImplCopyWith<$Res> {
  __$$StatusImplCopyWithImpl(
      _$StatusImpl _value, $Res Function(_$StatusImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? orderStatusNo = freezed,
  }) {
    return _then(_$StatusImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      orderStatusNo: freezed == orderStatusNo
          ? _value.orderStatusNo
          : orderStatusNo // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StatusImpl implements _Status {
  const _$StatusImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "statusName") this.statusName,
      @JsonKey(name: "orderStatusNumber") this.orderStatusNo});

  factory _$StatusImpl.fromJson(Map<String, dynamic> json) =>
      _$$StatusImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "statusName")
  final String? statusName;
  @override
  @JsonKey(name: "orderStatusNumber")
  final int? orderStatusNo;

  @override
  String toString() {
    return 'Status(id: $id, statusName: $statusName, orderStatusNo: $orderStatusNo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StatusImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.statusName, statusName) ||
                other.statusName == statusName) &&
            (identical(other.orderStatusNo, orderStatusNo) ||
                other.orderStatusNo == orderStatusNo));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, statusName, orderStatusNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      __$$StatusImplCopyWithImpl<_$StatusImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StatusImplToJson(
      this,
    );
  }
}

abstract class _Status implements Status {
  const factory _Status(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "statusName") final String? statusName,
          @JsonKey(name: "orderStatusNumber") final int? orderStatusNo}) =
      _$StatusImpl;

  factory _Status.fromJson(Map<String, dynamic> json) = _$StatusImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "statusName")
  String? get statusName;
  @override
  @JsonKey(name: "orderStatusNumber")
  int? get orderStatusNo;
  @override
  @JsonKey(ignore: true)
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MetaData _$MetaDataFromJson(Map<String, dynamic> json) {
  return _MetaData.fromJson(json);
}

/// @nodoc
mixin _$MetaData {
  @JsonKey(name: "currentPage")
  int? get currentPage => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MetaDataCopyWith<MetaData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MetaDataCopyWith<$Res> {
  factory $MetaDataCopyWith(MetaData value, $Res Function(MetaData) then) =
      _$MetaDataCopyWithImpl<$Res, MetaData>;
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class _$MetaDataCopyWithImpl<$Res, $Val extends MetaData>
    implements $MetaDataCopyWith<$Res> {
  _$MetaDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_value.copyWith(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MetaDataImplCopyWith<$Res>
    implements $MetaDataCopyWith<$Res> {
  factory _$$MetaDataImplCopyWith(
          _$MetaDataImpl value, $Res Function(_$MetaDataImpl) then) =
      __$$MetaDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "currentPage") int? currentPage,
      @JsonKey(name: "totalFilteredCount") int? totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") int? totalFilteredPage});
}

/// @nodoc
class __$$MetaDataImplCopyWithImpl<$Res>
    extends _$MetaDataCopyWithImpl<$Res, _$MetaDataImpl>
    implements _$$MetaDataImplCopyWith<$Res> {
  __$$MetaDataImplCopyWithImpl(
      _$MetaDataImpl _value, $Res Function(_$MetaDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPage = freezed,
    Object? totalFilteredCount = freezed,
    Object? totalFilteredPage = freezed,
  }) {
    return _then(_$MetaDataImpl(
      currentPage: freezed == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredCount: freezed == totalFilteredCount
          ? _value.totalFilteredCount
          : totalFilteredCount // ignore: cast_nullable_to_non_nullable
              as int?,
      totalFilteredPage: freezed == totalFilteredPage
          ? _value.totalFilteredPage
          : totalFilteredPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MetaDataImpl implements _MetaData {
  const _$MetaDataImpl(
      {@JsonKey(name: "currentPage") this.currentPage,
      @JsonKey(name: "totalFilteredCount") this.totalFilteredCount,
      @JsonKey(name: "totalFilteredPage") this.totalFilteredPage});

  factory _$MetaDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MetaDataImplFromJson(json);

  @override
  @JsonKey(name: "currentPage")
  final int? currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  final int? totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  final int? totalFilteredPage;

  @override
  String toString() {
    return 'MetaData(currentPage: $currentPage, totalFilteredCount: $totalFilteredCount, totalFilteredPage: $totalFilteredPage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MetaDataImpl &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalFilteredCount, totalFilteredCount) ||
                other.totalFilteredCount == totalFilteredCount) &&
            (identical(other.totalFilteredPage, totalFilteredPage) ||
                other.totalFilteredPage == totalFilteredPage));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, currentPage, totalFilteredCount, totalFilteredPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      __$$MetaDataImplCopyWithImpl<_$MetaDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MetaDataImplToJson(
      this,
    );
  }
}

abstract class _MetaData implements MetaData {
  const factory _MetaData(
          {@JsonKey(name: "currentPage") final int? currentPage,
          @JsonKey(name: "totalFilteredCount") final int? totalFilteredCount,
          @JsonKey(name: "totalFilteredPage") final int? totalFilteredPage}) =
      _$MetaDataImpl;

  factory _MetaData.fromJson(Map<String, dynamic> json) =
      _$MetaDataImpl.fromJson;

  @override
  @JsonKey(name: "currentPage")
  int? get currentPage;
  @override
  @JsonKey(name: "totalFilteredCount")
  int? get totalFilteredCount;
  @override
  @JsonKey(name: "totalFilteredPage")
  int? get totalFilteredPage;
  @override
  @JsonKey(ignore: true)
  _$$MetaDataImplCopyWith<_$MetaDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
