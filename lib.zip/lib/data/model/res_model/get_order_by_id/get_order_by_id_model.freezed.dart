// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_order_by_id_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetOrderByIdModel _$GetOrderByIdModelFromJson(Map<String, dynamic> json) {
  return _GetOrderByIdModel.fromJson(json);
}

/// @nodoc
mixin _$GetOrderByIdModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  Data? get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetOrderByIdModelCopyWith<GetOrderByIdModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetOrderByIdModelCopyWith<$Res> {
  factory $GetOrderByIdModelCopyWith(
          GetOrderByIdModel value, $Res Function(GetOrderByIdModel) then) =
      _$GetOrderByIdModelCopyWithImpl<$Res, GetOrderByIdModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") Data? data});

  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class _$GetOrderByIdModelCopyWithImpl<$Res, $Val extends GetOrderByIdModel>
    implements $GetOrderByIdModelCopyWith<$Res> {
  _$GetOrderByIdModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $DataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GetOrderByIdModelImplCopyWith<$Res>
    implements $GetOrderByIdModelCopyWith<$Res> {
  factory _$$GetOrderByIdModelImplCopyWith(_$GetOrderByIdModelImpl value,
          $Res Function(_$GetOrderByIdModelImpl) then) =
      __$$GetOrderByIdModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") Data? data});

  @override
  $DataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$GetOrderByIdModelImplCopyWithImpl<$Res>
    extends _$GetOrderByIdModelCopyWithImpl<$Res, _$GetOrderByIdModelImpl>
    implements _$$GetOrderByIdModelImplCopyWith<$Res> {
  __$$GetOrderByIdModelImplCopyWithImpl(_$GetOrderByIdModelImpl _value,
      $Res Function(_$GetOrderByIdModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_$GetOrderByIdModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Data?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetOrderByIdModelImpl implements _GetOrderByIdModel {
  const _$GetOrderByIdModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message,
      @JsonKey(name: "data") this.data});

  factory _$GetOrderByIdModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetOrderByIdModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;
  @override
  @JsonKey(name: "data")
  final Data? data;

  @override
  String toString() {
    return 'GetOrderByIdModel(status: $status, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetOrderByIdModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.data, data) || other.data == data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetOrderByIdModelImplCopyWith<_$GetOrderByIdModelImpl> get copyWith =>
      __$$GetOrderByIdModelImplCopyWithImpl<_$GetOrderByIdModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetOrderByIdModelImplToJson(
      this,
    );
  }
}

abstract class _GetOrderByIdModel implements GetOrderByIdModel {
  const factory _GetOrderByIdModel(
      {@JsonKey(name: "status") final int? status,
      @JsonKey(name: "message") final String? message,
      @JsonKey(name: "data") final Data? data}) = _$GetOrderByIdModelImpl;

  factory _GetOrderByIdModel.fromJson(Map<String, dynamic> json) =
      _$GetOrderByIdModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(name: "data")
  Data? get data;
  @override
  @JsonKey(ignore: true)
  _$$GetOrderByIdModelImplCopyWith<_$GetOrderByIdModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Data _$DataFromJson(Map<String, dynamic> json) {
  return _Data.fromJson(json);
}

/// @nodoc
mixin _$Data {
  @JsonKey(name: "orderData")
  List<OrderDatum>? get orderData => throw _privateConstructorUsedError;
  @JsonKey(name: "ordersBySupplier")
  List<OrdersBySupplier>? get ordersBySupplier =>
      throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DataCopyWith<Data> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DataCopyWith<$Res> {
  factory $DataCopyWith(Data value, $Res Function(Data) then) =
      _$DataCopyWithImpl<$Res, Data>;
  @useResult
  $Res call(
      {@JsonKey(name: "orderData") List<OrderDatum>? orderData,
      @JsonKey(name: "ordersBySupplier")
      List<OrdersBySupplier>? ordersBySupplier});
}

/// @nodoc
class _$DataCopyWithImpl<$Res, $Val extends Data>
    implements $DataCopyWith<$Res> {
  _$DataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderData = freezed,
    Object? ordersBySupplier = freezed,
  }) {
    return _then(_value.copyWith(
      orderData: freezed == orderData
          ? _value.orderData
          : orderData // ignore: cast_nullable_to_non_nullable
              as List<OrderDatum>?,
      ordersBySupplier: freezed == ordersBySupplier
          ? _value.ordersBySupplier
          : ordersBySupplier // ignore: cast_nullable_to_non_nullable
              as List<OrdersBySupplier>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DataImplCopyWith<$Res> implements $DataCopyWith<$Res> {
  factory _$$DataImplCopyWith(
          _$DataImpl value, $Res Function(_$DataImpl) then) =
      __$$DataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "orderData") List<OrderDatum>? orderData,
      @JsonKey(name: "ordersBySupplier")
      List<OrdersBySupplier>? ordersBySupplier});
}

/// @nodoc
class __$$DataImplCopyWithImpl<$Res>
    extends _$DataCopyWithImpl<$Res, _$DataImpl>
    implements _$$DataImplCopyWith<$Res> {
  __$$DataImplCopyWithImpl(_$DataImpl _value, $Res Function(_$DataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderData = freezed,
    Object? ordersBySupplier = freezed,
  }) {
    return _then(_$DataImpl(
      orderData: freezed == orderData
          ? _value._orderData
          : orderData // ignore: cast_nullable_to_non_nullable
              as List<OrderDatum>?,
      ordersBySupplier: freezed == ordersBySupplier
          ? _value._ordersBySupplier
          : ordersBySupplier // ignore: cast_nullable_to_non_nullable
              as List<OrdersBySupplier>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DataImpl implements _Data {
  const _$DataImpl(
      {@JsonKey(name: "orderData") final List<OrderDatum>? orderData,
      @JsonKey(name: "ordersBySupplier")
      final List<OrdersBySupplier>? ordersBySupplier})
      : _orderData = orderData,
        _ordersBySupplier = ordersBySupplier;

  factory _$DataImpl.fromJson(Map<String, dynamic> json) =>
      _$$DataImplFromJson(json);

  final List<OrderDatum>? _orderData;
  @override
  @JsonKey(name: "orderData")
  List<OrderDatum>? get orderData {
    final value = _orderData;
    if (value == null) return null;
    if (_orderData is EqualUnmodifiableListView) return _orderData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<OrdersBySupplier>? _ordersBySupplier;
  @override
  @JsonKey(name: "ordersBySupplier")
  List<OrdersBySupplier>? get ordersBySupplier {
    final value = _ordersBySupplier;
    if (value == null) return null;
    if (_ordersBySupplier is EqualUnmodifiableListView)
      return _ordersBySupplier;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'Data(orderData: $orderData, ordersBySupplier: $ordersBySupplier)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DataImpl &&
            const DeepCollectionEquality()
                .equals(other._orderData, _orderData) &&
            const DeepCollectionEquality()
                .equals(other._ordersBySupplier, _ordersBySupplier));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_orderData),
      const DeepCollectionEquality().hash(_ordersBySupplier));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      __$$DataImplCopyWithImpl<_$DataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DataImplToJson(
      this,
    );
  }
}

abstract class _Data implements Data {
  const factory _Data(
      {@JsonKey(name: "orderData") final List<OrderDatum>? orderData,
      @JsonKey(name: "ordersBySupplier")
      final List<OrdersBySupplier>? ordersBySupplier}) = _$DataImpl;

  factory _Data.fromJson(Map<String, dynamic> json) = _$DataImpl.fromJson;

  @override
  @JsonKey(name: "orderData")
  List<OrderDatum>? get orderData;
  @override
  @JsonKey(name: "ordersBySupplier")
  List<OrdersBySupplier>? get ordersBySupplier;
  @override
  @JsonKey(ignore: true)
  _$$DataImplCopyWith<_$DataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

OrderDatum _$OrderDatumFromJson(Map<String, dynamic> json) {
  return _OrderDatum.fromJson(json);
}

/// @nodoc
mixin _$OrderDatum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  double? get vatPercentage => throw _privateConstructorUsedError;
  double? get totalVatAmount => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "orderstatus")
  Status? get orderstatus => throw _privateConstructorUsedError;
  @JsonKey(name: "client")
  Client? get client => throw _privateConstructorUsedError;
  @JsonKey(name: "totalAmount")
  double? get totalAmount => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  double? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "surfaceWeight")
  double? get surfaceWeight => throw _privateConstructorUsedError;
  int? get bottleQuantities => throw _privateConstructorUsedError;
  double? get bottlePrice => throw _privateConstructorUsedError;
  double? get bottleTax => throw _privateConstructorUsedError;
  double? get vatAmount => throw _privateConstructorUsedError;
  double? get comaxInvoicePrice => throw _privateConstructorUsedError;
  double? get rivchitInvoicePrice => throw _privateConstructorUsedError;
  double? get totalRefundAmount => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $OrderDatumCopyWith<OrderDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderDatumCopyWith<$Res> {
  factory $OrderDatumCopyWith(
          OrderDatum value, $Res Function(OrderDatum) then) =
      _$OrderDatumCopyWithImpl<$Res, OrderDatum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      double? vatPercentage,
      double? totalVatAmount,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "orderstatus") Status? orderstatus,
      @JsonKey(name: "client") Client? client,
      @JsonKey(name: "totalAmount") double? totalAmount,
      @JsonKey(name: "totalWeight") double? totalWeight,
      @JsonKey(name: "surfaceWeight") double? surfaceWeight,
      int? bottleQuantities,
      double? bottlePrice,
      double? bottleTax,
      double? vatAmount,
      double? comaxInvoicePrice,
      double? rivchitInvoicePrice,
      double? totalRefundAmount});

  $StatusCopyWith<$Res>? get orderstatus;
  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class _$OrderDatumCopyWithImpl<$Res, $Val extends OrderDatum>
    implements $OrderDatumCopyWith<$Res> {
  _$OrderDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? vatPercentage = freezed,
    Object? totalVatAmount = freezed,
    Object? createdAt = freezed,
    Object? orderstatus = freezed,
    Object? client = freezed,
    Object? totalAmount = freezed,
    Object? totalWeight = freezed,
    Object? surfaceWeight = freezed,
    Object? bottleQuantities = freezed,
    Object? bottlePrice = freezed,
    Object? bottleTax = freezed,
    Object? vatAmount = freezed,
    Object? comaxInvoicePrice = freezed,
    Object? rivchitInvoicePrice = freezed,
    Object? totalRefundAmount = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      vatPercentage: freezed == vatPercentage
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      totalVatAmount: freezed == totalVatAmount
          ? _value.totalVatAmount
          : totalVatAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      orderstatus: freezed == orderstatus
          ? _value.orderstatus
          : orderstatus // ignore: cast_nullable_to_non_nullable
              as Status?,
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      surfaceWeight: freezed == surfaceWeight
          ? _value.surfaceWeight
          : surfaceWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      bottleQuantities: freezed == bottleQuantities
          ? _value.bottleQuantities
          : bottleQuantities // ignore: cast_nullable_to_non_nullable
              as int?,
      bottlePrice: freezed == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double?,
      bottleTax: freezed == bottleTax
          ? _value.bottleTax
          : bottleTax // ignore: cast_nullable_to_non_nullable
              as double?,
      vatAmount: freezed == vatAmount
          ? _value.vatAmount
          : vatAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      comaxInvoicePrice: freezed == comaxInvoicePrice
          ? _value.comaxInvoicePrice
          : comaxInvoicePrice // ignore: cast_nullable_to_non_nullable
              as double?,
      rivchitInvoicePrice: freezed == rivchitInvoicePrice
          ? _value.rivchitInvoicePrice
          : rivchitInvoicePrice // ignore: cast_nullable_to_non_nullable
              as double?,
      totalRefundAmount: freezed == totalRefundAmount
          ? _value.totalRefundAmount
          : totalRefundAmount // ignore: cast_nullable_to_non_nullable
              as double?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $StatusCopyWith<$Res>? get orderstatus {
    if (_value.orderstatus == null) {
      return null;
    }

    return $StatusCopyWith<$Res>(_value.orderstatus!, (value) {
      return _then(_value.copyWith(orderstatus: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientCopyWith<$Res>? get client {
    if (_value.client == null) {
      return null;
    }

    return $ClientCopyWith<$Res>(_value.client!, (value) {
      return _then(_value.copyWith(client: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$OrderDatumImplCopyWith<$Res>
    implements $OrderDatumCopyWith<$Res> {
  factory _$$OrderDatumImplCopyWith(
          _$OrderDatumImpl value, $Res Function(_$OrderDatumImpl) then) =
      __$$OrderDatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      double? vatPercentage,
      double? totalVatAmount,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "orderstatus") Status? orderstatus,
      @JsonKey(name: "client") Client? client,
      @JsonKey(name: "totalAmount") double? totalAmount,
      @JsonKey(name: "totalWeight") double? totalWeight,
      @JsonKey(name: "surfaceWeight") double? surfaceWeight,
      int? bottleQuantities,
      double? bottlePrice,
      double? bottleTax,
      double? vatAmount,
      double? comaxInvoicePrice,
      double? rivchitInvoicePrice,
      double? totalRefundAmount});

  @override
  $StatusCopyWith<$Res>? get orderstatus;
  @override
  $ClientCopyWith<$Res>? get client;
}

/// @nodoc
class __$$OrderDatumImplCopyWithImpl<$Res>
    extends _$OrderDatumCopyWithImpl<$Res, _$OrderDatumImpl>
    implements _$$OrderDatumImplCopyWith<$Res> {
  __$$OrderDatumImplCopyWithImpl(
      _$OrderDatumImpl _value, $Res Function(_$OrderDatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? vatPercentage = freezed,
    Object? totalVatAmount = freezed,
    Object? createdAt = freezed,
    Object? orderstatus = freezed,
    Object? client = freezed,
    Object? totalAmount = freezed,
    Object? totalWeight = freezed,
    Object? surfaceWeight = freezed,
    Object? bottleQuantities = freezed,
    Object? bottlePrice = freezed,
    Object? bottleTax = freezed,
    Object? vatAmount = freezed,
    Object? comaxInvoicePrice = freezed,
    Object? rivchitInvoicePrice = freezed,
    Object? totalRefundAmount = freezed,
  }) {
    return _then(_$OrderDatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      vatPercentage: freezed == vatPercentage
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as double?,
      totalVatAmount: freezed == totalVatAmount
          ? _value.totalVatAmount
          : totalVatAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      orderstatus: freezed == orderstatus
          ? _value.orderstatus
          : orderstatus // ignore: cast_nullable_to_non_nullable
              as Status?,
      client: freezed == client
          ? _value.client
          : client // ignore: cast_nullable_to_non_nullable
              as Client?,
      totalAmount: freezed == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      surfaceWeight: freezed == surfaceWeight
          ? _value.surfaceWeight
          : surfaceWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      bottleQuantities: freezed == bottleQuantities
          ? _value.bottleQuantities
          : bottleQuantities // ignore: cast_nullable_to_non_nullable
              as int?,
      bottlePrice: freezed == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double?,
      bottleTax: freezed == bottleTax
          ? _value.bottleTax
          : bottleTax // ignore: cast_nullable_to_non_nullable
              as double?,
      vatAmount: freezed == vatAmount
          ? _value.vatAmount
          : vatAmount // ignore: cast_nullable_to_non_nullable
              as double?,
      comaxInvoicePrice: freezed == comaxInvoicePrice
          ? _value.comaxInvoicePrice
          : comaxInvoicePrice // ignore: cast_nullable_to_non_nullable
              as double?,
      rivchitInvoicePrice: freezed == rivchitInvoicePrice
          ? _value.rivchitInvoicePrice
          : rivchitInvoicePrice // ignore: cast_nullable_to_non_nullable
              as double?,
      totalRefundAmount: freezed == totalRefundAmount
          ? _value.totalRefundAmount
          : totalRefundAmount // ignore: cast_nullable_to_non_nullable
              as double?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$OrderDatumImpl implements _OrderDatum {
  const _$OrderDatumImpl(
      {@JsonKey(name: "_id") this.id,
      this.vatPercentage,
      this.totalVatAmount,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "orderstatus") this.orderstatus,
      @JsonKey(name: "client") this.client,
      @JsonKey(name: "totalAmount") this.totalAmount,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "surfaceWeight") this.surfaceWeight,
      this.bottleQuantities,
      this.bottlePrice,
      this.bottleTax,
      this.vatAmount,
      this.comaxInvoicePrice,
      this.rivchitInvoicePrice,
      this.totalRefundAmount});

  factory _$OrderDatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$OrderDatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  final double? vatPercentage;
  @override
  final double? totalVatAmount;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "orderstatus")
  final Status? orderstatus;
  @override
  @JsonKey(name: "client")
  final Client? client;
  @override
  @JsonKey(name: "totalAmount")
  final double? totalAmount;
  @override
  @JsonKey(name: "totalWeight")
  final double? totalWeight;
  @override
  @JsonKey(name: "surfaceWeight")
  final double? surfaceWeight;
  @override
  final int? bottleQuantities;
  @override
  final double? bottlePrice;
  @override
  final double? bottleTax;
  @override
  final double? vatAmount;
  @override
  final double? comaxInvoicePrice;
  @override
  final double? rivchitInvoicePrice;
  @override
  final double? totalRefundAmount;

  @override
  String toString() {
    return 'OrderDatum(id: $id, vatPercentage: $vatPercentage, totalVatAmount: $totalVatAmount, createdAt: $createdAt, orderstatus: $orderstatus, client: $client, totalAmount: $totalAmount, totalWeight: $totalWeight, surfaceWeight: $surfaceWeight, bottleQuantities: $bottleQuantities, bottlePrice: $bottlePrice, bottleTax: $bottleTax, vatAmount: $vatAmount, comaxInvoicePrice: $comaxInvoicePrice, rivchitInvoicePrice: $rivchitInvoicePrice, totalRefundAmount: $totalRefundAmount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OrderDatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.vatPercentage, vatPercentage) ||
                other.vatPercentage == vatPercentage) &&
            (identical(other.totalVatAmount, totalVatAmount) ||
                other.totalVatAmount == totalVatAmount) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.orderstatus, orderstatus) ||
                other.orderstatus == orderstatus) &&
            (identical(other.client, client) || other.client == client) &&
            (identical(other.totalAmount, totalAmount) ||
                other.totalAmount == totalAmount) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.surfaceWeight, surfaceWeight) ||
                other.surfaceWeight == surfaceWeight) &&
            (identical(other.bottleQuantities, bottleQuantities) ||
                other.bottleQuantities == bottleQuantities) &&
            (identical(other.bottlePrice, bottlePrice) ||
                other.bottlePrice == bottlePrice) &&
            (identical(other.bottleTax, bottleTax) ||
                other.bottleTax == bottleTax) &&
            (identical(other.vatAmount, vatAmount) ||
                other.vatAmount == vatAmount) &&
            (identical(other.comaxInvoicePrice, comaxInvoicePrice) ||
                other.comaxInvoicePrice == comaxInvoicePrice) &&
            (identical(other.rivchitInvoicePrice, rivchitInvoicePrice) ||
                other.rivchitInvoicePrice == rivchitInvoicePrice) &&
            (identical(other.totalRefundAmount, totalRefundAmount) ||
                other.totalRefundAmount == totalRefundAmount));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      vatPercentage,
      totalVatAmount,
      createdAt,
      orderstatus,
      client,
      totalAmount,
      totalWeight,
      surfaceWeight,
      bottleQuantities,
      bottlePrice,
      bottleTax,
      vatAmount,
      comaxInvoicePrice,
      rivchitInvoicePrice,
      totalRefundAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OrderDatumImplCopyWith<_$OrderDatumImpl> get copyWith =>
      __$$OrderDatumImplCopyWithImpl<_$OrderDatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$OrderDatumImplToJson(
      this,
    );
  }
}

abstract class _OrderDatum implements OrderDatum {
  const factory _OrderDatum(
      {@JsonKey(name: "_id") final String? id,
      final double? vatPercentage,
      final double? totalVatAmount,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "orderstatus") final Status? orderstatus,
      @JsonKey(name: "client") final Client? client,
      @JsonKey(name: "totalAmount") final double? totalAmount,
      @JsonKey(name: "totalWeight") final double? totalWeight,
      @JsonKey(name: "surfaceWeight") final double? surfaceWeight,
      final int? bottleQuantities,
      final double? bottlePrice,
      final double? bottleTax,
      final double? vatAmount,
      final double? comaxInvoicePrice,
      final double? rivchitInvoicePrice,
      final double? totalRefundAmount}) = _$OrderDatumImpl;

  factory _OrderDatum.fromJson(Map<String, dynamic> json) =
      _$OrderDatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  double? get vatPercentage;
  @override
  double? get totalVatAmount;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "orderstatus")
  Status? get orderstatus;
  @override
  @JsonKey(name: "client")
  Client? get client;
  @override
  @JsonKey(name: "totalAmount")
  double? get totalAmount;
  @override
  @JsonKey(name: "totalWeight")
  double? get totalWeight;
  @override
  @JsonKey(name: "surfaceWeight")
  double? get surfaceWeight;
  @override
  int? get bottleQuantities;
  @override
  double? get bottlePrice;
  @override
  double? get bottleTax;
  @override
  double? get vatAmount;
  @override
  double? get comaxInvoicePrice;
  @override
  double? get rivchitInvoicePrice;
  @override
  double? get totalRefundAmount;
  @override
  @JsonKey(ignore: true)
  _$$OrderDatumImplCopyWith<_$OrderDatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Client _$ClientFromJson(Map<String, dynamic> json) {
  return _Client.fromJson(json);
}

/// @nodoc
mixin _$Client {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "clientName")
  String? get clientName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientCopyWith<Client> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientCopyWith<$Res> {
  factory $ClientCopyWith(Client value, $Res Function(Client) then) =
      _$ClientCopyWithImpl<$Res, Client>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "clientName") String? clientName});
}

/// @nodoc
class _$ClientCopyWithImpl<$Res, $Val extends Client>
    implements $ClientCopyWith<$Res> {
  _$ClientCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? clientName = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      clientName: freezed == clientName
          ? _value.clientName
          : clientName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientImplCopyWith<$Res> implements $ClientCopyWith<$Res> {
  factory _$$ClientImplCopyWith(
          _$ClientImpl value, $Res Function(_$ClientImpl) then) =
      __$$ClientImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "clientName") String? clientName});
}

/// @nodoc
class __$$ClientImplCopyWithImpl<$Res>
    extends _$ClientCopyWithImpl<$Res, _$ClientImpl>
    implements _$$ClientImplCopyWith<$Res> {
  __$$ClientImplCopyWithImpl(
      _$ClientImpl _value, $Res Function(_$ClientImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? clientName = freezed,
  }) {
    return _then(_$ClientImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      clientName: freezed == clientName
          ? _value.clientName
          : clientName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientImpl implements _Client {
  const _$ClientImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "clientName") this.clientName});

  factory _$ClientImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "clientName")
  final String? clientName;

  @override
  String toString() {
    return 'Client(id: $id, clientName: $clientName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.clientName, clientName) ||
                other.clientName == clientName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, clientName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      __$$ClientImplCopyWithImpl<_$ClientImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientImplToJson(
      this,
    );
  }
}

abstract class _Client implements Client {
  const factory _Client(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "clientName") final String? clientName}) = _$ClientImpl;

  factory _Client.fromJson(Map<String, dynamic> json) = _$ClientImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "clientName")
  String? get clientName;
  @override
  @JsonKey(ignore: true)
  _$$ClientImplCopyWith<_$ClientImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Status _$StatusFromJson(Map<String, dynamic> json) {
  return _Status.fromJson(json);
}

/// @nodoc
mixin _$Status {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "statusName")
  String? get statusName => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "orderStatusNumber")
  int? get orderStatusNumber => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StatusCopyWith<Status> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StatusCopyWith<$Res> {
  factory $StatusCopyWith(Status value, $Res Function(Status) then) =
      _$StatusCopyWithImpl<$Res, Status>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "orderStatusNumber") int? orderStatusNumber});
}

/// @nodoc
class _$StatusCopyWithImpl<$Res, $Val extends Status>
    implements $StatusCopyWith<$Res> {
  _$StatusCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
    Object? orderStatusNumber = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      orderStatusNumber: freezed == orderStatusNumber
          ? _value.orderStatusNumber
          : orderStatusNumber // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StatusImplCopyWith<$Res> implements $StatusCopyWith<$Res> {
  factory _$$StatusImplCopyWith(
          _$StatusImpl value, $Res Function(_$StatusImpl) then) =
      __$$StatusImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "statusName") String? statusName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "orderStatusNumber") int? orderStatusNumber});
}

/// @nodoc
class __$$StatusImplCopyWithImpl<$Res>
    extends _$StatusCopyWithImpl<$Res, _$StatusImpl>
    implements _$$StatusImplCopyWith<$Res> {
  __$$StatusImplCopyWithImpl(
      _$StatusImpl _value, $Res Function(_$StatusImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? statusName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
    Object? orderStatusNumber = freezed,
  }) {
    return _then(_$StatusImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      statusName: freezed == statusName
          ? _value.statusName
          : statusName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      orderStatusNumber: freezed == orderStatusNumber
          ? _value.orderStatusNumber
          : orderStatusNumber // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StatusImpl implements _Status {
  const _$StatusImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "statusName") this.statusName,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "orderStatusNumber") this.orderStatusNumber});

  factory _$StatusImpl.fromJson(Map<String, dynamic> json) =>
      _$$StatusImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "statusName")
  final String? statusName;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "orderStatusNumber")
  final int? orderStatusNumber;

  @override
  String toString() {
    return 'Status(id: $id, statusName: $statusName, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, isDeleted: $isDeleted, orderStatusNumber: $orderStatusNumber)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StatusImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.statusName, statusName) ||
                other.statusName == statusName) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.orderStatusNumber, orderStatusNumber) ||
                other.orderStatusNumber == orderStatusNumber));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, statusName, createdAt,
      updatedAt, v, isDeleted, orderStatusNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      __$$StatusImplCopyWithImpl<_$StatusImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StatusImplToJson(
      this,
    );
  }
}

abstract class _Status implements Status {
  const factory _Status(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "statusName") final String? statusName,
          @JsonKey(name: "createdAt") final String? createdAt,
          @JsonKey(name: "updatedAt") final String? updatedAt,
          @JsonKey(name: "__v") final int? v,
          @JsonKey(name: "isDeleted") final bool? isDeleted,
          @JsonKey(name: "orderStatusNumber") final int? orderStatusNumber}) =
      _$StatusImpl;

  factory _Status.fromJson(Map<String, dynamic> json) = _$StatusImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "statusName")
  String? get statusName;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "orderStatusNumber")
  int? get orderStatusNumber;
  @override
  @JsonKey(ignore: true)
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

OrdersBySupplier _$OrdersBySupplierFromJson(Map<String, dynamic> json) {
  return _OrdersBySupplier.fromJson(json);
}

/// @nodoc
mixin _$OrdersBySupplier {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierName")
  String? get supplierName => throw _privateConstructorUsedError;
  @JsonKey(name: "deliverStatus")
  Status? get deliverStatus => throw _privateConstructorUsedError;
  @JsonKey(name: "arrivalDate")
  String? get arrivalDate => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierOrderNumber")
  String? get supplierOrderNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "orderDeliveryDate")
  String? get orderDeliveryDate => throw _privateConstructorUsedError;
  @JsonKey(name: "orderDate")
  String? get orderDate => throw _privateConstructorUsedError;
  @JsonKey(name: "totalWeight")
  double? get totalWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "totalPayment")
  double? get totalPayment => throw _privateConstructorUsedError;
  @JsonKey(name: "driverName")
  String? get driverName => throw _privateConstructorUsedError;
  @JsonKey(name: "driverNumber")
  String? get driverNumber => throw _privateConstructorUsedError;
  @JsonKey(name: "signature")
  String? get signature => throw _privateConstructorUsedError;
  @JsonKey(name: "products")
  List<Product>? get products => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $OrdersBySupplierCopyWith<OrdersBySupplier> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrdersBySupplierCopyWith<$Res> {
  factory $OrdersBySupplierCopyWith(
          OrdersBySupplier value, $Res Function(OrdersBySupplier) then) =
      _$OrdersBySupplierCopyWithImpl<$Res, OrdersBySupplier>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "supplierName") String? supplierName,
      @JsonKey(name: "deliverStatus") Status? deliverStatus,
      @JsonKey(name: "arrivalDate") String? arrivalDate,
      @JsonKey(name: "supplierOrderNumber") String? supplierOrderNumber,
      @JsonKey(name: "orderDeliveryDate") String? orderDeliveryDate,
      @JsonKey(name: "orderDate") String? orderDate,
      @JsonKey(name: "totalWeight") double? totalWeight,
      @JsonKey(name: "totalPayment") double? totalPayment,
      @JsonKey(name: "driverName") String? driverName,
      @JsonKey(name: "driverNumber") String? driverNumber,
      @JsonKey(name: "signature") String? signature,
      @JsonKey(name: "products") List<Product>? products});

  $StatusCopyWith<$Res>? get deliverStatus;
}

/// @nodoc
class _$OrdersBySupplierCopyWithImpl<$Res, $Val extends OrdersBySupplier>
    implements $OrdersBySupplierCopyWith<$Res> {
  _$OrdersBySupplierCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? supplierName = freezed,
    Object? deliverStatus = freezed,
    Object? arrivalDate = freezed,
    Object? supplierOrderNumber = freezed,
    Object? orderDeliveryDate = freezed,
    Object? orderDate = freezed,
    Object? totalWeight = freezed,
    Object? totalPayment = freezed,
    Object? driverName = freezed,
    Object? driverNumber = freezed,
    Object? signature = freezed,
    Object? products = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierName: freezed == supplierName
          ? _value.supplierName
          : supplierName // ignore: cast_nullable_to_non_nullable
              as String?,
      deliverStatus: freezed == deliverStatus
          ? _value.deliverStatus
          : deliverStatus // ignore: cast_nullable_to_non_nullable
              as Status?,
      arrivalDate: freezed == arrivalDate
          ? _value.arrivalDate
          : arrivalDate // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierOrderNumber: freezed == supplierOrderNumber
          ? _value.supplierOrderNumber
          : supplierOrderNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      orderDeliveryDate: freezed == orderDeliveryDate
          ? _value.orderDeliveryDate
          : orderDeliveryDate // ignore: cast_nullable_to_non_nullable
              as String?,
      orderDate: freezed == orderDate
          ? _value.orderDate
          : orderDate // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      totalPayment: freezed == totalPayment
          ? _value.totalPayment
          : totalPayment // ignore: cast_nullable_to_non_nullable
              as double?,
      driverName: freezed == driverName
          ? _value.driverName
          : driverName // ignore: cast_nullable_to_non_nullable
              as String?,
      driverNumber: freezed == driverNumber
          ? _value.driverNumber
          : driverNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      signature: freezed == signature
          ? _value.signature
          : signature // ignore: cast_nullable_to_non_nullable
              as String?,
      products: freezed == products
          ? _value.products
          : products // ignore: cast_nullable_to_non_nullable
              as List<Product>?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $StatusCopyWith<$Res>? get deliverStatus {
    if (_value.deliverStatus == null) {
      return null;
    }

    return $StatusCopyWith<$Res>(_value.deliverStatus!, (value) {
      return _then(_value.copyWith(deliverStatus: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$OrdersBySupplierImplCopyWith<$Res>
    implements $OrdersBySupplierCopyWith<$Res> {
  factory _$$OrdersBySupplierImplCopyWith(_$OrdersBySupplierImpl value,
          $Res Function(_$OrdersBySupplierImpl) then) =
      __$$OrdersBySupplierImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "supplierName") String? supplierName,
      @JsonKey(name: "deliverStatus") Status? deliverStatus,
      @JsonKey(name: "arrivalDate") String? arrivalDate,
      @JsonKey(name: "supplierOrderNumber") String? supplierOrderNumber,
      @JsonKey(name: "orderDeliveryDate") String? orderDeliveryDate,
      @JsonKey(name: "orderDate") String? orderDate,
      @JsonKey(name: "totalWeight") double? totalWeight,
      @JsonKey(name: "totalPayment") double? totalPayment,
      @JsonKey(name: "driverName") String? driverName,
      @JsonKey(name: "driverNumber") String? driverNumber,
      @JsonKey(name: "signature") String? signature,
      @JsonKey(name: "products") List<Product>? products});

  @override
  $StatusCopyWith<$Res>? get deliverStatus;
}

/// @nodoc
class __$$OrdersBySupplierImplCopyWithImpl<$Res>
    extends _$OrdersBySupplierCopyWithImpl<$Res, _$OrdersBySupplierImpl>
    implements _$$OrdersBySupplierImplCopyWith<$Res> {
  __$$OrdersBySupplierImplCopyWithImpl(_$OrdersBySupplierImpl _value,
      $Res Function(_$OrdersBySupplierImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? supplierName = freezed,
    Object? deliverStatus = freezed,
    Object? arrivalDate = freezed,
    Object? supplierOrderNumber = freezed,
    Object? orderDeliveryDate = freezed,
    Object? orderDate = freezed,
    Object? totalWeight = freezed,
    Object? totalPayment = freezed,
    Object? driverName = freezed,
    Object? driverNumber = freezed,
    Object? signature = freezed,
    Object? products = freezed,
  }) {
    return _then(_$OrdersBySupplierImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierName: freezed == supplierName
          ? _value.supplierName
          : supplierName // ignore: cast_nullable_to_non_nullable
              as String?,
      deliverStatus: freezed == deliverStatus
          ? _value.deliverStatus
          : deliverStatus // ignore: cast_nullable_to_non_nullable
              as Status?,
      arrivalDate: freezed == arrivalDate
          ? _value.arrivalDate
          : arrivalDate // ignore: cast_nullable_to_non_nullable
              as String?,
      supplierOrderNumber: freezed == supplierOrderNumber
          ? _value.supplierOrderNumber
          : supplierOrderNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      orderDeliveryDate: freezed == orderDeliveryDate
          ? _value.orderDeliveryDate
          : orderDeliveryDate // ignore: cast_nullable_to_non_nullable
              as String?,
      orderDate: freezed == orderDate
          ? _value.orderDate
          : orderDate // ignore: cast_nullable_to_non_nullable
              as String?,
      totalWeight: freezed == totalWeight
          ? _value.totalWeight
          : totalWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      totalPayment: freezed == totalPayment
          ? _value.totalPayment
          : totalPayment // ignore: cast_nullable_to_non_nullable
              as double?,
      driverName: freezed == driverName
          ? _value.driverName
          : driverName // ignore: cast_nullable_to_non_nullable
              as String?,
      driverNumber: freezed == driverNumber
          ? _value.driverNumber
          : driverNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      signature: freezed == signature
          ? _value.signature
          : signature // ignore: cast_nullable_to_non_nullable
              as String?,
      products: freezed == products
          ? _value._products
          : products // ignore: cast_nullable_to_non_nullable
              as List<Product>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$OrdersBySupplierImpl implements _OrdersBySupplier {
  const _$OrdersBySupplierImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "supplierName") this.supplierName,
      @JsonKey(name: "deliverStatus") this.deliverStatus,
      @JsonKey(name: "arrivalDate") this.arrivalDate,
      @JsonKey(name: "supplierOrderNumber") this.supplierOrderNumber,
      @JsonKey(name: "orderDeliveryDate") this.orderDeliveryDate,
      @JsonKey(name: "orderDate") this.orderDate,
      @JsonKey(name: "totalWeight") this.totalWeight,
      @JsonKey(name: "totalPayment") this.totalPayment,
      @JsonKey(name: "driverName") this.driverName,
      @JsonKey(name: "driverNumber") this.driverNumber,
      @JsonKey(name: "signature") this.signature,
      @JsonKey(name: "products") final List<Product>? products})
      : _products = products;

  factory _$OrdersBySupplierImpl.fromJson(Map<String, dynamic> json) =>
      _$$OrdersBySupplierImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "supplierName")
  final String? supplierName;
  @override
  @JsonKey(name: "deliverStatus")
  final Status? deliverStatus;
  @override
  @JsonKey(name: "arrivalDate")
  final String? arrivalDate;
  @override
  @JsonKey(name: "supplierOrderNumber")
  final String? supplierOrderNumber;
  @override
  @JsonKey(name: "orderDeliveryDate")
  final String? orderDeliveryDate;
  @override
  @JsonKey(name: "orderDate")
  final String? orderDate;
  @override
  @JsonKey(name: "totalWeight")
  final double? totalWeight;
  @override
  @JsonKey(name: "totalPayment")
  final double? totalPayment;
  @override
  @JsonKey(name: "driverName")
  final String? driverName;
  @override
  @JsonKey(name: "driverNumber")
  final String? driverNumber;
  @override
  @JsonKey(name: "signature")
  final String? signature;
  final List<Product>? _products;
  @override
  @JsonKey(name: "products")
  List<Product>? get products {
    final value = _products;
    if (value == null) return null;
    if (_products is EqualUnmodifiableListView) return _products;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'OrdersBySupplier(id: $id, supplierName: $supplierName, deliverStatus: $deliverStatus, arrivalDate: $arrivalDate, supplierOrderNumber: $supplierOrderNumber, orderDeliveryDate: $orderDeliveryDate, orderDate: $orderDate, totalWeight: $totalWeight, totalPayment: $totalPayment, driverName: $driverName, driverNumber: $driverNumber, signature: $signature, products: $products)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OrdersBySupplierImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.supplierName, supplierName) ||
                other.supplierName == supplierName) &&
            (identical(other.deliverStatus, deliverStatus) ||
                other.deliverStatus == deliverStatus) &&
            (identical(other.arrivalDate, arrivalDate) ||
                other.arrivalDate == arrivalDate) &&
            (identical(other.supplierOrderNumber, supplierOrderNumber) ||
                other.supplierOrderNumber == supplierOrderNumber) &&
            (identical(other.orderDeliveryDate, orderDeliveryDate) ||
                other.orderDeliveryDate == orderDeliveryDate) &&
            (identical(other.orderDate, orderDate) ||
                other.orderDate == orderDate) &&
            (identical(other.totalWeight, totalWeight) ||
                other.totalWeight == totalWeight) &&
            (identical(other.totalPayment, totalPayment) ||
                other.totalPayment == totalPayment) &&
            (identical(other.driverName, driverName) ||
                other.driverName == driverName) &&
            (identical(other.driverNumber, driverNumber) ||
                other.driverNumber == driverNumber) &&
            (identical(other.signature, signature) ||
                other.signature == signature) &&
            const DeepCollectionEquality().equals(other._products, _products));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      supplierName,
      deliverStatus,
      arrivalDate,
      supplierOrderNumber,
      orderDeliveryDate,
      orderDate,
      totalWeight,
      totalPayment,
      driverName,
      driverNumber,
      signature,
      const DeepCollectionEquality().hash(_products));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OrdersBySupplierImplCopyWith<_$OrdersBySupplierImpl> get copyWith =>
      __$$OrdersBySupplierImplCopyWithImpl<_$OrdersBySupplierImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$OrdersBySupplierImplToJson(
      this,
    );
  }
}

abstract class _OrdersBySupplier implements OrdersBySupplier {
  const factory _OrdersBySupplier(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "supplierName") final String? supplierName,
      @JsonKey(name: "deliverStatus") final Status? deliverStatus,
      @JsonKey(name: "arrivalDate") final String? arrivalDate,
      @JsonKey(name: "supplierOrderNumber") final String? supplierOrderNumber,
      @JsonKey(name: "orderDeliveryDate") final String? orderDeliveryDate,
      @JsonKey(name: "orderDate") final String? orderDate,
      @JsonKey(name: "totalWeight") final double? totalWeight,
      @JsonKey(name: "totalPayment") final double? totalPayment,
      @JsonKey(name: "driverName") final String? driverName,
      @JsonKey(name: "driverNumber") final String? driverNumber,
      @JsonKey(name: "signature") final String? signature,
      @JsonKey(name: "products")
      final List<Product>? products}) = _$OrdersBySupplierImpl;

  factory _OrdersBySupplier.fromJson(Map<String, dynamic> json) =
      _$OrdersBySupplierImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "supplierName")
  String? get supplierName;
  @override
  @JsonKey(name: "deliverStatus")
  Status? get deliverStatus;
  @override
  @JsonKey(name: "arrivalDate")
  String? get arrivalDate;
  @override
  @JsonKey(name: "supplierOrderNumber")
  String? get supplierOrderNumber;
  @override
  @JsonKey(name: "orderDeliveryDate")
  String? get orderDeliveryDate;
  @override
  @JsonKey(name: "orderDate")
  String? get orderDate;
  @override
  @JsonKey(name: "totalWeight")
  double? get totalWeight;
  @override
  @JsonKey(name: "totalPayment")
  double? get totalPayment;
  @override
  @JsonKey(name: "driverName")
  String? get driverName;
  @override
  @JsonKey(name: "driverNumber")
  String? get driverNumber;
  @override
  @JsonKey(name: "signature")
  String? get signature;
  @override
  @JsonKey(name: "products")
  List<Product>? get products;
  @override
  @JsonKey(ignore: true)
  _$$OrdersBySupplierImplCopyWith<_$OrdersBySupplierImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Product _$ProductFromJson(Map<String, dynamic> json) {
  return _Product.fromJson(json);
}

/// @nodoc
mixin _$Product {
  @JsonKey(name: "productId")
  String? get productId => throw _privateConstructorUsedError;
  @JsonKey(name: "productName")
  String? get productName => throw _privateConstructorUsedError;
  @JsonKey(name: "quantity")
  int? get quantity => throw _privateConstructorUsedError;
  int? get unitQuantity => throw _privateConstructorUsedError;
  @JsonKey(name: "sku")
  String? get sku => throw _privateConstructorUsedError;
  @JsonKey(name: "brand")
  String? get brand => throw _privateConstructorUsedError;
  @JsonKey(name: "scale")
  String? get scale => throw _privateConstructorUsedError;
  @JsonKey(name: "category")
  Category? get category => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategory")
  SubCategory? get subCategory => throw _privateConstructorUsedError;
  @JsonKey(name: "subSubCategory")
  SubSubCategory? get subSubCategory => throw _privateConstructorUsedError;
  @JsonKey(name: "pricePerUnit")
  double? get pricePerUnit => throw _privateConstructorUsedError;
  @JsonKey(name: "totalPayment")
  double? get totalPayment => throw _privateConstructorUsedError;
  @JsonKey(name: "discountedPrice")
  double? get discountedPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "itemWeight")
  double? get itemWeight => throw _privateConstructorUsedError;
  @JsonKey(name: "issueStatus")
  Status? get issueStatus => throw _privateConstructorUsedError;
  @JsonKey(name: "isIssue")
  bool? get isIssue => throw _privateConstructorUsedError;
  @JsonKey(name: "issue")
  String? get issue => throw _privateConstructorUsedError;
  @JsonKey(name: "note")
  String? get note => throw _privateConstructorUsedError;
  @JsonKey(name: "missingQuantity")
  int? get missingQuantity => throw _privateConstructorUsedError;
  @JsonKey(name: "mainImage")
  String? get mainImage => throw _privateConstructorUsedError;
  bool? get isBottle => throw _privateConstructorUsedError;
  bool? get isUpdated => throw _privateConstructorUsedError;
  int? get updatedUnitQuantity => throw _privateConstructorUsedError;
  double? get updatedPrice => throw _privateConstructorUsedError;
  int? get numberOfUnit => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductCopyWith<Product> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductCopyWith<$Res> {
  factory $ProductCopyWith(Product value, $Res Function(Product) then) =
      _$ProductCopyWithImpl<$Res, Product>;
  @useResult
  $Res call(
      {@JsonKey(name: "productId") String? productId,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "quantity") int? quantity,
      int? unitQuantity,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "brand") String? brand,
      @JsonKey(name: "scale") String? scale,
      @JsonKey(name: "category") Category? category,
      @JsonKey(name: "subCategory") SubCategory? subCategory,
      @JsonKey(name: "subSubCategory") SubSubCategory? subSubCategory,
      @JsonKey(name: "pricePerUnit") double? pricePerUnit,
      @JsonKey(name: "totalPayment") double? totalPayment,
      @JsonKey(name: "discountedPrice") double? discountedPrice,
      @JsonKey(name: "itemWeight") double? itemWeight,
      @JsonKey(name: "issueStatus") Status? issueStatus,
      @JsonKey(name: "isIssue") bool? isIssue,
      @JsonKey(name: "issue") String? issue,
      @JsonKey(name: "note") String? note,
      @JsonKey(name: "missingQuantity") int? missingQuantity,
      @JsonKey(name: "mainImage") String? mainImage,
      bool? isBottle,
      bool? isUpdated,
      int? updatedUnitQuantity,
      double? updatedPrice,
      int? numberOfUnit});

  $CategoryCopyWith<$Res>? get category;
  $SubCategoryCopyWith<$Res>? get subCategory;
  $SubSubCategoryCopyWith<$Res>? get subSubCategory;
  $StatusCopyWith<$Res>? get issueStatus;
}

/// @nodoc
class _$ProductCopyWithImpl<$Res, $Val extends Product>
    implements $ProductCopyWith<$Res> {
  _$ProductCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productId = freezed,
    Object? productName = freezed,
    Object? quantity = freezed,
    Object? unitQuantity = freezed,
    Object? sku = freezed,
    Object? brand = freezed,
    Object? scale = freezed,
    Object? category = freezed,
    Object? subCategory = freezed,
    Object? subSubCategory = freezed,
    Object? pricePerUnit = freezed,
    Object? totalPayment = freezed,
    Object? discountedPrice = freezed,
    Object? itemWeight = freezed,
    Object? issueStatus = freezed,
    Object? isIssue = freezed,
    Object? issue = freezed,
    Object? note = freezed,
    Object? missingQuantity = freezed,
    Object? mainImage = freezed,
    Object? isBottle = freezed,
    Object? isUpdated = freezed,
    Object? updatedUnitQuantity = freezed,
    Object? updatedPrice = freezed,
    Object? numberOfUnit = freezed,
  }) {
    return _then(_value.copyWith(
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      quantity: freezed == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int?,
      unitQuantity: freezed == unitQuantity
          ? _value.unitQuantity
          : unitQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      brand: freezed == brand
          ? _value.brand
          : brand // ignore: cast_nullable_to_non_nullable
              as String?,
      scale: freezed == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as Category?,
      subCategory: freezed == subCategory
          ? _value.subCategory
          : subCategory // ignore: cast_nullable_to_non_nullable
              as SubCategory?,
      subSubCategory: freezed == subSubCategory
          ? _value.subSubCategory
          : subSubCategory // ignore: cast_nullable_to_non_nullable
              as SubSubCategory?,
      pricePerUnit: freezed == pricePerUnit
          ? _value.pricePerUnit
          : pricePerUnit // ignore: cast_nullable_to_non_nullable
              as double?,
      totalPayment: freezed == totalPayment
          ? _value.totalPayment
          : totalPayment // ignore: cast_nullable_to_non_nullable
              as double?,
      discountedPrice: freezed == discountedPrice
          ? _value.discountedPrice
          : discountedPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      itemWeight: freezed == itemWeight
          ? _value.itemWeight
          : itemWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      issueStatus: freezed == issueStatus
          ? _value.issueStatus
          : issueStatus // ignore: cast_nullable_to_non_nullable
              as Status?,
      isIssue: freezed == isIssue
          ? _value.isIssue
          : isIssue // ignore: cast_nullable_to_non_nullable
              as bool?,
      issue: freezed == issue
          ? _value.issue
          : issue // ignore: cast_nullable_to_non_nullable
              as String?,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      missingQuantity: freezed == missingQuantity
          ? _value.missingQuantity
          : missingQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isBottle: freezed == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool?,
      isUpdated: freezed == isUpdated
          ? _value.isUpdated
          : isUpdated // ignore: cast_nullable_to_non_nullable
              as bool?,
      updatedUnitQuantity: freezed == updatedUnitQuantity
          ? _value.updatedUnitQuantity
          : updatedUnitQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      updatedPrice: freezed == updatedPrice
          ? _value.updatedPrice
          : updatedPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $CategoryCopyWith<$Res>? get category {
    if (_value.category == null) {
      return null;
    }

    return $CategoryCopyWith<$Res>(_value.category!, (value) {
      return _then(_value.copyWith(category: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $SubCategoryCopyWith<$Res>? get subCategory {
    if (_value.subCategory == null) {
      return null;
    }

    return $SubCategoryCopyWith<$Res>(_value.subCategory!, (value) {
      return _then(_value.copyWith(subCategory: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $SubSubCategoryCopyWith<$Res>? get subSubCategory {
    if (_value.subSubCategory == null) {
      return null;
    }

    return $SubSubCategoryCopyWith<$Res>(_value.subSubCategory!, (value) {
      return _then(_value.copyWith(subSubCategory: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $StatusCopyWith<$Res>? get issueStatus {
    if (_value.issueStatus == null) {
      return null;
    }

    return $StatusCopyWith<$Res>(_value.issueStatus!, (value) {
      return _then(_value.copyWith(issueStatus: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProductImplCopyWith<$Res> implements $ProductCopyWith<$Res> {
  factory _$$ProductImplCopyWith(
          _$ProductImpl value, $Res Function(_$ProductImpl) then) =
      __$$ProductImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "productId") String? productId,
      @JsonKey(name: "productName") String? productName,
      @JsonKey(name: "quantity") int? quantity,
      int? unitQuantity,
      @JsonKey(name: "sku") String? sku,
      @JsonKey(name: "brand") String? brand,
      @JsonKey(name: "scale") String? scale,
      @JsonKey(name: "category") Category? category,
      @JsonKey(name: "subCategory") SubCategory? subCategory,
      @JsonKey(name: "subSubCategory") SubSubCategory? subSubCategory,
      @JsonKey(name: "pricePerUnit") double? pricePerUnit,
      @JsonKey(name: "totalPayment") double? totalPayment,
      @JsonKey(name: "discountedPrice") double? discountedPrice,
      @JsonKey(name: "itemWeight") double? itemWeight,
      @JsonKey(name: "issueStatus") Status? issueStatus,
      @JsonKey(name: "isIssue") bool? isIssue,
      @JsonKey(name: "issue") String? issue,
      @JsonKey(name: "note") String? note,
      @JsonKey(name: "missingQuantity") int? missingQuantity,
      @JsonKey(name: "mainImage") String? mainImage,
      bool? isBottle,
      bool? isUpdated,
      int? updatedUnitQuantity,
      double? updatedPrice,
      int? numberOfUnit});

  @override
  $CategoryCopyWith<$Res>? get category;
  @override
  $SubCategoryCopyWith<$Res>? get subCategory;
  @override
  $SubSubCategoryCopyWith<$Res>? get subSubCategory;
  @override
  $StatusCopyWith<$Res>? get issueStatus;
}

/// @nodoc
class __$$ProductImplCopyWithImpl<$Res>
    extends _$ProductCopyWithImpl<$Res, _$ProductImpl>
    implements _$$ProductImplCopyWith<$Res> {
  __$$ProductImplCopyWithImpl(
      _$ProductImpl _value, $Res Function(_$ProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productId = freezed,
    Object? productName = freezed,
    Object? quantity = freezed,
    Object? unitQuantity = freezed,
    Object? sku = freezed,
    Object? brand = freezed,
    Object? scale = freezed,
    Object? category = freezed,
    Object? subCategory = freezed,
    Object? subSubCategory = freezed,
    Object? pricePerUnit = freezed,
    Object? totalPayment = freezed,
    Object? discountedPrice = freezed,
    Object? itemWeight = freezed,
    Object? issueStatus = freezed,
    Object? isIssue = freezed,
    Object? issue = freezed,
    Object? note = freezed,
    Object? missingQuantity = freezed,
    Object? mainImage = freezed,
    Object? isBottle = freezed,
    Object? isUpdated = freezed,
    Object? updatedUnitQuantity = freezed,
    Object? updatedPrice = freezed,
    Object? numberOfUnit = freezed,
  }) {
    return _then(_$ProductImpl(
      productId: freezed == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String?,
      productName: freezed == productName
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String?,
      quantity: freezed == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int?,
      unitQuantity: freezed == unitQuantity
          ? _value.unitQuantity
          : unitQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      sku: freezed == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String?,
      brand: freezed == brand
          ? _value.brand
          : brand // ignore: cast_nullable_to_non_nullable
              as String?,
      scale: freezed == scale
          ? _value.scale
          : scale // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as Category?,
      subCategory: freezed == subCategory
          ? _value.subCategory
          : subCategory // ignore: cast_nullable_to_non_nullable
              as SubCategory?,
      subSubCategory: freezed == subSubCategory
          ? _value.subSubCategory
          : subSubCategory // ignore: cast_nullable_to_non_nullable
              as SubSubCategory?,
      pricePerUnit: freezed == pricePerUnit
          ? _value.pricePerUnit
          : pricePerUnit // ignore: cast_nullable_to_non_nullable
              as double?,
      totalPayment: freezed == totalPayment
          ? _value.totalPayment
          : totalPayment // ignore: cast_nullable_to_non_nullable
              as double?,
      discountedPrice: freezed == discountedPrice
          ? _value.discountedPrice
          : discountedPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      itemWeight: freezed == itemWeight
          ? _value.itemWeight
          : itemWeight // ignore: cast_nullable_to_non_nullable
              as double?,
      issueStatus: freezed == issueStatus
          ? _value.issueStatus
          : issueStatus // ignore: cast_nullable_to_non_nullable
              as Status?,
      isIssue: freezed == isIssue
          ? _value.isIssue
          : isIssue // ignore: cast_nullable_to_non_nullable
              as bool?,
      issue: freezed == issue
          ? _value.issue
          : issue // ignore: cast_nullable_to_non_nullable
              as String?,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      missingQuantity: freezed == missingQuantity
          ? _value.missingQuantity
          : missingQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      mainImage: freezed == mainImage
          ? _value.mainImage
          : mainImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isBottle: freezed == isBottle
          ? _value.isBottle
          : isBottle // ignore: cast_nullable_to_non_nullable
              as bool?,
      isUpdated: freezed == isUpdated
          ? _value.isUpdated
          : isUpdated // ignore: cast_nullable_to_non_nullable
              as bool?,
      updatedUnitQuantity: freezed == updatedUnitQuantity
          ? _value.updatedUnitQuantity
          : updatedUnitQuantity // ignore: cast_nullable_to_non_nullable
              as int?,
      updatedPrice: freezed == updatedPrice
          ? _value.updatedPrice
          : updatedPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      numberOfUnit: freezed == numberOfUnit
          ? _value.numberOfUnit
          : numberOfUnit // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductImpl implements _Product {
  const _$ProductImpl(
      {@JsonKey(name: "productId") this.productId,
      @JsonKey(name: "productName") this.productName,
      @JsonKey(name: "quantity") this.quantity,
      this.unitQuantity,
      @JsonKey(name: "sku") this.sku,
      @JsonKey(name: "brand") this.brand,
      @JsonKey(name: "scale") this.scale,
      @JsonKey(name: "category") this.category,
      @JsonKey(name: "subCategory") this.subCategory,
      @JsonKey(name: "subSubCategory") this.subSubCategory,
      @JsonKey(name: "pricePerUnit") this.pricePerUnit,
      @JsonKey(name: "totalPayment") this.totalPayment,
      @JsonKey(name: "discountedPrice") this.discountedPrice,
      @JsonKey(name: "itemWeight") this.itemWeight,
      @JsonKey(name: "issueStatus") this.issueStatus,
      @JsonKey(name: "isIssue") this.isIssue,
      @JsonKey(name: "issue") this.issue,
      @JsonKey(name: "note") this.note,
      @JsonKey(name: "missingQuantity") this.missingQuantity,
      @JsonKey(name: "mainImage") this.mainImage,
      this.isBottle,
      this.isUpdated,
      this.updatedUnitQuantity,
      this.updatedPrice,
      this.numberOfUnit});

  factory _$ProductImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductImplFromJson(json);

  @override
  @JsonKey(name: "productId")
  final String? productId;
  @override
  @JsonKey(name: "productName")
  final String? productName;
  @override
  @JsonKey(name: "quantity")
  final int? quantity;
  @override
  final int? unitQuantity;
  @override
  @JsonKey(name: "sku")
  final String? sku;
  @override
  @JsonKey(name: "brand")
  final String? brand;
  @override
  @JsonKey(name: "scale")
  final String? scale;
  @override
  @JsonKey(name: "category")
  final Category? category;
  @override
  @JsonKey(name: "subCategory")
  final SubCategory? subCategory;
  @override
  @JsonKey(name: "subSubCategory")
  final SubSubCategory? subSubCategory;
  @override
  @JsonKey(name: "pricePerUnit")
  final double? pricePerUnit;
  @override
  @JsonKey(name: "totalPayment")
  final double? totalPayment;
  @override
  @JsonKey(name: "discountedPrice")
  final double? discountedPrice;
  @override
  @JsonKey(name: "itemWeight")
  final double? itemWeight;
  @override
  @JsonKey(name: "issueStatus")
  final Status? issueStatus;
  @override
  @JsonKey(name: "isIssue")
  final bool? isIssue;
  @override
  @JsonKey(name: "issue")
  final String? issue;
  @override
  @JsonKey(name: "note")
  final String? note;
  @override
  @JsonKey(name: "missingQuantity")
  final int? missingQuantity;
  @override
  @JsonKey(name: "mainImage")
  final String? mainImage;
  @override
  final bool? isBottle;
  @override
  final bool? isUpdated;
  @override
  final int? updatedUnitQuantity;
  @override
  final double? updatedPrice;
  @override
  final int? numberOfUnit;

  @override
  String toString() {
    return 'Product(productId: $productId, productName: $productName, quantity: $quantity, unitQuantity: $unitQuantity, sku: $sku, brand: $brand, scale: $scale, category: $category, subCategory: $subCategory, subSubCategory: $subSubCategory, pricePerUnit: $pricePerUnit, totalPayment: $totalPayment, discountedPrice: $discountedPrice, itemWeight: $itemWeight, issueStatus: $issueStatus, isIssue: $isIssue, issue: $issue, note: $note, missingQuantity: $missingQuantity, mainImage: $mainImage, isBottle: $isBottle, isUpdated: $isUpdated, updatedUnitQuantity: $updatedUnitQuantity, updatedPrice: $updatedPrice, numberOfUnit: $numberOfUnit)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductImpl &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.productName, productName) ||
                other.productName == productName) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.unitQuantity, unitQuantity) ||
                other.unitQuantity == unitQuantity) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            (identical(other.brand, brand) || other.brand == brand) &&
            (identical(other.scale, scale) || other.scale == scale) &&
            (identical(other.category, category) ||
                other.category == category) &&
            (identical(other.subCategory, subCategory) ||
                other.subCategory == subCategory) &&
            (identical(other.subSubCategory, subSubCategory) ||
                other.subSubCategory == subSubCategory) &&
            (identical(other.pricePerUnit, pricePerUnit) ||
                other.pricePerUnit == pricePerUnit) &&
            (identical(other.totalPayment, totalPayment) ||
                other.totalPayment == totalPayment) &&
            (identical(other.discountedPrice, discountedPrice) ||
                other.discountedPrice == discountedPrice) &&
            (identical(other.itemWeight, itemWeight) ||
                other.itemWeight == itemWeight) &&
            (identical(other.issueStatus, issueStatus) ||
                other.issueStatus == issueStatus) &&
            (identical(other.isIssue, isIssue) || other.isIssue == isIssue) &&
            (identical(other.issue, issue) || other.issue == issue) &&
            (identical(other.note, note) || other.note == note) &&
            (identical(other.missingQuantity, missingQuantity) ||
                other.missingQuantity == missingQuantity) &&
            (identical(other.mainImage, mainImage) ||
                other.mainImage == mainImage) &&
            (identical(other.isBottle, isBottle) ||
                other.isBottle == isBottle) &&
            (identical(other.isUpdated, isUpdated) ||
                other.isUpdated == isUpdated) &&
            (identical(other.updatedUnitQuantity, updatedUnitQuantity) ||
                other.updatedUnitQuantity == updatedUnitQuantity) &&
            (identical(other.updatedPrice, updatedPrice) ||
                other.updatedPrice == updatedPrice) &&
            (identical(other.numberOfUnit, numberOfUnit) ||
                other.numberOfUnit == numberOfUnit));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        productId,
        productName,
        quantity,
        unitQuantity,
        sku,
        brand,
        scale,
        category,
        subCategory,
        subSubCategory,
        pricePerUnit,
        totalPayment,
        discountedPrice,
        itemWeight,
        issueStatus,
        isIssue,
        issue,
        note,
        missingQuantity,
        mainImage,
        isBottle,
        isUpdated,
        updatedUnitQuantity,
        updatedPrice,
        numberOfUnit
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductImplCopyWith<_$ProductImpl> get copyWith =>
      __$$ProductImplCopyWithImpl<_$ProductImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductImplToJson(
      this,
    );
  }
}

abstract class _Product implements Product {
  const factory _Product(
      {@JsonKey(name: "productId") final String? productId,
      @JsonKey(name: "productName") final String? productName,
      @JsonKey(name: "quantity") final int? quantity,
      final int? unitQuantity,
      @JsonKey(name: "sku") final String? sku,
      @JsonKey(name: "brand") final String? brand,
      @JsonKey(name: "scale") final String? scale,
      @JsonKey(name: "category") final Category? category,
      @JsonKey(name: "subCategory") final SubCategory? subCategory,
      @JsonKey(name: "subSubCategory") final SubSubCategory? subSubCategory,
      @JsonKey(name: "pricePerUnit") final double? pricePerUnit,
      @JsonKey(name: "totalPayment") final double? totalPayment,
      @JsonKey(name: "discountedPrice") final double? discountedPrice,
      @JsonKey(name: "itemWeight") final double? itemWeight,
      @JsonKey(name: "issueStatus") final Status? issueStatus,
      @JsonKey(name: "isIssue") final bool? isIssue,
      @JsonKey(name: "issue") final String? issue,
      @JsonKey(name: "note") final String? note,
      @JsonKey(name: "missingQuantity") final int? missingQuantity,
      @JsonKey(name: "mainImage") final String? mainImage,
      final bool? isBottle,
      final bool? isUpdated,
      final int? updatedUnitQuantity,
      final double? updatedPrice,
      final int? numberOfUnit}) = _$ProductImpl;

  factory _Product.fromJson(Map<String, dynamic> json) = _$ProductImpl.fromJson;

  @override
  @JsonKey(name: "productId")
  String? get productId;
  @override
  @JsonKey(name: "productName")
  String? get productName;
  @override
  @JsonKey(name: "quantity")
  int? get quantity;
  @override
  int? get unitQuantity;
  @override
  @JsonKey(name: "sku")
  String? get sku;
  @override
  @JsonKey(name: "brand")
  String? get brand;
  @override
  @JsonKey(name: "scale")
  String? get scale;
  @override
  @JsonKey(name: "category")
  Category? get category;
  @override
  @JsonKey(name: "subCategory")
  SubCategory? get subCategory;
  @override
  @JsonKey(name: "subSubCategory")
  SubSubCategory? get subSubCategory;
  @override
  @JsonKey(name: "pricePerUnit")
  double? get pricePerUnit;
  @override
  @JsonKey(name: "totalPayment")
  double? get totalPayment;
  @override
  @JsonKey(name: "discountedPrice")
  double? get discountedPrice;
  @override
  @JsonKey(name: "itemWeight")
  double? get itemWeight;
  @override
  @JsonKey(name: "issueStatus")
  Status? get issueStatus;
  @override
  @JsonKey(name: "isIssue")
  bool? get isIssue;
  @override
  @JsonKey(name: "issue")
  String? get issue;
  @override
  @JsonKey(name: "note")
  String? get note;
  @override
  @JsonKey(name: "missingQuantity")
  int? get missingQuantity;
  @override
  @JsonKey(name: "mainImage")
  String? get mainImage;
  @override
  bool? get isBottle;
  @override
  bool? get isUpdated;
  @override
  int? get updatedUnitQuantity;
  @override
  double? get updatedPrice;
  @override
  int? get numberOfUnit;
  @override
  @JsonKey(ignore: true)
  _$$ProductImplCopyWith<_$ProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Category _$CategoryFromJson(Map<String, dynamic> json) {
  return _Category.fromJson(json);
}

/// @nodoc
mixin _$Category {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryName")
  String? get categoryName => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "categoryImage")
  String? get categoryImage => throw _privateConstructorUsedError;
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference => throw _privateConstructorUsedError;
  @JsonKey(name: "order")
  int? get order => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CategoryCopyWith<Category> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CategoryCopyWith<$Res> {
  factory $CategoryCopyWith(Category value, $Res Function(Category) then) =
      _$CategoryCopyWithImpl<$Res, Category>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryName") String? categoryName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "categoryImage") String? categoryImage,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class _$CategoryCopyWithImpl<$Res, $Val extends Category>
    implements $CategoryCopyWith<$Res> {
  _$CategoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? categoryImage = freezed,
    Object? isHomePreference = freezed,
    Object? order = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryImage: freezed == categoryImage
          ? _value.categoryImage
          : categoryImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CategoryImplCopyWith<$Res>
    implements $CategoryCopyWith<$Res> {
  factory _$$CategoryImplCopyWith(
          _$CategoryImpl value, $Res Function(_$CategoryImpl) then) =
      __$$CategoryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "categoryName") String? categoryName,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "categoryImage") String? categoryImage,
      @JsonKey(name: "isHomePreference") bool? isHomePreference,
      @JsonKey(name: "order") int? order,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class __$$CategoryImplCopyWithImpl<$Res>
    extends _$CategoryCopyWithImpl<$Res, _$CategoryImpl>
    implements _$$CategoryImplCopyWith<$Res> {
  __$$CategoryImplCopyWithImpl(
      _$CategoryImpl _value, $Res Function(_$CategoryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryName = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? categoryImage = freezed,
    Object? isHomePreference = freezed,
    Object? order = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_$CategoryImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      categoryName: freezed == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryImage: freezed == categoryImage
          ? _value.categoryImage
          : categoryImage // ignore: cast_nullable_to_non_nullable
              as String?,
      isHomePreference: freezed == isHomePreference
          ? _value.isHomePreference
          : isHomePreference // ignore: cast_nullable_to_non_nullable
              as bool?,
      order: freezed == order
          ? _value.order
          : order // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CategoryImpl implements _Category {
  const _$CategoryImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "categoryName") this.categoryName,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "categoryImage") this.categoryImage,
      @JsonKey(name: "isHomePreference") this.isHomePreference,
      @JsonKey(name: "order") this.order,
      @JsonKey(name: "isDeleted") this.isDeleted});

  factory _$CategoryImpl.fromJson(Map<String, dynamic> json) =>
      _$$CategoryImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "categoryName")
  final String? categoryName;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "categoryImage")
  final String? categoryImage;
  @override
  @JsonKey(name: "isHomePreference")
  final bool? isHomePreference;
  @override
  @JsonKey(name: "order")
  final int? order;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;

  @override
  String toString() {
    return 'Category(id: $id, categoryName: $categoryName, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, categoryImage: $categoryImage, isHomePreference: $isHomePreference, order: $order, isDeleted: $isDeleted)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CategoryImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.categoryName, categoryName) ||
                other.categoryName == categoryName) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.categoryImage, categoryImage) ||
                other.categoryImage == categoryImage) &&
            (identical(other.isHomePreference, isHomePreference) ||
                other.isHomePreference == isHomePreference) &&
            (identical(other.order, order) || other.order == order) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, categoryName, createdAt,
      updatedAt, v, categoryImage, isHomePreference, order, isDeleted);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CategoryImplCopyWith<_$CategoryImpl> get copyWith =>
      __$$CategoryImplCopyWithImpl<_$CategoryImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CategoryImplToJson(
      this,
    );
  }
}

abstract class _Category implements Category {
  const factory _Category(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "categoryName") final String? categoryName,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v,
      @JsonKey(name: "categoryImage") final String? categoryImage,
      @JsonKey(name: "isHomePreference") final bool? isHomePreference,
      @JsonKey(name: "order") final int? order,
      @JsonKey(name: "isDeleted") final bool? isDeleted}) = _$CategoryImpl;

  factory _Category.fromJson(Map<String, dynamic> json) =
      _$CategoryImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "categoryName")
  String? get categoryName;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "categoryImage")
  String? get categoryImage;
  @override
  @JsonKey(name: "isHomePreference")
  bool? get isHomePreference;
  @override
  @JsonKey(name: "order")
  int? get order;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(ignore: true)
  _$$CategoryImplCopyWith<_$CategoryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SubCategory _$SubCategoryFromJson(Map<String, dynamic> json) {
  return _SubCategory.fromJson(json);
}

/// @nodoc
mixin _$SubCategory {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryName")
  String? get subCategoryName => throw _privateConstructorUsedError;
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SubCategoryCopyWith<SubCategory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubCategoryCopyWith<$Res> {
  factory $SubCategoryCopyWith(
          SubCategory value, $Res Function(SubCategory) then) =
      _$SubCategoryCopyWithImpl<$Res, SubCategory>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryName") String? subCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class _$SubCategoryCopyWithImpl<$Res, $Val extends SubCategory>
    implements $SubCategoryCopyWith<$Res> {
  _$SubCategoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubCategoryImplCopyWith<$Res>
    implements $SubCategoryCopyWith<$Res> {
  factory _$$SubCategoryImplCopyWith(
          _$SubCategoryImpl value, $Res Function(_$SubCategoryImpl) then) =
      __$$SubCategoryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subCategoryName") String? subCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class __$$SubCategoryImplCopyWithImpl<$Res>
    extends _$SubCategoryCopyWithImpl<$Res, _$SubCategoryImpl>
    implements _$$SubCategoryImplCopyWith<$Res> {
  __$$SubCategoryImplCopyWithImpl(
      _$SubCategoryImpl _value, $Res Function(_$SubCategoryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_$SubCategoryImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryName: freezed == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SubCategoryImpl implements _SubCategory {
  const _$SubCategoryImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "subCategoryName") this.subCategoryName,
      @JsonKey(name: "parentCategoryId") this.parentCategoryId,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "isDeleted") this.isDeleted});

  factory _$SubCategoryImpl.fromJson(Map<String, dynamic> json) =>
      _$$SubCategoryImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "subCategoryName")
  final String? subCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  final String? parentCategoryId;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;

  @override
  String toString() {
    return 'SubCategory(id: $id, subCategoryName: $subCategoryName, parentCategoryId: $parentCategoryId, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, isDeleted: $isDeleted)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubCategoryImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.subCategoryName, subCategoryName) ||
                other.subCategoryName == subCategoryName) &&
            (identical(other.parentCategoryId, parentCategoryId) ||
                other.parentCategoryId == parentCategoryId) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, subCategoryName,
      parentCategoryId, createdAt, updatedAt, v, isDeleted);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubCategoryImplCopyWith<_$SubCategoryImpl> get copyWith =>
      __$$SubCategoryImplCopyWithImpl<_$SubCategoryImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SubCategoryImplToJson(
      this,
    );
  }
}

abstract class _SubCategory implements SubCategory {
  const factory _SubCategory(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "subCategoryName") final String? subCategoryName,
      @JsonKey(name: "parentCategoryId") final String? parentCategoryId,
      @JsonKey(name: "createdAt") final String? createdAt,
      @JsonKey(name: "updatedAt") final String? updatedAt,
      @JsonKey(name: "__v") final int? v,
      @JsonKey(name: "isDeleted") final bool? isDeleted}) = _$SubCategoryImpl;

  factory _SubCategory.fromJson(Map<String, dynamic> json) =
      _$SubCategoryImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "subCategoryName")
  String? get subCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(ignore: true)
  _$$SubCategoryImplCopyWith<_$SubCategoryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SubSubCategory _$SubSubCategoryFromJson(Map<String, dynamic> json) {
  return _SubSubCategory.fromJson(json);
}

/// @nodoc
mixin _$SubSubCategory {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "subSubCategoryName")
  String? get subSubCategoryName => throw _privateConstructorUsedError;
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SubSubCategoryCopyWith<SubSubCategory> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubSubCategoryCopyWith<$Res> {
  factory $SubSubCategoryCopyWith(
          SubSubCategory value, $Res Function(SubSubCategory) then) =
      _$SubSubCategoryCopyWithImpl<$Res, SubSubCategory>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subSubCategoryName") String? subSubCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class _$SubSubCategoryCopyWithImpl<$Res, $Val extends SubSubCategory>
    implements $SubSubCategoryCopyWith<$Res> {
  _$SubSubCategoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subSubCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? subCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subSubCategoryName: freezed == subSubCategoryName
          ? _value.subSubCategoryName
          : subSubCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubSubCategoryImplCopyWith<$Res>
    implements $SubSubCategoryCopyWith<$Res> {
  factory _$$SubSubCategoryImplCopyWith(_$SubSubCategoryImpl value,
          $Res Function(_$SubSubCategoryImpl) then) =
      __$$SubSubCategoryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "subSubCategoryName") String? subSubCategoryName,
      @JsonKey(name: "parentCategoryId") String? parentCategoryId,
      @JsonKey(name: "subCategoryId") String? subCategoryId,
      @JsonKey(name: "createdAt") String? createdAt,
      @JsonKey(name: "updatedAt") String? updatedAt,
      @JsonKey(name: "__v") int? v,
      @JsonKey(name: "isDeleted") bool? isDeleted});
}

/// @nodoc
class __$$SubSubCategoryImplCopyWithImpl<$Res>
    extends _$SubSubCategoryCopyWithImpl<$Res, _$SubSubCategoryImpl>
    implements _$$SubSubCategoryImplCopyWith<$Res> {
  __$$SubSubCategoryImplCopyWithImpl(
      _$SubSubCategoryImpl _value, $Res Function(_$SubSubCategoryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? subSubCategoryName = freezed,
    Object? parentCategoryId = freezed,
    Object? subCategoryId = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
    Object? isDeleted = freezed,
  }) {
    return _then(_$SubSubCategoryImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      subSubCategoryName: freezed == subSubCategoryName
          ? _value.subSubCategoryName
          : subSubCategoryName // ignore: cast_nullable_to_non_nullable
              as String?,
      parentCategoryId: freezed == parentCategoryId
          ? _value.parentCategoryId
          : parentCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      subCategoryId: freezed == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SubSubCategoryImpl implements _SubSubCategory {
  const _$SubSubCategoryImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "subSubCategoryName") this.subSubCategoryName,
      @JsonKey(name: "parentCategoryId") this.parentCategoryId,
      @JsonKey(name: "subCategoryId") this.subCategoryId,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v,
      @JsonKey(name: "isDeleted") this.isDeleted});

  factory _$SubSubCategoryImpl.fromJson(Map<String, dynamic> json) =>
      _$$SubSubCategoryImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "subSubCategoryName")
  final String? subSubCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  final String? parentCategoryId;
  @override
  @JsonKey(name: "subCategoryId")
  final String? subCategoryId;
  @override
  @JsonKey(name: "createdAt")
  final String? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final String? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;

  @override
  String toString() {
    return 'SubSubCategory(id: $id, subSubCategoryName: $subSubCategoryName, parentCategoryId: $parentCategoryId, subCategoryId: $subCategoryId, createdAt: $createdAt, updatedAt: $updatedAt, v: $v, isDeleted: $isDeleted)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubSubCategoryImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.subSubCategoryName, subSubCategoryName) ||
                other.subSubCategoryName == subSubCategoryName) &&
            (identical(other.parentCategoryId, parentCategoryId) ||
                other.parentCategoryId == parentCategoryId) &&
            (identical(other.subCategoryId, subCategoryId) ||
                other.subCategoryId == subCategoryId) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, subSubCategoryName,
      parentCategoryId, subCategoryId, createdAt, updatedAt, v, isDeleted);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubSubCategoryImplCopyWith<_$SubSubCategoryImpl> get copyWith =>
      __$$SubSubCategoryImplCopyWithImpl<_$SubSubCategoryImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SubSubCategoryImplToJson(
      this,
    );
  }
}

abstract class _SubSubCategory implements SubSubCategory {
  const factory _SubSubCategory(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "subSubCategoryName") final String? subSubCategoryName,
          @JsonKey(name: "parentCategoryId") final String? parentCategoryId,
          @JsonKey(name: "subCategoryId") final String? subCategoryId,
          @JsonKey(name: "createdAt") final String? createdAt,
          @JsonKey(name: "updatedAt") final String? updatedAt,
          @JsonKey(name: "__v") final int? v,
          @JsonKey(name: "isDeleted") final bool? isDeleted}) =
      _$SubSubCategoryImpl;

  factory _SubSubCategory.fromJson(Map<String, dynamic> json) =
      _$SubSubCategoryImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "subSubCategoryName")
  String? get subSubCategoryName;
  @override
  @JsonKey(name: "parentCategoryId")
  String? get parentCategoryId;
  @override
  @JsonKey(name: "subCategoryId")
  String? get subCategoryId;
  @override
  @JsonKey(name: "createdAt")
  String? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  String? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(ignore: true)
  _$$SubSubCategoryImplCopyWith<_$SubSubCategoryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
