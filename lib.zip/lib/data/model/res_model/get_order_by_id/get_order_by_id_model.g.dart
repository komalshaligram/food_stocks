// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_order_by_id_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetOrderByIdModelImpl _$$GetOrderByIdModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetOrderByIdModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$GetOrderByIdModelImplToJson(
        _$GetOrderByIdModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
    };

_$DataImpl _$$DataImplFromJson(Map<String, dynamic> json) => _$DataImpl(
      orderData: (json['orderData'] as List<dynamic>?)
          ?.map((e) => OrderDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
      ordersBySupplier: (json['ordersBySupplier'] as List<dynamic>?)
          ?.map((e) => OrdersBySupplier.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DataImplToJson(_$DataImpl instance) =>
    <String, dynamic>{
      'orderData': instance.orderData,
      'ordersBySupplier': instance.ordersBySupplier,
    };

_$OrderDatumImpl _$$OrderDatumImplFromJson(Map<String, dynamic> json) =>
    _$OrderDatumImpl(
      id: json['_id'] as String?,
      vatPercentage: (json['vatPercentage'] as num?)?.toDouble(),
      totalVatAmount: (json['totalVatAmount'] as num?)?.toDouble(),
      createdAt: json['createdAt'] as String?,
      orderstatus: json['orderstatus'] == null
          ? null
          : Status.fromJson(json['orderstatus'] as Map<String, dynamic>),
      client: json['client'] == null
          ? null
          : Client.fromJson(json['client'] as Map<String, dynamic>),
      totalAmount: (json['totalAmount'] as num?)?.toDouble(),
      totalWeight: (json['totalWeight'] as num?)?.toDouble(),
      surfaceWeight: (json['surfaceWeight'] as num?)?.toDouble(),
      bottleQuantities: json['bottleQuantities'] as int?,
      bottlePrice: (json['bottlePrice'] as num?)?.toDouble(),
      bottleTax: (json['bottleTax'] as num?)?.toDouble(),
      vatAmount: (json['vatAmount'] as num?)?.toDouble(),
      comaxInvoicePrice: (json['comaxInvoicePrice'] as num?)?.toDouble(),
      rivchitInvoicePrice: (json['rivchitInvoicePrice'] as num?)?.toDouble(),
      totalRefundAmount: (json['totalRefundAmount'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$$OrderDatumImplToJson(_$OrderDatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'vatPercentage': instance.vatPercentage,
      'totalVatAmount': instance.totalVatAmount,
      'createdAt': instance.createdAt,
      'orderstatus': instance.orderstatus,
      'client': instance.client,
      'totalAmount': instance.totalAmount,
      'totalWeight': instance.totalWeight,
      'surfaceWeight': instance.surfaceWeight,
      'bottleQuantities': instance.bottleQuantities,
      'bottlePrice': instance.bottlePrice,
      'bottleTax': instance.bottleTax,
      'vatAmount': instance.vatAmount,
      'comaxInvoicePrice': instance.comaxInvoicePrice,
      'rivchitInvoicePrice': instance.rivchitInvoicePrice,
      'totalRefundAmount': instance.totalRefundAmount,
    };

_$ClientImpl _$$ClientImplFromJson(Map<String, dynamic> json) => _$ClientImpl(
      id: json['_id'] as String?,
      clientName: json['clientName'] as String?,
    );

Map<String, dynamic> _$$ClientImplToJson(_$ClientImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'clientName': instance.clientName,
    };

_$StatusImpl _$$StatusImplFromJson(Map<String, dynamic> json) => _$StatusImpl(
      id: json['_id'] as String?,
      statusName: json['statusName'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      isDeleted: json['isDeleted'] as bool?,
      orderStatusNumber: json['orderStatusNumber'] as int?,
    );

Map<String, dynamic> _$$StatusImplToJson(_$StatusImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'statusName': instance.statusName,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'isDeleted': instance.isDeleted,
      'orderStatusNumber': instance.orderStatusNumber,
    };

_$OrdersBySupplierImpl _$$OrdersBySupplierImplFromJson(
        Map<String, dynamic> json) =>
    _$OrdersBySupplierImpl(
      id: json['_id'] as String?,
      supplierName: json['supplierName'] as String?,
      deliverStatus: json['deliverStatus'] == null
          ? null
          : Status.fromJson(json['deliverStatus'] as Map<String, dynamic>),
      arrivalDate: json['arrivalDate'] as String?,
      supplierOrderNumber: json['supplierOrderNumber'] as String?,
      orderDeliveryDate: json['orderDeliveryDate'] as String?,
      orderDate: json['orderDate'] as String?,
      totalWeight: (json['totalWeight'] as num?)?.toDouble(),
      totalPayment: (json['totalPayment'] as num?)?.toDouble(),
      driverName: json['driverName'] as String?,
      driverNumber: json['driverNumber'] as String?,
      signature: json['signature'] as String?,
      products: (json['products'] as List<dynamic>?)
          ?.map((e) => Product.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$OrdersBySupplierImplToJson(
        _$OrdersBySupplierImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'supplierName': instance.supplierName,
      'deliverStatus': instance.deliverStatus,
      'arrivalDate': instance.arrivalDate,
      'supplierOrderNumber': instance.supplierOrderNumber,
      'orderDeliveryDate': instance.orderDeliveryDate,
      'orderDate': instance.orderDate,
      'totalWeight': instance.totalWeight,
      'totalPayment': instance.totalPayment,
      'driverName': instance.driverName,
      'driverNumber': instance.driverNumber,
      'signature': instance.signature,
      'products': instance.products,
    };

_$ProductImpl _$$ProductImplFromJson(Map<String, dynamic> json) =>
    _$ProductImpl(
      productId: json['productId'] as String?,
      productName: json['productName'] as String?,
      quantity: json['quantity'] as int?,
      unitQuantity: json['unitQuantity'] as int?,
      sku: json['sku'] as String?,
      brand: json['brand'] as String?,
      scale: json['scale'] as String?,
      category: json['category'] == null
          ? null
          : Category.fromJson(json['category'] as Map<String, dynamic>),
      subCategory: json['subCategory'] == null
          ? null
          : SubCategory.fromJson(json['subCategory'] as Map<String, dynamic>),
      subSubCategory: json['subSubCategory'] == null
          ? null
          : SubSubCategory.fromJson(
              json['subSubCategory'] as Map<String, dynamic>),
      pricePerUnit: (json['pricePerUnit'] as num?)?.toDouble(),
      totalPayment: (json['totalPayment'] as num?)?.toDouble(),
      discountedPrice: (json['discountedPrice'] as num?)?.toDouble(),
      itemWeight: (json['itemWeight'] as num?)?.toDouble(),
      issueStatus: json['issueStatus'] == null
          ? null
          : Status.fromJson(json['issueStatus'] as Map<String, dynamic>),
      isIssue: json['isIssue'] as bool?,
      issue: json['issue'] as String?,
      note: json['note'] as String?,
      missingQuantity: json['missingQuantity'] as int?,
      mainImage: json['mainImage'] as String?,
      isBottle: json['isBottle'] as bool?,
      isUpdated: json['isUpdated'] as bool?,
      updatedUnitQuantity: json['updatedUnitQuantity'] as int?,
      updatedPrice: (json['updatedPrice'] as num?)?.toDouble(),
      numberOfUnit: json['numberOfUnit'] as int?,
    );

Map<String, dynamic> _$$ProductImplToJson(_$ProductImpl instance) =>
    <String, dynamic>{
      'productId': instance.productId,
      'productName': instance.productName,
      'quantity': instance.quantity,
      'unitQuantity': instance.unitQuantity,
      'sku': instance.sku,
      'brand': instance.brand,
      'scale': instance.scale,
      'category': instance.category,
      'subCategory': instance.subCategory,
      'subSubCategory': instance.subSubCategory,
      'pricePerUnit': instance.pricePerUnit,
      'totalPayment': instance.totalPayment,
      'discountedPrice': instance.discountedPrice,
      'itemWeight': instance.itemWeight,
      'issueStatus': instance.issueStatus,
      'isIssue': instance.isIssue,
      'issue': instance.issue,
      'note': instance.note,
      'missingQuantity': instance.missingQuantity,
      'mainImage': instance.mainImage,
      'isBottle': instance.isBottle,
      'isUpdated': instance.isUpdated,
      'updatedUnitQuantity': instance.updatedUnitQuantity,
      'updatedPrice': instance.updatedPrice,
      'numberOfUnit': instance.numberOfUnit,
    };

_$CategoryImpl _$$CategoryImplFromJson(Map<String, dynamic> json) =>
    _$CategoryImpl(
      id: json['_id'] as String?,
      categoryName: json['categoryName'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      categoryImage: json['categoryImage'] as String?,
      isHomePreference: json['isHomePreference'] as bool?,
      order: json['order'] as int?,
      isDeleted: json['isDeleted'] as bool?,
    );

Map<String, dynamic> _$$CategoryImplToJson(_$CategoryImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'categoryName': instance.categoryName,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'categoryImage': instance.categoryImage,
      'isHomePreference': instance.isHomePreference,
      'order': instance.order,
      'isDeleted': instance.isDeleted,
    };

_$SubCategoryImpl _$$SubCategoryImplFromJson(Map<String, dynamic> json) =>
    _$SubCategoryImpl(
      id: json['_id'] as String?,
      subCategoryName: json['subCategoryName'] as String?,
      parentCategoryId: json['parentCategoryId'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      isDeleted: json['isDeleted'] as bool?,
    );

Map<String, dynamic> _$$SubCategoryImplToJson(_$SubCategoryImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'subCategoryName': instance.subCategoryName,
      'parentCategoryId': instance.parentCategoryId,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'isDeleted': instance.isDeleted,
    };

_$SubSubCategoryImpl _$$SubSubCategoryImplFromJson(Map<String, dynamic> json) =>
    _$SubSubCategoryImpl(
      id: json['_id'] as String?,
      subSubCategoryName: json['subSubCategoryName'] as String?,
      parentCategoryId: json['parentCategoryId'] as String?,
      subCategoryId: json['subCategoryId'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
      v: json['__v'] as int?,
      isDeleted: json['isDeleted'] as bool?,
    );

Map<String, dynamic> _$$SubSubCategoryImplToJson(
        _$SubSubCategoryImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'subSubCategoryName': instance.subSubCategoryName,
      'parentCategoryId': instance.parentCategoryId,
      'subCategoryId': instance.subCategoryId,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      '__v': instance.v,
      'isDeleted': instance.isDeleted,
    };
