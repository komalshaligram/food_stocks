// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'export_wallet_transactions_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ExportWalletTransactionsResModel _$ExportWalletTransactionsResModelFromJson(
    Map<String, dynamic> json) {
  return _ExportWalletTransactionsResModel.fromJson(json);
}

/// @nodoc
mixin _$ExportWalletTransactionsResModel {
  int? get status => throw _privateConstructorUsedError;
  String? get data => throw _privateConstructorUsedError;
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ExportWalletTransactionsResModelCopyWith<ExportWalletTransactionsResModel>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ExportWalletTransactionsResModelCopyWith<$Res> {
  factory $ExportWalletTransactionsResModelCopyWith(
          ExportWalletTransactionsResModel value,
          $Res Function(ExportWalletTransactionsResModel) then) =
      _$ExportWalletTransactionsResModelCopyWithImpl<$Res,
          ExportWalletTransactionsResModel>;
  @useResult
  $Res call({int? status, String? data, String? message});
}

/// @nodoc
class _$ExportWalletTransactionsResModelCopyWithImpl<$Res,
        $Val extends ExportWalletTransactionsResModel>
    implements $ExportWalletTransactionsResModelCopyWith<$Res> {
  _$ExportWalletTransactionsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ExportWalletTransactionsResModelImplCopyWith<$Res>
    implements $ExportWalletTransactionsResModelCopyWith<$Res> {
  factory _$$ExportWalletTransactionsResModelImplCopyWith(
          _$ExportWalletTransactionsResModelImpl value,
          $Res Function(_$ExportWalletTransactionsResModelImpl) then) =
      __$$ExportWalletTransactionsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int? status, String? data, String? message});
}

/// @nodoc
class __$$ExportWalletTransactionsResModelImplCopyWithImpl<$Res>
    extends _$ExportWalletTransactionsResModelCopyWithImpl<$Res,
        _$ExportWalletTransactionsResModelImpl>
    implements _$$ExportWalletTransactionsResModelImplCopyWith<$Res> {
  __$$ExportWalletTransactionsResModelImplCopyWithImpl(
      _$ExportWalletTransactionsResModelImpl _value,
      $Res Function(_$ExportWalletTransactionsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$ExportWalletTransactionsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as String?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ExportWalletTransactionsResModelImpl
    implements _ExportWalletTransactionsResModel {
  const _$ExportWalletTransactionsResModelImpl(
      {this.status, this.data, this.message});

  factory _$ExportWalletTransactionsResModelImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$ExportWalletTransactionsResModelImplFromJson(json);

  @override
  final int? status;
  @override
  final String? data;
  @override
  final String? message;

  @override
  String toString() {
    return 'ExportWalletTransactionsResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ExportWalletTransactionsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ExportWalletTransactionsResModelImplCopyWith<
          _$ExportWalletTransactionsResModelImpl>
      get copyWith => __$$ExportWalletTransactionsResModelImplCopyWithImpl<
          _$ExportWalletTransactionsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ExportWalletTransactionsResModelImplToJson(
      this,
    );
  }
}

abstract class _ExportWalletTransactionsResModel
    implements ExportWalletTransactionsResModel {
  const factory _ExportWalletTransactionsResModel(
      {final int? status,
      final String? data,
      final String? message}) = _$ExportWalletTransactionsResModelImpl;

  factory _ExportWalletTransactionsResModel.fromJson(
          Map<String, dynamic> json) =
      _$ExportWalletTransactionsResModelImpl.fromJson;

  @override
  int? get status;
  @override
  String? get data;
  @override
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$ExportWalletTransactionsResModelImplCopyWith<
          _$ExportWalletTransactionsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
