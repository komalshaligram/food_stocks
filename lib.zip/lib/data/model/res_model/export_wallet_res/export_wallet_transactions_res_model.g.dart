// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'export_wallet_transactions_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ExportWalletTransactionsResModelImpl
    _$$ExportWalletTransactionsResModelImplFromJson(
            Map<String, dynamic> json) =>
        _$ExportWalletTransactionsResModelImpl(
          status: json['status'] as int?,
          data: json['data'] as String?,
          message: json['message'] as String?,
        );

Map<String, dynamic> _$$ExportWalletTransactionsResModelImplToJson(
        _$ExportWalletTransactionsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };
