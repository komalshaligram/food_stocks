// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_stock_verify_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProductStockVerifyResModel _$ProductStockVerifyResModelFromJson(
    Map<String, dynamic> json) {
  return _ProductStockVerifyResModel.fromJson(json);
}

/// @nodoc
mixin _$ProductStockVerifyResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  ProductStockVerifyResModelData? get data =>
      throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductStockVerifyResModelCopyWith<ProductStockVerifyResModel>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductStockVerifyResModelCopyWith<$Res> {
  factory $ProductStockVerifyResModelCopyWith(ProductStockVerifyResModel value,
          $Res Function(ProductStockVerifyResModel) then) =
      _$ProductStockVerifyResModelCopyWithImpl<$Res,
          ProductStockVerifyResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") ProductStockVerifyResModelData? data,
      @JsonKey(name: "message") String? message});

  $ProductStockVerifyResModelDataCopyWith<$Res>? get data;
}

/// @nodoc
class _$ProductStockVerifyResModelCopyWithImpl<$Res,
        $Val extends ProductStockVerifyResModel>
    implements $ProductStockVerifyResModelCopyWith<$Res> {
  _$ProductStockVerifyResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as ProductStockVerifyResModelData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ProductStockVerifyResModelDataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $ProductStockVerifyResModelDataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProductStockVerifyResModelImplCopyWith<$Res>
    implements $ProductStockVerifyResModelCopyWith<$Res> {
  factory _$$ProductStockVerifyResModelImplCopyWith(
          _$ProductStockVerifyResModelImpl value,
          $Res Function(_$ProductStockVerifyResModelImpl) then) =
      __$$ProductStockVerifyResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "data") ProductStockVerifyResModelData? data,
      @JsonKey(name: "message") String? message});

  @override
  $ProductStockVerifyResModelDataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$ProductStockVerifyResModelImplCopyWithImpl<$Res>
    extends _$ProductStockVerifyResModelCopyWithImpl<$Res,
        _$ProductStockVerifyResModelImpl>
    implements _$$ProductStockVerifyResModelImplCopyWith<$Res> {
  __$$ProductStockVerifyResModelImplCopyWithImpl(
      _$ProductStockVerifyResModelImpl _value,
      $Res Function(_$ProductStockVerifyResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? data = freezed,
    Object? message = freezed,
  }) {
    return _then(_$ProductStockVerifyResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as ProductStockVerifyResModelData?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductStockVerifyResModelImpl implements _ProductStockVerifyResModel {
  const _$ProductStockVerifyResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "data") this.data,
      @JsonKey(name: "message") this.message});

  factory _$ProductStockVerifyResModelImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$ProductStockVerifyResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "data")
  final ProductStockVerifyResModelData? data;
  @override
  @JsonKey(name: "message")
  final String? message;

  @override
  String toString() {
    return 'ProductStockVerifyResModel(status: $status, data: $data, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductStockVerifyResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.data, data) || other.data == data) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, data, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductStockVerifyResModelImplCopyWith<_$ProductStockVerifyResModelImpl>
      get copyWith => __$$ProductStockVerifyResModelImplCopyWithImpl<
          _$ProductStockVerifyResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductStockVerifyResModelImplToJson(
      this,
    );
  }
}

abstract class _ProductStockVerifyResModel
    implements ProductStockVerifyResModel {
  const factory _ProductStockVerifyResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "data") final ProductStockVerifyResModelData? data,
          @JsonKey(name: "message") final String? message}) =
      _$ProductStockVerifyResModelImpl;

  factory _ProductStockVerifyResModel.fromJson(Map<String, dynamic> json) =
      _$ProductStockVerifyResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "data")
  ProductStockVerifyResModelData? get data;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(ignore: true)
  _$$ProductStockVerifyResModelImplCopyWith<_$ProductStockVerifyResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

ProductStockVerifyResModelData _$ProductStockVerifyResModelDataFromJson(
    Map<String, dynamic> json) {
  return _ProductStockVerifyResModelData.fromJson(json);
}

/// @nodoc
mixin _$ProductStockVerifyResModelData {
  @JsonKey(name: "stock")
  List<Stock>? get stock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductStockVerifyResModelDataCopyWith<ProductStockVerifyResModelData>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductStockVerifyResModelDataCopyWith<$Res> {
  factory $ProductStockVerifyResModelDataCopyWith(
          ProductStockVerifyResModelData value,
          $Res Function(ProductStockVerifyResModelData) then) =
      _$ProductStockVerifyResModelDataCopyWithImpl<$Res,
          ProductStockVerifyResModelData>;
  @useResult
  $Res call({@JsonKey(name: "stock") List<Stock>? stock});
}

/// @nodoc
class _$ProductStockVerifyResModelDataCopyWithImpl<$Res,
        $Val extends ProductStockVerifyResModelData>
    implements $ProductStockVerifyResModelDataCopyWith<$Res> {
  _$ProductStockVerifyResModelDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? stock = freezed,
  }) {
    return _then(_value.copyWith(
      stock: freezed == stock
          ? _value.stock
          : stock // ignore: cast_nullable_to_non_nullable
              as List<Stock>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductStockVerifyResModelDataImplCopyWith<$Res>
    implements $ProductStockVerifyResModelDataCopyWith<$Res> {
  factory _$$ProductStockVerifyResModelDataImplCopyWith(
          _$ProductStockVerifyResModelDataImpl value,
          $Res Function(_$ProductStockVerifyResModelDataImpl) then) =
      __$$ProductStockVerifyResModelDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({@JsonKey(name: "stock") List<Stock>? stock});
}

/// @nodoc
class __$$ProductStockVerifyResModelDataImplCopyWithImpl<$Res>
    extends _$ProductStockVerifyResModelDataCopyWithImpl<$Res,
        _$ProductStockVerifyResModelDataImpl>
    implements _$$ProductStockVerifyResModelDataImplCopyWith<$Res> {
  __$$ProductStockVerifyResModelDataImplCopyWithImpl(
      _$ProductStockVerifyResModelDataImpl _value,
      $Res Function(_$ProductStockVerifyResModelDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? stock = freezed,
  }) {
    return _then(_$ProductStockVerifyResModelDataImpl(
      stock: freezed == stock
          ? _value._stock
          : stock // ignore: cast_nullable_to_non_nullable
              as List<Stock>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductStockVerifyResModelDataImpl
    implements _ProductStockVerifyResModelData {
  const _$ProductStockVerifyResModelDataImpl(
      {@JsonKey(name: "stock") final List<Stock>? stock})
      : _stock = stock;

  factory _$ProductStockVerifyResModelDataImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$ProductStockVerifyResModelDataImplFromJson(json);

  final List<Stock>? _stock;
  @override
  @JsonKey(name: "stock")
  List<Stock>? get stock {
    final value = _stock;
    if (value == null) return null;
    if (_stock is EqualUnmodifiableListView) return _stock;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'ProductStockVerifyResModelData(stock: $stock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductStockVerifyResModelDataImpl &&
            const DeepCollectionEquality().equals(other._stock, _stock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_stock));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductStockVerifyResModelDataImplCopyWith<
          _$ProductStockVerifyResModelDataImpl>
      get copyWith => __$$ProductStockVerifyResModelDataImplCopyWithImpl<
          _$ProductStockVerifyResModelDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductStockVerifyResModelDataImplToJson(
      this,
    );
  }
}

abstract class _ProductStockVerifyResModelData
    implements ProductStockVerifyResModelData {
  const factory _ProductStockVerifyResModelData(
          {@JsonKey(name: "stock") final List<Stock>? stock}) =
      _$ProductStockVerifyResModelDataImpl;

  factory _ProductStockVerifyResModelData.fromJson(Map<String, dynamic> json) =
      _$ProductStockVerifyResModelDataImpl.fromJson;

  @override
  @JsonKey(name: "stock")
  List<Stock>? get stock;
  @override
  @JsonKey(ignore: true)
  _$$ProductStockVerifyResModelDataImplCopyWith<
          _$ProductStockVerifyResModelDataImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Stock _$StockFromJson(Map<String, dynamic> json) {
  return _Stock.fromJson(json);
}

/// @nodoc
mixin _$Stock {
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  StockData? get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StockCopyWith<Stock> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StockCopyWith<$Res> {
  factory $StockCopyWith(Stock value, $Res Function(Stock) then) =
      _$StockCopyWithImpl<$Res, Stock>;
  @useResult
  $Res call(
      {@JsonKey(name: "message") String? message,
      @JsonKey(name: "data") StockData? data});

  $StockDataCopyWith<$Res>? get data;
}

/// @nodoc
class _$StockCopyWithImpl<$Res, $Val extends Stock>
    implements $StockCopyWith<$Res> {
  _$StockCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_value.copyWith(
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as StockData?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $StockDataCopyWith<$Res>? get data {
    if (_value.data == null) {
      return null;
    }

    return $StockDataCopyWith<$Res>(_value.data!, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$StockImplCopyWith<$Res> implements $StockCopyWith<$Res> {
  factory _$$StockImplCopyWith(
          _$StockImpl value, $Res Function(_$StockImpl) then) =
      __$$StockImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "message") String? message,
      @JsonKey(name: "data") StockData? data});

  @override
  $StockDataCopyWith<$Res>? get data;
}

/// @nodoc
class __$$StockImplCopyWithImpl<$Res>
    extends _$StockCopyWithImpl<$Res, _$StockImpl>
    implements _$$StockImplCopyWith<$Res> {
  __$$StockImplCopyWithImpl(
      _$StockImpl _value, $Res Function(_$StockImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_$StockImpl(
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as StockData?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StockImpl implements _Stock {
  const _$StockImpl(
      {@JsonKey(name: "message") this.message,
      @JsonKey(name: "data") this.data});

  factory _$StockImpl.fromJson(Map<String, dynamic> json) =>
      _$$StockImplFromJson(json);

  @override
  @JsonKey(name: "message")
  final String? message;
  @override
  @JsonKey(name: "data")
  final StockData? data;

  @override
  String toString() {
    return 'Stock(message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StockImpl &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.data, data) || other.data == data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, message, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StockImplCopyWith<_$StockImpl> get copyWith =>
      __$$StockImplCopyWithImpl<_$StockImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StockImplToJson(
      this,
    );
  }
}

abstract class _Stock implements Stock {
  const factory _Stock(
      {@JsonKey(name: "message") final String? message,
      @JsonKey(name: "data") final StockData? data}) = _$StockImpl;

  factory _Stock.fromJson(Map<String, dynamic> json) = _$StockImpl.fromJson;

  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(name: "data")
  StockData? get data;
  @override
  @JsonKey(ignore: true)
  _$$StockImplCopyWith<_$StockImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

StockData _$StockDataFromJson(Map<String, dynamic> json) {
  return _StockData.fromJson(json);
}

/// @nodoc
mixin _$StockData {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "productStock")
  int? get productStock => throw _privateConstructorUsedError;
  @JsonKey(name: "productPrice")
  double? get productPrice => throw _privateConstructorUsedError;
  @JsonKey(name: "supplierId")
  String? get supplierId => throw _privateConstructorUsedError;
  @JsonKey(name: "email")
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: "contactName")
  String? get contactName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StockDataCopyWith<StockData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StockDataCopyWith<$Res> {
  factory $StockDataCopyWith(StockData value, $Res Function(StockData) then) =
      _$StockDataCopyWithImpl<$Res, StockData>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productStock") int? productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "contactName") String? contactName});
}

/// @nodoc
class _$StockDataCopyWithImpl<$Res, $Val extends StockData>
    implements $StockDataCopyWith<$Res> {
  _$StockDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? supplierId = freezed,
    Object? email = freezed,
    Object? contactName = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StockDataImplCopyWith<$Res>
    implements $StockDataCopyWith<$Res> {
  factory _$$StockDataImplCopyWith(
          _$StockDataImpl value, $Res Function(_$StockDataImpl) then) =
      __$$StockDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "productStock") int? productStock,
      @JsonKey(name: "productPrice") double? productPrice,
      @JsonKey(name: "supplierId") String? supplierId,
      @JsonKey(name: "email") String? email,
      @JsonKey(name: "contactName") String? contactName});
}

/// @nodoc
class __$$StockDataImplCopyWithImpl<$Res>
    extends _$StockDataCopyWithImpl<$Res, _$StockDataImpl>
    implements _$$StockDataImplCopyWith<$Res> {
  __$$StockDataImplCopyWithImpl(
      _$StockDataImpl _value, $Res Function(_$StockDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? productStock = freezed,
    Object? productPrice = freezed,
    Object? supplierId = freezed,
    Object? email = freezed,
    Object? contactName = freezed,
  }) {
    return _then(_$StockDataImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      productStock: freezed == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as int?,
      productPrice: freezed == productPrice
          ? _value.productPrice
          : productPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      supplierId: freezed == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StockDataImpl implements _StockData {
  const _$StockDataImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "productStock") this.productStock,
      @JsonKey(name: "productPrice") this.productPrice,
      @JsonKey(name: "supplierId") this.supplierId,
      @JsonKey(name: "email") this.email,
      @JsonKey(name: "contactName") this.contactName});

  factory _$StockDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$StockDataImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "productStock")
  final int? productStock;
  @override
  @JsonKey(name: "productPrice")
  final double? productPrice;
  @override
  @JsonKey(name: "supplierId")
  final String? supplierId;
  @override
  @JsonKey(name: "email")
  final String? email;
  @override
  @JsonKey(name: "contactName")
  final String? contactName;

  @override
  String toString() {
    return 'StockData(id: $id, productStock: $productStock, productPrice: $productPrice, supplierId: $supplierId, email: $email, contactName: $contactName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StockDataImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.productPrice, productPrice) ||
                other.productPrice == productPrice) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, productStock, productPrice,
      supplierId, email, contactName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StockDataImplCopyWith<_$StockDataImpl> get copyWith =>
      __$$StockDataImplCopyWithImpl<_$StockDataImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StockDataImplToJson(
      this,
    );
  }
}

abstract class _StockData implements StockData {
  const factory _StockData(
          {@JsonKey(name: "_id") final String? id,
          @JsonKey(name: "productStock") final int? productStock,
          @JsonKey(name: "productPrice") final double? productPrice,
          @JsonKey(name: "supplierId") final String? supplierId,
          @JsonKey(name: "email") final String? email,
          @JsonKey(name: "contactName") final String? contactName}) =
      _$StockDataImpl;

  factory _StockData.fromJson(Map<String, dynamic> json) =
      _$StockDataImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "productStock")
  int? get productStock;
  @override
  @JsonKey(name: "productPrice")
  double? get productPrice;
  @override
  @JsonKey(name: "supplierId")
  String? get supplierId;
  @override
  @JsonKey(name: "email")
  String? get email;
  @override
  @JsonKey(name: "contactName")
  String? get contactName;
  @override
  @JsonKey(ignore: true)
  _$$StockDataImplCopyWith<_$StockDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
