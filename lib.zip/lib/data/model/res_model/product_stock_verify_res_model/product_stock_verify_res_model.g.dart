// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_stock_verify_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProductStockVerifyResModelImpl _$$ProductStockVerifyResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProductStockVerifyResModelImpl(
      status: json['status'] as int?,
      data: json['data'] == null
          ? null
          : ProductStockVerifyResModelData.fromJson(
              json['data'] as Map<String, dynamic>),
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$ProductStockVerifyResModelImplToJson(
        _$ProductStockVerifyResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'data': instance.data,
      'message': instance.message,
    };

_$ProductStockVerifyResModelDataImpl
    _$$ProductStockVerifyResModelDataImplFromJson(Map<String, dynamic> json) =>
        _$ProductStockVerifyResModelDataImpl(
          stock: (json['stock'] as List<dynamic>?)
              ?.map((e) => Stock.fromJson(e as Map<String, dynamic>))
              .toList(),
        );

Map<String, dynamic> _$$ProductStockVerifyResModelDataImplToJson(
        _$ProductStockVerifyResModelDataImpl instance) =>
    <String, dynamic>{
      'stock': instance.stock,
    };

_$StockImpl _$$StockImplFromJson(Map<String, dynamic> json) => _$StockImpl(
      message: json['message'] as String?,
      data: json['data'] == null
          ? null
          : StockData.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$StockImplToJson(_$StockImpl instance) =>
    <String, dynamic>{
      'message': instance.message,
      'data': instance.data,
    };

_$StockDataImpl _$$StockDataImplFromJson(Map<String, dynamic> json) =>
    _$StockDataImpl(
      id: json['_id'] as String?,
      productStock: json['productStock'] as int?,
      productPrice: (json['productPrice'] as num?)?.toDouble(),
      supplierId: json['supplierId'] as String?,
      email: json['email'] as String?,
      contactName: json['contactName'] as String?,
    );

Map<String, dynamic> _$$StockDataImplToJson(_$StockDataImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'productStock': instance.productStock,
      'productPrice': instance.productPrice,
      'supplierId': instance.supplierId,
      'email': instance.email,
      'contactName': instance.contactName,
    };
