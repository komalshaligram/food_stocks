// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_app_content_details_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAppContentDetailsResModelImpl _$$GetAppContentDetailsResModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetAppContentDetailsResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => Datum.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$GetAppContentDetailsResModelImplToJson(
        _$GetAppContentDetailsResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'data': instance.data,
    };

_$DatumImpl _$$DatumImplFromJson(Map<String, dynamic> json) => _$DatumImpl(
      id: json['_id'] as String?,
      contentName: json['contentName'] as String?,
      title: json['title'] as String?,
      adminType: json['adminType'] as String?,
      subTitle: json['subTitle'] as String?,
      textForButton1: json['textForButton1'] as String?,
      textForButton2: json['textForButton2'] as String?,
      fullText: json['fullText'] as String?,
      isDeleted: json['isDeleted'] as bool?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$DatumImplToJson(_$DatumImpl instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'contentName': instance.contentName,
      'title': instance.title,
      'adminType': instance.adminType,
      'subTitle': instance.subTitle,
      'textForButton1': instance.textForButton1,
      'textForButton2': instance.textForButton2,
      'fullText': instance.fullText,
      'isDeleted': instance.isDeleted,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
    };
