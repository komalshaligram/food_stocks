// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_app_content_details_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAppContentDetailsResModel _$GetAppContentDetailsResModelFromJson(
    Map<String, dynamic> json) {
  return _GetAppContentDetailsResModel.fromJson(json);
}

/// @nodoc
mixin _$GetAppContentDetailsResModel {
  @JsonKey(name: "status")
  int? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "message")
  String? get message => throw _privateConstructorUsedError;
  @JsonKey(name: "data")
  List<Datum>? get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAppContentDetailsResModelCopyWith<GetAppContentDetailsResModel>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAppContentDetailsResModelCopyWith<$Res> {
  factory $GetAppContentDetailsResModelCopyWith(
          GetAppContentDetailsResModel value,
          $Res Function(GetAppContentDetailsResModel) then) =
      _$GetAppContentDetailsResModelCopyWithImpl<$Res,
          GetAppContentDetailsResModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") List<Datum>? data});
}

/// @nodoc
class _$GetAppContentDetailsResModelCopyWithImpl<$Res,
        $Val extends GetAppContentDetailsResModel>
    implements $GetAppContentDetailsResModelCopyWith<$Res> {
  _$GetAppContentDetailsResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAppContentDetailsResModelImplCopyWith<$Res>
    implements $GetAppContentDetailsResModelCopyWith<$Res> {
  factory _$$GetAppContentDetailsResModelImplCopyWith(
          _$GetAppContentDetailsResModelImpl value,
          $Res Function(_$GetAppContentDetailsResModelImpl) then) =
      __$$GetAppContentDetailsResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "status") int? status,
      @JsonKey(name: "message") String? message,
      @JsonKey(name: "data") List<Datum>? data});
}

/// @nodoc
class __$$GetAppContentDetailsResModelImplCopyWithImpl<$Res>
    extends _$GetAppContentDetailsResModelCopyWithImpl<$Res,
        _$GetAppContentDetailsResModelImpl>
    implements _$$GetAppContentDetailsResModelImplCopyWith<$Res> {
  __$$GetAppContentDetailsResModelImplCopyWithImpl(
      _$GetAppContentDetailsResModelImpl _value,
      $Res Function(_$GetAppContentDetailsResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? data = freezed,
  }) {
    return _then(_$GetAppContentDetailsResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      data: freezed == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAppContentDetailsResModelImpl
    implements _GetAppContentDetailsResModel {
  const _$GetAppContentDetailsResModelImpl(
      {@JsonKey(name: "status") this.status,
      @JsonKey(name: "message") this.message,
      @JsonKey(name: "data") final List<Datum>? data})
      : _data = data;

  factory _$GetAppContentDetailsResModelImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$GetAppContentDetailsResModelImplFromJson(json);

  @override
  @JsonKey(name: "status")
  final int? status;
  @override
  @JsonKey(name: "message")
  final String? message;
  final List<Datum>? _data;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data {
    final value = _data;
    if (value == null) return null;
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'GetAppContentDetailsResModel(status: $status, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAppContentDetailsResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            const DeepCollectionEquality().equals(other._data, _data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, status, message, const DeepCollectionEquality().hash(_data));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAppContentDetailsResModelImplCopyWith<
          _$GetAppContentDetailsResModelImpl>
      get copyWith => __$$GetAppContentDetailsResModelImplCopyWithImpl<
          _$GetAppContentDetailsResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAppContentDetailsResModelImplToJson(
      this,
    );
  }
}

abstract class _GetAppContentDetailsResModel
    implements GetAppContentDetailsResModel {
  const factory _GetAppContentDetailsResModel(
          {@JsonKey(name: "status") final int? status,
          @JsonKey(name: "message") final String? message,
          @JsonKey(name: "data") final List<Datum>? data}) =
      _$GetAppContentDetailsResModelImpl;

  factory _GetAppContentDetailsResModel.fromJson(Map<String, dynamic> json) =
      _$GetAppContentDetailsResModelImpl.fromJson;

  @override
  @JsonKey(name: "status")
  int? get status;
  @override
  @JsonKey(name: "message")
  String? get message;
  @override
  @JsonKey(name: "data")
  List<Datum>? get data;
  @override
  @JsonKey(ignore: true)
  _$$GetAppContentDetailsResModelImplCopyWith<
          _$GetAppContentDetailsResModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Datum _$DatumFromJson(Map<String, dynamic> json) {
  return _Datum.fromJson(json);
}

/// @nodoc
mixin _$Datum {
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "contentName")
  String? get contentName => throw _privateConstructorUsedError;
  @JsonKey(name: "title")
  String? get title => throw _privateConstructorUsedError;
  @JsonKey(name: "adminType")
  String? get adminType => throw _privateConstructorUsedError;
  @JsonKey(name: "subTitle")
  String? get subTitle => throw _privateConstructorUsedError;
  @JsonKey(name: "textForButton1")
  String? get textForButton1 => throw _privateConstructorUsedError;
  @JsonKey(name: "textForButton2")
  String? get textForButton2 => throw _privateConstructorUsedError;
  @JsonKey(name: "fullText")
  String? get fullText => throw _privateConstructorUsedError;
  @JsonKey(name: "isDeleted")
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "createdAt")
  DateTime? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DatumCopyWith<Datum> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DatumCopyWith<$Res> {
  factory $DatumCopyWith(Datum value, $Res Function(Datum) then) =
      _$DatumCopyWithImpl<$Res, Datum>;
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "contentName") String? contentName,
      @JsonKey(name: "title") String? title,
      @JsonKey(name: "adminType") String? adminType,
      @JsonKey(name: "subTitle") String? subTitle,
      @JsonKey(name: "textForButton1") String? textForButton1,
      @JsonKey(name: "textForButton2") String? textForButton2,
      @JsonKey(name: "fullText") String? fullText,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class _$DatumCopyWithImpl<$Res, $Val extends Datum>
    implements $DatumCopyWith<$Res> {
  _$DatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? contentName = freezed,
    Object? title = freezed,
    Object? adminType = freezed,
    Object? subTitle = freezed,
    Object? textForButton1 = freezed,
    Object? textForButton2 = freezed,
    Object? fullText = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      contentName: freezed == contentName
          ? _value.contentName
          : contentName // ignore: cast_nullable_to_non_nullable
              as String?,
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as String?,
      subTitle: freezed == subTitle
          ? _value.subTitle
          : subTitle // ignore: cast_nullable_to_non_nullable
              as String?,
      textForButton1: freezed == textForButton1
          ? _value.textForButton1
          : textForButton1 // ignore: cast_nullable_to_non_nullable
              as String?,
      textForButton2: freezed == textForButton2
          ? _value.textForButton2
          : textForButton2 // ignore: cast_nullable_to_non_nullable
              as String?,
      fullText: freezed == fullText
          ? _value.fullText
          : fullText // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DatumImplCopyWith<$Res> implements $DatumCopyWith<$Res> {
  factory _$$DatumImplCopyWith(
          _$DatumImpl value, $Res Function(_$DatumImpl) then) =
      __$$DatumImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "_id") String? id,
      @JsonKey(name: "contentName") String? contentName,
      @JsonKey(name: "title") String? title,
      @JsonKey(name: "adminType") String? adminType,
      @JsonKey(name: "subTitle") String? subTitle,
      @JsonKey(name: "textForButton1") String? textForButton1,
      @JsonKey(name: "textForButton2") String? textForButton2,
      @JsonKey(name: "fullText") String? fullText,
      @JsonKey(name: "isDeleted") bool? isDeleted,
      @JsonKey(name: "createdAt") DateTime? createdAt,
      @JsonKey(name: "updatedAt") DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});
}

/// @nodoc
class __$$DatumImplCopyWithImpl<$Res>
    extends _$DatumCopyWithImpl<$Res, _$DatumImpl>
    implements _$$DatumImplCopyWith<$Res> {
  __$$DatumImplCopyWithImpl(
      _$DatumImpl _value, $Res Function(_$DatumImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? contentName = freezed,
    Object? title = freezed,
    Object? adminType = freezed,
    Object? subTitle = freezed,
    Object? textForButton1 = freezed,
    Object? textForButton2 = freezed,
    Object? fullText = freezed,
    Object? isDeleted = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$DatumImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      contentName: freezed == contentName
          ? _value.contentName
          : contentName // ignore: cast_nullable_to_non_nullable
              as String?,
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      adminType: freezed == adminType
          ? _value.adminType
          : adminType // ignore: cast_nullable_to_non_nullable
              as String?,
      subTitle: freezed == subTitle
          ? _value.subTitle
          : subTitle // ignore: cast_nullable_to_non_nullable
              as String?,
      textForButton1: freezed == textForButton1
          ? _value.textForButton1
          : textForButton1 // ignore: cast_nullable_to_non_nullable
              as String?,
      textForButton2: freezed == textForButton2
          ? _value.textForButton2
          : textForButton2 // ignore: cast_nullable_to_non_nullable
              as String?,
      fullText: freezed == fullText
          ? _value.fullText
          : fullText // ignore: cast_nullable_to_non_nullable
              as String?,
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DatumImpl implements _Datum {
  const _$DatumImpl(
      {@JsonKey(name: "_id") this.id,
      @JsonKey(name: "contentName") this.contentName,
      @JsonKey(name: "title") this.title,
      @JsonKey(name: "adminType") this.adminType,
      @JsonKey(name: "subTitle") this.subTitle,
      @JsonKey(name: "textForButton1") this.textForButton1,
      @JsonKey(name: "textForButton2") this.textForButton2,
      @JsonKey(name: "fullText") this.fullText,
      @JsonKey(name: "isDeleted") this.isDeleted,
      @JsonKey(name: "createdAt") this.createdAt,
      @JsonKey(name: "updatedAt") this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$DatumImpl.fromJson(Map<String, dynamic> json) =>
      _$$DatumImplFromJson(json);

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  @JsonKey(name: "contentName")
  final String? contentName;
  @override
  @JsonKey(name: "title")
  final String? title;
  @override
  @JsonKey(name: "adminType")
  final String? adminType;
  @override
  @JsonKey(name: "subTitle")
  final String? subTitle;
  @override
  @JsonKey(name: "textForButton1")
  final String? textForButton1;
  @override
  @JsonKey(name: "textForButton2")
  final String? textForButton2;
  @override
  @JsonKey(name: "fullText")
  final String? fullText;
  @override
  @JsonKey(name: "isDeleted")
  final bool? isDeleted;
  @override
  @JsonKey(name: "createdAt")
  final DateTime? createdAt;
  @override
  @JsonKey(name: "updatedAt")
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'Datum(id: $id, contentName: $contentName, title: $title, adminType: $adminType, subTitle: $subTitle, textForButton1: $textForButton1, textForButton2: $textForButton2, fullText: $fullText, isDeleted: $isDeleted, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DatumImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.contentName, contentName) ||
                other.contentName == contentName) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.adminType, adminType) ||
                other.adminType == adminType) &&
            (identical(other.subTitle, subTitle) ||
                other.subTitle == subTitle) &&
            (identical(other.textForButton1, textForButton1) ||
                other.textForButton1 == textForButton1) &&
            (identical(other.textForButton2, textForButton2) ||
                other.textForButton2 == textForButton2) &&
            (identical(other.fullText, fullText) ||
                other.fullText == fullText) &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      contentName,
      title,
      adminType,
      subTitle,
      textForButton1,
      textForButton2,
      fullText,
      isDeleted,
      createdAt,
      updatedAt,
      v);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      __$$DatumImplCopyWithImpl<_$DatumImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DatumImplToJson(
      this,
    );
  }
}

abstract class _Datum implements Datum {
  const factory _Datum(
      {@JsonKey(name: "_id") final String? id,
      @JsonKey(name: "contentName") final String? contentName,
      @JsonKey(name: "title") final String? title,
      @JsonKey(name: "adminType") final String? adminType,
      @JsonKey(name: "subTitle") final String? subTitle,
      @JsonKey(name: "textForButton1") final String? textForButton1,
      @JsonKey(name: "textForButton2") final String? textForButton2,
      @JsonKey(name: "fullText") final String? fullText,
      @JsonKey(name: "isDeleted") final bool? isDeleted,
      @JsonKey(name: "createdAt") final DateTime? createdAt,
      @JsonKey(name: "updatedAt") final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$DatumImpl;

  factory _Datum.fromJson(Map<String, dynamic> json) = _$DatumImpl.fromJson;

  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  @JsonKey(name: "contentName")
  String? get contentName;
  @override
  @JsonKey(name: "title")
  String? get title;
  @override
  @JsonKey(name: "adminType")
  String? get adminType;
  @override
  @JsonKey(name: "subTitle")
  String? get subTitle;
  @override
  @JsonKey(name: "textForButton1")
  String? get textForButton1;
  @override
  @JsonKey(name: "textForButton2")
  String? get textForButton2;
  @override
  @JsonKey(name: "fullText")
  String? get fullText;
  @override
  @JsonKey(name: "isDeleted")
  bool? get isDeleted;
  @override
  @JsonKey(name: "createdAt")
  DateTime? get createdAt;
  @override
  @JsonKey(name: "updatedAt")
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$DatumImplCopyWith<_$DatumImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
