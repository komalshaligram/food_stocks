// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_res_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$LoginResModelImpl _$$LoginResModelImplFromJson(Map<String, dynamic> json) =>
    _$LoginResModelImpl(
      status: json['status'] as int?,
      message: json['message'] as String?,
      user: json['user'] == null
          ? null
          : User.fromJson(json['user'] as Map<String, dynamic>),
      success: json['success'] as bool?,
    );

Map<String, dynamic> _$$LoginResModelImplToJson(_$LoginResModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
      'user': instance.user,
      'success': instance.success,
    };

_$UserImpl _$$UserImplFromJson(Map<String, dynamic> json) => _$UserImpl(
      isDeleted: json['isDeleted'] as bool?,
      id: json['_id'] as String?,
      email: json['email'] as String?,
      password: json['password'] as String?,
      firstName: json['firstName'] as String?,
      lastName: json['lastName'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      address: json['address'] as String?,
      cityId: json['cityId'] as String?,
      contactName: json['contactName'] as String?,
      statusId: json['statusId'] as String?,
      logo: json['logo'] as String?,
      adminTypeId: json['adminTypeId'] as String?,
      clientDetail: json['clientDetail'] == null
          ? null
          : ClientDetail.fromJson(json['clientDetail'] as Map<String, dynamic>),
      createdBy: json['createdBy'] as String?,
      updatedBy: json['updatedBy'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
      v: json['__v'] as int?,
    );

Map<String, dynamic> _$$UserImplToJson(_$UserImpl instance) =>
    <String, dynamic>{
      'isDeleted': instance.isDeleted,
      '_id': instance.id,
      'email': instance.email,
      'password': instance.password,
      'firstName': instance.firstName,
      'lastName': instance.lastName,
      'phoneNumber': instance.phoneNumber,
      'address': instance.address,
      'cityId': instance.cityId,
      'contactName': instance.contactName,
      'statusId': instance.statusId,
      'logo': instance.logo,
      'adminTypeId': instance.adminTypeId,
      'clientDetail': instance.clientDetail,
      'createdBy': instance.createdBy,
      'updatedBy': instance.updatedBy,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
      '__v': instance.v,
    };

_$ClientDetailImpl _$$ClientDetailImplFromJson(Map<String, dynamic> json) =>
    _$ClientDetailImpl(
      bussinessId: json['bussinessId'] as int?,
      bussinessName: json['bussinessName'] as String?,
      ownerName: json['ownerName'] as String?,
      clientTypeId: json['clientTypeId'] as String?,
      israelId: json['israelId'] as String?,
      tokenId: json['tokenId'] as String?,
      fax: json['fax'] as String?,
      lastSeen: json['lastSeen'] == null
          ? null
          : DateTime.parse(json['lastSeen'] as String),
      monthlyCredits: json['monthlyCredits'] as int?,
      applicationVersion: json['applicationVersion'] as String?,
      deviceType: json['deviceType'] as String?,
      operationTime: (json['operationTime'] as List<dynamic>?)
          ?.map((e) => OperationTime.fromJson(e as Map<String, dynamic>))
          .toList(),
      id: json['_id'] as String?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
    );

Map<String, dynamic> _$$ClientDetailImplToJson(_$ClientDetailImpl instance) =>
    <String, dynamic>{
      'bussinessId': instance.bussinessId,
      'bussinessName': instance.bussinessName,
      'ownerName': instance.ownerName,
      'clientTypeId': instance.clientTypeId,
      'israelId': instance.israelId,
      'tokenId': instance.tokenId,
      'fax': instance.fax,
      'lastSeen': instance.lastSeen?.toIso8601String(),
      'monthlyCredits': instance.monthlyCredits,
      'applicationVersion': instance.applicationVersion,
      'deviceType': instance.deviceType,
      'operationTime': instance.operationTime,
      '_id': instance.id,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
    };
