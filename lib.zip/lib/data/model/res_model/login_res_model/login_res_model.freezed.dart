// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'login_res_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

LoginResModel _$LoginResModelFromJson(Map<String, dynamic> json) {
  return _LoginResModel.fromJson(json);
}

/// @nodoc
mixin _$LoginResModel {
  int? get status => throw _privateConstructorUsedError;
  String? get message => throw _privateConstructorUsedError;
  User? get user => throw _privateConstructorUsedError;
  bool? get success => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $LoginResModelCopyWith<LoginResModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LoginResModelCopyWith<$Res> {
  factory $LoginResModelCopyWith(
          LoginResModel value, $Res Function(LoginResModel) then) =
      _$LoginResModelCopyWithImpl<$Res, LoginResModel>;
  @useResult
  $Res call({int? status, String? message, User? user, bool? success});

  $UserCopyWith<$Res>? get user;
}

/// @nodoc
class _$LoginResModelCopyWithImpl<$Res, $Val extends LoginResModel>
    implements $LoginResModelCopyWith<$Res> {
  _$LoginResModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? user = freezed,
    Object? success = freezed,
  }) {
    return _then(_value.copyWith(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      user: freezed == user
          ? _value.user
          : user // ignore: cast_nullable_to_non_nullable
              as User?,
      success: freezed == success
          ? _value.success
          : success // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $UserCopyWith<$Res>? get user {
    if (_value.user == null) {
      return null;
    }

    return $UserCopyWith<$Res>(_value.user!, (value) {
      return _then(_value.copyWith(user: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$LoginResModelImplCopyWith<$Res>
    implements $LoginResModelCopyWith<$Res> {
  factory _$$LoginResModelImplCopyWith(
          _$LoginResModelImpl value, $Res Function(_$LoginResModelImpl) then) =
      __$$LoginResModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int? status, String? message, User? user, bool? success});

  @override
  $UserCopyWith<$Res>? get user;
}

/// @nodoc
class __$$LoginResModelImplCopyWithImpl<$Res>
    extends _$LoginResModelCopyWithImpl<$Res, _$LoginResModelImpl>
    implements _$$LoginResModelImplCopyWith<$Res> {
  __$$LoginResModelImplCopyWithImpl(
      _$LoginResModelImpl _value, $Res Function(_$LoginResModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = freezed,
    Object? message = freezed,
    Object? user = freezed,
    Object? success = freezed,
  }) {
    return _then(_$LoginResModelImpl(
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as int?,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
      user: freezed == user
          ? _value.user
          : user // ignore: cast_nullable_to_non_nullable
              as User?,
      success: freezed == success
          ? _value.success
          : success // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$LoginResModelImpl implements _LoginResModel {
  const _$LoginResModelImpl(
      {this.status, this.message, this.user, this.success});

  factory _$LoginResModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$LoginResModelImplFromJson(json);

  @override
  final int? status;
  @override
  final String? message;
  @override
  final User? user;
  @override
  final bool? success;

  @override
  String toString() {
    return 'LoginResModel(status: $status, message: $message, user: $user, success: $success)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoginResModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.user, user) || other.user == user) &&
            (identical(other.success, success) || other.success == success));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, message, user, success);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoginResModelImplCopyWith<_$LoginResModelImpl> get copyWith =>
      __$$LoginResModelImplCopyWithImpl<_$LoginResModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$LoginResModelImplToJson(
      this,
    );
  }
}

abstract class _LoginResModel implements LoginResModel {
  const factory _LoginResModel(
      {final int? status,
      final String? message,
      final User? user,
      final bool? success}) = _$LoginResModelImpl;

  factory _LoginResModel.fromJson(Map<String, dynamic> json) =
      _$LoginResModelImpl.fromJson;

  @override
  int? get status;
  @override
  String? get message;
  @override
  User? get user;
  @override
  bool? get success;
  @override
  @JsonKey(ignore: true)
  _$$LoginResModelImplCopyWith<_$LoginResModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

User _$UserFromJson(Map<String, dynamic> json) {
  return _User.fromJson(json);
}

/// @nodoc
mixin _$User {
  bool? get isDeleted => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  String? get email => throw _privateConstructorUsedError;
  String? get password => throw _privateConstructorUsedError;
  String? get firstName => throw _privateConstructorUsedError;
  String? get lastName => throw _privateConstructorUsedError;
  String? get phoneNumber => throw _privateConstructorUsedError;
  String? get address => throw _privateConstructorUsedError;
  String? get cityId => throw _privateConstructorUsedError;
  String? get contactName => throw _privateConstructorUsedError;
  String? get statusId => throw _privateConstructorUsedError;
  String? get logo => throw _privateConstructorUsedError;
  String? get adminTypeId => throw _privateConstructorUsedError;
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail => throw _privateConstructorUsedError;
  String? get createdBy => throw _privateConstructorUsedError;
  String? get updatedBy => throw _privateConstructorUsedError;
  DateTime? get createdAt => throw _privateConstructorUsedError;
  DateTime? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "__v")
  int? get v => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $UserCopyWith<User> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserCopyWith<$Res> {
  factory $UserCopyWith(User value, $Res Function(User) then) =
      _$UserCopyWithImpl<$Res, User>;
  @useResult
  $Res call(
      {bool? isDeleted,
      @JsonKey(name: "_id") String? id,
      String? email,
      String? password,
      String? firstName,
      String? lastName,
      String? phoneNumber,
      String? address,
      String? cityId,
      String? contactName,
      String? statusId,
      String? logo,
      String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      String? createdBy,
      String? updatedBy,
      DateTime? createdAt,
      DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});

  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class _$UserCopyWithImpl<$Res, $Val extends User>
    implements $UserCopyWith<$Res> {
  _$UserCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isDeleted = freezed,
    Object? id = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? firstName = freezed,
    Object? lastName = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_value.copyWith(
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String?,
      firstName: freezed == firstName
          ? _value.firstName
          : firstName // ignore: cast_nullable_to_non_nullable
              as String?,
      lastName: freezed == lastName
          ? _value.lastName
          : lastName // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ClientDetailCopyWith<$Res>? get clientDetail {
    if (_value.clientDetail == null) {
      return null;
    }

    return $ClientDetailCopyWith<$Res>(_value.clientDetail!, (value) {
      return _then(_value.copyWith(clientDetail: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$UserImplCopyWith<$Res> implements $UserCopyWith<$Res> {
  factory _$$UserImplCopyWith(
          _$UserImpl value, $Res Function(_$UserImpl) then) =
      __$$UserImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool? isDeleted,
      @JsonKey(name: "_id") String? id,
      String? email,
      String? password,
      String? firstName,
      String? lastName,
      String? phoneNumber,
      String? address,
      String? cityId,
      String? contactName,
      String? statusId,
      String? logo,
      String? adminTypeId,
      @JsonKey(name: "clientDetail") ClientDetail? clientDetail,
      String? createdBy,
      String? updatedBy,
      DateTime? createdAt,
      DateTime? updatedAt,
      @JsonKey(name: "__v") int? v});

  @override
  $ClientDetailCopyWith<$Res>? get clientDetail;
}

/// @nodoc
class __$$UserImplCopyWithImpl<$Res>
    extends _$UserCopyWithImpl<$Res, _$UserImpl>
    implements _$$UserImplCopyWith<$Res> {
  __$$UserImplCopyWithImpl(_$UserImpl _value, $Res Function(_$UserImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isDeleted = freezed,
    Object? id = freezed,
    Object? email = freezed,
    Object? password = freezed,
    Object? firstName = freezed,
    Object? lastName = freezed,
    Object? phoneNumber = freezed,
    Object? address = freezed,
    Object? cityId = freezed,
    Object? contactName = freezed,
    Object? statusId = freezed,
    Object? logo = freezed,
    Object? adminTypeId = freezed,
    Object? clientDetail = freezed,
    Object? createdBy = freezed,
    Object? updatedBy = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
    Object? v = freezed,
  }) {
    return _then(_$UserImpl(
      isDeleted: freezed == isDeleted
          ? _value.isDeleted
          : isDeleted // ignore: cast_nullable_to_non_nullable
              as bool?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      password: freezed == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String?,
      firstName: freezed == firstName
          ? _value.firstName
          : firstName // ignore: cast_nullable_to_non_nullable
              as String?,
      lastName: freezed == lastName
          ? _value.lastName
          : lastName // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      address: freezed == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      cityId: freezed == cityId
          ? _value.cityId
          : cityId // ignore: cast_nullable_to_non_nullable
              as String?,
      contactName: freezed == contactName
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String?,
      statusId: freezed == statusId
          ? _value.statusId
          : statusId // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      adminTypeId: freezed == adminTypeId
          ? _value.adminTypeId
          : adminTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      clientDetail: freezed == clientDetail
          ? _value.clientDetail
          : clientDetail // ignore: cast_nullable_to_non_nullable
              as ClientDetail?,
      createdBy: freezed == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedBy: freezed == updatedBy
          ? _value.updatedBy
          : updatedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      v: freezed == v
          ? _value.v
          : v // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$UserImpl implements _User {
  const _$UserImpl(
      {this.isDeleted,
      @JsonKey(name: "_id") this.id,
      this.email,
      this.password,
      this.firstName,
      this.lastName,
      this.phoneNumber,
      this.address,
      this.cityId,
      this.contactName,
      this.statusId,
      this.logo,
      this.adminTypeId,
      @JsonKey(name: "clientDetail") this.clientDetail,
      this.createdBy,
      this.updatedBy,
      this.createdAt,
      this.updatedAt,
      @JsonKey(name: "__v") this.v});

  factory _$UserImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserImplFromJson(json);

  @override
  final bool? isDeleted;
  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  final String? email;
  @override
  final String? password;
  @override
  final String? firstName;
  @override
  final String? lastName;
  @override
  final String? phoneNumber;
  @override
  final String? address;
  @override
  final String? cityId;
  @override
  final String? contactName;
  @override
  final String? statusId;
  @override
  final String? logo;
  @override
  final String? adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  final ClientDetail? clientDetail;
  @override
  final String? createdBy;
  @override
  final String? updatedBy;
  @override
  final DateTime? createdAt;
  @override
  final DateTime? updatedAt;
  @override
  @JsonKey(name: "__v")
  final int? v;

  @override
  String toString() {
    return 'User(isDeleted: $isDeleted, id: $id, email: $email, password: $password, firstName: $firstName, lastName: $lastName, phoneNumber: $phoneNumber, address: $address, cityId: $cityId, contactName: $contactName, statusId: $statusId, logo: $logo, adminTypeId: $adminTypeId, clientDetail: $clientDetail, createdBy: $createdBy, updatedBy: $updatedBy, createdAt: $createdAt, updatedAt: $updatedAt, v: $v)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserImpl &&
            (identical(other.isDeleted, isDeleted) ||
                other.isDeleted == isDeleted) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.password, password) ||
                other.password == password) &&
            (identical(other.firstName, firstName) ||
                other.firstName == firstName) &&
            (identical(other.lastName, lastName) ||
                other.lastName == lastName) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.cityId, cityId) || other.cityId == cityId) &&
            (identical(other.contactName, contactName) ||
                other.contactName == contactName) &&
            (identical(other.statusId, statusId) ||
                other.statusId == statusId) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.adminTypeId, adminTypeId) ||
                other.adminTypeId == adminTypeId) &&
            (identical(other.clientDetail, clientDetail) ||
                other.clientDetail == clientDetail) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.updatedBy, updatedBy) ||
                other.updatedBy == updatedBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.v, v) || other.v == v));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        isDeleted,
        id,
        email,
        password,
        firstName,
        lastName,
        phoneNumber,
        address,
        cityId,
        contactName,
        statusId,
        logo,
        adminTypeId,
        clientDetail,
        createdBy,
        updatedBy,
        createdAt,
        updatedAt,
        v
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UserImplCopyWith<_$UserImpl> get copyWith =>
      __$$UserImplCopyWithImpl<_$UserImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserImplToJson(
      this,
    );
  }
}

abstract class _User implements User {
  const factory _User(
      {final bool? isDeleted,
      @JsonKey(name: "_id") final String? id,
      final String? email,
      final String? password,
      final String? firstName,
      final String? lastName,
      final String? phoneNumber,
      final String? address,
      final String? cityId,
      final String? contactName,
      final String? statusId,
      final String? logo,
      final String? adminTypeId,
      @JsonKey(name: "clientDetail") final ClientDetail? clientDetail,
      final String? createdBy,
      final String? updatedBy,
      final DateTime? createdAt,
      final DateTime? updatedAt,
      @JsonKey(name: "__v") final int? v}) = _$UserImpl;

  factory _User.fromJson(Map<String, dynamic> json) = _$UserImpl.fromJson;

  @override
  bool? get isDeleted;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  String? get email;
  @override
  String? get password;
  @override
  String? get firstName;
  @override
  String? get lastName;
  @override
  String? get phoneNumber;
  @override
  String? get address;
  @override
  String? get cityId;
  @override
  String? get contactName;
  @override
  String? get statusId;
  @override
  String? get logo;
  @override
  String? get adminTypeId;
  @override
  @JsonKey(name: "clientDetail")
  ClientDetail? get clientDetail;
  @override
  String? get createdBy;
  @override
  String? get updatedBy;
  @override
  DateTime? get createdAt;
  @override
  DateTime? get updatedAt;
  @override
  @JsonKey(name: "__v")
  int? get v;
  @override
  @JsonKey(ignore: true)
  _$$UserImplCopyWith<_$UserImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ClientDetail _$ClientDetailFromJson(Map<String, dynamic> json) {
  return _ClientDetail.fromJson(json);
}

/// @nodoc
mixin _$ClientDetail {
  int? get bussinessId => throw _privateConstructorUsedError;
  String? get bussinessName => throw _privateConstructorUsedError;
  String? get ownerName => throw _privateConstructorUsedError;
  String? get clientTypeId => throw _privateConstructorUsedError;
  String? get israelId => throw _privateConstructorUsedError;
  String? get tokenId => throw _privateConstructorUsedError;
  String? get fax => throw _privateConstructorUsedError;
  DateTime? get lastSeen => throw _privateConstructorUsedError;
  int? get monthlyCredits => throw _privateConstructorUsedError;
  String? get applicationVersion => throw _privateConstructorUsedError;
  String? get deviceType => throw _privateConstructorUsedError;
  List<OperationTime>? get operationTime => throw _privateConstructorUsedError;
  @JsonKey(name: "_id")
  String? get id => throw _privateConstructorUsedError;
  DateTime? get createdAt => throw _privateConstructorUsedError;
  DateTime? get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ClientDetailCopyWith<ClientDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClientDetailCopyWith<$Res> {
  factory $ClientDetailCopyWith(
          ClientDetail value, $Res Function(ClientDetail) then) =
      _$ClientDetailCopyWithImpl<$Res, ClientDetail>;
  @useResult
  $Res call(
      {int? bussinessId,
      String? bussinessName,
      String? ownerName,
      String? clientTypeId,
      String? israelId,
      String? tokenId,
      String? fax,
      DateTime? lastSeen,
      int? monthlyCredits,
      String? applicationVersion,
      String? deviceType,
      List<OperationTime>? operationTime,
      @JsonKey(name: "_id") String? id,
      DateTime? createdAt,
      DateTime? updatedAt});
}

/// @nodoc
class _$ClientDetailCopyWithImpl<$Res, $Val extends ClientDetail>
    implements $ClientDetailCopyWith<$Res> {
  _$ClientDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_value.copyWith(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as int?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value.operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ClientDetailImplCopyWith<$Res>
    implements $ClientDetailCopyWith<$Res> {
  factory _$$ClientDetailImplCopyWith(
          _$ClientDetailImpl value, $Res Function(_$ClientDetailImpl) then) =
      __$$ClientDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int? bussinessId,
      String? bussinessName,
      String? ownerName,
      String? clientTypeId,
      String? israelId,
      String? tokenId,
      String? fax,
      DateTime? lastSeen,
      int? monthlyCredits,
      String? applicationVersion,
      String? deviceType,
      List<OperationTime>? operationTime,
      @JsonKey(name: "_id") String? id,
      DateTime? createdAt,
      DateTime? updatedAt});
}

/// @nodoc
class __$$ClientDetailImplCopyWithImpl<$Res>
    extends _$ClientDetailCopyWithImpl<$Res, _$ClientDetailImpl>
    implements _$$ClientDetailImplCopyWith<$Res> {
  __$$ClientDetailImplCopyWithImpl(
      _$ClientDetailImpl _value, $Res Function(_$ClientDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bussinessId = freezed,
    Object? bussinessName = freezed,
    Object? ownerName = freezed,
    Object? clientTypeId = freezed,
    Object? israelId = freezed,
    Object? tokenId = freezed,
    Object? fax = freezed,
    Object? lastSeen = freezed,
    Object? monthlyCredits = freezed,
    Object? applicationVersion = freezed,
    Object? deviceType = freezed,
    Object? operationTime = freezed,
    Object? id = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_$ClientDetailImpl(
      bussinessId: freezed == bussinessId
          ? _value.bussinessId
          : bussinessId // ignore: cast_nullable_to_non_nullable
              as int?,
      bussinessName: freezed == bussinessName
          ? _value.bussinessName
          : bussinessName // ignore: cast_nullable_to_non_nullable
              as String?,
      ownerName: freezed == ownerName
          ? _value.ownerName
          : ownerName // ignore: cast_nullable_to_non_nullable
              as String?,
      clientTypeId: freezed == clientTypeId
          ? _value.clientTypeId
          : clientTypeId // ignore: cast_nullable_to_non_nullable
              as String?,
      israelId: freezed == israelId
          ? _value.israelId
          : israelId // ignore: cast_nullable_to_non_nullable
              as String?,
      tokenId: freezed == tokenId
          ? _value.tokenId
          : tokenId // ignore: cast_nullable_to_non_nullable
              as String?,
      fax: freezed == fax
          ? _value.fax
          : fax // ignore: cast_nullable_to_non_nullable
              as String?,
      lastSeen: freezed == lastSeen
          ? _value.lastSeen
          : lastSeen // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monthlyCredits: freezed == monthlyCredits
          ? _value.monthlyCredits
          : monthlyCredits // ignore: cast_nullable_to_non_nullable
              as int?,
      applicationVersion: freezed == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String?,
      deviceType: freezed == deviceType
          ? _value.deviceType
          : deviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      operationTime: freezed == operationTime
          ? _value._operationTime
          : operationTime // ignore: cast_nullable_to_non_nullable
              as List<OperationTime>?,
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ClientDetailImpl implements _ClientDetail {
  const _$ClientDetailImpl(
      {this.bussinessId,
      this.bussinessName,
      this.ownerName,
      this.clientTypeId,
      this.israelId,
      this.tokenId,
      this.fax,
      this.lastSeen,
      this.monthlyCredits,
      this.applicationVersion,
      this.deviceType,
      final List<OperationTime>? operationTime,
      @JsonKey(name: "_id") this.id,
      this.createdAt,
      this.updatedAt})
      : _operationTime = operationTime;

  factory _$ClientDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClientDetailImplFromJson(json);

  @override
  final int? bussinessId;
  @override
  final String? bussinessName;
  @override
  final String? ownerName;
  @override
  final String? clientTypeId;
  @override
  final String? israelId;
  @override
  final String? tokenId;
  @override
  final String? fax;
  @override
  final DateTime? lastSeen;
  @override
  final int? monthlyCredits;
  @override
  final String? applicationVersion;
  @override
  final String? deviceType;
  final List<OperationTime>? _operationTime;
  @override
  List<OperationTime>? get operationTime {
    final value = _operationTime;
    if (value == null) return null;
    if (_operationTime is EqualUnmodifiableListView) return _operationTime;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: "_id")
  final String? id;
  @override
  final DateTime? createdAt;
  @override
  final DateTime? updatedAt;

  @override
  String toString() {
    return 'ClientDetail(bussinessId: $bussinessId, bussinessName: $bussinessName, ownerName: $ownerName, clientTypeId: $clientTypeId, israelId: $israelId, tokenId: $tokenId, fax: $fax, lastSeen: $lastSeen, monthlyCredits: $monthlyCredits, applicationVersion: $applicationVersion, deviceType: $deviceType, operationTime: $operationTime, id: $id, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ClientDetailImpl &&
            (identical(other.bussinessId, bussinessId) ||
                other.bussinessId == bussinessId) &&
            (identical(other.bussinessName, bussinessName) ||
                other.bussinessName == bussinessName) &&
            (identical(other.ownerName, ownerName) ||
                other.ownerName == ownerName) &&
            (identical(other.clientTypeId, clientTypeId) ||
                other.clientTypeId == clientTypeId) &&
            (identical(other.israelId, israelId) ||
                other.israelId == israelId) &&
            (identical(other.tokenId, tokenId) || other.tokenId == tokenId) &&
            (identical(other.fax, fax) || other.fax == fax) &&
            (identical(other.lastSeen, lastSeen) ||
                other.lastSeen == lastSeen) &&
            (identical(other.monthlyCredits, monthlyCredits) ||
                other.monthlyCredits == monthlyCredits) &&
            (identical(other.applicationVersion, applicationVersion) ||
                other.applicationVersion == applicationVersion) &&
            (identical(other.deviceType, deviceType) ||
                other.deviceType == deviceType) &&
            const DeepCollectionEquality()
                .equals(other._operationTime, _operationTime) &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      bussinessId,
      bussinessName,
      ownerName,
      clientTypeId,
      israelId,
      tokenId,
      fax,
      lastSeen,
      monthlyCredits,
      applicationVersion,
      deviceType,
      const DeepCollectionEquality().hash(_operationTime),
      id,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      __$$ClientDetailImplCopyWithImpl<_$ClientDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClientDetailImplToJson(
      this,
    );
  }
}

abstract class _ClientDetail implements ClientDetail {
  const factory _ClientDetail(
      {final int? bussinessId,
      final String? bussinessName,
      final String? ownerName,
      final String? clientTypeId,
      final String? israelId,
      final String? tokenId,
      final String? fax,
      final DateTime? lastSeen,
      final int? monthlyCredits,
      final String? applicationVersion,
      final String? deviceType,
      final List<OperationTime>? operationTime,
      @JsonKey(name: "_id") final String? id,
      final DateTime? createdAt,
      final DateTime? updatedAt}) = _$ClientDetailImpl;

  factory _ClientDetail.fromJson(Map<String, dynamic> json) =
      _$ClientDetailImpl.fromJson;

  @override
  int? get bussinessId;
  @override
  String? get bussinessName;
  @override
  String? get ownerName;
  @override
  String? get clientTypeId;
  @override
  String? get israelId;
  @override
  String? get tokenId;
  @override
  String? get fax;
  @override
  DateTime? get lastSeen;
  @override
  int? get monthlyCredits;
  @override
  String? get applicationVersion;
  @override
  String? get deviceType;
  @override
  List<OperationTime>? get operationTime;
  @override
  @JsonKey(name: "_id")
  String? get id;
  @override
  DateTime? get createdAt;
  @override
  DateTime? get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$ClientDetailImplCopyWith<_$ClientDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
