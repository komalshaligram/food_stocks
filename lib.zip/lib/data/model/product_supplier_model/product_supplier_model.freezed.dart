// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_supplier_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProductSupplierModel _$ProductSupplierModelFromJson(Map<String, dynamic> json) {
  return _ProductSupplierModel.fromJson(json);
}

/// @nodoc
mixin _$ProductSupplierModel {
  String get supplierId => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;
  List<SupplierSaleModel> get supplierSales =>
      throw _privateConstructorUsedError;
  int get quantity => throw _privateConstructorUsedError;
  double get basePrice => throw _privateConstructorUsedError;
  String get stock =>
      throw _privateConstructorUsedError; // @Default(false) bool isSelected,
  int get selectedIndex => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProductSupplierModelCopyWith<ProductSupplierModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductSupplierModelCopyWith<$Res> {
  factory $ProductSupplierModelCopyWith(ProductSupplierModel value,
          $Res Function(ProductSupplierModel) then) =
      _$ProductSupplierModelCopyWithImpl<$Res, ProductSupplierModel>;
  @useResult
  $Res call(
      {String supplierId,
      String companyName,
      List<SupplierSaleModel> supplierSales,
      int quantity,
      double basePrice,
      String stock,
      int selectedIndex});
}

/// @nodoc
class _$ProductSupplierModelCopyWithImpl<$Res,
        $Val extends ProductSupplierModel>
    implements $ProductSupplierModelCopyWith<$Res> {
  _$ProductSupplierModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierId = null,
    Object? companyName = null,
    Object? supplierSales = null,
    Object? quantity = null,
    Object? basePrice = null,
    Object? stock = null,
    Object? selectedIndex = null,
  }) {
    return _then(_value.copyWith(
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      supplierSales: null == supplierSales
          ? _value.supplierSales
          : supplierSales // ignore: cast_nullable_to_non_nullable
              as List<SupplierSaleModel>,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      basePrice: null == basePrice
          ? _value.basePrice
          : basePrice // ignore: cast_nullable_to_non_nullable
              as double,
      stock: null == stock
          ? _value.stock
          : stock // ignore: cast_nullable_to_non_nullable
              as String,
      selectedIndex: null == selectedIndex
          ? _value.selectedIndex
          : selectedIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductSupplierModelImplCopyWith<$Res>
    implements $ProductSupplierModelCopyWith<$Res> {
  factory _$$ProductSupplierModelImplCopyWith(_$ProductSupplierModelImpl value,
          $Res Function(_$ProductSupplierModelImpl) then) =
      __$$ProductSupplierModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String supplierId,
      String companyName,
      List<SupplierSaleModel> supplierSales,
      int quantity,
      double basePrice,
      String stock,
      int selectedIndex});
}

/// @nodoc
class __$$ProductSupplierModelImplCopyWithImpl<$Res>
    extends _$ProductSupplierModelCopyWithImpl<$Res, _$ProductSupplierModelImpl>
    implements _$$ProductSupplierModelImplCopyWith<$Res> {
  __$$ProductSupplierModelImplCopyWithImpl(_$ProductSupplierModelImpl _value,
      $Res Function(_$ProductSupplierModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierId = null,
    Object? companyName = null,
    Object? supplierSales = null,
    Object? quantity = null,
    Object? basePrice = null,
    Object? stock = null,
    Object? selectedIndex = null,
  }) {
    return _then(_$ProductSupplierModelImpl(
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      supplierSales: null == supplierSales
          ? _value._supplierSales
          : supplierSales // ignore: cast_nullable_to_non_nullable
              as List<SupplierSaleModel>,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      basePrice: null == basePrice
          ? _value.basePrice
          : basePrice // ignore: cast_nullable_to_non_nullable
              as double,
      stock: null == stock
          ? _value.stock
          : stock // ignore: cast_nullable_to_non_nullable
              as String,
      selectedIndex: null == selectedIndex
          ? _value.selectedIndex
          : selectedIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProductSupplierModelImpl implements _ProductSupplierModel {
  const _$ProductSupplierModelImpl(
      {required this.supplierId,
      required this.companyName,
      final List<SupplierSaleModel> supplierSales = const [],
      this.quantity = 0,
      this.basePrice = 0.0,
      this.stock = '0',
      this.selectedIndex = -1})
      : _supplierSales = supplierSales;

  factory _$ProductSupplierModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProductSupplierModelImplFromJson(json);

  @override
  final String supplierId;
  @override
  final String companyName;
  final List<SupplierSaleModel> _supplierSales;
  @override
  @JsonKey()
  List<SupplierSaleModel> get supplierSales {
    if (_supplierSales is EqualUnmodifiableListView) return _supplierSales;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_supplierSales);
  }

  @override
  @JsonKey()
  final int quantity;
  @override
  @JsonKey()
  final double basePrice;
  @override
  @JsonKey()
  final String stock;
// @Default(false) bool isSelected,
  @override
  @JsonKey()
  final int selectedIndex;

  @override
  String toString() {
    return 'ProductSupplierModel(supplierId: $supplierId, companyName: $companyName, supplierSales: $supplierSales, quantity: $quantity, basePrice: $basePrice, stock: $stock, selectedIndex: $selectedIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductSupplierModelImpl &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            const DeepCollectionEquality()
                .equals(other._supplierSales, _supplierSales) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.basePrice, basePrice) ||
                other.basePrice == basePrice) &&
            (identical(other.stock, stock) || other.stock == stock) &&
            (identical(other.selectedIndex, selectedIndex) ||
                other.selectedIndex == selectedIndex));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      supplierId,
      companyName,
      const DeepCollectionEquality().hash(_supplierSales),
      quantity,
      basePrice,
      stock,
      selectedIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductSupplierModelImplCopyWith<_$ProductSupplierModelImpl>
      get copyWith =>
          __$$ProductSupplierModelImplCopyWithImpl<_$ProductSupplierModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProductSupplierModelImplToJson(
      this,
    );
  }
}

abstract class _ProductSupplierModel implements ProductSupplierModel {
  const factory _ProductSupplierModel(
      {required final String supplierId,
      required final String companyName,
      final List<SupplierSaleModel> supplierSales,
      final int quantity,
      final double basePrice,
      final String stock,
      final int selectedIndex}) = _$ProductSupplierModelImpl;

  factory _ProductSupplierModel.fromJson(Map<String, dynamic> json) =
      _$ProductSupplierModelImpl.fromJson;

  @override
  String get supplierId;
  @override
  String get companyName;
  @override
  List<SupplierSaleModel> get supplierSales;
  @override
  int get quantity;
  @override
  double get basePrice;
  @override
  String get stock;
  @override // @Default(false) bool isSelected,
  int get selectedIndex;
  @override
  @JsonKey(ignore: true)
  _$$ProductSupplierModelImplCopyWith<_$ProductSupplierModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
