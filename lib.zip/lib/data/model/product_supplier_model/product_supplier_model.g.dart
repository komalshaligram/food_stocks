// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_supplier_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProductSupplierModelImpl _$$ProductSupplierModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProductSupplierModelImpl(
      supplierId: json['supplierId'] as String,
      companyName: json['companyName'] as String,
      supplierSales: (json['supplierSales'] as List<dynamic>?)
              ?.map(
                  (e) => SupplierSaleModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
      quantity: json['quantity'] as int? ?? 0,
      basePrice: (json['basePrice'] as num?)?.toDouble() ?? 0.0,
      stock: json['stock'] as String? ?? '0',
      selectedIndex: json['selectedIndex'] as int? ?? -1,
    );

Map<String, dynamic> _$$ProductSupplierModelImplToJson(
        _$ProductSupplierModelImpl instance) =>
    <String, dynamic>{
      'supplierId': instance.supplierId,
      'companyName': instance.companyName,
      'supplierSales': instance.supplierSales,
      'quantity': instance.quantity,
      'basePrice': instance.basePrice,
      'stock': instance.stock,
      'selectedIndex': instance.selectedIndex,
    };
