// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'supplier_sale_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SupplierSaleModel _$SupplierSaleModelFromJson(Map<String, dynamic> json) {
  return _SupplierSaleModel.fromJson(json);
}

/// @nodoc
mixin _$SupplierSaleModel {
  String get saleId => throw _privateConstructorUsedError;
  String get saleName => throw _privateConstructorUsedError;
  double get salePrice => throw _privateConstructorUsedError;
  double get saleDiscount => throw _privateConstructorUsedError;
  String get saleDescription => throw _privateConstructorUsedError;
  int get quantity => throw _privateConstructorUsedError;
  int get productStock => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierSaleModelCopyWith<SupplierSaleModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierSaleModelCopyWith<$Res> {
  factory $SupplierSaleModelCopyWith(
          SupplierSaleModel value, $Res Function(SupplierSaleModel) then) =
      _$SupplierSaleModelCopyWithImpl<$Res, SupplierSaleModel>;
  @useResult
  $Res call(
      {String saleId,
      String saleName,
      double salePrice,
      double saleDiscount,
      String saleDescription,
      int quantity,
      int productStock});
}

/// @nodoc
class _$SupplierSaleModelCopyWithImpl<$Res, $Val extends SupplierSaleModel>
    implements $SupplierSaleModelCopyWith<$Res> {
  _$SupplierSaleModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? saleId = null,
    Object? saleName = null,
    Object? salePrice = null,
    Object? saleDiscount = null,
    Object? saleDescription = null,
    Object? quantity = null,
    Object? productStock = null,
  }) {
    return _then(_value.copyWith(
      saleId: null == saleId
          ? _value.saleId
          : saleId // ignore: cast_nullable_to_non_nullable
              as String,
      saleName: null == saleName
          ? _value.saleName
          : saleName // ignore: cast_nullable_to_non_nullable
              as String,
      salePrice: null == salePrice
          ? _value.salePrice
          : salePrice // ignore: cast_nullable_to_non_nullable
              as double,
      saleDiscount: null == saleDiscount
          ? _value.saleDiscount
          : saleDiscount // ignore: cast_nullable_to_non_nullable
              as double,
      saleDescription: null == saleDescription
          ? _value.saleDescription
          : saleDescription // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      productStock: null == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierSaleModelImplCopyWith<$Res>
    implements $SupplierSaleModelCopyWith<$Res> {
  factory _$$SupplierSaleModelImplCopyWith(_$SupplierSaleModelImpl value,
          $Res Function(_$SupplierSaleModelImpl) then) =
      __$$SupplierSaleModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String saleId,
      String saleName,
      double salePrice,
      double saleDiscount,
      String saleDescription,
      int quantity,
      int productStock});
}

/// @nodoc
class __$$SupplierSaleModelImplCopyWithImpl<$Res>
    extends _$SupplierSaleModelCopyWithImpl<$Res, _$SupplierSaleModelImpl>
    implements _$$SupplierSaleModelImplCopyWith<$Res> {
  __$$SupplierSaleModelImplCopyWithImpl(_$SupplierSaleModelImpl _value,
      $Res Function(_$SupplierSaleModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? saleId = null,
    Object? saleName = null,
    Object? salePrice = null,
    Object? saleDiscount = null,
    Object? saleDescription = null,
    Object? quantity = null,
    Object? productStock = null,
  }) {
    return _then(_$SupplierSaleModelImpl(
      saleId: null == saleId
          ? _value.saleId
          : saleId // ignore: cast_nullable_to_non_nullable
              as String,
      saleName: null == saleName
          ? _value.saleName
          : saleName // ignore: cast_nullable_to_non_nullable
              as String,
      salePrice: null == salePrice
          ? _value.salePrice
          : salePrice // ignore: cast_nullable_to_non_nullable
              as double,
      saleDiscount: null == saleDiscount
          ? _value.saleDiscount
          : saleDiscount // ignore: cast_nullable_to_non_nullable
              as double,
      saleDescription: null == saleDescription
          ? _value.saleDescription
          : saleDescription // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      productStock: null == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SupplierSaleModelImpl implements _SupplierSaleModel {
  const _$SupplierSaleModelImpl(
      {required this.saleId,
      this.saleName = '',
      this.salePrice = 0.0,
      this.saleDiscount = 0.0,
      this.saleDescription = '',
      this.quantity = 0,
      this.productStock = 0});

  factory _$SupplierSaleModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SupplierSaleModelImplFromJson(json);

  @override
  final String saleId;
  @override
  @JsonKey()
  final String saleName;
  @override
  @JsonKey()
  final double salePrice;
  @override
  @JsonKey()
  final double saleDiscount;
  @override
  @JsonKey()
  final String saleDescription;
  @override
  @JsonKey()
  final int quantity;
  @override
  @JsonKey()
  final int productStock;

  @override
  String toString() {
    return 'SupplierSaleModel(saleId: $saleId, saleName: $saleName, salePrice: $salePrice, saleDiscount: $saleDiscount, saleDescription: $saleDescription, quantity: $quantity, productStock: $productStock)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSaleModelImpl &&
            (identical(other.saleId, saleId) || other.saleId == saleId) &&
            (identical(other.saleName, saleName) ||
                other.saleName == saleName) &&
            (identical(other.salePrice, salePrice) ||
                other.salePrice == salePrice) &&
            (identical(other.saleDiscount, saleDiscount) ||
                other.saleDiscount == saleDiscount) &&
            (identical(other.saleDescription, saleDescription) ||
                other.saleDescription == saleDescription) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, saleId, saleName, salePrice,
      saleDiscount, saleDescription, quantity, productStock);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSaleModelImplCopyWith<_$SupplierSaleModelImpl> get copyWith =>
      __$$SupplierSaleModelImplCopyWithImpl<_$SupplierSaleModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SupplierSaleModelImplToJson(
      this,
    );
  }
}

abstract class _SupplierSaleModel implements SupplierSaleModel {
  const factory _SupplierSaleModel(
      {required final String saleId,
      final String saleName,
      final double salePrice,
      final double saleDiscount,
      final String saleDescription,
      final int quantity,
      final int productStock}) = _$SupplierSaleModelImpl;

  factory _SupplierSaleModel.fromJson(Map<String, dynamic> json) =
      _$SupplierSaleModelImpl.fromJson;

  @override
  String get saleId;
  @override
  String get saleName;
  @override
  double get salePrice;
  @override
  double get saleDiscount;
  @override
  String get saleDescription;
  @override
  int get quantity;
  @override
  int get productStock;
  @override
  @JsonKey(ignore: true)
  _$$SupplierSaleModelImplCopyWith<_$SupplierSaleModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
