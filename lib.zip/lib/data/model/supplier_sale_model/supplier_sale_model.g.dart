// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'supplier_sale_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SupplierSaleModelImpl _$$SupplierSaleModelImplFromJson(
        Map<String, dynamic> json) =>
    _$SupplierSaleModelImpl(
      saleId: json['saleId'] as String,
      saleName: json['saleName'] as String? ?? '',
      salePrice: (json['salePrice'] as num?)?.toDouble() ?? 0.0,
      saleDiscount: (json['saleDiscount'] as num?)?.toDouble() ?? 0.0,
      saleDescription: json['saleDescription'] as String? ?? '',
      quantity: json['quantity'] as int? ?? 0,
      productStock: json['productStock'] as int? ?? 0,
    );

Map<String, dynamic> _$$SupplierSaleModelImplToJson(
        _$SupplierSaleModelImpl instance) =>
    <String, dynamic>{
      'saleId': instance.saleId,
      'saleName': instance.saleName,
      'salePrice': instance.salePrice,
      'saleDiscount': instance.saleDiscount,
      'saleDescription': instance.saleDescription,
      'quantity': instance.quantity,
      'productStock': instance.productStock,
    };
