// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'form_and_file_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$FormAndFileModelImpl _$$FormAndFileModelImplFromJson(
        Map<String, dynamic> json) =>
    _$FormAndFileModelImpl(
      id: json['id'] as String?,
      name: json['name'] as String?,
      url: json['url'] as String?,
      localUrl: json['localUrl'] as String?,
      isForm: json['isForm'] as bool?,
      sampleUrl: json['sampleUrl'] as String?,
    );

Map<String, dynamic> _$$FormAndFileModelImplToJson(
        _$FormAndFileModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'url': instance.url,
      'localUrl': instance.localUrl,
      'isForm': instance.isForm,
      'sampleUrl': instance.sampleUrl,
    };
