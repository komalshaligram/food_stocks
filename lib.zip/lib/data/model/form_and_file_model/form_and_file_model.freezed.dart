// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'form_and_file_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

FormAndFileModel _$FormAndFileModelFromJson(Map<String, dynamic> json) {
  return _FormAndFileModel.fromJson(json);
}

/// @nodoc
mixin _$FormAndFileModel {
  String? get id => throw _privateConstructorUsedError;
  String? get name => throw _privateConstructorUsedError;
  String? get url => throw _privateConstructorUsedError;
  String? get localUrl => throw _privateConstructorUsedError;
  bool? get isForm => throw _privateConstructorUsedError;
  String? get sampleUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $FormAndFileModelCopyWith<FormAndFileModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FormAndFileModelCopyWith<$Res> {
  factory $FormAndFileModelCopyWith(
          FormAndFileModel value, $Res Function(FormAndFileModel) then) =
      _$FormAndFileModelCopyWithImpl<$Res, FormAndFileModel>;
  @useResult
  $Res call(
      {String? id,
      String? name,
      String? url,
      String? localUrl,
      bool? isForm,
      String? sampleUrl});
}

/// @nodoc
class _$FormAndFileModelCopyWithImpl<$Res, $Val extends FormAndFileModel>
    implements $FormAndFileModelCopyWith<$Res> {
  _$FormAndFileModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? url = freezed,
    Object? localUrl = freezed,
    Object? isForm = freezed,
    Object? sampleUrl = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      url: freezed == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String?,
      localUrl: freezed == localUrl
          ? _value.localUrl
          : localUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      isForm: freezed == isForm
          ? _value.isForm
          : isForm // ignore: cast_nullable_to_non_nullable
              as bool?,
      sampleUrl: freezed == sampleUrl
          ? _value.sampleUrl
          : sampleUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FormAndFileModelImplCopyWith<$Res>
    implements $FormAndFileModelCopyWith<$Res> {
  factory _$$FormAndFileModelImplCopyWith(_$FormAndFileModelImpl value,
          $Res Function(_$FormAndFileModelImpl) then) =
      __$$FormAndFileModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? name,
      String? url,
      String? localUrl,
      bool? isForm,
      String? sampleUrl});
}

/// @nodoc
class __$$FormAndFileModelImplCopyWithImpl<$Res>
    extends _$FormAndFileModelCopyWithImpl<$Res, _$FormAndFileModelImpl>
    implements _$$FormAndFileModelImplCopyWith<$Res> {
  __$$FormAndFileModelImplCopyWithImpl(_$FormAndFileModelImpl _value,
      $Res Function(_$FormAndFileModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? url = freezed,
    Object? localUrl = freezed,
    Object? isForm = freezed,
    Object? sampleUrl = freezed,
  }) {
    return _then(_$FormAndFileModelImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      url: freezed == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String?,
      localUrl: freezed == localUrl
          ? _value.localUrl
          : localUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      isForm: freezed == isForm
          ? _value.isForm
          : isForm // ignore: cast_nullable_to_non_nullable
              as bool?,
      sampleUrl: freezed == sampleUrl
          ? _value.sampleUrl
          : sampleUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$FormAndFileModelImpl implements _FormAndFileModel {
  const _$FormAndFileModelImpl(
      {this.id,
      this.name,
      this.url,
      this.localUrl,
      this.isForm,
      this.sampleUrl});

  factory _$FormAndFileModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$FormAndFileModelImplFromJson(json);

  @override
  final String? id;
  @override
  final String? name;
  @override
  final String? url;
  @override
  final String? localUrl;
  @override
  final bool? isForm;
  @override
  final String? sampleUrl;

  @override
  String toString() {
    return 'FormAndFileModel(id: $id, name: $name, url: $url, localUrl: $localUrl, isForm: $isForm, sampleUrl: $sampleUrl)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FormAndFileModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.url, url) || other.url == url) &&
            (identical(other.localUrl, localUrl) ||
                other.localUrl == localUrl) &&
            (identical(other.isForm, isForm) || other.isForm == isForm) &&
            (identical(other.sampleUrl, sampleUrl) ||
                other.sampleUrl == sampleUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, name, url, localUrl, isForm, sampleUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FormAndFileModelImplCopyWith<_$FormAndFileModelImpl> get copyWith =>
      __$$FormAndFileModelImplCopyWithImpl<_$FormAndFileModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$FormAndFileModelImplToJson(
      this,
    );
  }
}

abstract class _FormAndFileModel implements FormAndFileModel {
  const factory _FormAndFileModel(
      {final String? id,
      final String? name,
      final String? url,
      final String? localUrl,
      final bool? isForm,
      final String? sampleUrl}) = _$FormAndFileModelImpl;

  factory _FormAndFileModel.fromJson(Map<String, dynamic> json) =
      _$FormAndFileModelImpl.fromJson;

  @override
  String? get id;
  @override
  String? get name;
  @override
  String? get url;
  @override
  String? get localUrl;
  @override
  bool? get isForm;
  @override
  String? get sampleUrl;
  @override
  @JsonKey(ignore: true)
  _$$FormAndFileModelImplCopyWith<_$FormAndFileModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
