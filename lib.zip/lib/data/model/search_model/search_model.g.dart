// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SearchModelImpl _$$SearchModelImplFromJson(Map<String, dynamic> json) =>
    _$SearchModelImpl(
      searchId: json['searchId'] as String,
      name: json['name'] as String,
      lowStock: json['lowStock'] ?? '',
      searchType: $enumDecode(_$SearchTypesEnumMap, json['searchType']),
      image: json['image'] as String? ?? '',
      categoryId: json['categoryId'] as String? ?? '',
      categoryName: json['categoryName'] as String? ?? '',
      productStock: json['productStock'] as String? ?? '0',
      numberOfUnits: json['numberOfUnits'] as int? ?? 0,
      priceParUnit: (json['priceParUnit'] as num?)?.toDouble() ?? 0.0,
      priceOfBox: (json['priceOfBox'] as num?)?.toDouble() ?? 0.0,
      isPesach: json['isPesach'] as bool? ?? false,
    );

Map<String, dynamic> _$$SearchModelImplToJson(_$SearchModelImpl instance) =>
    <String, dynamic>{
      'searchId': instance.searchId,
      'name': instance.name,
      'lowStock': instance.lowStock,
      'searchType': _$SearchTypesEnumMap[instance.searchType]!,
      'image': instance.image,
      'categoryId': instance.categoryId,
      'categoryName': instance.categoryName,
      'productStock': instance.productStock,
      'numberOfUnits': instance.numberOfUnits,
      'priceParUnit': instance.priceParUnit,
      'priceOfBox': instance.priceOfBox,
      'isPesach': instance.isPesach,
    };

const _$SearchTypesEnumMap = {
  SearchTypes.category: 'category',
  SearchTypes.subCategory: 'subCategory',
  SearchTypes.company: 'company',
  SearchTypes.supplier: 'supplier',
  SearchTypes.product: 'product',
  SearchTypes.sale: 'sale',
};
