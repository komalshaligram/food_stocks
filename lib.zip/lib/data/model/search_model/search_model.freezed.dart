// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'search_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SearchModel _$SearchModelFromJson(Map<String, dynamic> json) {
  return _SearchModel.fromJson(json);
}

/// @nodoc
mixin _$SearchModel {
  String get searchId => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  dynamic get lowStock => throw _privateConstructorUsedError;
  SearchTypes get searchType => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get categoryId => throw _privateConstructorUsedError;
  String get categoryName => throw _privateConstructorUsedError;
  String get productStock => throw _privateConstructorUsedError;
  int get numberOfUnits => throw _privateConstructorUsedError;
  double get priceParUnit => throw _privateConstructorUsedError;
  double get priceOfBox => throw _privateConstructorUsedError;
  bool get isPesach => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SearchModelCopyWith<SearchModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SearchModelCopyWith<$Res> {
  factory $SearchModelCopyWith(
          SearchModel value, $Res Function(SearchModel) then) =
      _$SearchModelCopyWithImpl<$Res, SearchModel>;
  @useResult
  $Res call(
      {String searchId,
      String name,
      dynamic lowStock,
      SearchTypes searchType,
      String image,
      String categoryId,
      String categoryName,
      String productStock,
      int numberOfUnits,
      double priceParUnit,
      double priceOfBox,
      bool isPesach});
}

/// @nodoc
class _$SearchModelCopyWithImpl<$Res, $Val extends SearchModel>
    implements $SearchModelCopyWith<$Res> {
  _$SearchModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? searchId = null,
    Object? name = null,
    Object? lowStock = freezed,
    Object? searchType = null,
    Object? image = null,
    Object? categoryId = null,
    Object? categoryName = null,
    Object? productStock = null,
    Object? numberOfUnits = null,
    Object? priceParUnit = null,
    Object? priceOfBox = null,
    Object? isPesach = null,
  }) {
    return _then(_value.copyWith(
      searchId: null == searchId
          ? _value.searchId
          : searchId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      lowStock: freezed == lowStock
          ? _value.lowStock
          : lowStock // ignore: cast_nullable_to_non_nullable
              as dynamic,
      searchType: null == searchType
          ? _value.searchType
          : searchType // ignore: cast_nullable_to_non_nullable
              as SearchTypes,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      categoryId: null == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String,
      categoryName: null == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String,
      productStock: null == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String,
      numberOfUnits: null == numberOfUnits
          ? _value.numberOfUnits
          : numberOfUnits // ignore: cast_nullable_to_non_nullable
              as int,
      priceParUnit: null == priceParUnit
          ? _value.priceParUnit
          : priceParUnit // ignore: cast_nullable_to_non_nullable
              as double,
      priceOfBox: null == priceOfBox
          ? _value.priceOfBox
          : priceOfBox // ignore: cast_nullable_to_non_nullable
              as double,
      isPesach: null == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SearchModelImplCopyWith<$Res>
    implements $SearchModelCopyWith<$Res> {
  factory _$$SearchModelImplCopyWith(
          _$SearchModelImpl value, $Res Function(_$SearchModelImpl) then) =
      __$$SearchModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String searchId,
      String name,
      dynamic lowStock,
      SearchTypes searchType,
      String image,
      String categoryId,
      String categoryName,
      String productStock,
      int numberOfUnits,
      double priceParUnit,
      double priceOfBox,
      bool isPesach});
}

/// @nodoc
class __$$SearchModelImplCopyWithImpl<$Res>
    extends _$SearchModelCopyWithImpl<$Res, _$SearchModelImpl>
    implements _$$SearchModelImplCopyWith<$Res> {
  __$$SearchModelImplCopyWithImpl(
      _$SearchModelImpl _value, $Res Function(_$SearchModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? searchId = null,
    Object? name = null,
    Object? lowStock = freezed,
    Object? searchType = null,
    Object? image = null,
    Object? categoryId = null,
    Object? categoryName = null,
    Object? productStock = null,
    Object? numberOfUnits = null,
    Object? priceParUnit = null,
    Object? priceOfBox = null,
    Object? isPesach = null,
  }) {
    return _then(_$SearchModelImpl(
      searchId: null == searchId
          ? _value.searchId
          : searchId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      lowStock: freezed == lowStock ? _value.lowStock! : lowStock,
      searchType: null == searchType
          ? _value.searchType
          : searchType // ignore: cast_nullable_to_non_nullable
              as SearchTypes,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      categoryId: null == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String,
      categoryName: null == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String,
      productStock: null == productStock
          ? _value.productStock
          : productStock // ignore: cast_nullable_to_non_nullable
              as String,
      numberOfUnits: null == numberOfUnits
          ? _value.numberOfUnits
          : numberOfUnits // ignore: cast_nullable_to_non_nullable
              as int,
      priceParUnit: null == priceParUnit
          ? _value.priceParUnit
          : priceParUnit // ignore: cast_nullable_to_non_nullable
              as double,
      priceOfBox: null == priceOfBox
          ? _value.priceOfBox
          : priceOfBox // ignore: cast_nullable_to_non_nullable
              as double,
      isPesach: null == isPesach
          ? _value.isPesach
          : isPesach // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SearchModelImpl implements _SearchModel {
  const _$SearchModelImpl(
      {required this.searchId,
      required this.name,
      this.lowStock = '',
      required this.searchType,
      this.image = '',
      this.categoryId = '',
      this.categoryName = '',
      this.productStock = '0',
      this.numberOfUnits = 0,
      this.priceParUnit = 0.0,
      this.priceOfBox = 0.0,
      this.isPesach = false});

  factory _$SearchModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SearchModelImplFromJson(json);

  @override
  final String searchId;
  @override
  final String name;
  @override
  @JsonKey()
  final dynamic lowStock;
  @override
  final SearchTypes searchType;
  @override
  @JsonKey()
  final String image;
  @override
  @JsonKey()
  final String categoryId;
  @override
  @JsonKey()
  final String categoryName;
  @override
  @JsonKey()
  final String productStock;
  @override
  @JsonKey()
  final int numberOfUnits;
  @override
  @JsonKey()
  final double priceParUnit;
  @override
  @JsonKey()
  final double priceOfBox;
  @override
  @JsonKey()
  final bool isPesach;

  @override
  String toString() {
    return 'SearchModel(searchId: $searchId, name: $name, lowStock: $lowStock, searchType: $searchType, image: $image, categoryId: $categoryId, categoryName: $categoryName, productStock: $productStock, numberOfUnits: $numberOfUnits, priceParUnit: $priceParUnit, priceOfBox: $priceOfBox, isPesach: $isPesach)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SearchModelImpl &&
            (identical(other.searchId, searchId) ||
                other.searchId == searchId) &&
            (identical(other.name, name) || other.name == name) &&
            const DeepCollectionEquality().equals(other.lowStock, lowStock) &&
            (identical(other.searchType, searchType) ||
                other.searchType == searchType) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.categoryId, categoryId) ||
                other.categoryId == categoryId) &&
            (identical(other.categoryName, categoryName) ||
                other.categoryName == categoryName) &&
            (identical(other.productStock, productStock) ||
                other.productStock == productStock) &&
            (identical(other.numberOfUnits, numberOfUnits) ||
                other.numberOfUnits == numberOfUnits) &&
            (identical(other.priceParUnit, priceParUnit) ||
                other.priceParUnit == priceParUnit) &&
            (identical(other.priceOfBox, priceOfBox) ||
                other.priceOfBox == priceOfBox) &&
            (identical(other.isPesach, isPesach) ||
                other.isPesach == isPesach));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      searchId,
      name,
      const DeepCollectionEquality().hash(lowStock),
      searchType,
      image,
      categoryId,
      categoryName,
      productStock,
      numberOfUnits,
      priceParUnit,
      priceOfBox,
      isPesach);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SearchModelImplCopyWith<_$SearchModelImpl> get copyWith =>
      __$$SearchModelImplCopyWithImpl<_$SearchModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SearchModelImplToJson(
      this,
    );
  }
}

abstract class _SearchModel implements SearchModel {
  const factory _SearchModel(
      {required final String searchId,
      required final String name,
      final dynamic lowStock,
      required final SearchTypes searchType,
      final String image,
      final String categoryId,
      final String categoryName,
      final String productStock,
      final int numberOfUnits,
      final double priceParUnit,
      final double priceOfBox,
      final bool isPesach}) = _$SearchModelImpl;

  factory _SearchModel.fromJson(Map<String, dynamic> json) =
      _$SearchModelImpl.fromJson;

  @override
  String get searchId;
  @override
  String get name;
  @override
  dynamic get lowStock;
  @override
  SearchTypes get searchType;
  @override
  String get image;
  @override
  String get categoryId;
  @override
  String get categoryName;
  @override
  String get productStock;
  @override
  int get numberOfUnits;
  @override
  double get priceParUnit;
  @override
  double get priceOfBox;
  @override
  bool get isPesach;
  @override
  @JsonKey(ignore: true)
  _$$SearchModelImplCopyWith<_$SearchModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
