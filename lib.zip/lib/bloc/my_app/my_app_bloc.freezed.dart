// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'my_app_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MyAppState {}

/// @nodoc
abstract class $MyAppStateCopyWith<$Res> {
  factory $MyAppStateCopyWith(
          MyAppState value, $Res Function(MyAppState) then) =
      _$MyAppStateCopyWithImpl<$Res, MyAppState>;
}

/// @nodoc
class _$MyAppStateCopyWithImpl<$Res, $Val extends MyAppState>
    implements $MyAppStateCopyWith<$Res> {
  _$MyAppStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$MyAppStateImplCopyWith<$Res> {
  factory _$$MyAppStateImplCopyWith(
          _$MyAppStateImpl value, $Res Function(_$MyAppStateImpl) then) =
      __$$MyAppStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$MyAppStateImplCopyWithImpl<$Res>
    extends _$MyAppStateCopyWithImpl<$Res, _$MyAppStateImpl>
    implements _$$MyAppStateImplCopyWith<$Res> {
  __$$MyAppStateImplCopyWithImpl(
      _$MyAppStateImpl _value, $Res Function(_$MyAppStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$MyAppStateImpl implements _MyAppState {
  const _$MyAppStateImpl();

  @override
  String toString() {
    return 'MyAppState()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$MyAppStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;
}

abstract class _MyAppState implements MyAppState {
  const factory _MyAppState() = _$MyAppStateImpl;
}

/// @nodoc
mixin _$MyAppEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MyAppEventCopyWith<MyAppEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MyAppEventCopyWith<$Res> {
  factory $MyAppEventCopyWith(
          MyAppEvent value, $Res Function(MyAppEvent) then) =
      _$MyAppEventCopyWithImpl<$Res, MyAppEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$MyAppEventCopyWithImpl<$Res, $Val extends MyAppEvent>
    implements $MyAppEventCopyWith<$Res> {
  _$MyAppEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$updateProfileDetailsEventImplCopyWith<$Res>
    implements $MyAppEventCopyWith<$Res> {
  factory _$$updateProfileDetailsEventImplCopyWith(
          _$updateProfileDetailsEventImpl value,
          $Res Function(_$updateProfileDetailsEventImpl) then) =
      __$$updateProfileDetailsEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$updateProfileDetailsEventImplCopyWithImpl<$Res>
    extends _$MyAppEventCopyWithImpl<$Res, _$updateProfileDetailsEventImpl>
    implements _$$updateProfileDetailsEventImplCopyWith<$Res> {
  __$$updateProfileDetailsEventImplCopyWithImpl(
      _$updateProfileDetailsEventImpl _value,
      $Res Function(_$updateProfileDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$updateProfileDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$updateProfileDetailsEventImpl implements _updateProfileDetailsEvent {
  _$updateProfileDetailsEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MyAppEvent.updateProfileDetailsEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateProfileDetailsEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateProfileDetailsEventImplCopyWith<_$updateProfileDetailsEventImpl>
      get copyWith => __$$updateProfileDetailsEventImplCopyWithImpl<
          _$updateProfileDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
  }) {
    return updateProfileDetailsEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
  }) {
    return updateProfileDetailsEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    required TResult orElse(),
  }) {
    if (updateProfileDetailsEvent != null) {
      return updateProfileDetailsEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
  }) {
    return updateProfileDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
  }) {
    return updateProfileDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    required TResult orElse(),
  }) {
    if (updateProfileDetailsEvent != null) {
      return updateProfileDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _updateProfileDetailsEvent implements MyAppEvent {
  factory _updateProfileDetailsEvent({required final BuildContext context}) =
      _$updateProfileDetailsEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$updateProfileDetailsEventImplCopyWith<_$updateProfileDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}
