// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'home_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$HomeEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeEventCopyWith<$Res> {
  factory $HomeEventCopyWith(HomeEvent value, $Res Function(HomeEvent) then) =
      _$HomeEventCopyWithImpl<$Res, HomeEvent>;
}

/// @nodoc
class _$HomeEventCopyWithImpl<$Res, $Val extends HomeEvent>
    implements $HomeEventCopyWith<$Res> {
  _$HomeEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getPreferencesDataEventImplCopyWith<$Res> {
  factory _$$getPreferencesDataEventImplCopyWith(
          _$getPreferencesDataEventImpl value,
          $Res Function(_$getPreferencesDataEventImpl) then) =
      __$$getPreferencesDataEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getPreferencesDataEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$getPreferencesDataEventImpl>
    implements _$$getPreferencesDataEventImplCopyWith<$Res> {
  __$$getPreferencesDataEventImplCopyWithImpl(
      _$getPreferencesDataEventImpl _value,
      $Res Function(_$getPreferencesDataEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getPreferencesDataEventImpl implements _getPreferencesDataEvent {
  const _$getPreferencesDataEventImpl();

  @override
  String toString() {
    return 'HomeEvent.getPreferencesDataEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPreferencesDataEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPreferencesDataEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPreferencesDataEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPreferencesDataEvent != null) {
      return getPreferencesDataEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPreferencesDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPreferencesDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPreferencesDataEvent != null) {
      return getPreferencesDataEvent(this);
    }
    return orElse();
  }
}

abstract class _getPreferencesDataEvent implements HomeEvent {
  const factory _getPreferencesDataEvent() = _$getPreferencesDataEventImpl;
}

/// @nodoc
abstract class _$$GetProductSalesListEventImplCopyWith<$Res> {
  factory _$$GetProductSalesListEventImplCopyWith(
          _$GetProductSalesListEventImpl value,
          $Res Function(_$GetProductSalesListEventImpl) then) =
      __$$GetProductSalesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductSalesListEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$GetProductSalesListEventImpl>
    implements _$$GetProductSalesListEventImplCopyWith<$Res> {
  __$$GetProductSalesListEventImplCopyWithImpl(
      _$GetProductSalesListEventImpl _value,
      $Res Function(_$GetProductSalesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductSalesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductSalesListEventImpl implements _GetProductSalesListEvent {
  const _$GetProductSalesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getProductSalesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductSalesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductSalesListEventImplCopyWith<_$GetProductSalesListEventImpl>
      get copyWith => __$$GetProductSalesListEventImplCopyWithImpl<
          _$GetProductSalesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductSalesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductSalesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductSalesListEvent != null) {
      return getProductSalesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductSalesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductSalesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductSalesListEvent != null) {
      return getProductSalesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductSalesListEvent implements HomeEvent {
  const factory _GetProductSalesListEvent(
      {required final BuildContext context}) = _$GetProductSalesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductSalesListEventImplCopyWith<_$GetProductSalesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductDetailsEventImplCopyWith<$Res> {
  factory _$$GetProductDetailsEventImplCopyWith(
          _$GetProductDetailsEventImpl value,
          $Res Function(_$GetProductDetailsEventImpl) then) =
      __$$GetProductDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      bool isBarcode,
      String productId,
      int productListIndex});
}

/// @nodoc
class __$$GetProductDetailsEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$GetProductDetailsEventImpl>
    implements _$$GetProductDetailsEventImplCopyWith<$Res> {
  __$$GetProductDetailsEventImplCopyWithImpl(
      _$GetProductDetailsEventImpl _value,
      $Res Function(_$GetProductDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isBarcode = null,
    Object? productId = null,
    Object? productListIndex = null,
  }) {
    return _then(_$GetProductDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$GetProductDetailsEventImpl implements _GetProductDetailsEvent {
  const _$GetProductDetailsEventImpl(
      {required this.context,
      required this.isBarcode,
      required this.productId,
      required this.productListIndex});

  @override
  final BuildContext context;
  @override
  final bool isBarcode;
  @override
  final String productId;
  @override
  final int productListIndex;

  @override
  String toString() {
    return 'HomeEvent.getProductDetailsEvent(context: $context, isBarcode: $isBarcode, productId: $productId, productListIndex: $productListIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.productListIndex, productListIndex) ||
                other.productListIndex == productListIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, isBarcode, productId, productListIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => __$$GetProductDetailsEventImplCopyWithImpl<
          _$GetProductDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductDetailsEvent(
        context, isBarcode, productId, productListIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(
        context, isBarcode, productId, productListIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(
          context, isBarcode, productId, productListIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductDetailsEvent implements HomeEvent {
  const factory _GetProductDetailsEvent(
      {required final BuildContext context,
      required final bool isBarcode,
      required final String productId,
      required final int productListIndex}) = _$GetProductDetailsEventImpl;

  BuildContext get context;
  bool get isBarcode;
  String get productId;
  int get productListIndex;
  @JsonKey(ignore: true)
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$IncreaseQuantityOfProductImplCopyWith(
          _$IncreaseQuantityOfProductImpl value,
          $Res Function(_$IncreaseQuantityOfProductImpl) then) =
      __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$IncreaseQuantityOfProductImpl>
    implements _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  __$$IncreaseQuantityOfProductImplCopyWithImpl(
      _$IncreaseQuantityOfProductImpl _value,
      $Res Function(_$IncreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$IncreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$IncreaseQuantityOfProductImpl implements _IncreaseQuantityOfProduct {
  const _$IncreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.increaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => __$$IncreaseQuantityOfProductImplCopyWithImpl<
          _$IncreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return increaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return increaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _IncreaseQuantityOfProduct implements HomeEvent {
  const factory _IncreaseQuantityOfProduct(
      {required final BuildContext context}) = _$IncreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GeneralSettingsImplCopyWith<$Res> {
  factory _$$GeneralSettingsImplCopyWith(_$GeneralSettingsImpl value,
          $Res Function(_$GeneralSettingsImpl) then) =
      __$$GeneralSettingsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GeneralSettingsImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$GeneralSettingsImpl>
    implements _$$GeneralSettingsImplCopyWith<$Res> {
  __$$GeneralSettingsImplCopyWithImpl(
      _$GeneralSettingsImpl _value, $Res Function(_$GeneralSettingsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GeneralSettingsImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GeneralSettingsImpl implements _GeneralSettings {
  const _$GeneralSettingsImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.generalSettings(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GeneralSettingsImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GeneralSettingsImplCopyWith<_$GeneralSettingsImpl> get copyWith =>
      __$$GeneralSettingsImplCopyWithImpl<_$GeneralSettingsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return generalSettings(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return generalSettings?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (generalSettings != null) {
      return generalSettings(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return generalSettings(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return generalSettings?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (generalSettings != null) {
      return generalSettings(this);
    }
    return orElse();
  }
}

abstract class _GeneralSettings implements HomeEvent {
  const factory _GeneralSettings({required final BuildContext context}) =
      _$GeneralSettingsImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GeneralSettingsImplCopyWith<_$GeneralSettingsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$DecreaseQuantityOfProductImplCopyWith(
          _$DecreaseQuantityOfProductImpl value,
          $Res Function(_$DecreaseQuantityOfProductImpl) then) =
      __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$DecreaseQuantityOfProductImpl>
    implements _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  __$$DecreaseQuantityOfProductImplCopyWithImpl(
      _$DecreaseQuantityOfProductImpl _value,
      $Res Function(_$DecreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DecreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DecreaseQuantityOfProductImpl implements _DecreaseQuantityOfProduct {
  const _$DecreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.decreaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DecreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => __$$DecreaseQuantityOfProductImplCopyWithImpl<
          _$DecreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _DecreaseQuantityOfProduct implements HomeEvent {
  const factory _DecreaseQuantityOfProduct(
      {required final BuildContext context}) = _$DecreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  factory _$$UpdateQuantityOfProductImplCopyWith(
          _$UpdateQuantityOfProductImpl value,
          $Res Function(_$UpdateQuantityOfProductImpl) then) =
      __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String quantity});
}

/// @nodoc
class __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$UpdateQuantityOfProductImpl>
    implements _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  __$$UpdateQuantityOfProductImplCopyWithImpl(
      _$UpdateQuantityOfProductImpl _value,
      $Res Function(_$UpdateQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? quantity = null,
  }) {
    return _then(_$UpdateQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UpdateQuantityOfProductImpl implements _UpdateQuantityOfProduct {
  const _$UpdateQuantityOfProductImpl(
      {required this.context, required this.quantity});

  @override
  final BuildContext context;
  @override
  final String quantity;

  @override
  String toString() {
    return 'HomeEvent.updateQuantityOfProduct(context: $context, quantity: $quantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, quantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => __$$UpdateQuantityOfProductImplCopyWithImpl<
          _$UpdateQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateQuantityOfProduct(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(context, quantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _UpdateQuantityOfProduct implements HomeEvent {
  const factory _UpdateQuantityOfProduct(
      {required final BuildContext context,
      required final String quantity}) = _$UpdateQuantityOfProductImpl;

  BuildContext get context;
  String get quantity;
  @JsonKey(ignore: true)
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeNoteOfProductImplCopyWith<$Res> {
  factory _$$ChangeNoteOfProductImplCopyWith(_$ChangeNoteOfProductImpl value,
          $Res Function(_$ChangeNoteOfProductImpl) then) =
      __$$ChangeNoteOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String newNote});
}

/// @nodoc
class __$$ChangeNoteOfProductImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$ChangeNoteOfProductImpl>
    implements _$$ChangeNoteOfProductImplCopyWith<$Res> {
  __$$ChangeNoteOfProductImplCopyWithImpl(_$ChangeNoteOfProductImpl _value,
      $Res Function(_$ChangeNoteOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newNote = null,
  }) {
    return _then(_$ChangeNoteOfProductImpl(
      newNote: null == newNote
          ? _value.newNote
          : newNote // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeNoteOfProductImpl implements _ChangeNoteOfProduct {
  const _$ChangeNoteOfProductImpl({required this.newNote});

  @override
  final String newNote;

  @override
  String toString() {
    return 'HomeEvent.changeNoteOfProduct(newNote: $newNote)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeNoteOfProductImpl &&
            (identical(other.newNote, newNote) || other.newNote == newNote));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newNote);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      __$$ChangeNoteOfProductImplCopyWithImpl<_$ChangeNoteOfProductImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeNoteOfProduct(newNote);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(newNote);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(newNote);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeNoteOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(this);
    }
    return orElse();
  }
}

abstract class _ChangeNoteOfProduct implements HomeEvent {
  const factory _ChangeNoteOfProduct({required final String newNote}) =
      _$ChangeNoteOfProductImpl;

  String get newNote;
  @JsonKey(ignore: true)
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  factory _$$ChangeSupplierSelectionExpansionEventImplCopyWith(
          _$ChangeSupplierSelectionExpansionEventImpl value,
          $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) then) =
      __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isSelectSupplier});
}

/// @nodoc
class __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res,
        _$ChangeSupplierSelectionExpansionEventImpl>
    implements _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl(
      _$ChangeSupplierSelectionExpansionEventImpl _value,
      $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSelectSupplier = freezed,
  }) {
    return _then(_$ChangeSupplierSelectionExpansionEventImpl(
      isSelectSupplier: freezed == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeSupplierSelectionExpansionEventImpl
    implements _ChangeSupplierSelectionExpansionEvent {
  const _$ChangeSupplierSelectionExpansionEventImpl({this.isSelectSupplier});

  @override
  final bool? isSelectSupplier;

  @override
  String toString() {
    return 'HomeEvent.changeSupplierSelectionExpansionEvent(isSelectSupplier: $isSelectSupplier)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSupplierSelectionExpansionEventImpl &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSelectSupplier);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<
          _$ChangeSupplierSelectionExpansionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(isSelectSupplier);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSupplierSelectionExpansionEvent implements HomeEvent {
  const factory _ChangeSupplierSelectionExpansionEvent(
          {final bool? isSelectSupplier}) =
      _$ChangeSupplierSelectionExpansionEventImpl;

  bool? get isSelectSupplier;
  @JsonKey(ignore: true)
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SupplierSelectionEventImplCopyWith<$Res> {
  factory _$$SupplierSelectionEventImplCopyWith(
          _$SupplierSelectionEventImpl value,
          $Res Function(_$SupplierSelectionEventImpl) then) =
      __$$SupplierSelectionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int supplierIndex, BuildContext context, int supplierSaleIndex});
}

/// @nodoc
class __$$SupplierSelectionEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$SupplierSelectionEventImpl>
    implements _$$SupplierSelectionEventImplCopyWith<$Res> {
  __$$SupplierSelectionEventImplCopyWithImpl(
      _$SupplierSelectionEventImpl _value,
      $Res Function(_$SupplierSelectionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierIndex = null,
    Object? context = null,
    Object? supplierSaleIndex = null,
  }) {
    return _then(_$SupplierSelectionEventImpl(
      supplierIndex: null == supplierIndex
          ? _value.supplierIndex
          : supplierIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierSaleIndex: null == supplierSaleIndex
          ? _value.supplierSaleIndex
          : supplierSaleIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SupplierSelectionEventImpl implements _SupplierSelectionEvent {
  const _$SupplierSelectionEventImpl(
      {required this.supplierIndex,
      required this.context,
      required this.supplierSaleIndex});

  @override
  final int supplierIndex;
  @override
  final BuildContext context;
  @override
  final int supplierSaleIndex;

  @override
  String toString() {
    return 'HomeEvent.supplierSelectionEvent(supplierIndex: $supplierIndex, context: $context, supplierSaleIndex: $supplierSaleIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSelectionEventImpl &&
            (identical(other.supplierIndex, supplierIndex) ||
                other.supplierIndex == supplierIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierSaleIndex, supplierSaleIndex) ||
                other.supplierSaleIndex == supplierSaleIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, supplierIndex, context, supplierSaleIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => __$$SupplierSelectionEventImplCopyWithImpl<
          _$SupplierSelectionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(
        supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return supplierSelectionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(this);
    }
    return orElse();
  }
}

abstract class _SupplierSelectionEvent implements HomeEvent {
  const factory _SupplierSelectionEvent(
      {required final int supplierIndex,
      required final BuildContext context,
      required final int supplierSaleIndex}) = _$SupplierSelectionEventImpl;

  int get supplierIndex;
  BuildContext get context;
  int get supplierSaleIndex;
  @JsonKey(ignore: true)
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddToCartProductEventImplCopyWith<$Res> {
  factory _$$AddToCartProductEventImplCopyWith(
          _$AddToCartProductEventImpl value,
          $Res Function(_$AddToCartProductEventImpl) then) =
      __$$AddToCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$AddToCartProductEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$AddToCartProductEventImpl>
    implements _$$AddToCartProductEventImplCopyWith<$Res> {
  __$$AddToCartProductEventImplCopyWithImpl(_$AddToCartProductEventImpl _value,
      $Res Function(_$AddToCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$AddToCartProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AddToCartProductEventImpl implements _AddToCartProductEvent {
  const _$AddToCartProductEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'HomeEvent.addToCartProductEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddToCartProductEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => __$$AddToCartProductEventImplCopyWithImpl<
          _$AddToCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return addToCartProductEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return addToCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _AddToCartProductEvent implements HomeEvent {
  const factory _AddToCartProductEvent(
      {required final BuildContext context,
      required final String productId}) = _$AddToCartProductEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetCartCountEventImplCopyWith<$Res> {
  factory _$$SetCartCountEventImplCopyWith(_$SetCartCountEventImpl value,
          $Res Function(_$SetCartCountEventImpl) then) =
      __$$SetCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SetCartCountEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$SetCartCountEventImpl>
    implements _$$SetCartCountEventImplCopyWith<$Res> {
  __$$SetCartCountEventImplCopyWithImpl(_$SetCartCountEventImpl _value,
      $Res Function(_$SetCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SetCartCountEventImpl implements _SetCartCountEvent {
  const _$SetCartCountEventImpl();

  @override
  String toString() {
    return 'HomeEvent.setCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SetCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return setCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return setCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return setCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return setCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetCartCountEvent implements HomeEvent {
  const factory _SetCartCountEvent() = _$SetCartCountEventImpl;
}

/// @nodoc
abstract class _$$SetMessageCountEventImplCopyWith<$Res> {
  factory _$$SetMessageCountEventImplCopyWith(_$SetMessageCountEventImpl value,
          $Res Function(_$SetMessageCountEventImpl) then) =
      __$$SetMessageCountEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int messageCount});
}

/// @nodoc
class __$$SetMessageCountEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$SetMessageCountEventImpl>
    implements _$$SetMessageCountEventImplCopyWith<$Res> {
  __$$SetMessageCountEventImplCopyWithImpl(_$SetMessageCountEventImpl _value,
      $Res Function(_$SetMessageCountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageCount = null,
  }) {
    return _then(_$SetMessageCountEventImpl(
      messageCount: null == messageCount
          ? _value.messageCount
          : messageCount // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SetMessageCountEventImpl implements _SetMessageCountEvent {
  const _$SetMessageCountEventImpl({required this.messageCount});

  @override
  final int messageCount;

  @override
  String toString() {
    return 'HomeEvent.setMessageCountEvent(messageCount: $messageCount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SetMessageCountEventImpl &&
            (identical(other.messageCount, messageCount) ||
                other.messageCount == messageCount));
  }

  @override
  int get hashCode => Object.hash(runtimeType, messageCount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SetMessageCountEventImplCopyWith<_$SetMessageCountEventImpl>
      get copyWith =>
          __$$SetMessageCountEventImplCopyWithImpl<_$SetMessageCountEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return setMessageCountEvent(messageCount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return setMessageCountEvent?.call(messageCount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setMessageCountEvent != null) {
      return setMessageCountEvent(messageCount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return setMessageCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return setMessageCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setMessageCountEvent != null) {
      return setMessageCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetMessageCountEvent implements HomeEvent {
  const factory _SetMessageCountEvent({required final int messageCount}) =
      _$SetMessageCountEventImpl;

  int get messageCount;
  @JsonKey(ignore: true)
  _$$SetMessageCountEventImplCopyWith<_$SetMessageCountEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getWalletRecordEventImplCopyWith<$Res> {
  factory _$$getWalletRecordEventImplCopyWith(_$getWalletRecordEventImpl value,
          $Res Function(_$getWalletRecordEventImpl) then) =
      __$$getWalletRecordEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getWalletRecordEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$getWalletRecordEventImpl>
    implements _$$getWalletRecordEventImplCopyWith<$Res> {
  __$$getWalletRecordEventImplCopyWithImpl(_$getWalletRecordEventImpl _value,
      $Res Function(_$getWalletRecordEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getWalletRecordEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getWalletRecordEventImpl implements _getWalletRecordEvent {
  const _$getWalletRecordEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getWalletRecordEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getWalletRecordEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getWalletRecordEventImplCopyWith<_$getWalletRecordEventImpl>
      get copyWith =>
          __$$getWalletRecordEventImplCopyWithImpl<_$getWalletRecordEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getWalletRecordEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getWalletRecordEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getWalletRecordEvent != null) {
      return getWalletRecordEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getWalletRecordEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getWalletRecordEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getWalletRecordEvent != null) {
      return getWalletRecordEvent(this);
    }
    return orElse();
  }
}

abstract class _getWalletRecordEvent implements HomeEvent {
  const factory _getWalletRecordEvent({required final BuildContext context}) =
      _$getWalletRecordEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getWalletRecordEventImplCopyWith<_$getWalletRecordEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getOrderCountEventImplCopyWith<$Res> {
  factory _$$getOrderCountEventImplCopyWith(_$getOrderCountEventImpl value,
          $Res Function(_$getOrderCountEventImpl) then) =
      __$$getOrderCountEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getOrderCountEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$getOrderCountEventImpl>
    implements _$$getOrderCountEventImplCopyWith<$Res> {
  __$$getOrderCountEventImplCopyWithImpl(_$getOrderCountEventImpl _value,
      $Res Function(_$getOrderCountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getOrderCountEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getOrderCountEventImpl implements _getOrderCountEvent {
  const _$getOrderCountEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getOrderCountEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getOrderCountEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getOrderCountEventImplCopyWith<_$getOrderCountEventImpl> get copyWith =>
      __$$getOrderCountEventImplCopyWithImpl<_$getOrderCountEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getOrderCountEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getOrderCountEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getOrderCountEvent != null) {
      return getOrderCountEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getOrderCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getOrderCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getOrderCountEvent != null) {
      return getOrderCountEvent(this);
    }
    return orElse();
  }
}

abstract class _getOrderCountEvent implements HomeEvent {
  const factory _getOrderCountEvent({required final BuildContext context}) =
      _$getOrderCountEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getOrderCountEventImplCopyWith<_$getOrderCountEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetMessageListEventImplCopyWith<$Res> {
  factory _$$GetMessageListEventImplCopyWith(_$GetMessageListEventImpl value,
          $Res Function(_$GetMessageListEventImpl) then) =
      __$$GetMessageListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetMessageListEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$GetMessageListEventImpl>
    implements _$$GetMessageListEventImplCopyWith<$Res> {
  __$$GetMessageListEventImplCopyWithImpl(_$GetMessageListEventImpl _value,
      $Res Function(_$GetMessageListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetMessageListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetMessageListEventImpl implements _GetMessageListEvent {
  const _$GetMessageListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getMessageListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetMessageListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetMessageListEventImplCopyWith<_$GetMessageListEventImpl> get copyWith =>
      __$$GetMessageListEventImplCopyWithImpl<_$GetMessageListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getMessageListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getMessageListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getMessageListEvent != null) {
      return getMessageListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getMessageListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getMessageListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getMessageListEvent != null) {
      return getMessageListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetMessageListEvent implements HomeEvent {
  const factory _GetMessageListEvent({required final BuildContext context}) =
      _$GetMessageListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetMessageListEventImplCopyWith<_$GetMessageListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetCartCountEventImplCopyWith<$Res> {
  factory _$$GetCartCountEventImplCopyWith(_$GetCartCountEventImpl value,
          $Res Function(_$GetCartCountEventImpl) then) =
      __$$GetCartCountEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetCartCountEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$GetCartCountEventImpl>
    implements _$$GetCartCountEventImplCopyWith<$Res> {
  __$$GetCartCountEventImplCopyWithImpl(_$GetCartCountEventImpl _value,
      $Res Function(_$GetCartCountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetCartCountEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetCartCountEventImpl implements _GetCartCountEvent {
  const _$GetCartCountEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getCartCountEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetCartCountEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetCartCountEventImplCopyWith<_$GetCartCountEventImpl> get copyWith =>
      __$$GetCartCountEventImplCopyWithImpl<_$GetCartCountEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getCartCountEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getCartCountEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _GetCartCountEvent implements HomeEvent {
  const factory _GetCartCountEvent({required final BuildContext context}) =
      _$GetCartCountEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetCartCountEventImplCopyWith<_$GetCartCountEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveOrUpdateMessageEventImplCopyWith<$Res> {
  factory _$$RemoveOrUpdateMessageEventImplCopyWith(
          _$RemoveOrUpdateMessageEventImpl value,
          $Res Function(_$RemoveOrUpdateMessageEventImpl) then) =
      __$$RemoveOrUpdateMessageEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String messageId, bool isRead, bool isDelete});
}

/// @nodoc
class __$$RemoveOrUpdateMessageEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$RemoveOrUpdateMessageEventImpl>
    implements _$$RemoveOrUpdateMessageEventImplCopyWith<$Res> {
  __$$RemoveOrUpdateMessageEventImplCopyWithImpl(
      _$RemoveOrUpdateMessageEventImpl _value,
      $Res Function(_$RemoveOrUpdateMessageEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageId = null,
    Object? isRead = null,
    Object? isDelete = null,
  }) {
    return _then(_$RemoveOrUpdateMessageEventImpl(
      messageId: null == messageId
          ? _value.messageId
          : messageId // ignore: cast_nullable_to_non_nullable
              as String,
      isRead: null == isRead
          ? _value.isRead
          : isRead // ignore: cast_nullable_to_non_nullable
              as bool,
      isDelete: null == isDelete
          ? _value.isDelete
          : isDelete // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$RemoveOrUpdateMessageEventImpl implements _RemoveOrUpdateMessageEvent {
  const _$RemoveOrUpdateMessageEventImpl(
      {required this.messageId, required this.isRead, required this.isDelete});

  @override
  final String messageId;
  @override
  final bool isRead;
  @override
  final bool isDelete;

  @override
  String toString() {
    return 'HomeEvent.removeOrUpdateMessageEvent(messageId: $messageId, isRead: $isRead, isDelete: $isDelete)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveOrUpdateMessageEventImpl &&
            (identical(other.messageId, messageId) ||
                other.messageId == messageId) &&
            (identical(other.isRead, isRead) || other.isRead == isRead) &&
            (identical(other.isDelete, isDelete) ||
                other.isDelete == isDelete));
  }

  @override
  int get hashCode => Object.hash(runtimeType, messageId, isRead, isDelete);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RemoveOrUpdateMessageEventImplCopyWith<_$RemoveOrUpdateMessageEventImpl>
      get copyWith => __$$RemoveOrUpdateMessageEventImplCopyWithImpl<
          _$RemoveOrUpdateMessageEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return removeOrUpdateMessageEvent(messageId, isRead, isDelete);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return removeOrUpdateMessageEvent?.call(messageId, isRead, isDelete);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (removeOrUpdateMessageEvent != null) {
      return removeOrUpdateMessageEvent(messageId, isRead, isDelete);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return removeOrUpdateMessageEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return removeOrUpdateMessageEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (removeOrUpdateMessageEvent != null) {
      return removeOrUpdateMessageEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveOrUpdateMessageEvent implements HomeEvent {
  const factory _RemoveOrUpdateMessageEvent(
      {required final String messageId,
      required final bool isRead,
      required final bool isDelete}) = _$RemoveOrUpdateMessageEventImpl;

  String get messageId;
  bool get isRead;
  bool get isDelete;
  @JsonKey(ignore: true)
  _$$RemoveOrUpdateMessageEventImplCopyWith<_$RemoveOrUpdateMessageEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateImageIndexEventImplCopyWith<$Res> {
  factory _$$UpdateImageIndexEventImplCopyWith(
          _$UpdateImageIndexEventImpl value,
          $Res Function(_$UpdateImageIndexEventImpl) then) =
      __$$UpdateImageIndexEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$UpdateImageIndexEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$UpdateImageIndexEventImpl>
    implements _$$UpdateImageIndexEventImplCopyWith<$Res> {
  __$$UpdateImageIndexEventImplCopyWithImpl(_$UpdateImageIndexEventImpl _value,
      $Res Function(_$UpdateImageIndexEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$UpdateImageIndexEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$UpdateImageIndexEventImpl implements _UpdateImageIndexEvent {
  const _$UpdateImageIndexEventImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'HomeEvent.updateImageIndexEvent(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateImageIndexEventImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => __$$UpdateImageIndexEventImplCopyWithImpl<
          _$UpdateImageIndexEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateImageIndexEvent(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateImageIndexEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateImageIndexEvent implements HomeEvent {
  const factory _UpdateImageIndexEvent({required final int index}) =
      _$UpdateImageIndexEventImpl;

  int get index;
  @JsonKey(ignore: true)
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateMessageListEventImplCopyWith<$Res> {
  factory _$$UpdateMessageListEventImplCopyWith(
          _$UpdateMessageListEventImpl value,
          $Res Function(_$UpdateMessageListEventImpl) then) =
      __$$UpdateMessageListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({List<String> messageIdList});
}

/// @nodoc
class __$$UpdateMessageListEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$UpdateMessageListEventImpl>
    implements _$$UpdateMessageListEventImplCopyWith<$Res> {
  __$$UpdateMessageListEventImplCopyWithImpl(
      _$UpdateMessageListEventImpl _value,
      $Res Function(_$UpdateMessageListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageIdList = null,
  }) {
    return _then(_$UpdateMessageListEventImpl(
      messageIdList: null == messageIdList
          ? _value._messageIdList
          : messageIdList // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ));
  }
}

/// @nodoc

class _$UpdateMessageListEventImpl implements _UpdateMessageListEvent {
  const _$UpdateMessageListEventImpl(
      {required final List<String> messageIdList})
      : _messageIdList = messageIdList;

  final List<String> _messageIdList;
  @override
  List<String> get messageIdList {
    if (_messageIdList is EqualUnmodifiableListView) return _messageIdList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_messageIdList);
  }

  @override
  String toString() {
    return 'HomeEvent.updateMessageListEvent(messageIdList: $messageIdList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateMessageListEventImpl &&
            const DeepCollectionEquality()
                .equals(other._messageIdList, _messageIdList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_messageIdList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateMessageListEventImplCopyWith<_$UpdateMessageListEventImpl>
      get copyWith => __$$UpdateMessageListEventImplCopyWithImpl<
          _$UpdateMessageListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateMessageListEvent(messageIdList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateMessageListEvent?.call(messageIdList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateMessageListEvent != null) {
      return updateMessageListEvent(messageIdList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateMessageListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateMessageListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateMessageListEvent != null) {
      return updateMessageListEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateMessageListEvent implements HomeEvent {
  const factory _UpdateMessageListEvent(
          {required final List<String> messageIdList}) =
      _$UpdateMessageListEventImpl;

  List<String> get messageIdList;
  @JsonKey(ignore: true)
  _$$UpdateMessageListEventImplCopyWith<_$UpdateMessageListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ToggleNoteEventImplCopyWith<$Res> {
  factory _$$ToggleNoteEventImplCopyWith(_$ToggleNoteEventImpl value,
          $Res Function(_$ToggleNoteEventImpl) then) =
      __$$ToggleNoteEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isBarcode});
}

/// @nodoc
class __$$ToggleNoteEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$ToggleNoteEventImpl>
    implements _$$ToggleNoteEventImplCopyWith<$Res> {
  __$$ToggleNoteEventImplCopyWithImpl(
      _$ToggleNoteEventImpl _value, $Res Function(_$ToggleNoteEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isBarcode = null,
  }) {
    return _then(_$ToggleNoteEventImpl(
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ToggleNoteEventImpl implements _ToggleNoteEvent {
  const _$ToggleNoteEventImpl({required this.isBarcode});

  @override
  final bool isBarcode;

  @override
  String toString() {
    return 'HomeEvent.toggleNoteEvent(isBarcode: $isBarcode)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ToggleNoteEventImpl &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isBarcode);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ToggleNoteEventImplCopyWith<_$ToggleNoteEventImpl> get copyWith =>
      __$$ToggleNoteEventImplCopyWithImpl<_$ToggleNoteEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return toggleNoteEvent(isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(isBarcode);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return toggleNoteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(this);
    }
    return orElse();
  }
}

abstract class _ToggleNoteEvent implements HomeEvent {
  const factory _ToggleNoteEvent({required final bool isBarcode}) =
      _$ToggleNoteEventImpl;

  bool get isBarcode;
  @JsonKey(ignore: true)
  _$$ToggleNoteEventImplCopyWith<_$ToggleNoteEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getProfileDetailsEventImplCopyWith<$Res> {
  factory _$$getProfileDetailsEventImplCopyWith(
          _$getProfileDetailsEventImpl value,
          $Res Function(_$getProfileDetailsEventImpl) then) =
      __$$getProfileDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getProfileDetailsEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$getProfileDetailsEventImpl>
    implements _$$getProfileDetailsEventImplCopyWith<$Res> {
  __$$getProfileDetailsEventImplCopyWithImpl(
      _$getProfileDetailsEventImpl _value,
      $Res Function(_$getProfileDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getProfileDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getProfileDetailsEventImpl implements _getProfileDetailsEvent {
  const _$getProfileDetailsEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getProfileDetailsEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getProfileDetailsEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getProfileDetailsEventImplCopyWith<_$getProfileDetailsEventImpl>
      get copyWith => __$$getProfileDetailsEventImplCopyWithImpl<
          _$getProfileDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProfileDetailsEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProfileDetailsEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProfileDetailsEvent != null) {
      return getProfileDetailsEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProfileDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProfileDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProfileDetailsEvent != null) {
      return getProfileDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _getProfileDetailsEvent implements HomeEvent {
  const factory _getProfileDetailsEvent({required final BuildContext context}) =
      _$getProfileDetailsEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getProfileDetailsEventImplCopyWith<_$getProfileDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetRecommendationProductsListEventImplCopyWith<$Res> {
  factory _$$GetRecommendationProductsListEventImplCopyWith(
          _$GetRecommendationProductsListEventImpl value,
          $Res Function(_$GetRecommendationProductsListEventImpl) then) =
      __$$GetRecommendationProductsListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetRecommendationProductsListEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res,
        _$GetRecommendationProductsListEventImpl>
    implements _$$GetRecommendationProductsListEventImplCopyWith<$Res> {
  __$$GetRecommendationProductsListEventImplCopyWithImpl(
      _$GetRecommendationProductsListEventImpl _value,
      $Res Function(_$GetRecommendationProductsListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetRecommendationProductsListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetRecommendationProductsListEventImpl
    implements _GetRecommendationProductsListEvent {
  const _$GetRecommendationProductsListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getRecommendationProductsListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetRecommendationProductsListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetRecommendationProductsListEventImplCopyWith<
          _$GetRecommendationProductsListEventImpl>
      get copyWith => __$$GetRecommendationProductsListEventImplCopyWithImpl<
          _$GetRecommendationProductsListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getRecommendationProductsListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getRecommendationProductsListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getRecommendationProductsListEvent != null) {
      return getRecommendationProductsListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getRecommendationProductsListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getRecommendationProductsListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getRecommendationProductsListEvent != null) {
      return getRecommendationProductsListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetRecommendationProductsListEvent implements HomeEvent {
  const factory _GetRecommendationProductsListEvent(
          {required final BuildContext context}) =
      _$GetRecommendationProductsListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetRecommendationProductsListEventImplCopyWith<
          _$GetRecommendationProductsListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  factory _$$ChangeCategoryExpansionImplCopyWith(
          _$ChangeCategoryExpansionImpl value,
          $Res Function(_$ChangeCategoryExpansionImpl) then) =
      __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isOpened});
}

/// @nodoc
class __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$ChangeCategoryExpansionImpl>
    implements _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  __$$ChangeCategoryExpansionImplCopyWithImpl(
      _$ChangeCategoryExpansionImpl _value,
      $Res Function(_$ChangeCategoryExpansionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isOpened = freezed,
  }) {
    return _then(_$ChangeCategoryExpansionImpl(
      isOpened: freezed == isOpened
          ? _value.isOpened
          : isOpened // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeCategoryExpansionImpl implements _ChangeCategoryExpansion {
  const _$ChangeCategoryExpansionImpl({this.isOpened});

  @override
  final bool? isOpened;

  @override
  String toString() {
    return 'HomeEvent.changeCategoryExpansion(isOpened: $isOpened)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeCategoryExpansionImpl &&
            (identical(other.isOpened, isOpened) ||
                other.isOpened == isOpened));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isOpened);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => __$$ChangeCategoryExpansionImplCopyWithImpl<
          _$ChangeCategoryExpansionImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeCategoryExpansion(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(isOpened);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeCategoryExpansion(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(this);
    }
    return orElse();
  }
}

abstract class _ChangeCategoryExpansion implements HomeEvent {
  const factory _ChangeCategoryExpansion({final bool? isOpened}) =
      _$ChangeCategoryExpansionImpl;

  bool? get isOpened;
  @JsonKey(ignore: true)
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GlobalSearchEventImplCopyWith<$Res> {
  factory _$$GlobalSearchEventImplCopyWith(_$GlobalSearchEventImpl value,
          $Res Function(_$GlobalSearchEventImpl) then) =
      __$$GlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GlobalSearchEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$GlobalSearchEventImpl>
    implements _$$GlobalSearchEventImplCopyWith<$Res> {
  __$$GlobalSearchEventImplCopyWithImpl(_$GlobalSearchEventImpl _value,
      $Res Function(_$GlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GlobalSearchEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GlobalSearchEventImpl implements _GlobalSearchEvent {
  const _$GlobalSearchEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.globalSearchEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalSearchEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      __$$GlobalSearchEventImplCopyWithImpl<_$GlobalSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return globalSearchEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return globalSearchEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return globalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return globalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _GlobalSearchEvent implements HomeEvent {
  const factory _GlobalSearchEvent({required final BuildContext context}) =
      _$GlobalSearchEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  factory _$$UpdateGlobalSearchEventImplCopyWith(
          _$UpdateGlobalSearchEventImpl value,
          $Res Function(_$UpdateGlobalSearchEventImpl) then) =
      __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search, List<SearchModel> searchList});
}

/// @nodoc
class __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$UpdateGlobalSearchEventImpl>
    implements _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  __$$UpdateGlobalSearchEventImplCopyWithImpl(
      _$UpdateGlobalSearchEventImpl _value,
      $Res Function(_$UpdateGlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
    Object? searchList = null,
  }) {
    return _then(_$UpdateGlobalSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
    ));
  }
}

/// @nodoc

class _$UpdateGlobalSearchEventImpl implements _UpdateGlobalSearchEvent {
  const _$UpdateGlobalSearchEventImpl(
      {required this.search, required final List<SearchModel> searchList})
      : _searchList = searchList;

  @override
  final String search;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  String toString() {
    return 'HomeEvent.updateGlobalSearchEvent(search: $search, searchList: $searchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateGlobalSearchEventImpl &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, search, const DeepCollectionEquality().hash(_searchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => __$$UpdateGlobalSearchEventImplCopyWithImpl<
          _$UpdateGlobalSearchEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateGlobalSearchEvent(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(search, searchList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateGlobalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateGlobalSearchEvent implements HomeEvent {
  const factory _UpdateGlobalSearchEvent(
          {required final String search,
          required final List<SearchModel> searchList}) =
      _$UpdateGlobalSearchEventImpl;

  String get search;
  List<SearchModel> get searchList;
  @JsonKey(ignore: true)
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  factory _$$GetProductCategoriesListEventImplCopyWith(
          _$GetProductCategoriesListEventImpl value,
          $Res Function(_$GetProductCategoriesListEventImpl) then) =
      __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$GetProductCategoriesListEventImpl>
    implements _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  __$$GetProductCategoriesListEventImplCopyWithImpl(
      _$GetProductCategoriesListEventImpl _value,
      $Res Function(_$GetProductCategoriesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductCategoriesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductCategoriesListEventImpl
    implements _GetProductCategoriesListEvent {
  const _$GetProductCategoriesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getProductCategoriesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductCategoriesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => __$$GetProductCategoriesListEventImplCopyWithImpl<
          _$GetProductCategoriesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductCategoriesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductCategoriesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductCategoriesListEvent implements HomeEvent {
  const factory _GetProductCategoriesListEvent(
          {required final BuildContext context}) =
      _$GetProductCategoriesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$checkVersionOfAppEventImplCopyWith<$Res> {
  factory _$$checkVersionOfAppEventImplCopyWith(
          _$checkVersionOfAppEventImpl value,
          $Res Function(_$checkVersionOfAppEventImpl) then) =
      __$$checkVersionOfAppEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$checkVersionOfAppEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$checkVersionOfAppEventImpl>
    implements _$$checkVersionOfAppEventImplCopyWith<$Res> {
  __$$checkVersionOfAppEventImplCopyWithImpl(
      _$checkVersionOfAppEventImpl _value,
      $Res Function(_$checkVersionOfAppEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$checkVersionOfAppEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$checkVersionOfAppEventImpl implements _checkVersionOfAppEvent {
  const _$checkVersionOfAppEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.checkVersionOfAppEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$checkVersionOfAppEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$checkVersionOfAppEventImplCopyWith<_$checkVersionOfAppEventImpl>
      get copyWith => __$$checkVersionOfAppEventImplCopyWithImpl<
          _$checkVersionOfAppEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return checkVersionOfAppEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return checkVersionOfAppEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (checkVersionOfAppEvent != null) {
      return checkVersionOfAppEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return checkVersionOfAppEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return checkVersionOfAppEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (checkVersionOfAppEvent != null) {
      return checkVersionOfAppEvent(this);
    }
    return orElse();
  }
}

abstract class _checkVersionOfAppEvent implements HomeEvent {
  const factory _checkVersionOfAppEvent({required final BuildContext context}) =
      _$checkVersionOfAppEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$checkVersionOfAppEventImplCopyWith<_$checkVersionOfAppEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RelatedProductsEventImplCopyWith<$Res> {
  factory _$$RelatedProductsEventImplCopyWith(_$RelatedProductsEventImpl value,
          $Res Function(_$RelatedProductsEventImpl) then) =
      __$$RelatedProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$RelatedProductsEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$RelatedProductsEventImpl>
    implements _$$RelatedProductsEventImplCopyWith<$Res> {
  __$$RelatedProductsEventImplCopyWithImpl(_$RelatedProductsEventImpl _value,
      $Res Function(_$RelatedProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$RelatedProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RelatedProductsEventImpl implements _RelatedProductsEvent {
  const _$RelatedProductsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'HomeEvent.RelatedProductsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith =>
          __$$RelatedProductsEventImplCopyWithImpl<_$RelatedProductsEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RelatedProductsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RelatedProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _RelatedProductsEvent implements HomeEvent {
  const factory _RelatedProductsEvent(
      {required final BuildContext context,
      required final String productId}) = _$RelatedProductsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  factory _$$RemoveRelatedProductEventImplCopyWith(
          _$RemoveRelatedProductEventImpl value,
          $Res Function(_$RemoveRelatedProductEventImpl) then) =
      __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$RemoveRelatedProductEventImpl>
    implements _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  __$$RemoveRelatedProductEventImplCopyWithImpl(
      _$RemoveRelatedProductEventImpl _value,
      $Res Function(_$RemoveRelatedProductEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$RemoveRelatedProductEventImpl implements _RemoveRelatedProductEvent {
  const _$RemoveRelatedProductEventImpl();

  @override
  String toString() {
    return 'HomeEvent.RemoveRelatedProductEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveRelatedProductEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RemoveRelatedProductEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RemoveRelatedProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveRelatedProductEvent implements HomeEvent {
  const factory _RemoveRelatedProductEvent() = _$RemoveRelatedProductEventImpl;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$HomeEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'HomeEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferencesDataEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, bool isBarcode,
            String productId, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int messageCount) setMessageCountEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(BuildContext context) getCartCountEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(List<String> messageIdList)
        updateMessageListEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferencesDataEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int messageCount)? setMessageCountEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(BuildContext context)? getCartCountEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(List<String> messageIdList)? updateMessageListEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferencesDataEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, bool isBarcode, String productId,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int messageCount)? setMessageCountEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(BuildContext context)? getCartCountEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(List<String> messageIdList)? updateMessageListEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferencesDataEvent value)
        getPreferencesDataEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_SetMessageCountEvent value) setMessageCountEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_GetCartCountEvent value) getCartCountEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateMessageListEvent value)
        updateMessageListEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferencesDataEvent value)? getPreferencesDataEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_SetMessageCountEvent value)? setMessageCountEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_GetCartCountEvent value)? getCartCountEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateMessageListEvent value)? updateMessageListEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements HomeEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$HomeState {
  String get UserImageUrl => throw _privateConstructorUsedError;
  String get UserCompanyLogoUrl => throw _privateConstructorUsedError;
  int get cartCount => throw _privateConstructorUsedError;
  int get messageCount => throw _privateConstructorUsedError;
  List<ProductSale> get productSalesList => throw _privateConstructorUsedError;
  bool get isProductSaleShimmering => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isProductLoading => throw _privateConstructorUsedError;
  List<Product> get productDetails => throw _privateConstructorUsedError;
  List<List<ProductStockModel>> get productStockList =>
      throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  bool get isSelectSupplier => throw _privateConstructorUsedError;
  List<ProductSupplierModel> get productSupplierList =>
      throw _privateConstructorUsedError;
  bool get isCartCountChange => throw _privateConstructorUsedError;
  double get totalCredit => throw _privateConstructorUsedError;
  double get thisMonthExpense => throw _privateConstructorUsedError;
  double get lastMonthExpense => throw _privateConstructorUsedError;
  int get orderThisMonth => throw _privateConstructorUsedError;
  double get balance => throw _privateConstructorUsedError;
  int get imageIndex => throw _privateConstructorUsedError;
  List<MessageData> get messageList => throw _privateConstructorUsedError;
  bool get isMessageShimmering => throw _privateConstructorUsedError;
  double get expensePercentage => throw _privateConstructorUsedError;
  TextEditingController get noteController =>
      throw _privateConstructorUsedError;
  List<RecommendationData> get recommendedProductsList =>
      throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isCategoryExpand => throw _privateConstructorUsedError;
  bool get isSearching => throw _privateConstructorUsedError;
  TextEditingController get searchController =>
      throw _privateConstructorUsedError;
  List<SearchModel> get searchList => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  List<Category> get productCategoryList => throw _privateConstructorUsedError;
  bool get isCatVisible => throw _privateConstructorUsedError;
  bool get isGuestUser => throw _privateConstructorUsedError;
  bool get isIgnorePointer => throw _privateConstructorUsedError;
  bool get isRelatedShimmering => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get relatedProductList =>
      throw _privateConstructorUsedError;
  int get productListIndex => throw _privateConstructorUsedError;
  bool get showPesachBanner => throw _privateConstructorUsedError;
  String get pesachBannerURL => throw _privateConstructorUsedError;
  bool get pesachBannerShimmering => throw _privateConstructorUsedError;
  double get bottlePrice => throw _privateConstructorUsedError;
  bool get isSubUserAddToBasket => throw _privateConstructorUsedError;
  bool get isSubUserSeeWallet => throw _privateConstructorUsedError;
  bool get isAccountPermissionShimmering => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $HomeStateCopyWith<HomeState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeStateCopyWith<$Res> {
  factory $HomeStateCopyWith(HomeState value, $Res Function(HomeState) then) =
      _$HomeStateCopyWithImpl<$Res, HomeState>;
  @useResult
  $Res call(
      {String UserImageUrl,
      String UserCompanyLogoUrl,
      int cartCount,
      int messageCount,
      List<ProductSale> productSalesList,
      bool isProductSaleShimmering,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      bool isCartCountChange,
      double totalCredit,
      double thisMonthExpense,
      double lastMonthExpense,
      int orderThisMonth,
      double balance,
      int imageIndex,
      List<MessageData> messageList,
      bool isMessageShimmering,
      double expensePercentage,
      TextEditingController noteController,
      List<RecommendationData> recommendedProductsList,
      bool isShimmering,
      bool isCategoryExpand,
      bool isSearching,
      TextEditingController searchController,
      List<SearchModel> searchList,
      String search,
      List<Category> productCategoryList,
      bool isCatVisible,
      bool isGuestUser,
      bool isIgnorePointer,
      bool isRelatedShimmering,
      List<RelatedProductDatum> relatedProductList,
      int productListIndex,
      bool showPesachBanner,
      String pesachBannerURL,
      bool pesachBannerShimmering,
      double bottlePrice,
      bool isSubUserAddToBasket,
      bool isSubUserSeeWallet,
      bool isAccountPermissionShimmering});
}

/// @nodoc
class _$HomeStateCopyWithImpl<$Res, $Val extends HomeState>
    implements $HomeStateCopyWith<$Res> {
  _$HomeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? UserImageUrl = null,
    Object? UserCompanyLogoUrl = null,
    Object? cartCount = null,
    Object? messageCount = null,
    Object? productSalesList = null,
    Object? isProductSaleShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? isCartCountChange = null,
    Object? totalCredit = null,
    Object? thisMonthExpense = null,
    Object? lastMonthExpense = null,
    Object? orderThisMonth = null,
    Object? balance = null,
    Object? imageIndex = null,
    Object? messageList = null,
    Object? isMessageShimmering = null,
    Object? expensePercentage = null,
    Object? noteController = null,
    Object? recommendedProductsList = null,
    Object? isShimmering = null,
    Object? isCategoryExpand = null,
    Object? isSearching = null,
    Object? searchController = null,
    Object? searchList = null,
    Object? search = null,
    Object? productCategoryList = null,
    Object? isCatVisible = null,
    Object? isGuestUser = null,
    Object? isIgnorePointer = null,
    Object? isRelatedShimmering = null,
    Object? relatedProductList = null,
    Object? productListIndex = null,
    Object? showPesachBanner = null,
    Object? pesachBannerURL = null,
    Object? pesachBannerShimmering = null,
    Object? bottlePrice = null,
    Object? isSubUserAddToBasket = null,
    Object? isSubUserSeeWallet = null,
    Object? isAccountPermissionShimmering = null,
  }) {
    return _then(_value.copyWith(
      UserImageUrl: null == UserImageUrl
          ? _value.UserImageUrl
          : UserImageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      UserCompanyLogoUrl: null == UserCompanyLogoUrl
          ? _value.UserCompanyLogoUrl
          : UserCompanyLogoUrl // ignore: cast_nullable_to_non_nullable
              as String,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      messageCount: null == messageCount
          ? _value.messageCount
          : messageCount // ignore: cast_nullable_to_non_nullable
              as int,
      productSalesList: null == productSalesList
          ? _value.productSalesList
          : productSalesList // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>,
      isProductSaleShimmering: null == isProductSaleShimmering
          ? _value.isProductSaleShimmering
          : isProductSaleShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value.productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      thisMonthExpense: null == thisMonthExpense
          ? _value.thisMonthExpense
          : thisMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      lastMonthExpense: null == lastMonthExpense
          ? _value.lastMonthExpense
          : lastMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      orderThisMonth: null == orderThisMonth
          ? _value.orderThisMonth
          : orderThisMonth // ignore: cast_nullable_to_non_nullable
              as int,
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as double,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      messageList: null == messageList
          ? _value.messageList
          : messageList // ignore: cast_nullable_to_non_nullable
              as List<MessageData>,
      isMessageShimmering: null == isMessageShimmering
          ? _value.isMessageShimmering
          : isMessageShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      expensePercentage: null == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      recommendedProductsList: null == recommendedProductsList
          ? _value.recommendedProductsList
          : recommendedProductsList // ignore: cast_nullable_to_non_nullable
              as List<RecommendationData>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      searchList: null == searchList
          ? _value.searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productCategoryList: null == productCategoryList
          ? _value.productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isIgnorePointer: null == isIgnorePointer
          ? _value.isIgnorePointer
          : isIgnorePointer // ignore: cast_nullable_to_non_nullable
              as bool,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value.relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      showPesachBanner: null == showPesachBanner
          ? _value.showPesachBanner
          : showPesachBanner // ignore: cast_nullable_to_non_nullable
              as bool,
      pesachBannerURL: null == pesachBannerURL
          ? _value.pesachBannerURL
          : pesachBannerURL // ignore: cast_nullable_to_non_nullable
              as String,
      pesachBannerShimmering: null == pesachBannerShimmering
          ? _value.pesachBannerShimmering
          : pesachBannerShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      bottlePrice: null == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserSeeWallet: null == isSubUserSeeWallet
          ? _value.isSubUserSeeWallet
          : isSubUserSeeWallet // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$HomeStateImplCopyWith<$Res>
    implements $HomeStateCopyWith<$Res> {
  factory _$$HomeStateImplCopyWith(
          _$HomeStateImpl value, $Res Function(_$HomeStateImpl) then) =
      __$$HomeStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String UserImageUrl,
      String UserCompanyLogoUrl,
      int cartCount,
      int messageCount,
      List<ProductSale> productSalesList,
      bool isProductSaleShimmering,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      bool isCartCountChange,
      double totalCredit,
      double thisMonthExpense,
      double lastMonthExpense,
      int orderThisMonth,
      double balance,
      int imageIndex,
      List<MessageData> messageList,
      bool isMessageShimmering,
      double expensePercentage,
      TextEditingController noteController,
      List<RecommendationData> recommendedProductsList,
      bool isShimmering,
      bool isCategoryExpand,
      bool isSearching,
      TextEditingController searchController,
      List<SearchModel> searchList,
      String search,
      List<Category> productCategoryList,
      bool isCatVisible,
      bool isGuestUser,
      bool isIgnorePointer,
      bool isRelatedShimmering,
      List<RelatedProductDatum> relatedProductList,
      int productListIndex,
      bool showPesachBanner,
      String pesachBannerURL,
      bool pesachBannerShimmering,
      double bottlePrice,
      bool isSubUserAddToBasket,
      bool isSubUserSeeWallet,
      bool isAccountPermissionShimmering});
}

/// @nodoc
class __$$HomeStateImplCopyWithImpl<$Res>
    extends _$HomeStateCopyWithImpl<$Res, _$HomeStateImpl>
    implements _$$HomeStateImplCopyWith<$Res> {
  __$$HomeStateImplCopyWithImpl(
      _$HomeStateImpl _value, $Res Function(_$HomeStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? UserImageUrl = null,
    Object? UserCompanyLogoUrl = null,
    Object? cartCount = null,
    Object? messageCount = null,
    Object? productSalesList = null,
    Object? isProductSaleShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? isCartCountChange = null,
    Object? totalCredit = null,
    Object? thisMonthExpense = null,
    Object? lastMonthExpense = null,
    Object? orderThisMonth = null,
    Object? balance = null,
    Object? imageIndex = null,
    Object? messageList = null,
    Object? isMessageShimmering = null,
    Object? expensePercentage = null,
    Object? noteController = null,
    Object? recommendedProductsList = null,
    Object? isShimmering = null,
    Object? isCategoryExpand = null,
    Object? isSearching = null,
    Object? searchController = null,
    Object? searchList = null,
    Object? search = null,
    Object? productCategoryList = null,
    Object? isCatVisible = null,
    Object? isGuestUser = null,
    Object? isIgnorePointer = null,
    Object? isRelatedShimmering = null,
    Object? relatedProductList = null,
    Object? productListIndex = null,
    Object? showPesachBanner = null,
    Object? pesachBannerURL = null,
    Object? pesachBannerShimmering = null,
    Object? bottlePrice = null,
    Object? isSubUserAddToBasket = null,
    Object? isSubUserSeeWallet = null,
    Object? isAccountPermissionShimmering = null,
  }) {
    return _then(_$HomeStateImpl(
      UserImageUrl: null == UserImageUrl
          ? _value.UserImageUrl
          : UserImageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      UserCompanyLogoUrl: null == UserCompanyLogoUrl
          ? _value.UserCompanyLogoUrl
          : UserCompanyLogoUrl // ignore: cast_nullable_to_non_nullable
              as String,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      messageCount: null == messageCount
          ? _value.messageCount
          : messageCount // ignore: cast_nullable_to_non_nullable
              as int,
      productSalesList: null == productSalesList
          ? _value._productSalesList
          : productSalesList // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>,
      isProductSaleShimmering: null == isProductSaleShimmering
          ? _value.isProductSaleShimmering
          : isProductSaleShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value._productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value._productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      thisMonthExpense: null == thisMonthExpense
          ? _value.thisMonthExpense
          : thisMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      lastMonthExpense: null == lastMonthExpense
          ? _value.lastMonthExpense
          : lastMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      orderThisMonth: null == orderThisMonth
          ? _value.orderThisMonth
          : orderThisMonth // ignore: cast_nullable_to_non_nullable
              as int,
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as double,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      messageList: null == messageList
          ? _value._messageList
          : messageList // ignore: cast_nullable_to_non_nullable
              as List<MessageData>,
      isMessageShimmering: null == isMessageShimmering
          ? _value.isMessageShimmering
          : isMessageShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      expensePercentage: null == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      recommendedProductsList: null == recommendedProductsList
          ? _value._recommendedProductsList
          : recommendedProductsList // ignore: cast_nullable_to_non_nullable
              as List<RecommendationData>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productCategoryList: null == productCategoryList
          ? _value._productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isIgnorePointer: null == isIgnorePointer
          ? _value.isIgnorePointer
          : isIgnorePointer // ignore: cast_nullable_to_non_nullable
              as bool,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value._relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      showPesachBanner: null == showPesachBanner
          ? _value.showPesachBanner
          : showPesachBanner // ignore: cast_nullable_to_non_nullable
              as bool,
      pesachBannerURL: null == pesachBannerURL
          ? _value.pesachBannerURL
          : pesachBannerURL // ignore: cast_nullable_to_non_nullable
              as String,
      pesachBannerShimmering: null == pesachBannerShimmering
          ? _value.pesachBannerShimmering
          : pesachBannerShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      bottlePrice: null == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserSeeWallet: null == isSubUserSeeWallet
          ? _value.isSubUserSeeWallet
          : isSubUserSeeWallet // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$HomeStateImpl implements _HomeState {
  const _$HomeStateImpl(
      {required this.UserImageUrl,
      required this.UserCompanyLogoUrl,
      required this.cartCount,
      required this.messageCount,
      required final List<ProductSale> productSalesList,
      required this.isProductSaleShimmering,
      required this.isLoading,
      required this.isProductLoading,
      required final List<Product> productDetails,
      required final List<List<ProductStockModel>> productStockList,
      required this.productStockUpdateIndex,
      required this.isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required this.isCartCountChange,
      required this.totalCredit,
      required this.thisMonthExpense,
      required this.lastMonthExpense,
      required this.orderThisMonth,
      required this.balance,
      required this.imageIndex,
      required final List<MessageData> messageList,
      required this.isMessageShimmering,
      required this.expensePercentage,
      required this.noteController,
      required final List<RecommendationData> recommendedProductsList,
      required this.isShimmering,
      required this.isCategoryExpand,
      required this.isSearching,
      required this.searchController,
      required final List<SearchModel> searchList,
      required this.search,
      required final List<Category> productCategoryList,
      required this.isCatVisible,
      required this.isGuestUser,
      required this.isIgnorePointer,
      required this.isRelatedShimmering,
      required final List<RelatedProductDatum> relatedProductList,
      required this.productListIndex,
      required this.showPesachBanner,
      required this.pesachBannerURL,
      required this.pesachBannerShimmering,
      required this.bottlePrice,
      required this.isSubUserAddToBasket,
      required this.isSubUserSeeWallet,
      required this.isAccountPermissionShimmering})
      : _productSalesList = productSalesList,
        _productDetails = productDetails,
        _productStockList = productStockList,
        _productSupplierList = productSupplierList,
        _messageList = messageList,
        _recommendedProductsList = recommendedProductsList,
        _searchList = searchList,
        _productCategoryList = productCategoryList,
        _relatedProductList = relatedProductList;

  @override
  final String UserImageUrl;
  @override
  final String UserCompanyLogoUrl;
  @override
  final int cartCount;
  @override
  final int messageCount;
  final List<ProductSale> _productSalesList;
  @override
  List<ProductSale> get productSalesList {
    if (_productSalesList is EqualUnmodifiableListView)
      return _productSalesList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSalesList);
  }

  @override
  final bool isProductSaleShimmering;
  @override
  final bool isLoading;
  @override
  final bool isProductLoading;
  final List<Product> _productDetails;
  @override
  List<Product> get productDetails {
    if (_productDetails is EqualUnmodifiableListView) return _productDetails;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productDetails);
  }

  final List<List<ProductStockModel>> _productStockList;
  @override
  List<List<ProductStockModel>> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final int productStockUpdateIndex;
  @override
  final bool isSelectSupplier;
  final List<ProductSupplierModel> _productSupplierList;
  @override
  List<ProductSupplierModel> get productSupplierList {
    if (_productSupplierList is EqualUnmodifiableListView)
      return _productSupplierList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSupplierList);
  }

  @override
  final bool isCartCountChange;
  @override
  final double totalCredit;
  @override
  final double thisMonthExpense;
  @override
  final double lastMonthExpense;
  @override
  final int orderThisMonth;
  @override
  final double balance;
  @override
  final int imageIndex;
  final List<MessageData> _messageList;
  @override
  List<MessageData> get messageList {
    if (_messageList is EqualUnmodifiableListView) return _messageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_messageList);
  }

  @override
  final bool isMessageShimmering;
  @override
  final double expensePercentage;
  @override
  final TextEditingController noteController;
  final List<RecommendationData> _recommendedProductsList;
  @override
  List<RecommendationData> get recommendedProductsList {
    if (_recommendedProductsList is EqualUnmodifiableListView)
      return _recommendedProductsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_recommendedProductsList);
  }

  @override
  final bool isShimmering;
  @override
  final bool isCategoryExpand;
  @override
  final bool isSearching;
  @override
  final TextEditingController searchController;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  final String search;
  final List<Category> _productCategoryList;
  @override
  List<Category> get productCategoryList {
    if (_productCategoryList is EqualUnmodifiableListView)
      return _productCategoryList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productCategoryList);
  }

  @override
  final bool isCatVisible;
  @override
  final bool isGuestUser;
  @override
  final bool isIgnorePointer;
  @override
  final bool isRelatedShimmering;
  final List<RelatedProductDatum> _relatedProductList;
  @override
  List<RelatedProductDatum> get relatedProductList {
    if (_relatedProductList is EqualUnmodifiableListView)
      return _relatedProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedProductList);
  }

  @override
  final int productListIndex;
  @override
  final bool showPesachBanner;
  @override
  final String pesachBannerURL;
  @override
  final bool pesachBannerShimmering;
  @override
  final double bottlePrice;
  @override
  final bool isSubUserAddToBasket;
  @override
  final bool isSubUserSeeWallet;
  @override
  final bool isAccountPermissionShimmering;

  @override
  String toString() {
    return 'HomeState(UserImageUrl: $UserImageUrl, UserCompanyLogoUrl: $UserCompanyLogoUrl, cartCount: $cartCount, messageCount: $messageCount, productSalesList: $productSalesList, isProductSaleShimmering: $isProductSaleShimmering, isLoading: $isLoading, isProductLoading: $isProductLoading, productDetails: $productDetails, productStockList: $productStockList, productStockUpdateIndex: $productStockUpdateIndex, isSelectSupplier: $isSelectSupplier, productSupplierList: $productSupplierList, isCartCountChange: $isCartCountChange, totalCredit: $totalCredit, thisMonthExpense: $thisMonthExpense, lastMonthExpense: $lastMonthExpense, orderThisMonth: $orderThisMonth, balance: $balance, imageIndex: $imageIndex, messageList: $messageList, isMessageShimmering: $isMessageShimmering, expensePercentage: $expensePercentage, noteController: $noteController, recommendedProductsList: $recommendedProductsList, isShimmering: $isShimmering, isCategoryExpand: $isCategoryExpand, isSearching: $isSearching, searchController: $searchController, searchList: $searchList, search: $search, productCategoryList: $productCategoryList, isCatVisible: $isCatVisible, isGuestUser: $isGuestUser, isIgnorePointer: $isIgnorePointer, isRelatedShimmering: $isRelatedShimmering, relatedProductList: $relatedProductList, productListIndex: $productListIndex, showPesachBanner: $showPesachBanner, pesachBannerURL: $pesachBannerURL, pesachBannerShimmering: $pesachBannerShimmering, bottlePrice: $bottlePrice, isSubUserAddToBasket: $isSubUserAddToBasket, isSubUserSeeWallet: $isSubUserSeeWallet, isAccountPermissionShimmering: $isAccountPermissionShimmering)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HomeStateImpl &&
            (identical(other.UserImageUrl, UserImageUrl) ||
                other.UserImageUrl == UserImageUrl) &&
            (identical(other.UserCompanyLogoUrl, UserCompanyLogoUrl) ||
                other.UserCompanyLogoUrl == UserCompanyLogoUrl) &&
            (identical(other.cartCount, cartCount) ||
                other.cartCount == cartCount) &&
            (identical(other.messageCount, messageCount) ||
                other.messageCount == messageCount) &&
            const DeepCollectionEquality()
                .equals(other._productSalesList, _productSalesList) &&
            (identical(other.isProductSaleShimmering, isProductSaleShimmering) ||
                other.isProductSaleShimmering == isProductSaleShimmering) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isProductLoading, isProductLoading) ||
                other.isProductLoading == isProductLoading) &&
            const DeepCollectionEquality()
                .equals(other._productDetails, _productDetails) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier) &&
            const DeepCollectionEquality()
                .equals(other._productSupplierList, _productSupplierList) &&
            (identical(other.isCartCountChange, isCartCountChange) ||
                other.isCartCountChange == isCartCountChange) &&
            (identical(other.totalCredit, totalCredit) ||
                other.totalCredit == totalCredit) &&
            (identical(other.thisMonthExpense, thisMonthExpense) ||
                other.thisMonthExpense == thisMonthExpense) &&
            (identical(other.lastMonthExpense, lastMonthExpense) ||
                other.lastMonthExpense == lastMonthExpense) &&
            (identical(other.orderThisMonth, orderThisMonth) ||
                other.orderThisMonth == orderThisMonth) &&
            (identical(other.balance, balance) || other.balance == balance) &&
            (identical(other.imageIndex, imageIndex) ||
                other.imageIndex == imageIndex) &&
            const DeepCollectionEquality()
                .equals(other._messageList, _messageList) &&
            (identical(other.isMessageShimmering, isMessageShimmering) ||
                other.isMessageShimmering == isMessageShimmering) &&
            (identical(other.expensePercentage, expensePercentage) ||
                other.expensePercentage == expensePercentage) &&
            (identical(other.noteController, noteController) ||
                other.noteController == noteController) &&
            const DeepCollectionEquality().equals(
                other._recommendedProductsList, _recommendedProductsList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isCategoryExpand, isCategoryExpand) ||
                other.isCategoryExpand == isCategoryExpand) &&
            (identical(other.isSearching, isSearching) ||
                other.isSearching == isSearching) &&
            (identical(other.searchController, searchController) ||
                other.searchController == searchController) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList) &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality().equals(other._productCategoryList, _productCategoryList) &&
            (identical(other.isCatVisible, isCatVisible) || other.isCatVisible == isCatVisible) &&
            (identical(other.isGuestUser, isGuestUser) || other.isGuestUser == isGuestUser) &&
            (identical(other.isIgnorePointer, isIgnorePointer) || other.isIgnorePointer == isIgnorePointer) &&
            (identical(other.isRelatedShimmering, isRelatedShimmering) || other.isRelatedShimmering == isRelatedShimmering) &&
            const DeepCollectionEquality().equals(other._relatedProductList, _relatedProductList) &&
            (identical(other.productListIndex, productListIndex) || other.productListIndex == productListIndex) &&
            (identical(other.showPesachBanner, showPesachBanner) || other.showPesachBanner == showPesachBanner) &&
            (identical(other.pesachBannerURL, pesachBannerURL) || other.pesachBannerURL == pesachBannerURL) &&
            (identical(other.pesachBannerShimmering, pesachBannerShimmering) || other.pesachBannerShimmering == pesachBannerShimmering) &&
            (identical(other.bottlePrice, bottlePrice) || other.bottlePrice == bottlePrice) &&
            (identical(other.isSubUserAddToBasket, isSubUserAddToBasket) || other.isSubUserAddToBasket == isSubUserAddToBasket) &&
            (identical(other.isSubUserSeeWallet, isSubUserSeeWallet) || other.isSubUserSeeWallet == isSubUserSeeWallet) &&
            (identical(other.isAccountPermissionShimmering, isAccountPermissionShimmering) || other.isAccountPermissionShimmering == isAccountPermissionShimmering));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        UserImageUrl,
        UserCompanyLogoUrl,
        cartCount,
        messageCount,
        const DeepCollectionEquality().hash(_productSalesList),
        isProductSaleShimmering,
        isLoading,
        isProductLoading,
        const DeepCollectionEquality().hash(_productDetails),
        const DeepCollectionEquality().hash(_productStockList),
        productStockUpdateIndex,
        isSelectSupplier,
        const DeepCollectionEquality().hash(_productSupplierList),
        isCartCountChange,
        totalCredit,
        thisMonthExpense,
        lastMonthExpense,
        orderThisMonth,
        balance,
        imageIndex,
        const DeepCollectionEquality().hash(_messageList),
        isMessageShimmering,
        expensePercentage,
        noteController,
        const DeepCollectionEquality().hash(_recommendedProductsList),
        isShimmering,
        isCategoryExpand,
        isSearching,
        searchController,
        const DeepCollectionEquality().hash(_searchList),
        search,
        const DeepCollectionEquality().hash(_productCategoryList),
        isCatVisible,
        isGuestUser,
        isIgnorePointer,
        isRelatedShimmering,
        const DeepCollectionEquality().hash(_relatedProductList),
        productListIndex,
        showPesachBanner,
        pesachBannerURL,
        pesachBannerShimmering,
        bottlePrice,
        isSubUserAddToBasket,
        isSubUserSeeWallet,
        isAccountPermissionShimmering
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$HomeStateImplCopyWith<_$HomeStateImpl> get copyWith =>
      __$$HomeStateImplCopyWithImpl<_$HomeStateImpl>(this, _$identity);
}

abstract class _HomeState implements HomeState {
  const factory _HomeState(
      {required final String UserImageUrl,
      required final String UserCompanyLogoUrl,
      required final int cartCount,
      required final int messageCount,
      required final List<ProductSale> productSalesList,
      required final bool isProductSaleShimmering,
      required final bool isLoading,
      required final bool isProductLoading,
      required final List<Product> productDetails,
      required final List<List<ProductStockModel>> productStockList,
      required final int productStockUpdateIndex,
      required final bool isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required final bool isCartCountChange,
      required final double totalCredit,
      required final double thisMonthExpense,
      required final double lastMonthExpense,
      required final int orderThisMonth,
      required final double balance,
      required final int imageIndex,
      required final List<MessageData> messageList,
      required final bool isMessageShimmering,
      required final double expensePercentage,
      required final TextEditingController noteController,
      required final List<RecommendationData> recommendedProductsList,
      required final bool isShimmering,
      required final bool isCategoryExpand,
      required final bool isSearching,
      required final TextEditingController searchController,
      required final List<SearchModel> searchList,
      required final String search,
      required final List<Category> productCategoryList,
      required final bool isCatVisible,
      required final bool isGuestUser,
      required final bool isIgnorePointer,
      required final bool isRelatedShimmering,
      required final List<RelatedProductDatum> relatedProductList,
      required final int productListIndex,
      required final bool showPesachBanner,
      required final String pesachBannerURL,
      required final bool pesachBannerShimmering,
      required final double bottlePrice,
      required final bool isSubUserAddToBasket,
      required final bool isSubUserSeeWallet,
      required final bool isAccountPermissionShimmering}) = _$HomeStateImpl;

  @override
  String get UserImageUrl;
  @override
  String get UserCompanyLogoUrl;
  @override
  int get cartCount;
  @override
  int get messageCount;
  @override
  List<ProductSale> get productSalesList;
  @override
  bool get isProductSaleShimmering;
  @override
  bool get isLoading;
  @override
  bool get isProductLoading;
  @override
  List<Product> get productDetails;
  @override
  List<List<ProductStockModel>> get productStockList;
  @override
  int get productStockUpdateIndex;
  @override
  bool get isSelectSupplier;
  @override
  List<ProductSupplierModel> get productSupplierList;
  @override
  bool get isCartCountChange;
  @override
  double get totalCredit;
  @override
  double get thisMonthExpense;
  @override
  double get lastMonthExpense;
  @override
  int get orderThisMonth;
  @override
  double get balance;
  @override
  int get imageIndex;
  @override
  List<MessageData> get messageList;
  @override
  bool get isMessageShimmering;
  @override
  double get expensePercentage;
  @override
  TextEditingController get noteController;
  @override
  List<RecommendationData> get recommendedProductsList;
  @override
  bool get isShimmering;
  @override
  bool get isCategoryExpand;
  @override
  bool get isSearching;
  @override
  TextEditingController get searchController;
  @override
  List<SearchModel> get searchList;
  @override
  String get search;
  @override
  List<Category> get productCategoryList;
  @override
  bool get isCatVisible;
  @override
  bool get isGuestUser;
  @override
  bool get isIgnorePointer;
  @override
  bool get isRelatedShimmering;
  @override
  List<RelatedProductDatum> get relatedProductList;
  @override
  int get productListIndex;
  @override
  bool get showPesachBanner;
  @override
  String get pesachBannerURL;
  @override
  bool get pesachBannerShimmering;
  @override
  double get bottlePrice;
  @override
  bool get isSubUserAddToBasket;
  @override
  bool get isSubUserSeeWallet;
  @override
  bool get isAccountPermissionShimmering;
  @override
  @JsonKey(ignore: true)
  _$$HomeStateImplCopyWith<_$HomeStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
