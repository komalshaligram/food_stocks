// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_category_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProductCategoryEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context)
        navigateToStoreCategoryEvent,
    required TResult Function(String reqSearch, bool isFromStoreCategory)
        setSearchNavEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function() getCartCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult? Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function()? getCartCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function()? getCartCountEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_NavigateToStoreCategoryEvent value)
        navigateToStoreCategoryEvent,
    required TResult Function(_SetSearchNavEvent value) setSearchNavEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult? Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductCategoryEventCopyWith<$Res> {
  factory $ProductCategoryEventCopyWith(ProductCategoryEvent value,
          $Res Function(ProductCategoryEvent) then) =
      _$ProductCategoryEventCopyWithImpl<$Res, ProductCategoryEvent>;
}

/// @nodoc
class _$ProductCategoryEventCopyWithImpl<$Res,
        $Val extends ProductCategoryEvent>
    implements $ProductCategoryEventCopyWith<$Res> {
  _$ProductCategoryEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  factory _$$GetProductCategoriesListEventImplCopyWith(
          _$GetProductCategoriesListEventImpl value,
          $Res Function(_$GetProductCategoriesListEventImpl) then) =
      __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>
    extends _$ProductCategoryEventCopyWithImpl<$Res,
        _$GetProductCategoriesListEventImpl>
    implements _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  __$$GetProductCategoriesListEventImplCopyWithImpl(
      _$GetProductCategoriesListEventImpl _value,
      $Res Function(_$GetProductCategoriesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductCategoriesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductCategoriesListEventImpl
    implements _GetProductCategoriesListEvent {
  const _$GetProductCategoriesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductCategoryEvent.getProductCategoriesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductCategoriesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => __$$GetProductCategoriesListEventImplCopyWithImpl<
          _$GetProductCategoriesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context)
        navigateToStoreCategoryEvent,
    required TResult Function(String reqSearch, bool isFromStoreCategory)
        setSearchNavEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function() getCartCountEvent,
  }) {
    return getProductCategoriesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult? Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function()? getCartCountEvent,
  }) {
    return getProductCategoriesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function()? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_NavigateToStoreCategoryEvent value)
        navigateToStoreCategoryEvent,
    required TResult Function(_SetSearchNavEvent value) setSearchNavEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
  }) {
    return getProductCategoriesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult? Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
  }) {
    return getProductCategoriesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductCategoriesListEvent implements ProductCategoryEvent {
  const factory _GetProductCategoriesListEvent(
          {required final BuildContext context}) =
      _$GetProductCategoriesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$NavigateToStoreCategoryEventImplCopyWith<$Res> {
  factory _$$NavigateToStoreCategoryEventImplCopyWith(
          _$NavigateToStoreCategoryEventImpl value,
          $Res Function(_$NavigateToStoreCategoryEventImpl) then) =
      __$$NavigateToStoreCategoryEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$NavigateToStoreCategoryEventImplCopyWithImpl<$Res>
    extends _$ProductCategoryEventCopyWithImpl<$Res,
        _$NavigateToStoreCategoryEventImpl>
    implements _$$NavigateToStoreCategoryEventImplCopyWith<$Res> {
  __$$NavigateToStoreCategoryEventImplCopyWithImpl(
      _$NavigateToStoreCategoryEventImpl _value,
      $Res Function(_$NavigateToStoreCategoryEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$NavigateToStoreCategoryEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$NavigateToStoreCategoryEventImpl
    implements _NavigateToStoreCategoryEvent {
  const _$NavigateToStoreCategoryEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductCategoryEvent.navigateToStoreCategoryEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NavigateToStoreCategoryEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NavigateToStoreCategoryEventImplCopyWith<
          _$NavigateToStoreCategoryEventImpl>
      get copyWith => __$$NavigateToStoreCategoryEventImplCopyWithImpl<
          _$NavigateToStoreCategoryEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context)
        navigateToStoreCategoryEvent,
    required TResult Function(String reqSearch, bool isFromStoreCategory)
        setSearchNavEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function() getCartCountEvent,
  }) {
    return navigateToStoreCategoryEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult? Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function()? getCartCountEvent,
  }) {
    return navigateToStoreCategoryEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function()? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (navigateToStoreCategoryEvent != null) {
      return navigateToStoreCategoryEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_NavigateToStoreCategoryEvent value)
        navigateToStoreCategoryEvent,
    required TResult Function(_SetSearchNavEvent value) setSearchNavEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
  }) {
    return navigateToStoreCategoryEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult? Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
  }) {
    return navigateToStoreCategoryEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (navigateToStoreCategoryEvent != null) {
      return navigateToStoreCategoryEvent(this);
    }
    return orElse();
  }
}

abstract class _NavigateToStoreCategoryEvent implements ProductCategoryEvent {
  const factory _NavigateToStoreCategoryEvent(
          {required final BuildContext context}) =
      _$NavigateToStoreCategoryEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$NavigateToStoreCategoryEventImplCopyWith<
          _$NavigateToStoreCategoryEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetSearchNavEventImplCopyWith<$Res> {
  factory _$$SetSearchNavEventImplCopyWith(_$SetSearchNavEventImpl value,
          $Res Function(_$SetSearchNavEventImpl) then) =
      __$$SetSearchNavEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String reqSearch, bool isFromStoreCategory});
}

/// @nodoc
class __$$SetSearchNavEventImplCopyWithImpl<$Res>
    extends _$ProductCategoryEventCopyWithImpl<$Res, _$SetSearchNavEventImpl>
    implements _$$SetSearchNavEventImplCopyWith<$Res> {
  __$$SetSearchNavEventImplCopyWithImpl(_$SetSearchNavEventImpl _value,
      $Res Function(_$SetSearchNavEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? reqSearch = null,
    Object? isFromStoreCategory = null,
  }) {
    return _then(_$SetSearchNavEventImpl(
      reqSearch: null == reqSearch
          ? _value.reqSearch
          : reqSearch // ignore: cast_nullable_to_non_nullable
              as String,
      isFromStoreCategory: null == isFromStoreCategory
          ? _value.isFromStoreCategory
          : isFromStoreCategory // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$SetSearchNavEventImpl implements _SetSearchNavEvent {
  const _$SetSearchNavEventImpl(
      {required this.reqSearch, required this.isFromStoreCategory});

  @override
  final String reqSearch;
  @override
  final bool isFromStoreCategory;

  @override
  String toString() {
    return 'ProductCategoryEvent.setSearchNavEvent(reqSearch: $reqSearch, isFromStoreCategory: $isFromStoreCategory)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SetSearchNavEventImpl &&
            (identical(other.reqSearch, reqSearch) ||
                other.reqSearch == reqSearch) &&
            (identical(other.isFromStoreCategory, isFromStoreCategory) ||
                other.isFromStoreCategory == isFromStoreCategory));
  }

  @override
  int get hashCode => Object.hash(runtimeType, reqSearch, isFromStoreCategory);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SetSearchNavEventImplCopyWith<_$SetSearchNavEventImpl> get copyWith =>
      __$$SetSearchNavEventImplCopyWithImpl<_$SetSearchNavEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context)
        navigateToStoreCategoryEvent,
    required TResult Function(String reqSearch, bool isFromStoreCategory)
        setSearchNavEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function() getCartCountEvent,
  }) {
    return setSearchNavEvent(reqSearch, isFromStoreCategory);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult? Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function()? getCartCountEvent,
  }) {
    return setSearchNavEvent?.call(reqSearch, isFromStoreCategory);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function()? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (setSearchNavEvent != null) {
      return setSearchNavEvent(reqSearch, isFromStoreCategory);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_NavigateToStoreCategoryEvent value)
        navigateToStoreCategoryEvent,
    required TResult Function(_SetSearchNavEvent value) setSearchNavEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
  }) {
    return setSearchNavEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult? Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
  }) {
    return setSearchNavEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (setSearchNavEvent != null) {
      return setSearchNavEvent(this);
    }
    return orElse();
  }
}

abstract class _SetSearchNavEvent implements ProductCategoryEvent {
  const factory _SetSearchNavEvent(
      {required final String reqSearch,
      required final bool isFromStoreCategory}) = _$SetSearchNavEventImpl;

  String get reqSearch;
  bool get isFromStoreCategory;
  @JsonKey(ignore: true)
  _$$SetSearchNavEventImplCopyWith<_$SetSearchNavEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  factory _$$UpdateGlobalSearchEventImplCopyWith(
          _$UpdateGlobalSearchEventImpl value,
          $Res Function(_$UpdateGlobalSearchEventImpl) then) =
      __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search, List<SearchModel> searchList});
}

/// @nodoc
class __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>
    extends _$ProductCategoryEventCopyWithImpl<$Res,
        _$UpdateGlobalSearchEventImpl>
    implements _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  __$$UpdateGlobalSearchEventImplCopyWithImpl(
      _$UpdateGlobalSearchEventImpl _value,
      $Res Function(_$UpdateGlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
    Object? searchList = null,
  }) {
    return _then(_$UpdateGlobalSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
    ));
  }
}

/// @nodoc

class _$UpdateGlobalSearchEventImpl implements _UpdateGlobalSearchEvent {
  const _$UpdateGlobalSearchEventImpl(
      {required this.search, required final List<SearchModel> searchList})
      : _searchList = searchList;

  @override
  final String search;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  String toString() {
    return 'ProductCategoryEvent.updateGlobalSearchEvent(search: $search, searchList: $searchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateGlobalSearchEventImpl &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, search, const DeepCollectionEquality().hash(_searchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => __$$UpdateGlobalSearchEventImplCopyWithImpl<
          _$UpdateGlobalSearchEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context)
        navigateToStoreCategoryEvent,
    required TResult Function(String reqSearch, bool isFromStoreCategory)
        setSearchNavEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function() getCartCountEvent,
  }) {
    return updateGlobalSearchEvent(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult? Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function()? getCartCountEvent,
  }) {
    return updateGlobalSearchEvent?.call(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function()? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(search, searchList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_NavigateToStoreCategoryEvent value)
        navigateToStoreCategoryEvent,
    required TResult Function(_SetSearchNavEvent value) setSearchNavEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
  }) {
    return updateGlobalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult? Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
  }) {
    return updateGlobalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateGlobalSearchEvent implements ProductCategoryEvent {
  const factory _UpdateGlobalSearchEvent(
          {required final String search,
          required final List<SearchModel> searchList}) =
      _$UpdateGlobalSearchEventImpl;

  String get search;
  List<SearchModel> get searchList;
  @JsonKey(ignore: true)
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$ProductCategoryEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductCategoryEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context)
        navigateToStoreCategoryEvent,
    required TResult Function(String reqSearch, bool isFromStoreCategory)
        setSearchNavEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function() getCartCountEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult? Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function()? getCartCountEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function()? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_NavigateToStoreCategoryEvent value)
        navigateToStoreCategoryEvent,
    required TResult Function(_SetSearchNavEvent value) setSearchNavEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult? Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements ProductCategoryEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getCartCountEventImplCopyWith<$Res> {
  factory _$$getCartCountEventImplCopyWith(_$getCartCountEventImpl value,
          $Res Function(_$getCartCountEventImpl) then) =
      __$$getCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getCartCountEventImplCopyWithImpl<$Res>
    extends _$ProductCategoryEventCopyWithImpl<$Res, _$getCartCountEventImpl>
    implements _$$getCartCountEventImplCopyWith<$Res> {
  __$$getCartCountEventImplCopyWithImpl(_$getCartCountEventImpl _value,
      $Res Function(_$getCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getCartCountEventImpl implements _getCartCountEvent {
  const _$getCartCountEventImpl();

  @override
  String toString() {
    return 'ProductCategoryEvent.getCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context)
        navigateToStoreCategoryEvent,
    required TResult Function(String reqSearch, bool isFromStoreCategory)
        setSearchNavEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function() getCartCountEvent,
  }) {
    return getCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult? Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function()? getCartCountEvent,
  }) {
    return getCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? navigateToStoreCategoryEvent,
    TResult Function(String reqSearch, bool isFromStoreCategory)?
        setSearchNavEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function()? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_NavigateToStoreCategoryEvent value)
        navigateToStoreCategoryEvent,
    required TResult Function(_SetSearchNavEvent value) setSearchNavEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
  }) {
    return getCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult? Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
  }) {
    return getCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_NavigateToStoreCategoryEvent value)?
        navigateToStoreCategoryEvent,
    TResult Function(_SetSearchNavEvent value)? setSearchNavEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _getCartCountEvent implements ProductCategoryEvent {
  const factory _getCartCountEvent() = _$getCartCountEventImpl;
}

/// @nodoc
mixin _$ProductCategoryState {
  List<Category> get productCategoryList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isBottomOfCategories => throw _privateConstructorUsedError;
  bool get isFromStoreCategory => throw _privateConstructorUsedError;
  List<SearchModel> get searchList => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  String get reqSearch => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  int get cartCount => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProductCategoryStateCopyWith<ProductCategoryState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductCategoryStateCopyWith<$Res> {
  factory $ProductCategoryStateCopyWith(ProductCategoryState value,
          $Res Function(ProductCategoryState) then) =
      _$ProductCategoryStateCopyWithImpl<$Res, ProductCategoryState>;
  @useResult
  $Res call(
      {List<Category> productCategoryList,
      bool isShimmering,
      bool isLoadMore,
      int pageNum,
      bool isBottomOfCategories,
      bool isFromStoreCategory,
      List<SearchModel> searchList,
      String search,
      String reqSearch,
      RefreshController refreshController,
      int cartCount});
}

/// @nodoc
class _$ProductCategoryStateCopyWithImpl<$Res,
        $Val extends ProductCategoryState>
    implements $ProductCategoryStateCopyWith<$Res> {
  _$ProductCategoryStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productCategoryList = null,
    Object? isShimmering = null,
    Object? isLoadMore = null,
    Object? pageNum = null,
    Object? isBottomOfCategories = null,
    Object? isFromStoreCategory = null,
    Object? searchList = null,
    Object? search = null,
    Object? reqSearch = null,
    Object? refreshController = null,
    Object? cartCount = null,
  }) {
    return _then(_value.copyWith(
      productCategoryList: null == productCategoryList
          ? _value.productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isBottomOfCategories: null == isBottomOfCategories
          ? _value.isBottomOfCategories
          : isBottomOfCategories // ignore: cast_nullable_to_non_nullable
              as bool,
      isFromStoreCategory: null == isFromStoreCategory
          ? _value.isFromStoreCategory
          : isFromStoreCategory // ignore: cast_nullable_to_non_nullable
              as bool,
      searchList: null == searchList
          ? _value.searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      reqSearch: null == reqSearch
          ? _value.reqSearch
          : reqSearch // ignore: cast_nullable_to_non_nullable
              as String,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductCategoryStateImplCopyWith<$Res>
    implements $ProductCategoryStateCopyWith<$Res> {
  factory _$$ProductCategoryStateImplCopyWith(_$ProductCategoryStateImpl value,
          $Res Function(_$ProductCategoryStateImpl) then) =
      __$$ProductCategoryStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Category> productCategoryList,
      bool isShimmering,
      bool isLoadMore,
      int pageNum,
      bool isBottomOfCategories,
      bool isFromStoreCategory,
      List<SearchModel> searchList,
      String search,
      String reqSearch,
      RefreshController refreshController,
      int cartCount});
}

/// @nodoc
class __$$ProductCategoryStateImplCopyWithImpl<$Res>
    extends _$ProductCategoryStateCopyWithImpl<$Res, _$ProductCategoryStateImpl>
    implements _$$ProductCategoryStateImplCopyWith<$Res> {
  __$$ProductCategoryStateImplCopyWithImpl(_$ProductCategoryStateImpl _value,
      $Res Function(_$ProductCategoryStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productCategoryList = null,
    Object? isShimmering = null,
    Object? isLoadMore = null,
    Object? pageNum = null,
    Object? isBottomOfCategories = null,
    Object? isFromStoreCategory = null,
    Object? searchList = null,
    Object? search = null,
    Object? reqSearch = null,
    Object? refreshController = null,
    Object? cartCount = null,
  }) {
    return _then(_$ProductCategoryStateImpl(
      productCategoryList: null == productCategoryList
          ? _value._productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isBottomOfCategories: null == isBottomOfCategories
          ? _value.isBottomOfCategories
          : isBottomOfCategories // ignore: cast_nullable_to_non_nullable
              as bool,
      isFromStoreCategory: null == isFromStoreCategory
          ? _value.isFromStoreCategory
          : isFromStoreCategory // ignore: cast_nullable_to_non_nullable
              as bool,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      reqSearch: null == reqSearch
          ? _value.reqSearch
          : reqSearch // ignore: cast_nullable_to_non_nullable
              as String,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$ProductCategoryStateImpl implements _ProductCategoryState {
  const _$ProductCategoryStateImpl(
      {required final List<Category> productCategoryList,
      required this.isShimmering,
      required this.isLoadMore,
      required this.pageNum,
      required this.isBottomOfCategories,
      required this.isFromStoreCategory,
      required final List<SearchModel> searchList,
      required this.search,
      required this.reqSearch,
      required this.refreshController,
      required this.cartCount})
      : _productCategoryList = productCategoryList,
        _searchList = searchList;

  final List<Category> _productCategoryList;
  @override
  List<Category> get productCategoryList {
    if (_productCategoryList is EqualUnmodifiableListView)
      return _productCategoryList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productCategoryList);
  }

  @override
  final bool isShimmering;
  @override
  final bool isLoadMore;
  @override
  final int pageNum;
  @override
  final bool isBottomOfCategories;
  @override
  final bool isFromStoreCategory;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  final String search;
  @override
  final String reqSearch;
  @override
  final RefreshController refreshController;
  @override
  final int cartCount;

  @override
  String toString() {
    return 'ProductCategoryState(productCategoryList: $productCategoryList, isShimmering: $isShimmering, isLoadMore: $isLoadMore, pageNum: $pageNum, isBottomOfCategories: $isBottomOfCategories, isFromStoreCategory: $isFromStoreCategory, searchList: $searchList, search: $search, reqSearch: $reqSearch, refreshController: $refreshController, cartCount: $cartCount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductCategoryStateImpl &&
            const DeepCollectionEquality()
                .equals(other._productCategoryList, _productCategoryList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isBottomOfCategories, isBottomOfCategories) ||
                other.isBottomOfCategories == isBottomOfCategories) &&
            (identical(other.isFromStoreCategory, isFromStoreCategory) ||
                other.isFromStoreCategory == isFromStoreCategory) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList) &&
            (identical(other.search, search) || other.search == search) &&
            (identical(other.reqSearch, reqSearch) ||
                other.reqSearch == reqSearch) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.cartCount, cartCount) ||
                other.cartCount == cartCount));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_productCategoryList),
      isShimmering,
      isLoadMore,
      pageNum,
      isBottomOfCategories,
      isFromStoreCategory,
      const DeepCollectionEquality().hash(_searchList),
      search,
      reqSearch,
      refreshController,
      cartCount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductCategoryStateImplCopyWith<_$ProductCategoryStateImpl>
      get copyWith =>
          __$$ProductCategoryStateImplCopyWithImpl<_$ProductCategoryStateImpl>(
              this, _$identity);
}

abstract class _ProductCategoryState implements ProductCategoryState {
  const factory _ProductCategoryState(
      {required final List<Category> productCategoryList,
      required final bool isShimmering,
      required final bool isLoadMore,
      required final int pageNum,
      required final bool isBottomOfCategories,
      required final bool isFromStoreCategory,
      required final List<SearchModel> searchList,
      required final String search,
      required final String reqSearch,
      required final RefreshController refreshController,
      required final int cartCount}) = _$ProductCategoryStateImpl;

  @override
  List<Category> get productCategoryList;
  @override
  bool get isShimmering;
  @override
  bool get isLoadMore;
  @override
  int get pageNum;
  @override
  bool get isBottomOfCategories;
  @override
  bool get isFromStoreCategory;
  @override
  List<SearchModel> get searchList;
  @override
  String get search;
  @override
  String get reqSearch;
  @override
  RefreshController get refreshController;
  @override
  int get cartCount;
  @override
  @JsonKey(ignore: true)
  _$$ProductCategoryStateImplCopyWith<_$ProductCategoryStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
