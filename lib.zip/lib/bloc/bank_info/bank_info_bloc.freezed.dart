// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'bank_info_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$BankInfoEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String bankName) selectBankEvent,
    required TResult Function(BuildContext context) getBankNameEvent,
    required TResult Function(
            BuildContext context, TermsConditionReqModel termsConditionReqModel)
        getTermsConditionModelEvent,
    required TResult Function(BuildContext context) termsConditionApiEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String bankName)? selectBankEvent,
    TResult? Function(BuildContext context)? getBankNameEvent,
    TResult? Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult? Function(BuildContext context)? termsConditionApiEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String bankName)? selectBankEvent,
    TResult Function(BuildContext context)? getBankNameEvent,
    TResult Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult Function(BuildContext context)? termsConditionApiEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectBankEvent value) selectBankEvent,
    required TResult Function(_getBankNameEvent value) getBankNameEvent,
    required TResult Function(_getTermsConditionModelEvent value)
        getTermsConditionModelEvent,
    required TResult Function(_termsConditionApiEvent value)
        termsConditionApiEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectBankEvent value)? selectBankEvent,
    TResult? Function(_getBankNameEvent value)? getBankNameEvent,
    TResult? Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult? Function(_termsConditionApiEvent value)? termsConditionApiEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectBankEvent value)? selectBankEvent,
    TResult Function(_getBankNameEvent value)? getBankNameEvent,
    TResult Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult Function(_termsConditionApiEvent value)? termsConditionApiEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BankInfoEventCopyWith<$Res> {
  factory $BankInfoEventCopyWith(
          BankInfoEvent value, $Res Function(BankInfoEvent) then) =
      _$BankInfoEventCopyWithImpl<$Res, BankInfoEvent>;
}

/// @nodoc
class _$BankInfoEventCopyWithImpl<$Res, $Val extends BankInfoEvent>
    implements $BankInfoEventCopyWith<$Res> {
  _$BankInfoEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$selectBankEventImplCopyWith<$Res> {
  factory _$$selectBankEventImplCopyWith(_$selectBankEventImpl value,
          $Res Function(_$selectBankEventImpl) then) =
      __$$selectBankEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String bankName});
}

/// @nodoc
class __$$selectBankEventImplCopyWithImpl<$Res>
    extends _$BankInfoEventCopyWithImpl<$Res, _$selectBankEventImpl>
    implements _$$selectBankEventImplCopyWith<$Res> {
  __$$selectBankEventImplCopyWithImpl(
      _$selectBankEventImpl _value, $Res Function(_$selectBankEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bankName = null,
  }) {
    return _then(_$selectBankEventImpl(
      bankName: null == bankName
          ? _value.bankName
          : bankName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$selectBankEventImpl implements _selectBankEvent {
  _$selectBankEventImpl({required this.bankName});

  @override
  final String bankName;

  @override
  String toString() {
    return 'BankInfoEvent.selectBankEvent(bankName: $bankName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$selectBankEventImpl &&
            (identical(other.bankName, bankName) ||
                other.bankName == bankName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, bankName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$selectBankEventImplCopyWith<_$selectBankEventImpl> get copyWith =>
      __$$selectBankEventImplCopyWithImpl<_$selectBankEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String bankName) selectBankEvent,
    required TResult Function(BuildContext context) getBankNameEvent,
    required TResult Function(
            BuildContext context, TermsConditionReqModel termsConditionReqModel)
        getTermsConditionModelEvent,
    required TResult Function(BuildContext context) termsConditionApiEvent,
  }) {
    return selectBankEvent(bankName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String bankName)? selectBankEvent,
    TResult? Function(BuildContext context)? getBankNameEvent,
    TResult? Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult? Function(BuildContext context)? termsConditionApiEvent,
  }) {
    return selectBankEvent?.call(bankName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String bankName)? selectBankEvent,
    TResult Function(BuildContext context)? getBankNameEvent,
    TResult Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult Function(BuildContext context)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (selectBankEvent != null) {
      return selectBankEvent(bankName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectBankEvent value) selectBankEvent,
    required TResult Function(_getBankNameEvent value) getBankNameEvent,
    required TResult Function(_getTermsConditionModelEvent value)
        getTermsConditionModelEvent,
    required TResult Function(_termsConditionApiEvent value)
        termsConditionApiEvent,
  }) {
    return selectBankEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectBankEvent value)? selectBankEvent,
    TResult? Function(_getBankNameEvent value)? getBankNameEvent,
    TResult? Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult? Function(_termsConditionApiEvent value)? termsConditionApiEvent,
  }) {
    return selectBankEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectBankEvent value)? selectBankEvent,
    TResult Function(_getBankNameEvent value)? getBankNameEvent,
    TResult Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult Function(_termsConditionApiEvent value)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (selectBankEvent != null) {
      return selectBankEvent(this);
    }
    return orElse();
  }
}

abstract class _selectBankEvent implements BankInfoEvent {
  factory _selectBankEvent({required final String bankName}) =
      _$selectBankEventImpl;

  String get bankName;
  @JsonKey(ignore: true)
  _$$selectBankEventImplCopyWith<_$selectBankEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getBankNameEventImplCopyWith<$Res> {
  factory _$$getBankNameEventImplCopyWith(_$getBankNameEventImpl value,
          $Res Function(_$getBankNameEventImpl) then) =
      __$$getBankNameEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getBankNameEventImplCopyWithImpl<$Res>
    extends _$BankInfoEventCopyWithImpl<$Res, _$getBankNameEventImpl>
    implements _$$getBankNameEventImplCopyWith<$Res> {
  __$$getBankNameEventImplCopyWithImpl(_$getBankNameEventImpl _value,
      $Res Function(_$getBankNameEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getBankNameEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getBankNameEventImpl implements _getBankNameEvent {
  _$getBankNameEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BankInfoEvent.getBankNameEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getBankNameEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getBankNameEventImplCopyWith<_$getBankNameEventImpl> get copyWith =>
      __$$getBankNameEventImplCopyWithImpl<_$getBankNameEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String bankName) selectBankEvent,
    required TResult Function(BuildContext context) getBankNameEvent,
    required TResult Function(
            BuildContext context, TermsConditionReqModel termsConditionReqModel)
        getTermsConditionModelEvent,
    required TResult Function(BuildContext context) termsConditionApiEvent,
  }) {
    return getBankNameEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String bankName)? selectBankEvent,
    TResult? Function(BuildContext context)? getBankNameEvent,
    TResult? Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult? Function(BuildContext context)? termsConditionApiEvent,
  }) {
    return getBankNameEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String bankName)? selectBankEvent,
    TResult Function(BuildContext context)? getBankNameEvent,
    TResult Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult Function(BuildContext context)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (getBankNameEvent != null) {
      return getBankNameEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectBankEvent value) selectBankEvent,
    required TResult Function(_getBankNameEvent value) getBankNameEvent,
    required TResult Function(_getTermsConditionModelEvent value)
        getTermsConditionModelEvent,
    required TResult Function(_termsConditionApiEvent value)
        termsConditionApiEvent,
  }) {
    return getBankNameEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectBankEvent value)? selectBankEvent,
    TResult? Function(_getBankNameEvent value)? getBankNameEvent,
    TResult? Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult? Function(_termsConditionApiEvent value)? termsConditionApiEvent,
  }) {
    return getBankNameEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectBankEvent value)? selectBankEvent,
    TResult Function(_getBankNameEvent value)? getBankNameEvent,
    TResult Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult Function(_termsConditionApiEvent value)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (getBankNameEvent != null) {
      return getBankNameEvent(this);
    }
    return orElse();
  }
}

abstract class _getBankNameEvent implements BankInfoEvent {
  factory _getBankNameEvent({required final BuildContext context}) =
      _$getBankNameEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getBankNameEventImplCopyWith<_$getBankNameEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getTermsConditionModelEventImplCopyWith<$Res> {
  factory _$$getTermsConditionModelEventImplCopyWith(
          _$getTermsConditionModelEventImpl value,
          $Res Function(_$getTermsConditionModelEventImpl) then) =
      __$$getTermsConditionModelEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context, TermsConditionReqModel termsConditionReqModel});

  $TermsConditionReqModelCopyWith<$Res> get termsConditionReqModel;
}

/// @nodoc
class __$$getTermsConditionModelEventImplCopyWithImpl<$Res>
    extends _$BankInfoEventCopyWithImpl<$Res, _$getTermsConditionModelEventImpl>
    implements _$$getTermsConditionModelEventImplCopyWith<$Res> {
  __$$getTermsConditionModelEventImplCopyWithImpl(
      _$getTermsConditionModelEventImpl _value,
      $Res Function(_$getTermsConditionModelEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? termsConditionReqModel = null,
  }) {
    return _then(_$getTermsConditionModelEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      termsConditionReqModel: null == termsConditionReqModel
          ? _value.termsConditionReqModel
          : termsConditionReqModel // ignore: cast_nullable_to_non_nullable
              as TermsConditionReqModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $TermsConditionReqModelCopyWith<$Res> get termsConditionReqModel {
    return $TermsConditionReqModelCopyWith<$Res>(_value.termsConditionReqModel,
        (value) {
      return _then(_value.copyWith(termsConditionReqModel: value));
    });
  }
}

/// @nodoc

class _$getTermsConditionModelEventImpl
    implements _getTermsConditionModelEvent {
  _$getTermsConditionModelEventImpl(
      {required this.context, required this.termsConditionReqModel});

  @override
  final BuildContext context;
  @override
  final TermsConditionReqModel termsConditionReqModel;

  @override
  String toString() {
    return 'BankInfoEvent.getTermsConditionModelEvent(context: $context, termsConditionReqModel: $termsConditionReqModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getTermsConditionModelEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.termsConditionReqModel, termsConditionReqModel) ||
                other.termsConditionReqModel == termsConditionReqModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, termsConditionReqModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getTermsConditionModelEventImplCopyWith<_$getTermsConditionModelEventImpl>
      get copyWith => __$$getTermsConditionModelEventImplCopyWithImpl<
          _$getTermsConditionModelEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String bankName) selectBankEvent,
    required TResult Function(BuildContext context) getBankNameEvent,
    required TResult Function(
            BuildContext context, TermsConditionReqModel termsConditionReqModel)
        getTermsConditionModelEvent,
    required TResult Function(BuildContext context) termsConditionApiEvent,
  }) {
    return getTermsConditionModelEvent(context, termsConditionReqModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String bankName)? selectBankEvent,
    TResult? Function(BuildContext context)? getBankNameEvent,
    TResult? Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult? Function(BuildContext context)? termsConditionApiEvent,
  }) {
    return getTermsConditionModelEvent?.call(context, termsConditionReqModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String bankName)? selectBankEvent,
    TResult Function(BuildContext context)? getBankNameEvent,
    TResult Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult Function(BuildContext context)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (getTermsConditionModelEvent != null) {
      return getTermsConditionModelEvent(context, termsConditionReqModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectBankEvent value) selectBankEvent,
    required TResult Function(_getBankNameEvent value) getBankNameEvent,
    required TResult Function(_getTermsConditionModelEvent value)
        getTermsConditionModelEvent,
    required TResult Function(_termsConditionApiEvent value)
        termsConditionApiEvent,
  }) {
    return getTermsConditionModelEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectBankEvent value)? selectBankEvent,
    TResult? Function(_getBankNameEvent value)? getBankNameEvent,
    TResult? Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult? Function(_termsConditionApiEvent value)? termsConditionApiEvent,
  }) {
    return getTermsConditionModelEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectBankEvent value)? selectBankEvent,
    TResult Function(_getBankNameEvent value)? getBankNameEvent,
    TResult Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult Function(_termsConditionApiEvent value)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (getTermsConditionModelEvent != null) {
      return getTermsConditionModelEvent(this);
    }
    return orElse();
  }
}

abstract class _getTermsConditionModelEvent implements BankInfoEvent {
  factory _getTermsConditionModelEvent(
          {required final BuildContext context,
          required final TermsConditionReqModel termsConditionReqModel}) =
      _$getTermsConditionModelEventImpl;

  BuildContext get context;
  TermsConditionReqModel get termsConditionReqModel;
  @JsonKey(ignore: true)
  _$$getTermsConditionModelEventImplCopyWith<_$getTermsConditionModelEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$termsConditionApiEventImplCopyWith<$Res> {
  factory _$$termsConditionApiEventImplCopyWith(
          _$termsConditionApiEventImpl value,
          $Res Function(_$termsConditionApiEventImpl) then) =
      __$$termsConditionApiEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$termsConditionApiEventImplCopyWithImpl<$Res>
    extends _$BankInfoEventCopyWithImpl<$Res, _$termsConditionApiEventImpl>
    implements _$$termsConditionApiEventImplCopyWith<$Res> {
  __$$termsConditionApiEventImplCopyWithImpl(
      _$termsConditionApiEventImpl _value,
      $Res Function(_$termsConditionApiEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$termsConditionApiEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$termsConditionApiEventImpl implements _termsConditionApiEvent {
  _$termsConditionApiEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BankInfoEvent.termsConditionApiEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$termsConditionApiEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$termsConditionApiEventImplCopyWith<_$termsConditionApiEventImpl>
      get copyWith => __$$termsConditionApiEventImplCopyWithImpl<
          _$termsConditionApiEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String bankName) selectBankEvent,
    required TResult Function(BuildContext context) getBankNameEvent,
    required TResult Function(
            BuildContext context, TermsConditionReqModel termsConditionReqModel)
        getTermsConditionModelEvent,
    required TResult Function(BuildContext context) termsConditionApiEvent,
  }) {
    return termsConditionApiEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String bankName)? selectBankEvent,
    TResult? Function(BuildContext context)? getBankNameEvent,
    TResult? Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult? Function(BuildContext context)? termsConditionApiEvent,
  }) {
    return termsConditionApiEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String bankName)? selectBankEvent,
    TResult Function(BuildContext context)? getBankNameEvent,
    TResult Function(BuildContext context,
            TermsConditionReqModel termsConditionReqModel)?
        getTermsConditionModelEvent,
    TResult Function(BuildContext context)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (termsConditionApiEvent != null) {
      return termsConditionApiEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectBankEvent value) selectBankEvent,
    required TResult Function(_getBankNameEvent value) getBankNameEvent,
    required TResult Function(_getTermsConditionModelEvent value)
        getTermsConditionModelEvent,
    required TResult Function(_termsConditionApiEvent value)
        termsConditionApiEvent,
  }) {
    return termsConditionApiEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectBankEvent value)? selectBankEvent,
    TResult? Function(_getBankNameEvent value)? getBankNameEvent,
    TResult? Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult? Function(_termsConditionApiEvent value)? termsConditionApiEvent,
  }) {
    return termsConditionApiEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectBankEvent value)? selectBankEvent,
    TResult Function(_getBankNameEvent value)? getBankNameEvent,
    TResult Function(_getTermsConditionModelEvent value)?
        getTermsConditionModelEvent,
    TResult Function(_termsConditionApiEvent value)? termsConditionApiEvent,
    required TResult orElse(),
  }) {
    if (termsConditionApiEvent != null) {
      return termsConditionApiEvent(this);
    }
    return orElse();
  }
}

abstract class _termsConditionApiEvent implements BankInfoEvent {
  factory _termsConditionApiEvent({required final BuildContext context}) =
      _$termsConditionApiEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$termsConditionApiEventImplCopyWith<_$termsConditionApiEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$BankInfoState {
  List<BankDetail> get bankList => throw _privateConstructorUsedError;
  String get bankName => throw _privateConstructorUsedError;
  TextEditingController get accountNumberController =>
      throw _privateConstructorUsedError;
  TextEditingController get branchController =>
      throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isApiShimmering => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $BankInfoStateCopyWith<BankInfoState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BankInfoStateCopyWith<$Res> {
  factory $BankInfoStateCopyWith(
          BankInfoState value, $Res Function(BankInfoState) then) =
      _$BankInfoStateCopyWithImpl<$Res, BankInfoState>;
  @useResult
  $Res call(
      {List<BankDetail> bankList,
      String bankName,
      TextEditingController accountNumberController,
      TextEditingController branchController,
      bool isShimmering,
      bool isApiShimmering,
      bool isUpdate});
}

/// @nodoc
class _$BankInfoStateCopyWithImpl<$Res, $Val extends BankInfoState>
    implements $BankInfoStateCopyWith<$Res> {
  _$BankInfoStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bankList = null,
    Object? bankName = null,
    Object? accountNumberController = null,
    Object? branchController = null,
    Object? isShimmering = null,
    Object? isApiShimmering = null,
    Object? isUpdate = null,
  }) {
    return _then(_value.copyWith(
      bankList: null == bankList
          ? _value.bankList
          : bankList // ignore: cast_nullable_to_non_nullable
              as List<BankDetail>,
      bankName: null == bankName
          ? _value.bankName
          : bankName // ignore: cast_nullable_to_non_nullable
              as String,
      accountNumberController: null == accountNumberController
          ? _value.accountNumberController
          : accountNumberController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      branchController: null == branchController
          ? _value.branchController
          : branchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isApiShimmering: null == isApiShimmering
          ? _value.isApiShimmering
          : isApiShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$BankInfoStateImplCopyWith<$Res>
    implements $BankInfoStateCopyWith<$Res> {
  factory _$$BankInfoStateImplCopyWith(
          _$BankInfoStateImpl value, $Res Function(_$BankInfoStateImpl) then) =
      __$$BankInfoStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<BankDetail> bankList,
      String bankName,
      TextEditingController accountNumberController,
      TextEditingController branchController,
      bool isShimmering,
      bool isApiShimmering,
      bool isUpdate});
}

/// @nodoc
class __$$BankInfoStateImplCopyWithImpl<$Res>
    extends _$BankInfoStateCopyWithImpl<$Res, _$BankInfoStateImpl>
    implements _$$BankInfoStateImplCopyWith<$Res> {
  __$$BankInfoStateImplCopyWithImpl(
      _$BankInfoStateImpl _value, $Res Function(_$BankInfoStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? bankList = null,
    Object? bankName = null,
    Object? accountNumberController = null,
    Object? branchController = null,
    Object? isShimmering = null,
    Object? isApiShimmering = null,
    Object? isUpdate = null,
  }) {
    return _then(_$BankInfoStateImpl(
      bankList: null == bankList
          ? _value._bankList
          : bankList // ignore: cast_nullable_to_non_nullable
              as List<BankDetail>,
      bankName: null == bankName
          ? _value.bankName
          : bankName // ignore: cast_nullable_to_non_nullable
              as String,
      accountNumberController: null == accountNumberController
          ? _value.accountNumberController
          : accountNumberController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      branchController: null == branchController
          ? _value.branchController
          : branchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isApiShimmering: null == isApiShimmering
          ? _value.isApiShimmering
          : isApiShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$BankInfoStateImpl implements _BankInfoState {
  const _$BankInfoStateImpl(
      {required final List<BankDetail> bankList,
      required this.bankName,
      required this.accountNumberController,
      required this.branchController,
      required this.isShimmering,
      required this.isApiShimmering,
      required this.isUpdate})
      : _bankList = bankList;

  final List<BankDetail> _bankList;
  @override
  List<BankDetail> get bankList {
    if (_bankList is EqualUnmodifiableListView) return _bankList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_bankList);
  }

  @override
  final String bankName;
  @override
  final TextEditingController accountNumberController;
  @override
  final TextEditingController branchController;
  @override
  final bool isShimmering;
  @override
  final bool isApiShimmering;
  @override
  final bool isUpdate;

  @override
  String toString() {
    return 'BankInfoState(bankList: $bankList, bankName: $bankName, accountNumberController: $accountNumberController, branchController: $branchController, isShimmering: $isShimmering, isApiShimmering: $isApiShimmering, isUpdate: $isUpdate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BankInfoStateImpl &&
            const DeepCollectionEquality().equals(other._bankList, _bankList) &&
            (identical(other.bankName, bankName) ||
                other.bankName == bankName) &&
            (identical(
                    other.accountNumberController, accountNumberController) ||
                other.accountNumberController == accountNumberController) &&
            (identical(other.branchController, branchController) ||
                other.branchController == branchController) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isApiShimmering, isApiShimmering) ||
                other.isApiShimmering == isApiShimmering) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_bankList),
      bankName,
      accountNumberController,
      branchController,
      isShimmering,
      isApiShimmering,
      isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BankInfoStateImplCopyWith<_$BankInfoStateImpl> get copyWith =>
      __$$BankInfoStateImplCopyWithImpl<_$BankInfoStateImpl>(this, _$identity);
}

abstract class _BankInfoState implements BankInfoState {
  const factory _BankInfoState(
      {required final List<BankDetail> bankList,
      required final String bankName,
      required final TextEditingController accountNumberController,
      required final TextEditingController branchController,
      required final bool isShimmering,
      required final bool isApiShimmering,
      required final bool isUpdate}) = _$BankInfoStateImpl;

  @override
  List<BankDetail> get bankList;
  @override
  String get bankName;
  @override
  TextEditingController get accountNumberController;
  @override
  TextEditingController get branchController;
  @override
  bool get isShimmering;
  @override
  bool get isApiShimmering;
  @override
  bool get isUpdate;
  @override
  @JsonKey(ignore: true)
  _$$BankInfoStateImplCopyWith<_$BankInfoStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
