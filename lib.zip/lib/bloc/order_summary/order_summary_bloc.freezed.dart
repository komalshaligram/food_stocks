// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'order_summary_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$OrderSummaryEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, GetAllCartResModel CartItemList)
        getDataEvent,
    required TResult Function(BuildContext context) orderSendEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, GetAllCartResModel CartItemList)?
        getDataEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, GetAllCartResModel CartItemList)?
        getDataEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getDataEvent value) getDataEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getDataEvent value)? getDataEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getDataEvent value)? getDataEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OrderSummaryEventCopyWith<OrderSummaryEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderSummaryEventCopyWith<$Res> {
  factory $OrderSummaryEventCopyWith(
          OrderSummaryEvent value, $Res Function(OrderSummaryEvent) then) =
      _$OrderSummaryEventCopyWithImpl<$Res, OrderSummaryEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$OrderSummaryEventCopyWithImpl<$Res, $Val extends OrderSummaryEvent>
    implements $OrderSummaryEventCopyWith<$Res> {
  _$OrderSummaryEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$getDataEventImplCopyWith<$Res>
    implements $OrderSummaryEventCopyWith<$Res> {
  factory _$$getDataEventImplCopyWith(
          _$getDataEventImpl value, $Res Function(_$getDataEventImpl) then) =
      __$$getDataEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, GetAllCartResModel CartItemList});

  $GetAllCartResModelCopyWith<$Res> get CartItemList;
}

/// @nodoc
class __$$getDataEventImplCopyWithImpl<$Res>
    extends _$OrderSummaryEventCopyWithImpl<$Res, _$getDataEventImpl>
    implements _$$getDataEventImplCopyWith<$Res> {
  __$$getDataEventImplCopyWithImpl(
      _$getDataEventImpl _value, $Res Function(_$getDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? CartItemList = null,
  }) {
    return _then(_$getDataEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      CartItemList: null == CartItemList
          ? _value.CartItemList
          : CartItemList // ignore: cast_nullable_to_non_nullable
              as GetAllCartResModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $GetAllCartResModelCopyWith<$Res> get CartItemList {
    return $GetAllCartResModelCopyWith<$Res>(_value.CartItemList, (value) {
      return _then(_value.copyWith(CartItemList: value));
    });
  }
}

/// @nodoc

class _$getDataEventImpl implements _getDataEvent {
  const _$getDataEventImpl({required this.context, required this.CartItemList});

  @override
  final BuildContext context;
  @override
  final GetAllCartResModel CartItemList;

  @override
  String toString() {
    return 'OrderSummaryEvent.getDataEvent(context: $context, CartItemList: $CartItemList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getDataEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.CartItemList, CartItemList) ||
                other.CartItemList == CartItemList));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, CartItemList);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getDataEventImplCopyWith<_$getDataEventImpl> get copyWith =>
      __$$getDataEventImplCopyWithImpl<_$getDataEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, GetAllCartResModel CartItemList)
        getDataEvent,
    required TResult Function(BuildContext context) orderSendEvent,
  }) {
    return getDataEvent(context, CartItemList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, GetAllCartResModel CartItemList)?
        getDataEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
  }) {
    return getDataEvent?.call(context, CartItemList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, GetAllCartResModel CartItemList)?
        getDataEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    required TResult orElse(),
  }) {
    if (getDataEvent != null) {
      return getDataEvent(context, CartItemList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getDataEvent value) getDataEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
  }) {
    return getDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getDataEvent value)? getDataEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
  }) {
    return getDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getDataEvent value)? getDataEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    required TResult orElse(),
  }) {
    if (getDataEvent != null) {
      return getDataEvent(this);
    }
    return orElse();
  }
}

abstract class _getDataEvent implements OrderSummaryEvent {
  const factory _getDataEvent(
      {required final BuildContext context,
      required final GetAllCartResModel CartItemList}) = _$getDataEventImpl;

  @override
  BuildContext get context;
  GetAllCartResModel get CartItemList;
  @override
  @JsonKey(ignore: true)
  _$$getDataEventImplCopyWith<_$getDataEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$orderSendEventImplCopyWith<$Res>
    implements $OrderSummaryEventCopyWith<$Res> {
  factory _$$orderSendEventImplCopyWith(_$orderSendEventImpl value,
          $Res Function(_$orderSendEventImpl) then) =
      __$$orderSendEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$orderSendEventImplCopyWithImpl<$Res>
    extends _$OrderSummaryEventCopyWithImpl<$Res, _$orderSendEventImpl>
    implements _$$orderSendEventImplCopyWith<$Res> {
  __$$orderSendEventImplCopyWithImpl(
      _$orderSendEventImpl _value, $Res Function(_$orderSendEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$orderSendEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$orderSendEventImpl implements _orderSendEvent {
  const _$orderSendEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'OrderSummaryEvent.orderSendEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$orderSendEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$orderSendEventImplCopyWith<_$orderSendEventImpl> get copyWith =>
      __$$orderSendEventImplCopyWithImpl<_$orderSendEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, GetAllCartResModel CartItemList)
        getDataEvent,
    required TResult Function(BuildContext context) orderSendEvent,
  }) {
    return orderSendEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, GetAllCartResModel CartItemList)?
        getDataEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
  }) {
    return orderSendEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, GetAllCartResModel CartItemList)?
        getDataEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    required TResult orElse(),
  }) {
    if (orderSendEvent != null) {
      return orderSendEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getDataEvent value) getDataEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
  }) {
    return orderSendEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getDataEvent value)? getDataEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
  }) {
    return orderSendEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getDataEvent value)? getDataEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    required TResult orElse(),
  }) {
    if (orderSendEvent != null) {
      return orderSendEvent(this);
    }
    return orElse();
  }
}

abstract class _orderSendEvent implements OrderSummaryEvent {
  const factory _orderSendEvent({required final BuildContext context}) =
      _$orderSendEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$orderSendEventImplCopyWith<_$orderSendEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$OrderSummaryState {
  CartProductsSupplierResModel get orderSummaryList =>
      throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isEnable => throw _privateConstructorUsedError;
  GetAllCartResModel get CartItemList => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OrderSummaryStateCopyWith<OrderSummaryState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderSummaryStateCopyWith<$Res> {
  factory $OrderSummaryStateCopyWith(
          OrderSummaryState value, $Res Function(OrderSummaryState) then) =
      _$OrderSummaryStateCopyWithImpl<$Res, OrderSummaryState>;
  @useResult
  $Res call(
      {CartProductsSupplierResModel orderSummaryList,
      bool isLoading,
      bool isShimmering,
      bool isEnable,
      GetAllCartResModel CartItemList,
      String language});

  $CartProductsSupplierResModelCopyWith<$Res> get orderSummaryList;
  $GetAllCartResModelCopyWith<$Res> get CartItemList;
}

/// @nodoc
class _$OrderSummaryStateCopyWithImpl<$Res, $Val extends OrderSummaryState>
    implements $OrderSummaryStateCopyWith<$Res> {
  _$OrderSummaryStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderSummaryList = null,
    Object? isLoading = null,
    Object? isShimmering = null,
    Object? isEnable = null,
    Object? CartItemList = null,
    Object? language = null,
  }) {
    return _then(_value.copyWith(
      orderSummaryList: null == orderSummaryList
          ? _value.orderSummaryList
          : orderSummaryList // ignore: cast_nullable_to_non_nullable
              as CartProductsSupplierResModel,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isEnable: null == isEnable
          ? _value.isEnable
          : isEnable // ignore: cast_nullable_to_non_nullable
              as bool,
      CartItemList: null == CartItemList
          ? _value.CartItemList
          : CartItemList // ignore: cast_nullable_to_non_nullable
              as GetAllCartResModel,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $CartProductsSupplierResModelCopyWith<$Res> get orderSummaryList {
    return $CartProductsSupplierResModelCopyWith<$Res>(_value.orderSummaryList,
        (value) {
      return _then(_value.copyWith(orderSummaryList: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $GetAllCartResModelCopyWith<$Res> get CartItemList {
    return $GetAllCartResModelCopyWith<$Res>(_value.CartItemList, (value) {
      return _then(_value.copyWith(CartItemList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$OrderSummaryStateImplCopyWith<$Res>
    implements $OrderSummaryStateCopyWith<$Res> {
  factory _$$OrderSummaryStateImplCopyWith(_$OrderSummaryStateImpl value,
          $Res Function(_$OrderSummaryStateImpl) then) =
      __$$OrderSummaryStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {CartProductsSupplierResModel orderSummaryList,
      bool isLoading,
      bool isShimmering,
      bool isEnable,
      GetAllCartResModel CartItemList,
      String language});

  @override
  $CartProductsSupplierResModelCopyWith<$Res> get orderSummaryList;
  @override
  $GetAllCartResModelCopyWith<$Res> get CartItemList;
}

/// @nodoc
class __$$OrderSummaryStateImplCopyWithImpl<$Res>
    extends _$OrderSummaryStateCopyWithImpl<$Res, _$OrderSummaryStateImpl>
    implements _$$OrderSummaryStateImplCopyWith<$Res> {
  __$$OrderSummaryStateImplCopyWithImpl(_$OrderSummaryStateImpl _value,
      $Res Function(_$OrderSummaryStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderSummaryList = null,
    Object? isLoading = null,
    Object? isShimmering = null,
    Object? isEnable = null,
    Object? CartItemList = null,
    Object? language = null,
  }) {
    return _then(_$OrderSummaryStateImpl(
      orderSummaryList: null == orderSummaryList
          ? _value.orderSummaryList
          : orderSummaryList // ignore: cast_nullable_to_non_nullable
              as CartProductsSupplierResModel,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isEnable: null == isEnable
          ? _value.isEnable
          : isEnable // ignore: cast_nullable_to_non_nullable
              as bool,
      CartItemList: null == CartItemList
          ? _value.CartItemList
          : CartItemList // ignore: cast_nullable_to_non_nullable
              as GetAllCartResModel,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$OrderSummaryStateImpl implements _OrderSummaryState {
  const _$OrderSummaryStateImpl(
      {required this.orderSummaryList,
      required this.isLoading,
      required this.isShimmering,
      required this.isEnable,
      required this.CartItemList,
      required this.language});

  @override
  final CartProductsSupplierResModel orderSummaryList;
  @override
  final bool isLoading;
  @override
  final bool isShimmering;
  @override
  final bool isEnable;
  @override
  final GetAllCartResModel CartItemList;
  @override
  final String language;

  @override
  String toString() {
    return 'OrderSummaryState(orderSummaryList: $orderSummaryList, isLoading: $isLoading, isShimmering: $isShimmering, isEnable: $isEnable, CartItemList: $CartItemList, language: $language)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OrderSummaryStateImpl &&
            (identical(other.orderSummaryList, orderSummaryList) ||
                other.orderSummaryList == orderSummaryList) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isEnable, isEnable) ||
                other.isEnable == isEnable) &&
            (identical(other.CartItemList, CartItemList) ||
                other.CartItemList == CartItemList) &&
            (identical(other.language, language) ||
                other.language == language));
  }

  @override
  int get hashCode => Object.hash(runtimeType, orderSummaryList, isLoading,
      isShimmering, isEnable, CartItemList, language);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OrderSummaryStateImplCopyWith<_$OrderSummaryStateImpl> get copyWith =>
      __$$OrderSummaryStateImplCopyWithImpl<_$OrderSummaryStateImpl>(
          this, _$identity);
}

abstract class _OrderSummaryState implements OrderSummaryState {
  const factory _OrderSummaryState(
      {required final CartProductsSupplierResModel orderSummaryList,
      required final bool isLoading,
      required final bool isShimmering,
      required final bool isEnable,
      required final GetAllCartResModel CartItemList,
      required final String language}) = _$OrderSummaryStateImpl;

  @override
  CartProductsSupplierResModel get orderSummaryList;
  @override
  bool get isLoading;
  @override
  bool get isShimmering;
  @override
  bool get isEnable;
  @override
  GetAllCartResModel get CartItemList;
  @override
  String get language;
  @override
  @JsonKey(ignore: true)
  _$$OrderSummaryStateImplCopyWith<_$OrderSummaryStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
