// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'store_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$StoreEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StoreEventCopyWith<$Res> {
  factory $StoreEventCopyWith(
          StoreEvent value, $Res Function(StoreEvent) then) =
      _$StoreEventCopyWithImpl<$Res, StoreEvent>;
}

/// @nodoc
class _$StoreEventCopyWithImpl<$Res, $Val extends StoreEvent>
    implements $StoreEventCopyWith<$Res> {
  _$StoreEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  factory _$$ChangeCategoryExpansionImplCopyWith(
          _$ChangeCategoryExpansionImpl value,
          $Res Function(_$ChangeCategoryExpansionImpl) then) =
      __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isOpened});
}

/// @nodoc
class __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$ChangeCategoryExpansionImpl>
    implements _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  __$$ChangeCategoryExpansionImplCopyWithImpl(
      _$ChangeCategoryExpansionImpl _value,
      $Res Function(_$ChangeCategoryExpansionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isOpened = freezed,
  }) {
    return _then(_$ChangeCategoryExpansionImpl(
      isOpened: freezed == isOpened
          ? _value.isOpened
          : isOpened // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeCategoryExpansionImpl implements _ChangeCategoryExpansion {
  const _$ChangeCategoryExpansionImpl({this.isOpened});

  @override
  final bool? isOpened;

  @override
  String toString() {
    return 'StoreEvent.changeCategoryExpansion(isOpened: $isOpened)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeCategoryExpansionImpl &&
            (identical(other.isOpened, isOpened) ||
                other.isOpened == isOpened));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isOpened);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => __$$ChangeCategoryExpansionImplCopyWithImpl<
          _$ChangeCategoryExpansionImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeCategoryExpansion(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(isOpened);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeCategoryExpansion(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(this);
    }
    return orElse();
  }
}

abstract class _ChangeCategoryExpansion implements StoreEvent {
  const factory _ChangeCategoryExpansion({final bool? isOpened}) =
      _$ChangeCategoryExpansionImpl;

  bool? get isOpened;
  @JsonKey(ignore: true)
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  factory _$$GetProductCategoriesListEventImplCopyWith(
          _$GetProductCategoriesListEventImpl value,
          $Res Function(_$GetProductCategoriesListEventImpl) then) =
      __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$GetProductCategoriesListEventImpl>
    implements _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  __$$GetProductCategoriesListEventImplCopyWithImpl(
      _$GetProductCategoriesListEventImpl _value,
      $Res Function(_$GetProductCategoriesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductCategoriesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductCategoriesListEventImpl
    implements _GetProductCategoriesListEvent {
  const _$GetProductCategoriesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.getProductCategoriesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductCategoriesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => __$$GetProductCategoriesListEventImplCopyWithImpl<
          _$GetProductCategoriesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductCategoriesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductCategoriesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductCategoriesListEvent implements StoreEvent {
  const factory _GetProductCategoriesListEvent(
          {required final BuildContext context}) =
      _$GetProductCategoriesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductSalesListEventImplCopyWith<$Res> {
  factory _$$GetProductSalesListEventImplCopyWith(
          _$GetProductSalesListEventImpl value,
          $Res Function(_$GetProductSalesListEventImpl) then) =
      __$$GetProductSalesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductSalesListEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$GetProductSalesListEventImpl>
    implements _$$GetProductSalesListEventImplCopyWith<$Res> {
  __$$GetProductSalesListEventImplCopyWithImpl(
      _$GetProductSalesListEventImpl _value,
      $Res Function(_$GetProductSalesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductSalesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductSalesListEventImpl implements _GetProductSalesListEvent {
  const _$GetProductSalesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.getProductSalesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductSalesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductSalesListEventImplCopyWith<_$GetProductSalesListEventImpl>
      get copyWith => __$$GetProductSalesListEventImplCopyWithImpl<
          _$GetProductSalesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductSalesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductSalesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductSalesListEvent != null) {
      return getProductSalesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductSalesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductSalesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductSalesListEvent != null) {
      return getProductSalesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductSalesListEvent implements StoreEvent {
  const factory _GetProductSalesListEvent(
      {required final BuildContext context}) = _$GetProductSalesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductSalesListEventImplCopyWith<_$GetProductSalesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetRecommendationProductsListEventImplCopyWith<$Res> {
  factory _$$GetRecommendationProductsListEventImplCopyWith(
          _$GetRecommendationProductsListEventImpl value,
          $Res Function(_$GetRecommendationProductsListEventImpl) then) =
      __$$GetRecommendationProductsListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetRecommendationProductsListEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res,
        _$GetRecommendationProductsListEventImpl>
    implements _$$GetRecommendationProductsListEventImplCopyWith<$Res> {
  __$$GetRecommendationProductsListEventImplCopyWithImpl(
      _$GetRecommendationProductsListEventImpl _value,
      $Res Function(_$GetRecommendationProductsListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetRecommendationProductsListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetRecommendationProductsListEventImpl
    implements _GetRecommendationProductsListEvent {
  const _$GetRecommendationProductsListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.getRecommendationProductsListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetRecommendationProductsListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetRecommendationProductsListEventImplCopyWith<
          _$GetRecommendationProductsListEventImpl>
      get copyWith => __$$GetRecommendationProductsListEventImplCopyWithImpl<
          _$GetRecommendationProductsListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getRecommendationProductsListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getRecommendationProductsListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getRecommendationProductsListEvent != null) {
      return getRecommendationProductsListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getRecommendationProductsListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getRecommendationProductsListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getRecommendationProductsListEvent != null) {
      return getRecommendationProductsListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetRecommendationProductsListEvent implements StoreEvent {
  const factory _GetRecommendationProductsListEvent(
          {required final BuildContext context}) =
      _$GetRecommendationProductsListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetRecommendationProductsListEventImplCopyWith<
          _$GetRecommendationProductsListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetPreviousOrderProductsListEventImplCopyWith<$Res> {
  factory _$$GetPreviousOrderProductsListEventImplCopyWith(
          _$GetPreviousOrderProductsListEventImpl value,
          $Res Function(_$GetPreviousOrderProductsListEventImpl) then) =
      __$$GetPreviousOrderProductsListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetPreviousOrderProductsListEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res,
        _$GetPreviousOrderProductsListEventImpl>
    implements _$$GetPreviousOrderProductsListEventImplCopyWith<$Res> {
  __$$GetPreviousOrderProductsListEventImplCopyWithImpl(
      _$GetPreviousOrderProductsListEventImpl _value,
      $Res Function(_$GetPreviousOrderProductsListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetPreviousOrderProductsListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetPreviousOrderProductsListEventImpl
    implements _GetPreviousOrderProductsListEvent {
  const _$GetPreviousOrderProductsListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.getPreviousOrderProductsListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetPreviousOrderProductsListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetPreviousOrderProductsListEventImplCopyWith<
          _$GetPreviousOrderProductsListEventImpl>
      get copyWith => __$$GetPreviousOrderProductsListEventImplCopyWithImpl<
          _$GetPreviousOrderProductsListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPreviousOrderProductsListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPreviousOrderProductsListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPreviousOrderProductsListEvent != null) {
      return getPreviousOrderProductsListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPreviousOrderProductsListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPreviousOrderProductsListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPreviousOrderProductsListEvent != null) {
      return getPreviousOrderProductsListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetPreviousOrderProductsListEvent implements StoreEvent {
  const factory _GetPreviousOrderProductsListEvent(
          {required final BuildContext context}) =
      _$GetPreviousOrderProductsListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetPreviousOrderProductsListEventImplCopyWith<
          _$GetPreviousOrderProductsListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSearchListEventImplCopyWith<$Res> {
  factory _$$ChangeSearchListEventImplCopyWith(
          _$ChangeSearchListEventImpl value,
          $Res Function(_$ChangeSearchListEventImpl) then) =
      __$$ChangeSearchListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({List<SearchModel> newSearchList});
}

/// @nodoc
class __$$ChangeSearchListEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$ChangeSearchListEventImpl>
    implements _$$ChangeSearchListEventImplCopyWith<$Res> {
  __$$ChangeSearchListEventImplCopyWithImpl(_$ChangeSearchListEventImpl _value,
      $Res Function(_$ChangeSearchListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newSearchList = null,
  }) {
    return _then(_$ChangeSearchListEventImpl(
      newSearchList: null == newSearchList
          ? _value._newSearchList
          : newSearchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
    ));
  }
}

/// @nodoc

class _$ChangeSearchListEventImpl implements _ChangeSearchListEvent {
  const _$ChangeSearchListEventImpl(
      {required final List<SearchModel> newSearchList})
      : _newSearchList = newSearchList;

  final List<SearchModel> _newSearchList;
  @override
  List<SearchModel> get newSearchList {
    if (_newSearchList is EqualUnmodifiableListView) return _newSearchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_newSearchList);
  }

  @override
  String toString() {
    return 'StoreEvent.changeSearchListEvent(newSearchList: $newSearchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSearchListEventImpl &&
            const DeepCollectionEquality()
                .equals(other._newSearchList, _newSearchList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_newSearchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSearchListEventImplCopyWith<_$ChangeSearchListEventImpl>
      get copyWith => __$$ChangeSearchListEventImplCopyWithImpl<
          _$ChangeSearchListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSearchListEvent(newSearchList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSearchListEvent?.call(newSearchList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSearchListEvent != null) {
      return changeSearchListEvent(newSearchList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSearchListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSearchListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSearchListEvent != null) {
      return changeSearchListEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSearchListEvent implements StoreEvent {
  const factory _ChangeSearchListEvent(
          {required final List<SearchModel> newSearchList}) =
      _$ChangeSearchListEventImpl;

  List<SearchModel> get newSearchList;
  @JsonKey(ignore: true)
  _$$ChangeSearchListEventImplCopyWith<_$ChangeSearchListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetSuppliersListEventImplCopyWith<$Res> {
  factory _$$GetSuppliersListEventImplCopyWith(
          _$GetSuppliersListEventImpl value,
          $Res Function(_$GetSuppliersListEventImpl) then) =
      __$$GetSuppliersListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetSuppliersListEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$GetSuppliersListEventImpl>
    implements _$$GetSuppliersListEventImplCopyWith<$Res> {
  __$$GetSuppliersListEventImplCopyWithImpl(_$GetSuppliersListEventImpl _value,
      $Res Function(_$GetSuppliersListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetSuppliersListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetSuppliersListEventImpl implements _GetSuppliersListEvent {
  const _$GetSuppliersListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.getSuppliersListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetSuppliersListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetSuppliersListEventImplCopyWith<_$GetSuppliersListEventImpl>
      get copyWith => __$$GetSuppliersListEventImplCopyWithImpl<
          _$GetSuppliersListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getSuppliersListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getSuppliersListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSuppliersListEvent != null) {
      return getSuppliersListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getSuppliersListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getSuppliersListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSuppliersListEvent != null) {
      return getSuppliersListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetSuppliersListEvent implements StoreEvent {
  const factory _GetSuppliersListEvent({required final BuildContext context}) =
      _$GetSuppliersListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetSuppliersListEventImplCopyWith<_$GetSuppliersListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetCompaniesListEventImplCopyWith<$Res> {
  factory _$$GetCompaniesListEventImplCopyWith(
          _$GetCompaniesListEventImpl value,
          $Res Function(_$GetCompaniesListEventImpl) then) =
      __$$GetCompaniesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetCompaniesListEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$GetCompaniesListEventImpl>
    implements _$$GetCompaniesListEventImplCopyWith<$Res> {
  __$$GetCompaniesListEventImplCopyWithImpl(_$GetCompaniesListEventImpl _value,
      $Res Function(_$GetCompaniesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetCompaniesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetCompaniesListEventImpl implements _GetCompaniesListEvent {
  const _$GetCompaniesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.getCompaniesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetCompaniesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetCompaniesListEventImplCopyWith<_$GetCompaniesListEventImpl>
      get copyWith => __$$GetCompaniesListEventImplCopyWithImpl<
          _$GetCompaniesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getCompaniesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getCompaniesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCompaniesListEvent != null) {
      return getCompaniesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getCompaniesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getCompaniesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCompaniesListEvent != null) {
      return getCompaniesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetCompaniesListEvent implements StoreEvent {
  const factory _GetCompaniesListEvent({required final BuildContext context}) =
      _$GetCompaniesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetCompaniesListEventImplCopyWith<_$GetCompaniesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductDetailsEventImplCopyWith<$Res> {
  factory _$$GetProductDetailsEventImplCopyWith(
          _$GetProductDetailsEventImpl value,
          $Res Function(_$GetProductDetailsEventImpl) then) =
      __$$GetProductDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId, bool? isBarcode});
}

/// @nodoc
class __$$GetProductDetailsEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$GetProductDetailsEventImpl>
    implements _$$GetProductDetailsEventImplCopyWith<$Res> {
  __$$GetProductDetailsEventImplCopyWithImpl(
      _$GetProductDetailsEventImpl _value,
      $Res Function(_$GetProductDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
    Object? isBarcode = freezed,
  }) {
    return _then(_$GetProductDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      isBarcode: freezed == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$GetProductDetailsEventImpl implements _GetProductDetailsEvent {
  const _$GetProductDetailsEventImpl(
      {required this.context, required this.productId, this.isBarcode});

  @override
  final BuildContext context;
  @override
  final String productId;
  @override
  final bool? isBarcode;

  @override
  String toString() {
    return 'StoreEvent.getProductDetailsEvent(context: $context, productId: $productId, isBarcode: $isBarcode)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId, isBarcode);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => __$$GetProductDetailsEventImplCopyWithImpl<
          _$GetProductDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductDetailsEvent(context, productId, isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(context, productId, isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(context, productId, isBarcode);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductDetailsEvent implements StoreEvent {
  const factory _GetProductDetailsEvent(
      {required final BuildContext context,
      required final String productId,
      final bool? isBarcode}) = _$GetProductDetailsEventImpl;

  BuildContext get context;
  String get productId;
  bool? get isBarcode;
  @JsonKey(ignore: true)
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$IncreaseQuantityOfProductImplCopyWith(
          _$IncreaseQuantityOfProductImpl value,
          $Res Function(_$IncreaseQuantityOfProductImpl) then) =
      __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$IncreaseQuantityOfProductImpl>
    implements _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  __$$IncreaseQuantityOfProductImplCopyWithImpl(
      _$IncreaseQuantityOfProductImpl _value,
      $Res Function(_$IncreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$IncreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$IncreaseQuantityOfProductImpl implements _IncreaseQuantityOfProduct {
  const _$IncreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.increaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => __$$IncreaseQuantityOfProductImplCopyWithImpl<
          _$IncreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return increaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return increaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _IncreaseQuantityOfProduct implements StoreEvent {
  const factory _IncreaseQuantityOfProduct(
      {required final BuildContext context}) = _$IncreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$DecreaseQuantityOfProductImplCopyWith(
          _$DecreaseQuantityOfProductImpl value,
          $Res Function(_$DecreaseQuantityOfProductImpl) then) =
      __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$DecreaseQuantityOfProductImpl>
    implements _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  __$$DecreaseQuantityOfProductImplCopyWithImpl(
      _$DecreaseQuantityOfProductImpl _value,
      $Res Function(_$DecreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DecreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DecreaseQuantityOfProductImpl implements _DecreaseQuantityOfProduct {
  const _$DecreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.decreaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DecreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => __$$DecreaseQuantityOfProductImplCopyWithImpl<
          _$DecreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _DecreaseQuantityOfProduct implements StoreEvent {
  const factory _DecreaseQuantityOfProduct(
      {required final BuildContext context}) = _$DecreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  factory _$$UpdateQuantityOfProductImplCopyWith(
          _$UpdateQuantityOfProductImpl value,
          $Res Function(_$UpdateQuantityOfProductImpl) then) =
      __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String quantity});
}

/// @nodoc
class __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$UpdateQuantityOfProductImpl>
    implements _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  __$$UpdateQuantityOfProductImplCopyWithImpl(
      _$UpdateQuantityOfProductImpl _value,
      $Res Function(_$UpdateQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? quantity = null,
  }) {
    return _then(_$UpdateQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UpdateQuantityOfProductImpl implements _UpdateQuantityOfProduct {
  const _$UpdateQuantityOfProductImpl(
      {required this.context, required this.quantity});

  @override
  final BuildContext context;
  @override
  final String quantity;

  @override
  String toString() {
    return 'StoreEvent.updateQuantityOfProduct(context: $context, quantity: $quantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, quantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => __$$UpdateQuantityOfProductImplCopyWithImpl<
          _$UpdateQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateQuantityOfProduct(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(context, quantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _UpdateQuantityOfProduct implements StoreEvent {
  const factory _UpdateQuantityOfProduct(
      {required final BuildContext context,
      required final String quantity}) = _$UpdateQuantityOfProductImpl;

  BuildContext get context;
  String get quantity;
  @JsonKey(ignore: true)
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeNoteOfProductImplCopyWith<$Res> {
  factory _$$ChangeNoteOfProductImplCopyWith(_$ChangeNoteOfProductImpl value,
          $Res Function(_$ChangeNoteOfProductImpl) then) =
      __$$ChangeNoteOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String newNote});
}

/// @nodoc
class __$$ChangeNoteOfProductImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$ChangeNoteOfProductImpl>
    implements _$$ChangeNoteOfProductImplCopyWith<$Res> {
  __$$ChangeNoteOfProductImplCopyWithImpl(_$ChangeNoteOfProductImpl _value,
      $Res Function(_$ChangeNoteOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newNote = null,
  }) {
    return _then(_$ChangeNoteOfProductImpl(
      newNote: null == newNote
          ? _value.newNote
          : newNote // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeNoteOfProductImpl implements _ChangeNoteOfProduct {
  const _$ChangeNoteOfProductImpl({required this.newNote});

  @override
  final String newNote;

  @override
  String toString() {
    return 'StoreEvent.changeNoteOfProduct(newNote: $newNote)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeNoteOfProductImpl &&
            (identical(other.newNote, newNote) || other.newNote == newNote));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newNote);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      __$$ChangeNoteOfProductImplCopyWithImpl<_$ChangeNoteOfProductImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeNoteOfProduct(newNote);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(newNote);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(newNote);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeNoteOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(this);
    }
    return orElse();
  }
}

abstract class _ChangeNoteOfProduct implements StoreEvent {
  const factory _ChangeNoteOfProduct({required final String newNote}) =
      _$ChangeNoteOfProductImpl;

  String get newNote;
  @JsonKey(ignore: true)
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  factory _$$ChangeSupplierSelectionExpansionEventImplCopyWith(
          _$ChangeSupplierSelectionExpansionEventImpl value,
          $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) then) =
      __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isSelectSupplier});
}

/// @nodoc
class __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res,
        _$ChangeSupplierSelectionExpansionEventImpl>
    implements _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl(
      _$ChangeSupplierSelectionExpansionEventImpl _value,
      $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSelectSupplier = freezed,
  }) {
    return _then(_$ChangeSupplierSelectionExpansionEventImpl(
      isSelectSupplier: freezed == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeSupplierSelectionExpansionEventImpl
    implements _ChangeSupplierSelectionExpansionEvent {
  const _$ChangeSupplierSelectionExpansionEventImpl({this.isSelectSupplier});

  @override
  final bool? isSelectSupplier;

  @override
  String toString() {
    return 'StoreEvent.changeSupplierSelectionExpansionEvent(isSelectSupplier: $isSelectSupplier)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSupplierSelectionExpansionEventImpl &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSelectSupplier);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<
          _$ChangeSupplierSelectionExpansionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(isSelectSupplier);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSupplierSelectionExpansionEvent implements StoreEvent {
  const factory _ChangeSupplierSelectionExpansionEvent(
          {final bool? isSelectSupplier}) =
      _$ChangeSupplierSelectionExpansionEventImpl;

  bool? get isSelectSupplier;
  @JsonKey(ignore: true)
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SupplierSelectionEventImplCopyWith<$Res> {
  factory _$$SupplierSelectionEventImplCopyWith(
          _$SupplierSelectionEventImpl value,
          $Res Function(_$SupplierSelectionEventImpl) then) =
      __$$SupplierSelectionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int supplierIndex, BuildContext context, int supplierSaleIndex});
}

/// @nodoc
class __$$SupplierSelectionEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$SupplierSelectionEventImpl>
    implements _$$SupplierSelectionEventImplCopyWith<$Res> {
  __$$SupplierSelectionEventImplCopyWithImpl(
      _$SupplierSelectionEventImpl _value,
      $Res Function(_$SupplierSelectionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierIndex = null,
    Object? context = null,
    Object? supplierSaleIndex = null,
  }) {
    return _then(_$SupplierSelectionEventImpl(
      supplierIndex: null == supplierIndex
          ? _value.supplierIndex
          : supplierIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierSaleIndex: null == supplierSaleIndex
          ? _value.supplierSaleIndex
          : supplierSaleIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SupplierSelectionEventImpl implements _SupplierSelectionEvent {
  const _$SupplierSelectionEventImpl(
      {required this.supplierIndex,
      required this.context,
      required this.supplierSaleIndex});

  @override
  final int supplierIndex;
  @override
  final BuildContext context;
  @override
  final int supplierSaleIndex;

  @override
  String toString() {
    return 'StoreEvent.supplierSelectionEvent(supplierIndex: $supplierIndex, context: $context, supplierSaleIndex: $supplierSaleIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSelectionEventImpl &&
            (identical(other.supplierIndex, supplierIndex) ||
                other.supplierIndex == supplierIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierSaleIndex, supplierSaleIndex) ||
                other.supplierSaleIndex == supplierSaleIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, supplierIndex, context, supplierSaleIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => __$$SupplierSelectionEventImplCopyWithImpl<
          _$SupplierSelectionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(
        supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return supplierSelectionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(this);
    }
    return orElse();
  }
}

abstract class _SupplierSelectionEvent implements StoreEvent {
  const factory _SupplierSelectionEvent(
      {required final int supplierIndex,
      required final BuildContext context,
      required final int supplierSaleIndex}) = _$SupplierSelectionEventImpl;

  int get supplierIndex;
  BuildContext get context;
  int get supplierSaleIndex;
  @JsonKey(ignore: true)
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddToCartProductEventImplCopyWith<$Res> {
  factory _$$AddToCartProductEventImplCopyWith(
          _$AddToCartProductEventImpl value,
          $Res Function(_$AddToCartProductEventImpl) then) =
      __$$AddToCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$AddToCartProductEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$AddToCartProductEventImpl>
    implements _$$AddToCartProductEventImplCopyWith<$Res> {
  __$$AddToCartProductEventImplCopyWithImpl(_$AddToCartProductEventImpl _value,
      $Res Function(_$AddToCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$AddToCartProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AddToCartProductEventImpl implements _AddToCartProductEvent {
  const _$AddToCartProductEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'StoreEvent.addToCartProductEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddToCartProductEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => __$$AddToCartProductEventImplCopyWithImpl<
          _$AddToCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return addToCartProductEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return addToCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _AddToCartProductEvent implements StoreEvent {
  const factory _AddToCartProductEvent(
      {required final BuildContext context,
      required final String productId}) = _$AddToCartProductEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetCartCountEventImplCopyWith<$Res> {
  factory _$$SetCartCountEventImplCopyWith(_$SetCartCountEventImpl value,
          $Res Function(_$SetCartCountEventImpl) then) =
      __$$SetCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SetCartCountEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$SetCartCountEventImpl>
    implements _$$SetCartCountEventImplCopyWith<$Res> {
  __$$SetCartCountEventImplCopyWithImpl(_$SetCartCountEventImpl _value,
      $Res Function(_$SetCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SetCartCountEventImpl implements _SetCartCountEvent {
  const _$SetCartCountEventImpl();

  @override
  String toString() {
    return 'StoreEvent.setCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SetCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return setCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return setCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return setCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return setCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetCartCountEvent implements StoreEvent {
  const factory _SetCartCountEvent() = _$SetCartCountEventImpl;
}

/// @nodoc
abstract class _$$GlobalSearchEventImplCopyWith<$Res> {
  factory _$$GlobalSearchEventImplCopyWith(_$GlobalSearchEventImpl value,
          $Res Function(_$GlobalSearchEventImpl) then) =
      __$$GlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GlobalSearchEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$GlobalSearchEventImpl>
    implements _$$GlobalSearchEventImplCopyWith<$Res> {
  __$$GlobalSearchEventImplCopyWithImpl(_$GlobalSearchEventImpl _value,
      $Res Function(_$GlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GlobalSearchEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GlobalSearchEventImpl implements _GlobalSearchEvent {
  const _$GlobalSearchEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.globalSearchEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalSearchEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      __$$GlobalSearchEventImplCopyWithImpl<_$GlobalSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return globalSearchEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return globalSearchEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return globalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return globalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _GlobalSearchEvent implements StoreEvent {
  const factory _GlobalSearchEvent({required final BuildContext context}) =
      _$GlobalSearchEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ResetGlobalSearchEventImplCopyWith<$Res> {
  factory _$$ResetGlobalSearchEventImplCopyWith(
          _$ResetGlobalSearchEventImpl value,
          $Res Function(_$ResetGlobalSearchEventImpl) then) =
      __$$ResetGlobalSearchEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ResetGlobalSearchEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$ResetGlobalSearchEventImpl>
    implements _$$ResetGlobalSearchEventImplCopyWith<$Res> {
  __$$ResetGlobalSearchEventImplCopyWithImpl(
      _$ResetGlobalSearchEventImpl _value,
      $Res Function(_$ResetGlobalSearchEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ResetGlobalSearchEventImpl implements _ResetGlobalSearchEvent {
  const _$ResetGlobalSearchEventImpl();

  @override
  String toString() {
    return 'StoreEvent.resetGlobalSearchEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResetGlobalSearchEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return resetGlobalSearchEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return resetGlobalSearchEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (resetGlobalSearchEvent != null) {
      return resetGlobalSearchEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return resetGlobalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return resetGlobalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (resetGlobalSearchEvent != null) {
      return resetGlobalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _ResetGlobalSearchEvent implements StoreEvent {
  const factory _ResetGlobalSearchEvent() = _$ResetGlobalSearchEventImpl;
}

/// @nodoc
abstract class _$$UpdateImageIndexEventImplCopyWith<$Res> {
  factory _$$UpdateImageIndexEventImplCopyWith(
          _$UpdateImageIndexEventImpl value,
          $Res Function(_$UpdateImageIndexEventImpl) then) =
      __$$UpdateImageIndexEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$UpdateImageIndexEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$UpdateImageIndexEventImpl>
    implements _$$UpdateImageIndexEventImplCopyWith<$Res> {
  __$$UpdateImageIndexEventImplCopyWithImpl(_$UpdateImageIndexEventImpl _value,
      $Res Function(_$UpdateImageIndexEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$UpdateImageIndexEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$UpdateImageIndexEventImpl implements _UpdateImageIndexEvent {
  const _$UpdateImageIndexEventImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'StoreEvent.updateImageIndexEvent(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateImageIndexEventImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => __$$UpdateImageIndexEventImplCopyWithImpl<
          _$UpdateImageIndexEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateImageIndexEvent(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateImageIndexEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateImageIndexEvent implements StoreEvent {
  const factory _UpdateImageIndexEvent({required final int index}) =
      _$UpdateImageIndexEventImpl;

  int get index;
  @JsonKey(ignore: true)
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  factory _$$UpdateGlobalSearchEventImplCopyWith(
          _$UpdateGlobalSearchEventImpl value,
          $Res Function(_$UpdateGlobalSearchEventImpl) then) =
      __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search, List<SearchModel> searchList});
}

/// @nodoc
class __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$UpdateGlobalSearchEventImpl>
    implements _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  __$$UpdateGlobalSearchEventImplCopyWithImpl(
      _$UpdateGlobalSearchEventImpl _value,
      $Res Function(_$UpdateGlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
    Object? searchList = null,
  }) {
    return _then(_$UpdateGlobalSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
    ));
  }
}

/// @nodoc

class _$UpdateGlobalSearchEventImpl implements _UpdateGlobalSearchEvent {
  const _$UpdateGlobalSearchEventImpl(
      {required this.search, required final List<SearchModel> searchList})
      : _searchList = searchList;

  @override
  final String search;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  String toString() {
    return 'StoreEvent.updateGlobalSearchEvent(search: $search, searchList: $searchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateGlobalSearchEventImpl &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, search, const DeepCollectionEquality().hash(_searchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => __$$UpdateGlobalSearchEventImplCopyWithImpl<
          _$UpdateGlobalSearchEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateGlobalSearchEvent(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(search, searchList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateGlobalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateGlobalSearchEvent implements StoreEvent {
  const factory _UpdateGlobalSearchEvent(
          {required final String search,
          required final List<SearchModel> searchList}) =
      _$UpdateGlobalSearchEventImpl;

  String get search;
  List<SearchModel> get searchList;
  @JsonKey(ignore: true)
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ToggleNoteEventImplCopyWith<$Res> {
  factory _$$ToggleNoteEventImplCopyWith(_$ToggleNoteEventImpl value,
          $Res Function(_$ToggleNoteEventImpl) then) =
      __$$ToggleNoteEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isBarcode});
}

/// @nodoc
class __$$ToggleNoteEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$ToggleNoteEventImpl>
    implements _$$ToggleNoteEventImplCopyWith<$Res> {
  __$$ToggleNoteEventImplCopyWithImpl(
      _$ToggleNoteEventImpl _value, $Res Function(_$ToggleNoteEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isBarcode = null,
  }) {
    return _then(_$ToggleNoteEventImpl(
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ToggleNoteEventImpl implements _ToggleNoteEvent {
  const _$ToggleNoteEventImpl({required this.isBarcode});

  @override
  final bool isBarcode;

  @override
  String toString() {
    return 'StoreEvent.toggleNoteEvent(isBarcode: $isBarcode)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ToggleNoteEventImpl &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isBarcode);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ToggleNoteEventImplCopyWith<_$ToggleNoteEventImpl> get copyWith =>
      __$$ToggleNoteEventImplCopyWithImpl<_$ToggleNoteEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return toggleNoteEvent(isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(isBarcode);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return toggleNoteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(this);
    }
    return orElse();
  }
}

abstract class _ToggleNoteEvent implements StoreEvent {
  const factory _ToggleNoteEvent({required final bool isBarcode}) =
      _$ToggleNoteEventImpl;

  bool get isBarcode;
  @JsonKey(ignore: true)
  _$$ToggleNoteEventImplCopyWith<_$ToggleNoteEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RelatedProductsEventImplCopyWith<$Res> {
  factory _$$RelatedProductsEventImplCopyWith(_$RelatedProductsEventImpl value,
          $Res Function(_$RelatedProductsEventImpl) then) =
      __$$RelatedProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$RelatedProductsEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$RelatedProductsEventImpl>
    implements _$$RelatedProductsEventImplCopyWith<$Res> {
  __$$RelatedProductsEventImplCopyWithImpl(_$RelatedProductsEventImpl _value,
      $Res Function(_$RelatedProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$RelatedProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RelatedProductsEventImpl implements _RelatedProductsEvent {
  const _$RelatedProductsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'StoreEvent.RelatedProductsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith =>
          __$$RelatedProductsEventImplCopyWithImpl<_$RelatedProductsEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RelatedProductsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RelatedProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _RelatedProductsEvent implements StoreEvent {
  const factory _RelatedProductsEvent(
      {required final BuildContext context,
      required final String productId}) = _$RelatedProductsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  factory _$$RemoveRelatedProductEventImplCopyWith(
          _$RemoveRelatedProductEventImpl value,
          $Res Function(_$RemoveRelatedProductEventImpl) then) =
      __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$RemoveRelatedProductEventImpl>
    implements _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  __$$RemoveRelatedProductEventImplCopyWithImpl(
      _$RemoveRelatedProductEventImpl _value,
      $Res Function(_$RemoveRelatedProductEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$RemoveRelatedProductEventImpl implements _RemoveRelatedProductEvent {
  const _$RemoveRelatedProductEventImpl();

  @override
  String toString() {
    return 'StoreEvent.RemoveRelatedProductEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveRelatedProductEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RemoveRelatedProductEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RemoveRelatedProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveRelatedProductEvent implements StoreEvent {
  const factory _RemoveRelatedProductEvent() = _$RemoveRelatedProductEventImpl;
}

/// @nodoc
abstract class _$$GeneralSettingsImplCopyWith<$Res> {
  factory _$$GeneralSettingsImplCopyWith(_$GeneralSettingsImpl value,
          $Res Function(_$GeneralSettingsImpl) then) =
      __$$GeneralSettingsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GeneralSettingsImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$GeneralSettingsImpl>
    implements _$$GeneralSettingsImplCopyWith<$Res> {
  __$$GeneralSettingsImplCopyWithImpl(
      _$GeneralSettingsImpl _value, $Res Function(_$GeneralSettingsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GeneralSettingsImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GeneralSettingsImpl implements _GeneralSettings {
  const _$GeneralSettingsImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.generalSettings(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GeneralSettingsImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GeneralSettingsImplCopyWith<_$GeneralSettingsImpl> get copyWith =>
      __$$GeneralSettingsImplCopyWithImpl<_$GeneralSettingsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return generalSettings(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return generalSettings?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (generalSettings != null) {
      return generalSettings(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return generalSettings(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return generalSettings?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (generalSettings != null) {
      return generalSettings(this);
    }
    return orElse();
  }
}

abstract class _GeneralSettings implements StoreEvent {
  const factory _GeneralSettings({required final BuildContext context}) =
      _$GeneralSettingsImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GeneralSettingsImplCopyWith<_$GeneralSettingsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$StoreEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context)
        getRecommendationProductsListEvent,
    required TResult Function(BuildContext context)
        getPreviousOrderProductsListEvent,
    required TResult Function(List<SearchModel> newSearchList)
        changeSearchListEvent,
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(
            BuildContext context, String productId, bool? isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function() resetGlobalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) generalSettings,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult? Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult? Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function()? resetGlobalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? generalSettings,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context)? getRecommendationProductsListEvent,
    TResult Function(BuildContext context)? getPreviousOrderProductsListEvent,
    TResult Function(List<SearchModel> newSearchList)? changeSearchListEvent,
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(BuildContext context, String productId, bool? isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function()? resetGlobalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? generalSettings,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetRecommendationProductsListEvent value)
        getRecommendationProductsListEvent,
    required TResult Function(_GetPreviousOrderProductsListEvent value)
        getPreviousOrderProductsListEvent,
    required TResult Function(_ChangeSearchListEvent value)
        changeSearchListEvent,
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_ResetGlobalSearchEvent value)
        resetGlobalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_GeneralSettings value) generalSettings,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult? Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult? Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_GeneralSettings value)? generalSettings,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetRecommendationProductsListEvent value)?
        getRecommendationProductsListEvent,
    TResult Function(_GetPreviousOrderProductsListEvent value)?
        getPreviousOrderProductsListEvent,
    TResult Function(_ChangeSearchListEvent value)? changeSearchListEvent,
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_ResetGlobalSearchEvent value)? resetGlobalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_GeneralSettings value)? generalSettings,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements StoreEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$StoreState {
  bool get isCategoryExpand => throw _privateConstructorUsedError;
  List<Category> get productCategoryList => throw _privateConstructorUsedError;
  List<ProductSale> get productSalesList => throw _privateConstructorUsedError;
  List<RecommendationData> get recommendedProductsList =>
      throw _privateConstructorUsedError;
  List<PreviousOrderProductData> get previousOrderProductsList =>
      throw _privateConstructorUsedError;
  SuppliersResModel get suppliersList => throw _privateConstructorUsedError;
  List<Brand> get companiesList => throw _privateConstructorUsedError;
  List<SearchModel> get searchList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isProductLoading => throw _privateConstructorUsedError;
  List<Product> get productDetails => throw _privateConstructorUsedError;
  List<ProductStockModel> get productStockList =>
      throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  bool get isSelectSupplier => throw _privateConstructorUsedError;
  List<ProductSupplierModel> get productSupplierList =>
      throw _privateConstructorUsedError;
  bool get isCartCountChange => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  bool get isSearching => throw _privateConstructorUsedError;
  int get imageIndex => throw _privateConstructorUsedError;
  TextEditingController get searchController =>
      throw _privateConstructorUsedError;
  TextEditingController get noteController =>
      throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  bool get isCatVisible => throw _privateConstructorUsedError;
  bool get isSupplierVisible => throw _privateConstructorUsedError;
  bool get isCompanyVisible => throw _privateConstructorUsedError;
  bool get isGuestUser => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get relatedProductList =>
      throw _privateConstructorUsedError;
  bool get isRelatedShimmering => throw _privateConstructorUsedError;
  bool get showPesachBanner => throw _privateConstructorUsedError;
  String get pesachBannerURL => throw _privateConstructorUsedError;
  double get bottlePrice => throw _privateConstructorUsedError;
  bool get isSubUserAddToBasket => throw _privateConstructorUsedError;
  bool get isAccountPermissionShimmering => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $StoreStateCopyWith<StoreState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StoreStateCopyWith<$Res> {
  factory $StoreStateCopyWith(
          StoreState value, $Res Function(StoreState) then) =
      _$StoreStateCopyWithImpl<$Res, StoreState>;
  @useResult
  $Res call(
      {bool isCategoryExpand,
      List<Category> productCategoryList,
      List<ProductSale> productSalesList,
      List<RecommendationData> recommendedProductsList,
      List<PreviousOrderProductData> previousOrderProductsList,
      SuppliersResModel suppliersList,
      List<Brand> companiesList,
      List<SearchModel> searchList,
      bool isShimmering,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<ProductStockModel> productStockList,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      bool isCartCountChange,
      String search,
      bool isSearching,
      int imageIndex,
      TextEditingController searchController,
      TextEditingController noteController,
      RefreshController refreshController,
      bool isCatVisible,
      bool isSupplierVisible,
      bool isCompanyVisible,
      bool isGuestUser,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      bool showPesachBanner,
      String pesachBannerURL,
      double bottlePrice,
      bool isSubUserAddToBasket,
      bool isAccountPermissionShimmering});

  $SuppliersResModelCopyWith<$Res> get suppliersList;
}

/// @nodoc
class _$StoreStateCopyWithImpl<$Res, $Val extends StoreState>
    implements $StoreStateCopyWith<$Res> {
  _$StoreStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isCategoryExpand = null,
    Object? productCategoryList = null,
    Object? productSalesList = null,
    Object? recommendedProductsList = null,
    Object? previousOrderProductsList = null,
    Object? suppliersList = null,
    Object? companiesList = null,
    Object? searchList = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? isCartCountChange = null,
    Object? search = null,
    Object? isSearching = null,
    Object? imageIndex = null,
    Object? searchController = null,
    Object? noteController = null,
    Object? refreshController = null,
    Object? isCatVisible = null,
    Object? isSupplierVisible = null,
    Object? isCompanyVisible = null,
    Object? isGuestUser = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? showPesachBanner = null,
    Object? pesachBannerURL = null,
    Object? bottlePrice = null,
    Object? isSubUserAddToBasket = null,
    Object? isAccountPermissionShimmering = null,
  }) {
    return _then(_value.copyWith(
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      productCategoryList: null == productCategoryList
          ? _value.productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      productSalesList: null == productSalesList
          ? _value.productSalesList
          : productSalesList // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>,
      recommendedProductsList: null == recommendedProductsList
          ? _value.recommendedProductsList
          : recommendedProductsList // ignore: cast_nullable_to_non_nullable
              as List<RecommendationData>,
      previousOrderProductsList: null == previousOrderProductsList
          ? _value.previousOrderProductsList
          : previousOrderProductsList // ignore: cast_nullable_to_non_nullable
              as List<PreviousOrderProductData>,
      suppliersList: null == suppliersList
          ? _value.suppliersList
          : suppliersList // ignore: cast_nullable_to_non_nullable
              as SuppliersResModel,
      companiesList: null == companiesList
          ? _value.companiesList
          : companiesList // ignore: cast_nullable_to_non_nullable
              as List<Brand>,
      searchList: null == searchList
          ? _value.searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<ProductStockModel>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value.productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isSupplierVisible: null == isSupplierVisible
          ? _value.isSupplierVisible
          : isSupplierVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isCompanyVisible: null == isCompanyVisible
          ? _value.isCompanyVisible
          : isCompanyVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value.relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      showPesachBanner: null == showPesachBanner
          ? _value.showPesachBanner
          : showPesachBanner // ignore: cast_nullable_to_non_nullable
              as bool,
      pesachBannerURL: null == pesachBannerURL
          ? _value.pesachBannerURL
          : pesachBannerURL // ignore: cast_nullable_to_non_nullable
              as String,
      bottlePrice: null == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $SuppliersResModelCopyWith<$Res> get suppliersList {
    return $SuppliersResModelCopyWith<$Res>(_value.suppliersList, (value) {
      return _then(_value.copyWith(suppliersList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$StoreStateImplCopyWith<$Res>
    implements $StoreStateCopyWith<$Res> {
  factory _$$StoreStateImplCopyWith(
          _$StoreStateImpl value, $Res Function(_$StoreStateImpl) then) =
      __$$StoreStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isCategoryExpand,
      List<Category> productCategoryList,
      List<ProductSale> productSalesList,
      List<RecommendationData> recommendedProductsList,
      List<PreviousOrderProductData> previousOrderProductsList,
      SuppliersResModel suppliersList,
      List<Brand> companiesList,
      List<SearchModel> searchList,
      bool isShimmering,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<ProductStockModel> productStockList,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      bool isCartCountChange,
      String search,
      bool isSearching,
      int imageIndex,
      TextEditingController searchController,
      TextEditingController noteController,
      RefreshController refreshController,
      bool isCatVisible,
      bool isSupplierVisible,
      bool isCompanyVisible,
      bool isGuestUser,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      bool showPesachBanner,
      String pesachBannerURL,
      double bottlePrice,
      bool isSubUserAddToBasket,
      bool isAccountPermissionShimmering});

  @override
  $SuppliersResModelCopyWith<$Res> get suppliersList;
}

/// @nodoc
class __$$StoreStateImplCopyWithImpl<$Res>
    extends _$StoreStateCopyWithImpl<$Res, _$StoreStateImpl>
    implements _$$StoreStateImplCopyWith<$Res> {
  __$$StoreStateImplCopyWithImpl(
      _$StoreStateImpl _value, $Res Function(_$StoreStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isCategoryExpand = null,
    Object? productCategoryList = null,
    Object? productSalesList = null,
    Object? recommendedProductsList = null,
    Object? previousOrderProductsList = null,
    Object? suppliersList = null,
    Object? companiesList = null,
    Object? searchList = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? isCartCountChange = null,
    Object? search = null,
    Object? isSearching = null,
    Object? imageIndex = null,
    Object? searchController = null,
    Object? noteController = null,
    Object? refreshController = null,
    Object? isCatVisible = null,
    Object? isSupplierVisible = null,
    Object? isCompanyVisible = null,
    Object? isGuestUser = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? showPesachBanner = null,
    Object? pesachBannerURL = null,
    Object? bottlePrice = null,
    Object? isSubUserAddToBasket = null,
    Object? isAccountPermissionShimmering = null,
  }) {
    return _then(_$StoreStateImpl(
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      productCategoryList: null == productCategoryList
          ? _value._productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      productSalesList: null == productSalesList
          ? _value._productSalesList
          : productSalesList // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>,
      recommendedProductsList: null == recommendedProductsList
          ? _value._recommendedProductsList
          : recommendedProductsList // ignore: cast_nullable_to_non_nullable
              as List<RecommendationData>,
      previousOrderProductsList: null == previousOrderProductsList
          ? _value._previousOrderProductsList
          : previousOrderProductsList // ignore: cast_nullable_to_non_nullable
              as List<PreviousOrderProductData>,
      suppliersList: null == suppliersList
          ? _value.suppliersList
          : suppliersList // ignore: cast_nullable_to_non_nullable
              as SuppliersResModel,
      companiesList: null == companiesList
          ? _value._companiesList
          : companiesList // ignore: cast_nullable_to_non_nullable
              as List<Brand>,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value._productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<ProductStockModel>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value._productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isSupplierVisible: null == isSupplierVisible
          ? _value.isSupplierVisible
          : isSupplierVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isCompanyVisible: null == isCompanyVisible
          ? _value.isCompanyVisible
          : isCompanyVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value._relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      showPesachBanner: null == showPesachBanner
          ? _value.showPesachBanner
          : showPesachBanner // ignore: cast_nullable_to_non_nullable
              as bool,
      pesachBannerURL: null == pesachBannerURL
          ? _value.pesachBannerURL
          : pesachBannerURL // ignore: cast_nullable_to_non_nullable
              as String,
      bottlePrice: null == bottlePrice
          ? _value.bottlePrice
          : bottlePrice // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$StoreStateImpl implements _StoreState {
  const _$StoreStateImpl(
      {required this.isCategoryExpand,
      required final List<Category> productCategoryList,
      required final List<ProductSale> productSalesList,
      required final List<RecommendationData> recommendedProductsList,
      required final List<PreviousOrderProductData> previousOrderProductsList,
      required this.suppliersList,
      required final List<Brand> companiesList,
      required final List<SearchModel> searchList,
      required this.isShimmering,
      required this.isLoading,
      required this.isProductLoading,
      required final List<Product> productDetails,
      required final List<ProductStockModel> productStockList,
      required this.productStockUpdateIndex,
      required this.isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required this.isCartCountChange,
      required this.search,
      required this.isSearching,
      required this.imageIndex,
      required this.searchController,
      required this.noteController,
      required this.refreshController,
      required this.isCatVisible,
      required this.isSupplierVisible,
      required this.isCompanyVisible,
      required this.isGuestUser,
      required final List<RelatedProductDatum> relatedProductList,
      required this.isRelatedShimmering,
      required this.showPesachBanner,
      required this.pesachBannerURL,
      required this.bottlePrice,
      required this.isSubUserAddToBasket,
      required this.isAccountPermissionShimmering})
      : _productCategoryList = productCategoryList,
        _productSalesList = productSalesList,
        _recommendedProductsList = recommendedProductsList,
        _previousOrderProductsList = previousOrderProductsList,
        _companiesList = companiesList,
        _searchList = searchList,
        _productDetails = productDetails,
        _productStockList = productStockList,
        _productSupplierList = productSupplierList,
        _relatedProductList = relatedProductList;

  @override
  final bool isCategoryExpand;
  final List<Category> _productCategoryList;
  @override
  List<Category> get productCategoryList {
    if (_productCategoryList is EqualUnmodifiableListView)
      return _productCategoryList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productCategoryList);
  }

  final List<ProductSale> _productSalesList;
  @override
  List<ProductSale> get productSalesList {
    if (_productSalesList is EqualUnmodifiableListView)
      return _productSalesList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSalesList);
  }

  final List<RecommendationData> _recommendedProductsList;
  @override
  List<RecommendationData> get recommendedProductsList {
    if (_recommendedProductsList is EqualUnmodifiableListView)
      return _recommendedProductsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_recommendedProductsList);
  }

  final List<PreviousOrderProductData> _previousOrderProductsList;
  @override
  List<PreviousOrderProductData> get previousOrderProductsList {
    if (_previousOrderProductsList is EqualUnmodifiableListView)
      return _previousOrderProductsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_previousOrderProductsList);
  }

  @override
  final SuppliersResModel suppliersList;
  final List<Brand> _companiesList;
  @override
  List<Brand> get companiesList {
    if (_companiesList is EqualUnmodifiableListView) return _companiesList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_companiesList);
  }

  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  final bool isShimmering;
  @override
  final bool isLoading;
  @override
  final bool isProductLoading;
  final List<Product> _productDetails;
  @override
  List<Product> get productDetails {
    if (_productDetails is EqualUnmodifiableListView) return _productDetails;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productDetails);
  }

  final List<ProductStockModel> _productStockList;
  @override
  List<ProductStockModel> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final int productStockUpdateIndex;
  @override
  final bool isSelectSupplier;
  final List<ProductSupplierModel> _productSupplierList;
  @override
  List<ProductSupplierModel> get productSupplierList {
    if (_productSupplierList is EqualUnmodifiableListView)
      return _productSupplierList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSupplierList);
  }

  @override
  final bool isCartCountChange;
  @override
  final String search;
  @override
  final bool isSearching;
  @override
  final int imageIndex;
  @override
  final TextEditingController searchController;
  @override
  final TextEditingController noteController;
  @override
  final RefreshController refreshController;
  @override
  final bool isCatVisible;
  @override
  final bool isSupplierVisible;
  @override
  final bool isCompanyVisible;
  @override
  final bool isGuestUser;
  final List<RelatedProductDatum> _relatedProductList;
  @override
  List<RelatedProductDatum> get relatedProductList {
    if (_relatedProductList is EqualUnmodifiableListView)
      return _relatedProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedProductList);
  }

  @override
  final bool isRelatedShimmering;
  @override
  final bool showPesachBanner;
  @override
  final String pesachBannerURL;
  @override
  final double bottlePrice;
  @override
  final bool isSubUserAddToBasket;
  @override
  final bool isAccountPermissionShimmering;

  @override
  String toString() {
    return 'StoreState(isCategoryExpand: $isCategoryExpand, productCategoryList: $productCategoryList, productSalesList: $productSalesList, recommendedProductsList: $recommendedProductsList, previousOrderProductsList: $previousOrderProductsList, suppliersList: $suppliersList, companiesList: $companiesList, searchList: $searchList, isShimmering: $isShimmering, isLoading: $isLoading, isProductLoading: $isProductLoading, productDetails: $productDetails, productStockList: $productStockList, productStockUpdateIndex: $productStockUpdateIndex, isSelectSupplier: $isSelectSupplier, productSupplierList: $productSupplierList, isCartCountChange: $isCartCountChange, search: $search, isSearching: $isSearching, imageIndex: $imageIndex, searchController: $searchController, noteController: $noteController, refreshController: $refreshController, isCatVisible: $isCatVisible, isSupplierVisible: $isSupplierVisible, isCompanyVisible: $isCompanyVisible, isGuestUser: $isGuestUser, relatedProductList: $relatedProductList, isRelatedShimmering: $isRelatedShimmering, showPesachBanner: $showPesachBanner, pesachBannerURL: $pesachBannerURL, bottlePrice: $bottlePrice, isSubUserAddToBasket: $isSubUserAddToBasket, isAccountPermissionShimmering: $isAccountPermissionShimmering)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StoreStateImpl &&
            (identical(other.isCategoryExpand, isCategoryExpand) ||
                other.isCategoryExpand == isCategoryExpand) &&
            const DeepCollectionEquality()
                .equals(other._productCategoryList, _productCategoryList) &&
            const DeepCollectionEquality()
                .equals(other._productSalesList, _productSalesList) &&
            const DeepCollectionEquality().equals(
                other._recommendedProductsList, _recommendedProductsList) &&
            const DeepCollectionEquality().equals(
                other._previousOrderProductsList, _previousOrderProductsList) &&
            (identical(other.suppliersList, suppliersList) ||
                other.suppliersList == suppliersList) &&
            const DeepCollectionEquality()
                .equals(other._companiesList, _companiesList) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isProductLoading, isProductLoading) ||
                other.isProductLoading == isProductLoading) &&
            const DeepCollectionEquality()
                .equals(other._productDetails, _productDetails) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier) &&
            const DeepCollectionEquality()
                .equals(other._productSupplierList, _productSupplierList) &&
            (identical(other.isCartCountChange, isCartCountChange) ||
                other.isCartCountChange == isCartCountChange) &&
            (identical(other.search, search) || other.search == search) &&
            (identical(other.isSearching, isSearching) ||
                other.isSearching == isSearching) &&
            (identical(other.imageIndex, imageIndex) ||
                other.imageIndex == imageIndex) &&
            (identical(other.searchController, searchController) ||
                other.searchController == searchController) &&
            (identical(other.noteController, noteController) ||
                other.noteController == noteController) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.isCatVisible, isCatVisible) ||
                other.isCatVisible == isCatVisible) &&
            (identical(other.isSupplierVisible, isSupplierVisible) ||
                other.isSupplierVisible == isSupplierVisible) &&
            (identical(other.isCompanyVisible, isCompanyVisible) ||
                other.isCompanyVisible == isCompanyVisible) &&
            (identical(other.isGuestUser, isGuestUser) ||
                other.isGuestUser == isGuestUser) &&
            const DeepCollectionEquality()
                .equals(other._relatedProductList, _relatedProductList) &&
            (identical(other.isRelatedShimmering, isRelatedShimmering) ||
                other.isRelatedShimmering == isRelatedShimmering) &&
            (identical(other.showPesachBanner, showPesachBanner) ||
                other.showPesachBanner == showPesachBanner) &&
            (identical(other.pesachBannerURL, pesachBannerURL) ||
                other.pesachBannerURL == pesachBannerURL) &&
            (identical(other.bottlePrice, bottlePrice) ||
                other.bottlePrice == bottlePrice) &&
            (identical(other.isSubUserAddToBasket, isSubUserAddToBasket) ||
                other.isSubUserAddToBasket == isSubUserAddToBasket) &&
            (identical(other.isAccountPermissionShimmering,
                    isAccountPermissionShimmering) ||
                other.isAccountPermissionShimmering ==
                    isAccountPermissionShimmering));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        isCategoryExpand,
        const DeepCollectionEquality().hash(_productCategoryList),
        const DeepCollectionEquality().hash(_productSalesList),
        const DeepCollectionEquality().hash(_recommendedProductsList),
        const DeepCollectionEquality().hash(_previousOrderProductsList),
        suppliersList,
        const DeepCollectionEquality().hash(_companiesList),
        const DeepCollectionEquality().hash(_searchList),
        isShimmering,
        isLoading,
        isProductLoading,
        const DeepCollectionEquality().hash(_productDetails),
        const DeepCollectionEquality().hash(_productStockList),
        productStockUpdateIndex,
        isSelectSupplier,
        const DeepCollectionEquality().hash(_productSupplierList),
        isCartCountChange,
        search,
        isSearching,
        imageIndex,
        searchController,
        noteController,
        refreshController,
        isCatVisible,
        isSupplierVisible,
        isCompanyVisible,
        isGuestUser,
        const DeepCollectionEquality().hash(_relatedProductList),
        isRelatedShimmering,
        showPesachBanner,
        pesachBannerURL,
        bottlePrice,
        isSubUserAddToBasket,
        isAccountPermissionShimmering
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StoreStateImplCopyWith<_$StoreStateImpl> get copyWith =>
      __$$StoreStateImplCopyWithImpl<_$StoreStateImpl>(this, _$identity);
}

abstract class _StoreState implements StoreState {
  const factory _StoreState(
      {required final bool isCategoryExpand,
      required final List<Category> productCategoryList,
      required final List<ProductSale> productSalesList,
      required final List<RecommendationData> recommendedProductsList,
      required final List<PreviousOrderProductData> previousOrderProductsList,
      required final SuppliersResModel suppliersList,
      required final List<Brand> companiesList,
      required final List<SearchModel> searchList,
      required final bool isShimmering,
      required final bool isLoading,
      required final bool isProductLoading,
      required final List<Product> productDetails,
      required final List<ProductStockModel> productStockList,
      required final int productStockUpdateIndex,
      required final bool isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required final bool isCartCountChange,
      required final String search,
      required final bool isSearching,
      required final int imageIndex,
      required final TextEditingController searchController,
      required final TextEditingController noteController,
      required final RefreshController refreshController,
      required final bool isCatVisible,
      required final bool isSupplierVisible,
      required final bool isCompanyVisible,
      required final bool isGuestUser,
      required final List<RelatedProductDatum> relatedProductList,
      required final bool isRelatedShimmering,
      required final bool showPesachBanner,
      required final String pesachBannerURL,
      required final double bottlePrice,
      required final bool isSubUserAddToBasket,
      required final bool isAccountPermissionShimmering}) = _$StoreStateImpl;

  @override
  bool get isCategoryExpand;
  @override
  List<Category> get productCategoryList;
  @override
  List<ProductSale> get productSalesList;
  @override
  List<RecommendationData> get recommendedProductsList;
  @override
  List<PreviousOrderProductData> get previousOrderProductsList;
  @override
  SuppliersResModel get suppliersList;
  @override
  List<Brand> get companiesList;
  @override
  List<SearchModel> get searchList;
  @override
  bool get isShimmering;
  @override
  bool get isLoading;
  @override
  bool get isProductLoading;
  @override
  List<Product> get productDetails;
  @override
  List<ProductStockModel> get productStockList;
  @override
  int get productStockUpdateIndex;
  @override
  bool get isSelectSupplier;
  @override
  List<ProductSupplierModel> get productSupplierList;
  @override
  bool get isCartCountChange;
  @override
  String get search;
  @override
  bool get isSearching;
  @override
  int get imageIndex;
  @override
  TextEditingController get searchController;
  @override
  TextEditingController get noteController;
  @override
  RefreshController get refreshController;
  @override
  bool get isCatVisible;
  @override
  bool get isSupplierVisible;
  @override
  bool get isCompanyVisible;
  @override
  bool get isGuestUser;
  @override
  List<RelatedProductDatum> get relatedProductList;
  @override
  bool get isRelatedShimmering;
  @override
  bool get showPesachBanner;
  @override
  String get pesachBannerURL;
  @override
  double get bottlePrice;
  @override
  bool get isSubUserAddToBasket;
  @override
  bool get isAccountPermissionShimmering;
  @override
  @JsonKey(ignore: true)
  _$$StoreStateImplCopyWith<_$StoreStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
