// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'order_details_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$OrderDetailsEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  String get orderId => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OrderDetailsEventCopyWith<OrderDetailsEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderDetailsEventCopyWith<$Res> {
  factory $OrderDetailsEventCopyWith(
          OrderDetailsEvent value, $Res Function(OrderDetailsEvent) then) =
      _$OrderDetailsEventCopyWithImpl<$Res, OrderDetailsEvent>;
  @useResult
  $Res call({BuildContext context, String orderId});
}

/// @nodoc
class _$OrderDetailsEventCopyWithImpl<$Res, $Val extends OrderDetailsEvent>
    implements $OrderDetailsEventCopyWith<$Res> {
  _$OrderDetailsEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? orderId = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$getOrderByIdEventImplCopyWith<$Res>
    implements $OrderDetailsEventCopyWith<$Res> {
  factory _$$getOrderByIdEventImplCopyWith(_$getOrderByIdEventImpl value,
          $Res Function(_$getOrderByIdEventImpl) then) =
      __$$getOrderByIdEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, String orderId});
}

/// @nodoc
class __$$getOrderByIdEventImplCopyWithImpl<$Res>
    extends _$OrderDetailsEventCopyWithImpl<$Res, _$getOrderByIdEventImpl>
    implements _$$getOrderByIdEventImplCopyWith<$Res> {
  __$$getOrderByIdEventImplCopyWithImpl(_$getOrderByIdEventImpl _value,
      $Res Function(_$getOrderByIdEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? orderId = null,
  }) {
    return _then(_$getOrderByIdEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getOrderByIdEventImpl implements _getOrderByIdEvent {
  const _$getOrderByIdEventImpl({required this.context, required this.orderId});

  @override
  final BuildContext context;
  @override
  final String orderId;

  @override
  String toString() {
    return 'OrderDetailsEvent.getOrderByIdEvent(context: $context, orderId: $orderId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getOrderByIdEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.orderId, orderId) || other.orderId == orderId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, orderId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getOrderByIdEventImplCopyWith<_$getOrderByIdEventImpl> get copyWith =>
      __$$getOrderByIdEventImplCopyWithImpl<_$getOrderByIdEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
  }) {
    return getOrderByIdEvent(context, orderId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
  }) {
    return getOrderByIdEvent?.call(context, orderId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    required TResult orElse(),
  }) {
    if (getOrderByIdEvent != null) {
      return getOrderByIdEvent(context, orderId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
  }) {
    return getOrderByIdEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
  }) {
    return getOrderByIdEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    required TResult orElse(),
  }) {
    if (getOrderByIdEvent != null) {
      return getOrderByIdEvent(this);
    }
    return orElse();
  }
}

abstract class _getOrderByIdEvent implements OrderDetailsEvent {
  const factory _getOrderByIdEvent(
      {required final BuildContext context,
      required final String orderId}) = _$getOrderByIdEventImpl;

  @override
  BuildContext get context;
  @override
  String get orderId;
  @override
  @JsonKey(ignore: true)
  _$$getOrderByIdEventImplCopyWith<_$getOrderByIdEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$OrderDetailsState {
  GetOrderByIdModel get orderByIdList => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OrderDetailsStateCopyWith<OrderDetailsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderDetailsStateCopyWith<$Res> {
  factory $OrderDetailsStateCopyWith(
          OrderDetailsState value, $Res Function(OrderDetailsState) then) =
      _$OrderDetailsStateCopyWithImpl<$Res, OrderDetailsState>;
  @useResult
  $Res call({GetOrderByIdModel orderByIdList});

  $GetOrderByIdModelCopyWith<$Res> get orderByIdList;
}

/// @nodoc
class _$OrderDetailsStateCopyWithImpl<$Res, $Val extends OrderDetailsState>
    implements $OrderDetailsStateCopyWith<$Res> {
  _$OrderDetailsStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderByIdList = null,
  }) {
    return _then(_value.copyWith(
      orderByIdList: null == orderByIdList
          ? _value.orderByIdList
          : orderByIdList // ignore: cast_nullable_to_non_nullable
              as GetOrderByIdModel,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $GetOrderByIdModelCopyWith<$Res> get orderByIdList {
    return $GetOrderByIdModelCopyWith<$Res>(_value.orderByIdList, (value) {
      return _then(_value.copyWith(orderByIdList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$OrderDetailsStateImplCopyWith<$Res>
    implements $OrderDetailsStateCopyWith<$Res> {
  factory _$$OrderDetailsStateImplCopyWith(_$OrderDetailsStateImpl value,
          $Res Function(_$OrderDetailsStateImpl) then) =
      __$$OrderDetailsStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({GetOrderByIdModel orderByIdList});

  @override
  $GetOrderByIdModelCopyWith<$Res> get orderByIdList;
}

/// @nodoc
class __$$OrderDetailsStateImplCopyWithImpl<$Res>
    extends _$OrderDetailsStateCopyWithImpl<$Res, _$OrderDetailsStateImpl>
    implements _$$OrderDetailsStateImplCopyWith<$Res> {
  __$$OrderDetailsStateImplCopyWithImpl(_$OrderDetailsStateImpl _value,
      $Res Function(_$OrderDetailsStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderByIdList = null,
  }) {
    return _then(_$OrderDetailsStateImpl(
      orderByIdList: null == orderByIdList
          ? _value.orderByIdList
          : orderByIdList // ignore: cast_nullable_to_non_nullable
              as GetOrderByIdModel,
    ));
  }
}

/// @nodoc

class _$OrderDetailsStateImpl implements _OrderDetailsState {
  const _$OrderDetailsStateImpl({required this.orderByIdList});

  @override
  final GetOrderByIdModel orderByIdList;

  @override
  String toString() {
    return 'OrderDetailsState(orderByIdList: $orderByIdList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OrderDetailsStateImpl &&
            (identical(other.orderByIdList, orderByIdList) ||
                other.orderByIdList == orderByIdList));
  }

  @override
  int get hashCode => Object.hash(runtimeType, orderByIdList);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OrderDetailsStateImplCopyWith<_$OrderDetailsStateImpl> get copyWith =>
      __$$OrderDetailsStateImplCopyWithImpl<_$OrderDetailsStateImpl>(
          this, _$identity);
}

abstract class _OrderDetailsState implements OrderDetailsState {
  const factory _OrderDetailsState(
          {required final GetOrderByIdModel orderByIdList}) =
      _$OrderDetailsStateImpl;

  @override
  GetOrderByIdModel get orderByIdList;
  @override
  @JsonKey(ignore: true)
  _$$OrderDetailsStateImplCopyWith<_$OrderDetailsStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
