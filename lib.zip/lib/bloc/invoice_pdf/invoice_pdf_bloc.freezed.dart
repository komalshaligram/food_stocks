// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'invoice_pdf_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$InvoicePdfState {
  Invoice get invoiceDetailsList => throw _privateConstructorUsedError;
  bool get isDownloading => throw _privateConstructorUsedError;
  int get downloadProgress => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $InvoicePdfStateCopyWith<InvoicePdfState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InvoicePdfStateCopyWith<$Res> {
  factory $InvoicePdfStateCopyWith(
          InvoicePdfState value, $Res Function(InvoicePdfState) then) =
      _$InvoicePdfStateCopyWithImpl<$Res, InvoicePdfState>;
  @useResult
  $Res call(
      {Invoice invoiceDetailsList, bool isDownloading, int downloadProgress});

  $InvoiceCopyWith<$Res> get invoiceDetailsList;
}

/// @nodoc
class _$InvoicePdfStateCopyWithImpl<$Res, $Val extends InvoicePdfState>
    implements $InvoicePdfStateCopyWith<$Res> {
  _$InvoicePdfStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? invoiceDetailsList = null,
    Object? isDownloading = null,
    Object? downloadProgress = null,
  }) {
    return _then(_value.copyWith(
      invoiceDetailsList: null == invoiceDetailsList
          ? _value.invoiceDetailsList
          : invoiceDetailsList // ignore: cast_nullable_to_non_nullable
              as Invoice,
      isDownloading: null == isDownloading
          ? _value.isDownloading
          : isDownloading // ignore: cast_nullable_to_non_nullable
              as bool,
      downloadProgress: null == downloadProgress
          ? _value.downloadProgress
          : downloadProgress // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $InvoiceCopyWith<$Res> get invoiceDetailsList {
    return $InvoiceCopyWith<$Res>(_value.invoiceDetailsList, (value) {
      return _then(_value.copyWith(invoiceDetailsList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$InvoicePdfStateImplCopyWith<$Res>
    implements $InvoicePdfStateCopyWith<$Res> {
  factory _$$InvoicePdfStateImplCopyWith(_$InvoicePdfStateImpl value,
          $Res Function(_$InvoicePdfStateImpl) then) =
      __$$InvoicePdfStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {Invoice invoiceDetailsList, bool isDownloading, int downloadProgress});

  @override
  $InvoiceCopyWith<$Res> get invoiceDetailsList;
}

/// @nodoc
class __$$InvoicePdfStateImplCopyWithImpl<$Res>
    extends _$InvoicePdfStateCopyWithImpl<$Res, _$InvoicePdfStateImpl>
    implements _$$InvoicePdfStateImplCopyWith<$Res> {
  __$$InvoicePdfStateImplCopyWithImpl(
      _$InvoicePdfStateImpl _value, $Res Function(_$InvoicePdfStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? invoiceDetailsList = null,
    Object? isDownloading = null,
    Object? downloadProgress = null,
  }) {
    return _then(_$InvoicePdfStateImpl(
      invoiceDetailsList: null == invoiceDetailsList
          ? _value.invoiceDetailsList
          : invoiceDetailsList // ignore: cast_nullable_to_non_nullable
              as Invoice,
      isDownloading: null == isDownloading
          ? _value.isDownloading
          : isDownloading // ignore: cast_nullable_to_non_nullable
              as bool,
      downloadProgress: null == downloadProgress
          ? _value.downloadProgress
          : downloadProgress // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$InvoicePdfStateImpl
    with DiagnosticableTreeMixin
    implements _InvoicePdfState {
  const _$InvoicePdfStateImpl(
      {required this.invoiceDetailsList,
      required this.isDownloading,
      required this.downloadProgress});

  @override
  final Invoice invoiceDetailsList;
  @override
  final bool isDownloading;
  @override
  final int downloadProgress;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'InvoicePdfState(invoiceDetailsList: $invoiceDetailsList, isDownloading: $isDownloading, downloadProgress: $downloadProgress)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'InvoicePdfState'))
      ..add(DiagnosticsProperty('invoiceDetailsList', invoiceDetailsList))
      ..add(DiagnosticsProperty('isDownloading', isDownloading))
      ..add(DiagnosticsProperty('downloadProgress', downloadProgress));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InvoicePdfStateImpl &&
            (identical(other.invoiceDetailsList, invoiceDetailsList) ||
                other.invoiceDetailsList == invoiceDetailsList) &&
            (identical(other.isDownloading, isDownloading) ||
                other.isDownloading == isDownloading) &&
            (identical(other.downloadProgress, downloadProgress) ||
                other.downloadProgress == downloadProgress));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, invoiceDetailsList, isDownloading, downloadProgress);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$InvoicePdfStateImplCopyWith<_$InvoicePdfStateImpl> get copyWith =>
      __$$InvoicePdfStateImplCopyWithImpl<_$InvoicePdfStateImpl>(
          this, _$identity);
}

abstract class _InvoicePdfState implements InvoicePdfState {
  const factory _InvoicePdfState(
      {required final Invoice invoiceDetailsList,
      required final bool isDownloading,
      required final int downloadProgress}) = _$InvoicePdfStateImpl;

  @override
  Invoice get invoiceDetailsList;
  @override
  bool get isDownloading;
  @override
  int get downloadProgress;
  @override
  @JsonKey(ignore: true)
  _$$InvoicePdfStateImplCopyWith<_$InvoicePdfStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$InvoicePdfEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(Invoice invoiceDetailsList) getArgumentEvent,
    required TResult Function(BuildContext context) pdfDownloadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(Invoice invoiceDetailsList)? getArgumentEvent,
    TResult? Function(BuildContext context)? pdfDownloadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(Invoice invoiceDetailsList)? getArgumentEvent,
    TResult Function(BuildContext context)? pdfDownloadEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getArgumentEvent value) getArgumentEvent,
    required TResult Function(_pdfDownloadEvent value) pdfDownloadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getArgumentEvent value)? getArgumentEvent,
    TResult? Function(_pdfDownloadEvent value)? pdfDownloadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getArgumentEvent value)? getArgumentEvent,
    TResult Function(_pdfDownloadEvent value)? pdfDownloadEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InvoicePdfEventCopyWith<$Res> {
  factory $InvoicePdfEventCopyWith(
          InvoicePdfEvent value, $Res Function(InvoicePdfEvent) then) =
      _$InvoicePdfEventCopyWithImpl<$Res, InvoicePdfEvent>;
}

/// @nodoc
class _$InvoicePdfEventCopyWithImpl<$Res, $Val extends InvoicePdfEvent>
    implements $InvoicePdfEventCopyWith<$Res> {
  _$InvoicePdfEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getArgumentEventImplCopyWith<$Res> {
  factory _$$getArgumentEventImplCopyWith(_$getArgumentEventImpl value,
          $Res Function(_$getArgumentEventImpl) then) =
      __$$getArgumentEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Invoice invoiceDetailsList});

  $InvoiceCopyWith<$Res> get invoiceDetailsList;
}

/// @nodoc
class __$$getArgumentEventImplCopyWithImpl<$Res>
    extends _$InvoicePdfEventCopyWithImpl<$Res, _$getArgumentEventImpl>
    implements _$$getArgumentEventImplCopyWith<$Res> {
  __$$getArgumentEventImplCopyWithImpl(_$getArgumentEventImpl _value,
      $Res Function(_$getArgumentEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? invoiceDetailsList = null,
  }) {
    return _then(_$getArgumentEventImpl(
      invoiceDetailsList: null == invoiceDetailsList
          ? _value.invoiceDetailsList
          : invoiceDetailsList // ignore: cast_nullable_to_non_nullable
              as Invoice,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $InvoiceCopyWith<$Res> get invoiceDetailsList {
    return $InvoiceCopyWith<$Res>(_value.invoiceDetailsList, (value) {
      return _then(_value.copyWith(invoiceDetailsList: value));
    });
  }
}

/// @nodoc

class _$getArgumentEventImpl
    with DiagnosticableTreeMixin
    implements _getArgumentEvent {
  _$getArgumentEventImpl({required this.invoiceDetailsList});

  @override
  final Invoice invoiceDetailsList;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'InvoicePdfEvent.getArgumentEvent(invoiceDetailsList: $invoiceDetailsList)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'InvoicePdfEvent.getArgumentEvent'))
      ..add(DiagnosticsProperty('invoiceDetailsList', invoiceDetailsList));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getArgumentEventImpl &&
            (identical(other.invoiceDetailsList, invoiceDetailsList) ||
                other.invoiceDetailsList == invoiceDetailsList));
  }

  @override
  int get hashCode => Object.hash(runtimeType, invoiceDetailsList);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getArgumentEventImplCopyWith<_$getArgumentEventImpl> get copyWith =>
      __$$getArgumentEventImplCopyWithImpl<_$getArgumentEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(Invoice invoiceDetailsList) getArgumentEvent,
    required TResult Function(BuildContext context) pdfDownloadEvent,
  }) {
    return getArgumentEvent(invoiceDetailsList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(Invoice invoiceDetailsList)? getArgumentEvent,
    TResult? Function(BuildContext context)? pdfDownloadEvent,
  }) {
    return getArgumentEvent?.call(invoiceDetailsList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(Invoice invoiceDetailsList)? getArgumentEvent,
    TResult Function(BuildContext context)? pdfDownloadEvent,
    required TResult orElse(),
  }) {
    if (getArgumentEvent != null) {
      return getArgumentEvent(invoiceDetailsList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getArgumentEvent value) getArgumentEvent,
    required TResult Function(_pdfDownloadEvent value) pdfDownloadEvent,
  }) {
    return getArgumentEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getArgumentEvent value)? getArgumentEvent,
    TResult? Function(_pdfDownloadEvent value)? pdfDownloadEvent,
  }) {
    return getArgumentEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getArgumentEvent value)? getArgumentEvent,
    TResult Function(_pdfDownloadEvent value)? pdfDownloadEvent,
    required TResult orElse(),
  }) {
    if (getArgumentEvent != null) {
      return getArgumentEvent(this);
    }
    return orElse();
  }
}

abstract class _getArgumentEvent implements InvoicePdfEvent {
  factory _getArgumentEvent({required final Invoice invoiceDetailsList}) =
      _$getArgumentEventImpl;

  Invoice get invoiceDetailsList;
  @JsonKey(ignore: true)
  _$$getArgumentEventImplCopyWith<_$getArgumentEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$pdfDownloadEventImplCopyWith<$Res> {
  factory _$$pdfDownloadEventImplCopyWith(_$pdfDownloadEventImpl value,
          $Res Function(_$pdfDownloadEventImpl) then) =
      __$$pdfDownloadEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$pdfDownloadEventImplCopyWithImpl<$Res>
    extends _$InvoicePdfEventCopyWithImpl<$Res, _$pdfDownloadEventImpl>
    implements _$$pdfDownloadEventImplCopyWith<$Res> {
  __$$pdfDownloadEventImplCopyWithImpl(_$pdfDownloadEventImpl _value,
      $Res Function(_$pdfDownloadEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$pdfDownloadEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$pdfDownloadEventImpl
    with DiagnosticableTreeMixin
    implements _pdfDownloadEvent {
  _$pdfDownloadEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'InvoicePdfEvent.pdfDownloadEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'InvoicePdfEvent.pdfDownloadEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$pdfDownloadEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$pdfDownloadEventImplCopyWith<_$pdfDownloadEventImpl> get copyWith =>
      __$$pdfDownloadEventImplCopyWithImpl<_$pdfDownloadEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(Invoice invoiceDetailsList) getArgumentEvent,
    required TResult Function(BuildContext context) pdfDownloadEvent,
  }) {
    return pdfDownloadEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(Invoice invoiceDetailsList)? getArgumentEvent,
    TResult? Function(BuildContext context)? pdfDownloadEvent,
  }) {
    return pdfDownloadEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(Invoice invoiceDetailsList)? getArgumentEvent,
    TResult Function(BuildContext context)? pdfDownloadEvent,
    required TResult orElse(),
  }) {
    if (pdfDownloadEvent != null) {
      return pdfDownloadEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getArgumentEvent value) getArgumentEvent,
    required TResult Function(_pdfDownloadEvent value) pdfDownloadEvent,
  }) {
    return pdfDownloadEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getArgumentEvent value)? getArgumentEvent,
    TResult? Function(_pdfDownloadEvent value)? pdfDownloadEvent,
  }) {
    return pdfDownloadEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getArgumentEvent value)? getArgumentEvent,
    TResult Function(_pdfDownloadEvent value)? pdfDownloadEvent,
    required TResult orElse(),
  }) {
    if (pdfDownloadEvent != null) {
      return pdfDownloadEvent(this);
    }
    return orElse();
  }
}

abstract class _pdfDownloadEvent implements InvoicePdfEvent {
  factory _pdfDownloadEvent({required final BuildContext context}) =
      _$pdfDownloadEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$pdfDownloadEventImplCopyWith<_$pdfDownloadEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
