// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'privacy_policy_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$PrivacyPolicyState {
  String get filePath => throw _privateConstructorUsedError;
  Uint8List get pdfPath => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;
  bool get isOwner2Available => throw _privateConstructorUsedError;
  bool get isNextEnable => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PrivacyPolicyStateCopyWith<PrivacyPolicyState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PrivacyPolicyStateCopyWith<$Res> {
  factory $PrivacyPolicyStateCopyWith(
          PrivacyPolicyState value, $Res Function(PrivacyPolicyState) then) =
      _$PrivacyPolicyStateCopyWithImpl<$Res, PrivacyPolicyState>;
  @useResult
  $Res call(
      {String filePath,
      Uint8List pdfPath,
      bool isShimmering,
      bool isUpdate,
      bool isOwner2Available,
      bool isNextEnable});
}

/// @nodoc
class _$PrivacyPolicyStateCopyWithImpl<$Res, $Val extends PrivacyPolicyState>
    implements $PrivacyPolicyStateCopyWith<$Res> {
  _$PrivacyPolicyStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? filePath = null,
    Object? pdfPath = null,
    Object? isShimmering = null,
    Object? isUpdate = null,
    Object? isOwner2Available = null,
    Object? isNextEnable = null,
  }) {
    return _then(_value.copyWith(
      filePath: null == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      pdfPath: null == pdfPath
          ? _value.pdfPath
          : pdfPath // ignore: cast_nullable_to_non_nullable
              as Uint8List,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      isOwner2Available: null == isOwner2Available
          ? _value.isOwner2Available
          : isOwner2Available // ignore: cast_nullable_to_non_nullable
              as bool,
      isNextEnable: null == isNextEnable
          ? _value.isNextEnable
          : isNextEnable // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PrivacyPolicyStateImplCopyWith<$Res>
    implements $PrivacyPolicyStateCopyWith<$Res> {
  factory _$$PrivacyPolicyStateImplCopyWith(_$PrivacyPolicyStateImpl value,
          $Res Function(_$PrivacyPolicyStateImpl) then) =
      __$$PrivacyPolicyStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String filePath,
      Uint8List pdfPath,
      bool isShimmering,
      bool isUpdate,
      bool isOwner2Available,
      bool isNextEnable});
}

/// @nodoc
class __$$PrivacyPolicyStateImplCopyWithImpl<$Res>
    extends _$PrivacyPolicyStateCopyWithImpl<$Res, _$PrivacyPolicyStateImpl>
    implements _$$PrivacyPolicyStateImplCopyWith<$Res> {
  __$$PrivacyPolicyStateImplCopyWithImpl(_$PrivacyPolicyStateImpl _value,
      $Res Function(_$PrivacyPolicyStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? filePath = null,
    Object? pdfPath = null,
    Object? isShimmering = null,
    Object? isUpdate = null,
    Object? isOwner2Available = null,
    Object? isNextEnable = null,
  }) {
    return _then(_$PrivacyPolicyStateImpl(
      filePath: null == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      pdfPath: null == pdfPath
          ? _value.pdfPath
          : pdfPath // ignore: cast_nullable_to_non_nullable
              as Uint8List,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      isOwner2Available: null == isOwner2Available
          ? _value.isOwner2Available
          : isOwner2Available // ignore: cast_nullable_to_non_nullable
              as bool,
      isNextEnable: null == isNextEnable
          ? _value.isNextEnable
          : isNextEnable // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$PrivacyPolicyStateImpl
    with DiagnosticableTreeMixin
    implements _PrivacyPolicyState {
  const _$PrivacyPolicyStateImpl(
      {required this.filePath,
      required this.pdfPath,
      required this.isShimmering,
      required this.isUpdate,
      required this.isOwner2Available,
      required this.isNextEnable});

  @override
  final String filePath;
  @override
  final Uint8List pdfPath;
  @override
  final bool isShimmering;
  @override
  final bool isUpdate;
  @override
  final bool isOwner2Available;
  @override
  final bool isNextEnable;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'PrivacyPolicyState(filePath: $filePath, pdfPath: $pdfPath, isShimmering: $isShimmering, isUpdate: $isUpdate, isOwner2Available: $isOwner2Available, isNextEnable: $isNextEnable)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'PrivacyPolicyState'))
      ..add(DiagnosticsProperty('filePath', filePath))
      ..add(DiagnosticsProperty('pdfPath', pdfPath))
      ..add(DiagnosticsProperty('isShimmering', isShimmering))
      ..add(DiagnosticsProperty('isUpdate', isUpdate))
      ..add(DiagnosticsProperty('isOwner2Available', isOwner2Available))
      ..add(DiagnosticsProperty('isNextEnable', isNextEnable));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PrivacyPolicyStateImpl &&
            (identical(other.filePath, filePath) ||
                other.filePath == filePath) &&
            const DeepCollectionEquality().equals(other.pdfPath, pdfPath) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            (identical(other.isOwner2Available, isOwner2Available) ||
                other.isOwner2Available == isOwner2Available) &&
            (identical(other.isNextEnable, isNextEnable) ||
                other.isNextEnable == isNextEnable));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      filePath,
      const DeepCollectionEquality().hash(pdfPath),
      isShimmering,
      isUpdate,
      isOwner2Available,
      isNextEnable);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PrivacyPolicyStateImplCopyWith<_$PrivacyPolicyStateImpl> get copyWith =>
      __$$PrivacyPolicyStateImplCopyWithImpl<_$PrivacyPolicyStateImpl>(
          this, _$identity);
}

abstract class _PrivacyPolicyState implements PrivacyPolicyState {
  const factory _PrivacyPolicyState(
      {required final String filePath,
      required final Uint8List pdfPath,
      required final bool isShimmering,
      required final bool isUpdate,
      required final bool isOwner2Available,
      required final bool isNextEnable}) = _$PrivacyPolicyStateImpl;

  @override
  String get filePath;
  @override
  Uint8List get pdfPath;
  @override
  bool get isShimmering;
  @override
  bool get isUpdate;
  @override
  bool get isOwner2Available;
  @override
  bool get isNextEnable;
  @override
  @JsonKey(ignore: true)
  _$$PrivacyPolicyStateImplCopyWith<_$PrivacyPolicyStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$PrivacyPolicyEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)
        onFormFieldFocusChangeEvent,
    required TResult Function(
            BuildContext context, PdfSignatureFormField formField)
        saveSignatureEvent,
    required TResult Function(BuildContext context) navigationEvent,
    required TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)
        getPdfDataEvent,
    required TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)
        signatureEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult? Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult? Function(BuildContext context)? navigationEvent,
    TResult? Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult? Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult Function(BuildContext context)? navigationEvent,
    TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_onFormFieldFocusChangeEvent value)
        onFormFieldFocusChangeEvent,
    required TResult Function(_saveSignatureEvent value) saveSignatureEvent,
    required TResult Function(_navigationEvent value) navigationEvent,
    required TResult Function(_getPdfDataEvent value) getPdfDataEvent,
    required TResult Function(_signatureEvent value) signatureEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult? Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult? Function(_navigationEvent value)? navigationEvent,
    TResult? Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult? Function(_signatureEvent value)? signatureEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult Function(_navigationEvent value)? navigationEvent,
    TResult Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult Function(_signatureEvent value)? signatureEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PrivacyPolicyEventCopyWith<PrivacyPolicyEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PrivacyPolicyEventCopyWith<$Res> {
  factory $PrivacyPolicyEventCopyWith(
          PrivacyPolicyEvent value, $Res Function(PrivacyPolicyEvent) then) =
      _$PrivacyPolicyEventCopyWithImpl<$Res, PrivacyPolicyEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$PrivacyPolicyEventCopyWithImpl<$Res, $Val extends PrivacyPolicyEvent>
    implements $PrivacyPolicyEventCopyWith<$Res> {
  _$PrivacyPolicyEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$onFormFieldFocusChangeEventImplCopyWith<$Res>
    implements $PrivacyPolicyEventCopyWith<$Res> {
  factory _$$onFormFieldFocusChangeEventImplCopyWith(
          _$onFormFieldFocusChangeEventImpl value,
          $Res Function(_$onFormFieldFocusChangeEventImpl) then) =
      __$$onFormFieldFocusChangeEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, PdfFormFieldFocusChangeDetails details});
}

/// @nodoc
class __$$onFormFieldFocusChangeEventImplCopyWithImpl<$Res>
    extends _$PrivacyPolicyEventCopyWithImpl<$Res,
        _$onFormFieldFocusChangeEventImpl>
    implements _$$onFormFieldFocusChangeEventImplCopyWith<$Res> {
  __$$onFormFieldFocusChangeEventImplCopyWithImpl(
      _$onFormFieldFocusChangeEventImpl _value,
      $Res Function(_$onFormFieldFocusChangeEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? details = null,
  }) {
    return _then(_$onFormFieldFocusChangeEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      details: null == details
          ? _value.details
          : details // ignore: cast_nullable_to_non_nullable
              as PdfFormFieldFocusChangeDetails,
    ));
  }
}

/// @nodoc

class _$onFormFieldFocusChangeEventImpl
    with DiagnosticableTreeMixin
    implements _onFormFieldFocusChangeEvent {
  _$onFormFieldFocusChangeEventImpl(
      {required this.context, required this.details});

  @override
  final BuildContext context;
  @override
  final PdfFormFieldFocusChangeDetails details;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'PrivacyPolicyEvent.onFormFieldFocusChangeEvent(context: $context, details: $details)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty(
          'type', 'PrivacyPolicyEvent.onFormFieldFocusChangeEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('details', details));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$onFormFieldFocusChangeEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.details, details) || other.details == details));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, details);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$onFormFieldFocusChangeEventImplCopyWith<_$onFormFieldFocusChangeEventImpl>
      get copyWith => __$$onFormFieldFocusChangeEventImplCopyWithImpl<
          _$onFormFieldFocusChangeEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)
        onFormFieldFocusChangeEvent,
    required TResult Function(
            BuildContext context, PdfSignatureFormField formField)
        saveSignatureEvent,
    required TResult Function(BuildContext context) navigationEvent,
    required TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)
        getPdfDataEvent,
    required TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)
        signatureEvent,
  }) {
    return onFormFieldFocusChangeEvent(context, details);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult? Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult? Function(BuildContext context)? navigationEvent,
    TResult? Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult? Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
  }) {
    return onFormFieldFocusChangeEvent?.call(context, details);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult Function(BuildContext context)? navigationEvent,
    TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
    required TResult orElse(),
  }) {
    if (onFormFieldFocusChangeEvent != null) {
      return onFormFieldFocusChangeEvent(context, details);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_onFormFieldFocusChangeEvent value)
        onFormFieldFocusChangeEvent,
    required TResult Function(_saveSignatureEvent value) saveSignatureEvent,
    required TResult Function(_navigationEvent value) navigationEvent,
    required TResult Function(_getPdfDataEvent value) getPdfDataEvent,
    required TResult Function(_signatureEvent value) signatureEvent,
  }) {
    return onFormFieldFocusChangeEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult? Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult? Function(_navigationEvent value)? navigationEvent,
    TResult? Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult? Function(_signatureEvent value)? signatureEvent,
  }) {
    return onFormFieldFocusChangeEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult Function(_navigationEvent value)? navigationEvent,
    TResult Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult Function(_signatureEvent value)? signatureEvent,
    required TResult orElse(),
  }) {
    if (onFormFieldFocusChangeEvent != null) {
      return onFormFieldFocusChangeEvent(this);
    }
    return orElse();
  }
}

abstract class _onFormFieldFocusChangeEvent implements PrivacyPolicyEvent {
  factory _onFormFieldFocusChangeEvent(
          {required final BuildContext context,
          required final PdfFormFieldFocusChangeDetails details}) =
      _$onFormFieldFocusChangeEventImpl;

  @override
  BuildContext get context;
  PdfFormFieldFocusChangeDetails get details;
  @override
  @JsonKey(ignore: true)
  _$$onFormFieldFocusChangeEventImplCopyWith<_$onFormFieldFocusChangeEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$saveSignatureEventImplCopyWith<$Res>
    implements $PrivacyPolicyEventCopyWith<$Res> {
  factory _$$saveSignatureEventImplCopyWith(_$saveSignatureEventImpl value,
          $Res Function(_$saveSignatureEventImpl) then) =
      __$$saveSignatureEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, PdfSignatureFormField formField});
}

/// @nodoc
class __$$saveSignatureEventImplCopyWithImpl<$Res>
    extends _$PrivacyPolicyEventCopyWithImpl<$Res, _$saveSignatureEventImpl>
    implements _$$saveSignatureEventImplCopyWith<$Res> {
  __$$saveSignatureEventImplCopyWithImpl(_$saveSignatureEventImpl _value,
      $Res Function(_$saveSignatureEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? formField = null,
  }) {
    return _then(_$saveSignatureEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      formField: null == formField
          ? _value.formField
          : formField // ignore: cast_nullable_to_non_nullable
              as PdfSignatureFormField,
    ));
  }
}

/// @nodoc

class _$saveSignatureEventImpl
    with DiagnosticableTreeMixin
    implements _saveSignatureEvent {
  _$saveSignatureEventImpl({required this.context, required this.formField});

  @override
  final BuildContext context;
  @override
  final PdfSignatureFormField formField;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'PrivacyPolicyEvent.saveSignatureEvent(context: $context, formField: $formField)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(
          DiagnosticsProperty('type', 'PrivacyPolicyEvent.saveSignatureEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('formField', formField));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$saveSignatureEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.formField, formField) ||
                other.formField == formField));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, formField);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$saveSignatureEventImplCopyWith<_$saveSignatureEventImpl> get copyWith =>
      __$$saveSignatureEventImplCopyWithImpl<_$saveSignatureEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)
        onFormFieldFocusChangeEvent,
    required TResult Function(
            BuildContext context, PdfSignatureFormField formField)
        saveSignatureEvent,
    required TResult Function(BuildContext context) navigationEvent,
    required TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)
        getPdfDataEvent,
    required TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)
        signatureEvent,
  }) {
    return saveSignatureEvent(context, formField);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult? Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult? Function(BuildContext context)? navigationEvent,
    TResult? Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult? Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
  }) {
    return saveSignatureEvent?.call(context, formField);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult Function(BuildContext context)? navigationEvent,
    TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
    required TResult orElse(),
  }) {
    if (saveSignatureEvent != null) {
      return saveSignatureEvent(context, formField);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_onFormFieldFocusChangeEvent value)
        onFormFieldFocusChangeEvent,
    required TResult Function(_saveSignatureEvent value) saveSignatureEvent,
    required TResult Function(_navigationEvent value) navigationEvent,
    required TResult Function(_getPdfDataEvent value) getPdfDataEvent,
    required TResult Function(_signatureEvent value) signatureEvent,
  }) {
    return saveSignatureEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult? Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult? Function(_navigationEvent value)? navigationEvent,
    TResult? Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult? Function(_signatureEvent value)? signatureEvent,
  }) {
    return saveSignatureEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult Function(_navigationEvent value)? navigationEvent,
    TResult Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult Function(_signatureEvent value)? signatureEvent,
    required TResult orElse(),
  }) {
    if (saveSignatureEvent != null) {
      return saveSignatureEvent(this);
    }
    return orElse();
  }
}

abstract class _saveSignatureEvent implements PrivacyPolicyEvent {
  factory _saveSignatureEvent(
          {required final BuildContext context,
          required final PdfSignatureFormField formField}) =
      _$saveSignatureEventImpl;

  @override
  BuildContext get context;
  PdfSignatureFormField get formField;
  @override
  @JsonKey(ignore: true)
  _$$saveSignatureEventImplCopyWith<_$saveSignatureEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$navigationEventImplCopyWith<$Res>
    implements $PrivacyPolicyEventCopyWith<$Res> {
  factory _$$navigationEventImplCopyWith(_$navigationEventImpl value,
          $Res Function(_$navigationEventImpl) then) =
      __$$navigationEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$navigationEventImplCopyWithImpl<$Res>
    extends _$PrivacyPolicyEventCopyWithImpl<$Res, _$navigationEventImpl>
    implements _$$navigationEventImplCopyWith<$Res> {
  __$$navigationEventImplCopyWithImpl(
      _$navigationEventImpl _value, $Res Function(_$navigationEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$navigationEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$navigationEventImpl
    with DiagnosticableTreeMixin
    implements _navigationEvent {
  _$navigationEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'PrivacyPolicyEvent.navigationEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'PrivacyPolicyEvent.navigationEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$navigationEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$navigationEventImplCopyWith<_$navigationEventImpl> get copyWith =>
      __$$navigationEventImplCopyWithImpl<_$navigationEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)
        onFormFieldFocusChangeEvent,
    required TResult Function(
            BuildContext context, PdfSignatureFormField formField)
        saveSignatureEvent,
    required TResult Function(BuildContext context) navigationEvent,
    required TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)
        getPdfDataEvent,
    required TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)
        signatureEvent,
  }) {
    return navigationEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult? Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult? Function(BuildContext context)? navigationEvent,
    TResult? Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult? Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
  }) {
    return navigationEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult Function(BuildContext context)? navigationEvent,
    TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
    required TResult orElse(),
  }) {
    if (navigationEvent != null) {
      return navigationEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_onFormFieldFocusChangeEvent value)
        onFormFieldFocusChangeEvent,
    required TResult Function(_saveSignatureEvent value) saveSignatureEvent,
    required TResult Function(_navigationEvent value) navigationEvent,
    required TResult Function(_getPdfDataEvent value) getPdfDataEvent,
    required TResult Function(_signatureEvent value) signatureEvent,
  }) {
    return navigationEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult? Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult? Function(_navigationEvent value)? navigationEvent,
    TResult? Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult? Function(_signatureEvent value)? signatureEvent,
  }) {
    return navigationEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult Function(_navigationEvent value)? navigationEvent,
    TResult Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult Function(_signatureEvent value)? signatureEvent,
    required TResult orElse(),
  }) {
    if (navigationEvent != null) {
      return navigationEvent(this);
    }
    return orElse();
  }
}

abstract class _navigationEvent implements PrivacyPolicyEvent {
  factory _navigationEvent({required final BuildContext context}) =
      _$navigationEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$navigationEventImplCopyWith<_$navigationEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPdfDataEventImplCopyWith<$Res>
    implements $PrivacyPolicyEventCopyWith<$Res> {
  factory _$$getPdfDataEventImplCopyWith(_$getPdfDataEventImpl value,
          $Res Function(_$getPdfDataEventImpl) then) =
      __$$getPdfDataEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {BuildContext context,
      String pdfData,
      TermsConditionReqModel termsConditionReqModel});

  $TermsConditionReqModelCopyWith<$Res> get termsConditionReqModel;
}

/// @nodoc
class __$$getPdfDataEventImplCopyWithImpl<$Res>
    extends _$PrivacyPolicyEventCopyWithImpl<$Res, _$getPdfDataEventImpl>
    implements _$$getPdfDataEventImplCopyWith<$Res> {
  __$$getPdfDataEventImplCopyWithImpl(
      _$getPdfDataEventImpl _value, $Res Function(_$getPdfDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? pdfData = null,
    Object? termsConditionReqModel = null,
  }) {
    return _then(_$getPdfDataEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      pdfData: null == pdfData
          ? _value.pdfData
          : pdfData // ignore: cast_nullable_to_non_nullable
              as String,
      termsConditionReqModel: null == termsConditionReqModel
          ? _value.termsConditionReqModel
          : termsConditionReqModel // ignore: cast_nullable_to_non_nullable
              as TermsConditionReqModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $TermsConditionReqModelCopyWith<$Res> get termsConditionReqModel {
    return $TermsConditionReqModelCopyWith<$Res>(_value.termsConditionReqModel,
        (value) {
      return _then(_value.copyWith(termsConditionReqModel: value));
    });
  }
}

/// @nodoc

class _$getPdfDataEventImpl
    with DiagnosticableTreeMixin
    implements _getPdfDataEvent {
  _$getPdfDataEventImpl(
      {required this.context,
      required this.pdfData,
      required this.termsConditionReqModel});

  @override
  final BuildContext context;
  @override
  final String pdfData;
  @override
  final TermsConditionReqModel termsConditionReqModel;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'PrivacyPolicyEvent.getPdfDataEvent(context: $context, pdfData: $pdfData, termsConditionReqModel: $termsConditionReqModel)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'PrivacyPolicyEvent.getPdfDataEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('pdfData', pdfData))
      ..add(DiagnosticsProperty(
          'termsConditionReqModel', termsConditionReqModel));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPdfDataEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.pdfData, pdfData) || other.pdfData == pdfData) &&
            (identical(other.termsConditionReqModel, termsConditionReqModel) ||
                other.termsConditionReqModel == termsConditionReqModel));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, pdfData, termsConditionReqModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPdfDataEventImplCopyWith<_$getPdfDataEventImpl> get copyWith =>
      __$$getPdfDataEventImplCopyWithImpl<_$getPdfDataEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)
        onFormFieldFocusChangeEvent,
    required TResult Function(
            BuildContext context, PdfSignatureFormField formField)
        saveSignatureEvent,
    required TResult Function(BuildContext context) navigationEvent,
    required TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)
        getPdfDataEvent,
    required TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)
        signatureEvent,
  }) {
    return getPdfDataEvent(context, pdfData, termsConditionReqModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult? Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult? Function(BuildContext context)? navigationEvent,
    TResult? Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult? Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
  }) {
    return getPdfDataEvent?.call(context, pdfData, termsConditionReqModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult Function(BuildContext context)? navigationEvent,
    TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
    required TResult orElse(),
  }) {
    if (getPdfDataEvent != null) {
      return getPdfDataEvent(context, pdfData, termsConditionReqModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_onFormFieldFocusChangeEvent value)
        onFormFieldFocusChangeEvent,
    required TResult Function(_saveSignatureEvent value) saveSignatureEvent,
    required TResult Function(_navigationEvent value) navigationEvent,
    required TResult Function(_getPdfDataEvent value) getPdfDataEvent,
    required TResult Function(_signatureEvent value) signatureEvent,
  }) {
    return getPdfDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult? Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult? Function(_navigationEvent value)? navigationEvent,
    TResult? Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult? Function(_signatureEvent value)? signatureEvent,
  }) {
    return getPdfDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult Function(_navigationEvent value)? navigationEvent,
    TResult Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult Function(_signatureEvent value)? signatureEvent,
    required TResult orElse(),
  }) {
    if (getPdfDataEvent != null) {
      return getPdfDataEvent(this);
    }
    return orElse();
  }
}

abstract class _getPdfDataEvent implements PrivacyPolicyEvent {
  factory _getPdfDataEvent(
          {required final BuildContext context,
          required final String pdfData,
          required final TermsConditionReqModel termsConditionReqModel}) =
      _$getPdfDataEventImpl;

  @override
  BuildContext get context;
  String get pdfData;
  TermsConditionReqModel get termsConditionReqModel;
  @override
  @JsonKey(ignore: true)
  _$$getPdfDataEventImplCopyWith<_$getPdfDataEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$signatureEventImplCopyWith<$Res>
    implements $PrivacyPolicyEventCopyWith<$Res> {
  factory _$$signatureEventImplCopyWith(_$signatureEventImpl value,
          $Res Function(_$signatureEventImpl) then) =
      __$$signatureEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, String fieldName, String fieldNameForSign});
}

/// @nodoc
class __$$signatureEventImplCopyWithImpl<$Res>
    extends _$PrivacyPolicyEventCopyWithImpl<$Res, _$signatureEventImpl>
    implements _$$signatureEventImplCopyWith<$Res> {
  __$$signatureEventImplCopyWithImpl(
      _$signatureEventImpl _value, $Res Function(_$signatureEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? fieldName = null,
    Object? fieldNameForSign = null,
  }) {
    return _then(_$signatureEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      fieldName: null == fieldName
          ? _value.fieldName
          : fieldName // ignore: cast_nullable_to_non_nullable
              as String,
      fieldNameForSign: null == fieldNameForSign
          ? _value.fieldNameForSign
          : fieldNameForSign // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$signatureEventImpl
    with DiagnosticableTreeMixin
    implements _signatureEvent {
  _$signatureEventImpl(
      {required this.context,
      required this.fieldName,
      required this.fieldNameForSign});

  @override
  final BuildContext context;
  @override
  final String fieldName;
  @override
  final String fieldNameForSign;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'PrivacyPolicyEvent.signatureEvent(context: $context, fieldName: $fieldName, fieldNameForSign: $fieldNameForSign)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'PrivacyPolicyEvent.signatureEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('fieldName', fieldName))
      ..add(DiagnosticsProperty('fieldNameForSign', fieldNameForSign));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$signatureEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.fieldName, fieldName) ||
                other.fieldName == fieldName) &&
            (identical(other.fieldNameForSign, fieldNameForSign) ||
                other.fieldNameForSign == fieldNameForSign));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, fieldName, fieldNameForSign);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$signatureEventImplCopyWith<_$signatureEventImpl> get copyWith =>
      __$$signatureEventImplCopyWithImpl<_$signatureEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)
        onFormFieldFocusChangeEvent,
    required TResult Function(
            BuildContext context, PdfSignatureFormField formField)
        saveSignatureEvent,
    required TResult Function(BuildContext context) navigationEvent,
    required TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)
        getPdfDataEvent,
    required TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)
        signatureEvent,
  }) {
    return signatureEvent(context, fieldName, fieldNameForSign);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult? Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult? Function(BuildContext context)? navigationEvent,
    TResult? Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult? Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
  }) {
    return signatureEvent?.call(context, fieldName, fieldNameForSign);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, PdfFormFieldFocusChangeDetails details)?
        onFormFieldFocusChangeEvent,
    TResult Function(BuildContext context, PdfSignatureFormField formField)?
        saveSignatureEvent,
    TResult Function(BuildContext context)? navigationEvent,
    TResult Function(BuildContext context, String pdfData,
            TermsConditionReqModel termsConditionReqModel)?
        getPdfDataEvent,
    TResult Function(
            BuildContext context, String fieldName, String fieldNameForSign)?
        signatureEvent,
    required TResult orElse(),
  }) {
    if (signatureEvent != null) {
      return signatureEvent(context, fieldName, fieldNameForSign);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_onFormFieldFocusChangeEvent value)
        onFormFieldFocusChangeEvent,
    required TResult Function(_saveSignatureEvent value) saveSignatureEvent,
    required TResult Function(_navigationEvent value) navigationEvent,
    required TResult Function(_getPdfDataEvent value) getPdfDataEvent,
    required TResult Function(_signatureEvent value) signatureEvent,
  }) {
    return signatureEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult? Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult? Function(_navigationEvent value)? navigationEvent,
    TResult? Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult? Function(_signatureEvent value)? signatureEvent,
  }) {
    return signatureEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_onFormFieldFocusChangeEvent value)?
        onFormFieldFocusChangeEvent,
    TResult Function(_saveSignatureEvent value)? saveSignatureEvent,
    TResult Function(_navigationEvent value)? navigationEvent,
    TResult Function(_getPdfDataEvent value)? getPdfDataEvent,
    TResult Function(_signatureEvent value)? signatureEvent,
    required TResult orElse(),
  }) {
    if (signatureEvent != null) {
      return signatureEvent(this);
    }
    return orElse();
  }
}

abstract class _signatureEvent implements PrivacyPolicyEvent {
  factory _signatureEvent(
      {required final BuildContext context,
      required final String fieldName,
      required final String fieldNameForSign}) = _$signatureEventImpl;

  @override
  BuildContext get context;
  String get fieldName;
  String get fieldNameForSign;
  @override
  @JsonKey(ignore: true)
  _$$signatureEventImplCopyWith<_$signatureEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
