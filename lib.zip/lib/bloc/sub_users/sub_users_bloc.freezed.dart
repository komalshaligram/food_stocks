// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sub_users_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SubUsersEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSubUserList,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context) popEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSubUserList,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context)? popEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSubUserList,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context)? popEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getSubUserList value) getSubUserList,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_popEvent value) popEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getSubUserList value)? getSubUserList,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_popEvent value)? popEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getSubUserList value)? getSubUserList,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_popEvent value)? popEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SubUsersEventCopyWith<SubUsersEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubUsersEventCopyWith<$Res> {
  factory $SubUsersEventCopyWith(
          SubUsersEvent value, $Res Function(SubUsersEvent) then) =
      _$SubUsersEventCopyWithImpl<$Res, SubUsersEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$SubUsersEventCopyWithImpl<$Res, $Val extends SubUsersEvent>
    implements $SubUsersEventCopyWith<$Res> {
  _$SubUsersEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$getSubUserListImplCopyWith<$Res>
    implements $SubUsersEventCopyWith<$Res> {
  factory _$$getSubUserListImplCopyWith(_$getSubUserListImpl value,
          $Res Function(_$getSubUserListImpl) then) =
      __$$getSubUserListImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getSubUserListImplCopyWithImpl<$Res>
    extends _$SubUsersEventCopyWithImpl<$Res, _$getSubUserListImpl>
    implements _$$getSubUserListImplCopyWith<$Res> {
  __$$getSubUserListImplCopyWithImpl(
      _$getSubUserListImpl _value, $Res Function(_$getSubUserListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getSubUserListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getSubUserListImpl implements _getSubUserList {
  const _$getSubUserListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SubUsersEvent.getSubUserList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getSubUserListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getSubUserListImplCopyWith<_$getSubUserListImpl> get copyWith =>
      __$$getSubUserListImplCopyWithImpl<_$getSubUserListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSubUserList,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context) popEvent,
  }) {
    return getSubUserList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSubUserList,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context)? popEvent,
  }) {
    return getSubUserList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSubUserList,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context)? popEvent,
    required TResult orElse(),
  }) {
    if (getSubUserList != null) {
      return getSubUserList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getSubUserList value) getSubUserList,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_popEvent value) popEvent,
  }) {
    return getSubUserList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getSubUserList value)? getSubUserList,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_popEvent value)? popEvent,
  }) {
    return getSubUserList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getSubUserList value)? getSubUserList,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_popEvent value)? popEvent,
    required TResult orElse(),
  }) {
    if (getSubUserList != null) {
      return getSubUserList(this);
    }
    return orElse();
  }
}

abstract class _getSubUserList implements SubUsersEvent {
  const factory _getSubUserList({required final BuildContext context}) =
      _$getSubUserListImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$getSubUserListImplCopyWith<_$getSubUserListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res>
    implements $SubUsersEventCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$SubUsersEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SubUsersEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSubUserList,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context) popEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSubUserList,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context)? popEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSubUserList,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context)? popEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getSubUserList value) getSubUserList,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_popEvent value) popEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getSubUserList value)? getSubUserList,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_popEvent value)? popEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getSubUserList value)? getSubUserList,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_popEvent value)? popEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements SubUsersEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$popEventImplCopyWith<$Res>
    implements $SubUsersEventCopyWith<$Res> {
  factory _$$popEventImplCopyWith(
          _$popEventImpl value, $Res Function(_$popEventImpl) then) =
      __$$popEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$popEventImplCopyWithImpl<$Res>
    extends _$SubUsersEventCopyWithImpl<$Res, _$popEventImpl>
    implements _$$popEventImplCopyWith<$Res> {
  __$$popEventImplCopyWithImpl(
      _$popEventImpl _value, $Res Function(_$popEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$popEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$popEventImpl implements _popEvent {
  const _$popEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SubUsersEvent.popEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$popEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$popEventImplCopyWith<_$popEventImpl> get copyWith =>
      __$$popEventImplCopyWithImpl<_$popEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSubUserList,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context) popEvent,
  }) {
    return popEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSubUserList,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context)? popEvent,
  }) {
    return popEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSubUserList,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context)? popEvent,
    required TResult orElse(),
  }) {
    if (popEvent != null) {
      return popEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getSubUserList value) getSubUserList,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_popEvent value) popEvent,
  }) {
    return popEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getSubUserList value)? getSubUserList,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_popEvent value)? popEvent,
  }) {
    return popEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getSubUserList value)? getSubUserList,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_popEvent value)? popEvent,
    required TResult orElse(),
  }) {
    if (popEvent != null) {
      return popEvent(this);
    }
    return orElse();
  }
}

abstract class _popEvent implements SubUsersEvent {
  const factory _popEvent({required final BuildContext context}) =
      _$popEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$popEventImplCopyWith<_$popEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SubUsersState {
  bool get isShimmering => throw _privateConstructorUsedError;
  List<User> get subUserList => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfProducts => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  bool get isPop => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SubUsersStateCopyWith<SubUsersState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubUsersStateCopyWith<$Res> {
  factory $SubUsersStateCopyWith(
          SubUsersState value, $Res Function(SubUsersState) then) =
      _$SubUsersStateCopyWithImpl<$Res, SubUsersState>;
  @useResult
  $Res call(
      {bool isShimmering,
      List<User> subUserList,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      RefreshController refreshController,
      bool isPop});
}

/// @nodoc
class _$SubUsersStateCopyWithImpl<$Res, $Val extends SubUsersState>
    implements $SubUsersStateCopyWith<$Res> {
  _$SubUsersStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? subUserList = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? refreshController = null,
    Object? isPop = null,
  }) {
    return _then(_value.copyWith(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserList: null == subUserList
          ? _value.subUserList
          : subUserList // ignore: cast_nullable_to_non_nullable
              as List<User>,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      isPop: null == isPop
          ? _value.isPop
          : isPop // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubUsersStateImplCopyWith<$Res>
    implements $SubUsersStateCopyWith<$Res> {
  factory _$$SubUsersStateImplCopyWith(
          _$SubUsersStateImpl value, $Res Function(_$SubUsersStateImpl) then) =
      __$$SubUsersStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isShimmering,
      List<User> subUserList,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      RefreshController refreshController,
      bool isPop});
}

/// @nodoc
class __$$SubUsersStateImplCopyWithImpl<$Res>
    extends _$SubUsersStateCopyWithImpl<$Res, _$SubUsersStateImpl>
    implements _$$SubUsersStateImplCopyWith<$Res> {
  __$$SubUsersStateImplCopyWithImpl(
      _$SubUsersStateImpl _value, $Res Function(_$SubUsersStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? subUserList = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? refreshController = null,
    Object? isPop = null,
  }) {
    return _then(_$SubUsersStateImpl(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserList: null == subUserList
          ? _value._subUserList
          : subUserList // ignore: cast_nullable_to_non_nullable
              as List<User>,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      isPop: null == isPop
          ? _value.isPop
          : isPop // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$SubUsersStateImpl implements _SubUsersState {
  const _$SubUsersStateImpl(
      {required this.isShimmering,
      required final List<User> subUserList,
      required this.pageNum,
      required this.isLoadMore,
      required this.isBottomOfProducts,
      required this.refreshController,
      required this.isPop})
      : _subUserList = subUserList;

  @override
  final bool isShimmering;
  final List<User> _subUserList;
  @override
  List<User> get subUserList {
    if (_subUserList is EqualUnmodifiableListView) return _subUserList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_subUserList);
  }

  @override
  final int pageNum;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfProducts;
  @override
  final RefreshController refreshController;
  @override
  final bool isPop;

  @override
  String toString() {
    return 'SubUsersState(isShimmering: $isShimmering, subUserList: $subUserList, pageNum: $pageNum, isLoadMore: $isLoadMore, isBottomOfProducts: $isBottomOfProducts, refreshController: $refreshController, isPop: $isPop)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubUsersStateImpl &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            const DeepCollectionEquality()
                .equals(other._subUserList, _subUserList) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfProducts, isBottomOfProducts) ||
                other.isBottomOfProducts == isBottomOfProducts) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.isPop, isPop) || other.isPop == isPop));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isShimmering,
      const DeepCollectionEquality().hash(_subUserList),
      pageNum,
      isLoadMore,
      isBottomOfProducts,
      refreshController,
      isPop);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubUsersStateImplCopyWith<_$SubUsersStateImpl> get copyWith =>
      __$$SubUsersStateImplCopyWithImpl<_$SubUsersStateImpl>(this, _$identity);
}

abstract class _SubUsersState implements SubUsersState {
  const factory _SubUsersState(
      {required final bool isShimmering,
      required final List<User> subUserList,
      required final int pageNum,
      required final bool isLoadMore,
      required final bool isBottomOfProducts,
      required final RefreshController refreshController,
      required final bool isPop}) = _$SubUsersStateImpl;

  @override
  bool get isShimmering;
  @override
  List<User> get subUserList;
  @override
  int get pageNum;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfProducts;
  @override
  RefreshController get refreshController;
  @override
  bool get isPop;
  @override
  @JsonKey(ignore: true)
  _$$SubUsersStateImplCopyWith<_$SubUsersStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
