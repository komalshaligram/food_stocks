// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'file_upload_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$FileUploadState {
  List<FormAndFileModel> get formsAndFilesList =>
      throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isApiLoading => throw _privateConstructorUsedError;
  bool get isUploadLoading => throw _privateConstructorUsedError;
  int get uploadIndex => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isDownloading => throw _privateConstructorUsedError;
  int get downloadProgress => throw _privateConstructorUsedError;
  bool get isFileSizeExceeds => throw _privateConstructorUsedError;
  bool get isRemoveProcess => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  bool get isPdfPreview => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $FileUploadStateCopyWith<FileUploadState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FileUploadStateCopyWith<$Res> {
  factory $FileUploadStateCopyWith(
          FileUploadState value, $Res Function(FileUploadState) then) =
      _$FileUploadStateCopyWithImpl<$Res, FileUploadState>;
  @useResult
  $Res call(
      {List<FormAndFileModel> formsAndFilesList,
      bool isLoading,
      bool isApiLoading,
      bool isUploadLoading,
      int uploadIndex,
      bool isUpdate,
      bool isShimmering,
      bool isDownloading,
      int downloadProgress,
      bool isFileSizeExceeds,
      bool isRemoveProcess,
      String language,
      bool isPdfPreview});
}

/// @nodoc
class _$FileUploadStateCopyWithImpl<$Res, $Val extends FileUploadState>
    implements $FileUploadStateCopyWith<$Res> {
  _$FileUploadStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? formsAndFilesList = null,
    Object? isLoading = null,
    Object? isApiLoading = null,
    Object? isUploadLoading = null,
    Object? uploadIndex = null,
    Object? isUpdate = null,
    Object? isShimmering = null,
    Object? isDownloading = null,
    Object? downloadProgress = null,
    Object? isFileSizeExceeds = null,
    Object? isRemoveProcess = null,
    Object? language = null,
    Object? isPdfPreview = null,
  }) {
    return _then(_value.copyWith(
      formsAndFilesList: null == formsAndFilesList
          ? _value.formsAndFilesList
          : formsAndFilesList // ignore: cast_nullable_to_non_nullable
              as List<FormAndFileModel>,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isApiLoading: null == isApiLoading
          ? _value.isApiLoading
          : isApiLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadLoading: null == isUploadLoading
          ? _value.isUploadLoading
          : isUploadLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      uploadIndex: null == uploadIndex
          ? _value.uploadIndex
          : uploadIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isDownloading: null == isDownloading
          ? _value.isDownloading
          : isDownloading // ignore: cast_nullable_to_non_nullable
              as bool,
      downloadProgress: null == downloadProgress
          ? _value.downloadProgress
          : downloadProgress // ignore: cast_nullable_to_non_nullable
              as int,
      isFileSizeExceeds: null == isFileSizeExceeds
          ? _value.isFileSizeExceeds
          : isFileSizeExceeds // ignore: cast_nullable_to_non_nullable
              as bool,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      isPdfPreview: null == isPdfPreview
          ? _value.isPdfPreview
          : isPdfPreview // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FileUploadStateImplCopyWith<$Res>
    implements $FileUploadStateCopyWith<$Res> {
  factory _$$FileUploadStateImplCopyWith(_$FileUploadStateImpl value,
          $Res Function(_$FileUploadStateImpl) then) =
      __$$FileUploadStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<FormAndFileModel> formsAndFilesList,
      bool isLoading,
      bool isApiLoading,
      bool isUploadLoading,
      int uploadIndex,
      bool isUpdate,
      bool isShimmering,
      bool isDownloading,
      int downloadProgress,
      bool isFileSizeExceeds,
      bool isRemoveProcess,
      String language,
      bool isPdfPreview});
}

/// @nodoc
class __$$FileUploadStateImplCopyWithImpl<$Res>
    extends _$FileUploadStateCopyWithImpl<$Res, _$FileUploadStateImpl>
    implements _$$FileUploadStateImplCopyWith<$Res> {
  __$$FileUploadStateImplCopyWithImpl(
      _$FileUploadStateImpl _value, $Res Function(_$FileUploadStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? formsAndFilesList = null,
    Object? isLoading = null,
    Object? isApiLoading = null,
    Object? isUploadLoading = null,
    Object? uploadIndex = null,
    Object? isUpdate = null,
    Object? isShimmering = null,
    Object? isDownloading = null,
    Object? downloadProgress = null,
    Object? isFileSizeExceeds = null,
    Object? isRemoveProcess = null,
    Object? language = null,
    Object? isPdfPreview = null,
  }) {
    return _then(_$FileUploadStateImpl(
      formsAndFilesList: null == formsAndFilesList
          ? _value._formsAndFilesList
          : formsAndFilesList // ignore: cast_nullable_to_non_nullable
              as List<FormAndFileModel>,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isApiLoading: null == isApiLoading
          ? _value.isApiLoading
          : isApiLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadLoading: null == isUploadLoading
          ? _value.isUploadLoading
          : isUploadLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      uploadIndex: null == uploadIndex
          ? _value.uploadIndex
          : uploadIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isDownloading: null == isDownloading
          ? _value.isDownloading
          : isDownloading // ignore: cast_nullable_to_non_nullable
              as bool,
      downloadProgress: null == downloadProgress
          ? _value.downloadProgress
          : downloadProgress // ignore: cast_nullable_to_non_nullable
              as int,
      isFileSizeExceeds: null == isFileSizeExceeds
          ? _value.isFileSizeExceeds
          : isFileSizeExceeds // ignore: cast_nullable_to_non_nullable
              as bool,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      isPdfPreview: null == isPdfPreview
          ? _value.isPdfPreview
          : isPdfPreview // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$FileUploadStateImpl
    with DiagnosticableTreeMixin
    implements _FileUploadState {
  const _$FileUploadStateImpl(
      {required final List<FormAndFileModel> formsAndFilesList,
      required this.isLoading,
      required this.isApiLoading,
      required this.isUploadLoading,
      required this.uploadIndex,
      required this.isUpdate,
      required this.isShimmering,
      required this.isDownloading,
      required this.downloadProgress,
      required this.isFileSizeExceeds,
      required this.isRemoveProcess,
      required this.language,
      required this.isPdfPreview})
      : _formsAndFilesList = formsAndFilesList;

  final List<FormAndFileModel> _formsAndFilesList;
  @override
  List<FormAndFileModel> get formsAndFilesList {
    if (_formsAndFilesList is EqualUnmodifiableListView)
      return _formsAndFilesList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_formsAndFilesList);
  }

  @override
  final bool isLoading;
  @override
  final bool isApiLoading;
  @override
  final bool isUploadLoading;
  @override
  final int uploadIndex;
  @override
  final bool isUpdate;
  @override
  final bool isShimmering;
  @override
  final bool isDownloading;
  @override
  final int downloadProgress;
  @override
  final bool isFileSizeExceeds;
  @override
  final bool isRemoveProcess;
  @override
  final String language;
  @override
  final bool isPdfPreview;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadState(formsAndFilesList: $formsAndFilesList, isLoading: $isLoading, isApiLoading: $isApiLoading, isUploadLoading: $isUploadLoading, uploadIndex: $uploadIndex, isUpdate: $isUpdate, isShimmering: $isShimmering, isDownloading: $isDownloading, downloadProgress: $downloadProgress, isFileSizeExceeds: $isFileSizeExceeds, isRemoveProcess: $isRemoveProcess, language: $language, isPdfPreview: $isPdfPreview)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadState'))
      ..add(DiagnosticsProperty('formsAndFilesList', formsAndFilesList))
      ..add(DiagnosticsProperty('isLoading', isLoading))
      ..add(DiagnosticsProperty('isApiLoading', isApiLoading))
      ..add(DiagnosticsProperty('isUploadLoading', isUploadLoading))
      ..add(DiagnosticsProperty('uploadIndex', uploadIndex))
      ..add(DiagnosticsProperty('isUpdate', isUpdate))
      ..add(DiagnosticsProperty('isShimmering', isShimmering))
      ..add(DiagnosticsProperty('isDownloading', isDownloading))
      ..add(DiagnosticsProperty('downloadProgress', downloadProgress))
      ..add(DiagnosticsProperty('isFileSizeExceeds', isFileSizeExceeds))
      ..add(DiagnosticsProperty('isRemoveProcess', isRemoveProcess))
      ..add(DiagnosticsProperty('language', language))
      ..add(DiagnosticsProperty('isPdfPreview', isPdfPreview));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FileUploadStateImpl &&
            const DeepCollectionEquality()
                .equals(other._formsAndFilesList, _formsAndFilesList) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isApiLoading, isApiLoading) ||
                other.isApiLoading == isApiLoading) &&
            (identical(other.isUploadLoading, isUploadLoading) ||
                other.isUploadLoading == isUploadLoading) &&
            (identical(other.uploadIndex, uploadIndex) ||
                other.uploadIndex == uploadIndex) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isDownloading, isDownloading) ||
                other.isDownloading == isDownloading) &&
            (identical(other.downloadProgress, downloadProgress) ||
                other.downloadProgress == downloadProgress) &&
            (identical(other.isFileSizeExceeds, isFileSizeExceeds) ||
                other.isFileSizeExceeds == isFileSizeExceeds) &&
            (identical(other.isRemoveProcess, isRemoveProcess) ||
                other.isRemoveProcess == isRemoveProcess) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.isPdfPreview, isPdfPreview) ||
                other.isPdfPreview == isPdfPreview));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_formsAndFilesList),
      isLoading,
      isApiLoading,
      isUploadLoading,
      uploadIndex,
      isUpdate,
      isShimmering,
      isDownloading,
      downloadProgress,
      isFileSizeExceeds,
      isRemoveProcess,
      language,
      isPdfPreview);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FileUploadStateImplCopyWith<_$FileUploadStateImpl> get copyWith =>
      __$$FileUploadStateImplCopyWithImpl<_$FileUploadStateImpl>(
          this, _$identity);
}

abstract class _FileUploadState implements FileUploadState {
  const factory _FileUploadState(
      {required final List<FormAndFileModel> formsAndFilesList,
      required final bool isLoading,
      required final bool isApiLoading,
      required final bool isUploadLoading,
      required final int uploadIndex,
      required final bool isUpdate,
      required final bool isShimmering,
      required final bool isDownloading,
      required final int downloadProgress,
      required final bool isFileSizeExceeds,
      required final bool isRemoveProcess,
      required final String language,
      required final bool isPdfPreview}) = _$FileUploadStateImpl;

  @override
  List<FormAndFileModel> get formsAndFilesList;
  @override
  bool get isLoading;
  @override
  bool get isApiLoading;
  @override
  bool get isUploadLoading;
  @override
  int get uploadIndex;
  @override
  bool get isUpdate;
  @override
  bool get isShimmering;
  @override
  bool get isDownloading;
  @override
  int get downloadProgress;
  @override
  bool get isFileSizeExceeds;
  @override
  bool get isRemoveProcess;
  @override
  String get language;
  @override
  bool get isPdfPreview;
  @override
  @JsonKey(ignore: true)
  _$$FileUploadStateImplCopyWith<_$FileUploadStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$FileUploadEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $FileUploadEventCopyWith<FileUploadEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FileUploadEventCopyWith<$Res> {
  factory $FileUploadEventCopyWith(
          FileUploadEvent value, $Res Function(FileUploadEvent) then) =
      _$FileUploadEventCopyWithImpl<$Res, FileUploadEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$FileUploadEventCopyWithImpl<$Res, $Val extends FileUploadEvent>
    implements $FileUploadEventCopyWith<$Res> {
  _$FileUploadEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$getFilesListEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$getFilesListEventImplCopyWith(_$getFilesListEventImpl value,
          $Res Function(_$getFilesListEventImpl) then) =
      __$$getFilesListEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, bool isUpdate});
}

/// @nodoc
class __$$getFilesListEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$getFilesListEventImpl>
    implements _$$getFilesListEventImplCopyWith<$Res> {
  __$$getFilesListEventImplCopyWithImpl(_$getFilesListEventImpl _value,
      $Res Function(_$getFilesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isUpdate = null,
  }) {
    return _then(_$getFilesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$getFilesListEventImpl
    with DiagnosticableTreeMixin
    implements _getFilesListEvent {
  _$getFilesListEventImpl({required this.context, required this.isUpdate});

  @override
  final BuildContext context;
  @override
  final bool isUpdate;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.getFilesListEvent(context: $context, isUpdate: $isUpdate)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadEvent.getFilesListEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('isUpdate', isUpdate));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getFilesListEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getFilesListEventImplCopyWith<_$getFilesListEventImpl> get copyWith =>
      __$$getFilesListEventImplCopyWithImpl<_$getFilesListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return getFilesListEvent(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return getFilesListEvent?.call(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (getFilesListEvent != null) {
      return getFilesListEvent(context, isUpdate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return getFilesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return getFilesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (getFilesListEvent != null) {
      return getFilesListEvent(this);
    }
    return orElse();
  }
}

abstract class _getFilesListEvent implements FileUploadEvent {
  factory _getFilesListEvent(
      {required final BuildContext context,
      required final bool isUpdate}) = _$getFilesListEventImpl;

  @override
  BuildContext get context;
  bool get isUpdate;
  @override
  @JsonKey(ignore: true)
  _$$getFilesListEventImplCopyWith<_$getFilesListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getFormsListEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$getFormsListEventImplCopyWith(_$getFormsListEventImpl value,
          $Res Function(_$getFormsListEventImpl) then) =
      __$$getFormsListEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, bool isUpdate});
}

/// @nodoc
class __$$getFormsListEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$getFormsListEventImpl>
    implements _$$getFormsListEventImplCopyWith<$Res> {
  __$$getFormsListEventImplCopyWithImpl(_$getFormsListEventImpl _value,
      $Res Function(_$getFormsListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isUpdate = null,
  }) {
    return _then(_$getFormsListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$getFormsListEventImpl
    with DiagnosticableTreeMixin
    implements _getFormsListEvent {
  _$getFormsListEventImpl({required this.context, required this.isUpdate});

  @override
  final BuildContext context;
  @override
  final bool isUpdate;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.getFormsListEvent(context: $context, isUpdate: $isUpdate)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadEvent.getFormsListEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('isUpdate', isUpdate));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getFormsListEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getFormsListEventImplCopyWith<_$getFormsListEventImpl> get copyWith =>
      __$$getFormsListEventImplCopyWithImpl<_$getFormsListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return getFormsListEvent(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return getFormsListEvent?.call(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (getFormsListEvent != null) {
      return getFormsListEvent(context, isUpdate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return getFormsListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return getFormsListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (getFormsListEvent != null) {
      return getFormsListEvent(this);
    }
    return orElse();
  }
}

abstract class _getFormsListEvent implements FileUploadEvent {
  factory _getFormsListEvent(
      {required final BuildContext context,
      required final bool isUpdate}) = _$getFormsListEventImpl;

  @override
  BuildContext get context;
  bool get isUpdate;
  @override
  @JsonKey(ignore: true)
  _$$getFormsListEventImplCopyWith<_$getFormsListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$pickDocumentEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$pickDocumentEventImplCopyWith(_$pickDocumentEventImpl value,
          $Res Function(_$pickDocumentEventImpl) then) =
      __$$pickDocumentEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {BuildContext context,
      int fileIndex,
      bool isFromCamera,
      bool isDocument});
}

/// @nodoc
class __$$pickDocumentEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$pickDocumentEventImpl>
    implements _$$pickDocumentEventImplCopyWith<$Res> {
  __$$pickDocumentEventImplCopyWithImpl(_$pickDocumentEventImpl _value,
      $Res Function(_$pickDocumentEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? fileIndex = null,
    Object? isFromCamera = null,
    Object? isDocument = null,
  }) {
    return _then(_$pickDocumentEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      fileIndex: null == fileIndex
          ? _value.fileIndex
          : fileIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isFromCamera: null == isFromCamera
          ? _value.isFromCamera
          : isFromCamera // ignore: cast_nullable_to_non_nullable
              as bool,
      isDocument: null == isDocument
          ? _value.isDocument
          : isDocument // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$pickDocumentEventImpl
    with DiagnosticableTreeMixin
    implements _pickDocumentEvent {
  _$pickDocumentEventImpl(
      {required this.context,
      required this.fileIndex,
      required this.isFromCamera,
      required this.isDocument});

  @override
  final BuildContext context;
  @override
  final int fileIndex;
  @override
  final bool isFromCamera;
  @override
  final bool isDocument;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.pickDocumentEvent(context: $context, fileIndex: $fileIndex, isFromCamera: $isFromCamera, isDocument: $isDocument)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadEvent.pickDocumentEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('fileIndex', fileIndex))
      ..add(DiagnosticsProperty('isFromCamera', isFromCamera))
      ..add(DiagnosticsProperty('isDocument', isDocument));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$pickDocumentEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.fileIndex, fileIndex) ||
                other.fileIndex == fileIndex) &&
            (identical(other.isFromCamera, isFromCamera) ||
                other.isFromCamera == isFromCamera) &&
            (identical(other.isDocument, isDocument) ||
                other.isDocument == isDocument));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, fileIndex, isFromCamera, isDocument);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$pickDocumentEventImplCopyWith<_$pickDocumentEventImpl> get copyWith =>
      __$$pickDocumentEventImplCopyWithImpl<_$pickDocumentEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return pickDocumentEvent(context, fileIndex, isFromCamera, isDocument);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return pickDocumentEvent?.call(
        context, fileIndex, isFromCamera, isDocument);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (pickDocumentEvent != null) {
      return pickDocumentEvent(context, fileIndex, isFromCamera, isDocument);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return pickDocumentEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return pickDocumentEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (pickDocumentEvent != null) {
      return pickDocumentEvent(this);
    }
    return orElse();
  }
}

abstract class _pickDocumentEvent implements FileUploadEvent {
  factory _pickDocumentEvent(
      {required final BuildContext context,
      required final int fileIndex,
      required final bool isFromCamera,
      required final bool isDocument}) = _$pickDocumentEventImpl;

  @override
  BuildContext get context;
  int get fileIndex;
  bool get isFromCamera;
  bool get isDocument;
  @override
  @JsonKey(ignore: true)
  _$$pickDocumentEventImplCopyWith<_$pickDocumentEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$uploadApiEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$uploadApiEventImplCopyWith(_$uploadApiEventImpl value,
          $Res Function(_$uploadApiEventImpl) then) =
      __$$uploadApiEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, bool? isFromDelete});
}

/// @nodoc
class __$$uploadApiEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$uploadApiEventImpl>
    implements _$$uploadApiEventImplCopyWith<$Res> {
  __$$uploadApiEventImplCopyWithImpl(
      _$uploadApiEventImpl _value, $Res Function(_$uploadApiEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isFromDelete = freezed,
  }) {
    return _then(_$uploadApiEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isFromDelete: freezed == isFromDelete
          ? _value.isFromDelete
          : isFromDelete // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$uploadApiEventImpl
    with DiagnosticableTreeMixin
    implements _uploadApiEvent {
  _$uploadApiEventImpl({required this.context, this.isFromDelete});

  @override
  final BuildContext context;
  @override
  final bool? isFromDelete;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.uploadApiEvent(context: $context, isFromDelete: $isFromDelete)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadEvent.uploadApiEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('isFromDelete', isFromDelete));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$uploadApiEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isFromDelete, isFromDelete) ||
                other.isFromDelete == isFromDelete));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isFromDelete);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$uploadApiEventImplCopyWith<_$uploadApiEventImpl> get copyWith =>
      __$$uploadApiEventImplCopyWithImpl<_$uploadApiEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return uploadApiEvent(context, isFromDelete);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return uploadApiEvent?.call(context, isFromDelete);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (uploadApiEvent != null) {
      return uploadApiEvent(context, isFromDelete);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return uploadApiEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return uploadApiEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (uploadApiEvent != null) {
      return uploadApiEvent(this);
    }
    return orElse();
  }
}

abstract class _uploadApiEvent implements FileUploadEvent {
  factory _uploadApiEvent(
      {required final BuildContext context,
      final bool? isFromDelete}) = _$uploadApiEventImpl;

  @override
  BuildContext get context;
  bool? get isFromDelete;
  @override
  @JsonKey(ignore: true)
  _$$uploadApiEventImplCopyWith<_$uploadApiEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$deleteFileEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$deleteFileEventImplCopyWith(_$deleteFileEventImpl value,
          $Res Function(_$deleteFileEventImpl) then) =
      __$$deleteFileEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int index, BuildContext context});
}

/// @nodoc
class __$$deleteFileEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$deleteFileEventImpl>
    implements _$$deleteFileEventImplCopyWith<$Res> {
  __$$deleteFileEventImplCopyWithImpl(
      _$deleteFileEventImpl _value, $Res Function(_$deleteFileEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
    Object? context = null,
  }) {
    return _then(_$deleteFileEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$deleteFileEventImpl
    with DiagnosticableTreeMixin
    implements _deleteFileEvent {
  _$deleteFileEventImpl({required this.index, required this.context});

  @override
  final int index;
  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.deleteFileEvent(index: $index, context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadEvent.deleteFileEvent'))
      ..add(DiagnosticsProperty('index', index))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deleteFileEventImpl &&
            (identical(other.index, index) || other.index == index) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      __$$deleteFileEventImplCopyWithImpl<_$deleteFileEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return deleteFileEvent(index, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return deleteFileEvent?.call(index, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(index, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return deleteFileEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return deleteFileEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(this);
    }
    return orElse();
  }
}

abstract class _deleteFileEvent implements FileUploadEvent {
  factory _deleteFileEvent(
      {required final int index,
      required final BuildContext context}) = _$deleteFileEventImpl;

  int get index;
  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$downloadFileEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$downloadFileEventImplCopyWith(_$downloadFileEventImpl value,
          $Res Function(_$downloadFileEventImpl) then) =
      __$$downloadFileEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, int fileIndex});
}

/// @nodoc
class __$$downloadFileEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$downloadFileEventImpl>
    implements _$$downloadFileEventImplCopyWith<$Res> {
  __$$downloadFileEventImplCopyWithImpl(_$downloadFileEventImpl _value,
      $Res Function(_$downloadFileEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? fileIndex = null,
  }) {
    return _then(_$downloadFileEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      fileIndex: null == fileIndex
          ? _value.fileIndex
          : fileIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$downloadFileEventImpl
    with DiagnosticableTreeMixin
    implements _downloadFileEvent {
  _$downloadFileEventImpl({required this.context, required this.fileIndex});

  @override
  final BuildContext context;
  @override
  final int fileIndex;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.downloadFileEvent(context: $context, fileIndex: $fileIndex)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadEvent.downloadFileEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('fileIndex', fileIndex));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$downloadFileEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.fileIndex, fileIndex) ||
                other.fileIndex == fileIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, fileIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$downloadFileEventImplCopyWith<_$downloadFileEventImpl> get copyWith =>
      __$$downloadFileEventImplCopyWithImpl<_$downloadFileEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return downloadFileEvent(context, fileIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return downloadFileEvent?.call(context, fileIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (downloadFileEvent != null) {
      return downloadFileEvent(context, fileIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return downloadFileEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return downloadFileEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (downloadFileEvent != null) {
      return downloadFileEvent(this);
    }
    return orElse();
  }
}

abstract class _downloadFileEvent implements FileUploadEvent {
  factory _downloadFileEvent(
      {required final BuildContext context,
      required final int fileIndex}) = _$downloadFileEventImpl;

  @override
  BuildContext get context;
  int get fileIndex;
  @override
  @JsonKey(ignore: true)
  _$$downloadFileEventImplCopyWith<_$downloadFileEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getProfileFilesAndFormsEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$getProfileFilesAndFormsEventImplCopyWith(
          _$getProfileFilesAndFormsEventImpl value,
          $Res Function(_$getProfileFilesAndFormsEventImpl) then) =
      __$$getProfileFilesAndFormsEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, bool isUpdate});
}

/// @nodoc
class __$$getProfileFilesAndFormsEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res,
        _$getProfileFilesAndFormsEventImpl>
    implements _$$getProfileFilesAndFormsEventImplCopyWith<$Res> {
  __$$getProfileFilesAndFormsEventImplCopyWithImpl(
      _$getProfileFilesAndFormsEventImpl _value,
      $Res Function(_$getProfileFilesAndFormsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isUpdate = null,
  }) {
    return _then(_$getProfileFilesAndFormsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$getProfileFilesAndFormsEventImpl
    with DiagnosticableTreeMixin
    implements _getProfileFilesAndFormsEvent {
  _$getProfileFilesAndFormsEventImpl(
      {required this.context, required this.isUpdate});

  @override
  final BuildContext context;
  @override
  final bool isUpdate;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.getProfileFilesAndFormsEvent(context: $context, isUpdate: $isUpdate)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty(
          'type', 'FileUploadEvent.getProfileFilesAndFormsEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('isUpdate', isUpdate));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getProfileFilesAndFormsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getProfileFilesAndFormsEventImplCopyWith<
          _$getProfileFilesAndFormsEventImpl>
      get copyWith => __$$getProfileFilesAndFormsEventImplCopyWithImpl<
          _$getProfileFilesAndFormsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return getProfileFilesAndFormsEvent(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return getProfileFilesAndFormsEvent?.call(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (getProfileFilesAndFormsEvent != null) {
      return getProfileFilesAndFormsEvent(context, isUpdate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return getProfileFilesAndFormsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return getProfileFilesAndFormsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (getProfileFilesAndFormsEvent != null) {
      return getProfileFilesAndFormsEvent(this);
    }
    return orElse();
  }
}

abstract class _getProfileFilesAndFormsEvent implements FileUploadEvent {
  factory _getProfileFilesAndFormsEvent(
      {required final BuildContext context,
      required final bool isUpdate}) = _$getProfileFilesAndFormsEventImpl;

  @override
  BuildContext get context;
  bool get isUpdate;
  @override
  @JsonKey(ignore: true)
  _$$getProfileFilesAndFormsEventImplCopyWith<
          _$getProfileFilesAndFormsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$formFileRegisterEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$formFileRegisterEventImplCopyWith(
          _$formFileRegisterEventImpl value,
          $Res Function(_$formFileRegisterEventImpl) then) =
      __$$formFileRegisterEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, bool isUpdate});
}

/// @nodoc
class __$$formFileRegisterEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$formFileRegisterEventImpl>
    implements _$$formFileRegisterEventImplCopyWith<$Res> {
  __$$formFileRegisterEventImplCopyWithImpl(_$formFileRegisterEventImpl _value,
      $Res Function(_$formFileRegisterEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isUpdate = null,
  }) {
    return _then(_$formFileRegisterEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$formFileRegisterEventImpl
    with DiagnosticableTreeMixin
    implements _formFileRegisterEvent {
  _$formFileRegisterEventImpl({required this.context, required this.isUpdate});

  @override
  final BuildContext context;
  @override
  final bool isUpdate;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.formFileRegisterEvent(context: $context, isUpdate: $isUpdate)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(
          DiagnosticsProperty('type', 'FileUploadEvent.formFileRegisterEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('isUpdate', isUpdate));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$formFileRegisterEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$formFileRegisterEventImplCopyWith<_$formFileRegisterEventImpl>
      get copyWith => __$$formFileRegisterEventImplCopyWithImpl<
          _$formFileRegisterEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return formFileRegisterEvent(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return formFileRegisterEvent?.call(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (formFileRegisterEvent != null) {
      return formFileRegisterEvent(context, isUpdate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return formFileRegisterEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return formFileRegisterEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (formFileRegisterEvent != null) {
      return formFileRegisterEvent(this);
    }
    return orElse();
  }
}

abstract class _formFileRegisterEvent implements FileUploadEvent {
  factory _formFileRegisterEvent(
      {required final BuildContext context,
      required final bool isUpdate}) = _$formFileRegisterEventImpl;

  @override
  BuildContext get context;
  bool get isUpdate;
  @override
  @JsonKey(ignore: true)
  _$$formFileRegisterEventImplCopyWith<_$formFileRegisterEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$pdfPreviewEventImplCopyWith<$Res>
    implements $FileUploadEventCopyWith<$Res> {
  factory _$$pdfPreviewEventImplCopyWith(_$pdfPreviewEventImpl value,
          $Res Function(_$pdfPreviewEventImpl) then) =
      __$$pdfPreviewEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, int fileIndex});
}

/// @nodoc
class __$$pdfPreviewEventImplCopyWithImpl<$Res>
    extends _$FileUploadEventCopyWithImpl<$Res, _$pdfPreviewEventImpl>
    implements _$$pdfPreviewEventImplCopyWith<$Res> {
  __$$pdfPreviewEventImplCopyWithImpl(
      _$pdfPreviewEventImpl _value, $Res Function(_$pdfPreviewEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? fileIndex = null,
  }) {
    return _then(_$pdfPreviewEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      fileIndex: null == fileIndex
          ? _value.fileIndex
          : fileIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$pdfPreviewEventImpl
    with DiagnosticableTreeMixin
    implements _pdfPreviewEvent {
  _$pdfPreviewEventImpl({required this.context, required this.fileIndex});

  @override
  final BuildContext context;
  @override
  final int fileIndex;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'FileUploadEvent.pdfPreviewEvent(context: $context, fileIndex: $fileIndex)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'FileUploadEvent.pdfPreviewEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('fileIndex', fileIndex));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$pdfPreviewEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.fileIndex, fileIndex) ||
                other.fileIndex == fileIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, fileIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$pdfPreviewEventImplCopyWith<_$pdfPreviewEventImpl> get copyWith =>
      __$$pdfPreviewEventImplCopyWithImpl<_$pdfPreviewEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, bool isUpdate)
        getFilesListEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getFormsListEvent,
    required TResult Function(BuildContext context, int fileIndex,
            bool isFromCamera, bool isDocument)
        pickDocumentEvent,
    required TResult Function(BuildContext context, bool? isFromDelete)
        uploadApiEvent,
    required TResult Function(int index, BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, int fileIndex)
        downloadFileEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileFilesAndFormsEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        formFileRegisterEvent,
    required TResult Function(BuildContext context, int fileIndex)
        pdfPreviewEvent,
  }) {
    return pdfPreviewEvent(context, fileIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult? Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult? Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult? Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult? Function(int index, BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult? Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
  }) {
    return pdfPreviewEvent?.call(context, fileIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, bool isUpdate)? getFilesListEvent,
    TResult Function(BuildContext context, bool isUpdate)? getFormsListEvent,
    TResult Function(BuildContext context, int fileIndex, bool isFromCamera,
            bool isDocument)?
        pickDocumentEvent,
    TResult Function(BuildContext context, bool? isFromDelete)? uploadApiEvent,
    TResult Function(int index, BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, int fileIndex)? downloadFileEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileFilesAndFormsEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        formFileRegisterEvent,
    TResult Function(BuildContext context, int fileIndex)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (pdfPreviewEvent != null) {
      return pdfPreviewEvent(context, fileIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getFilesListEvent value) getFilesListEvent,
    required TResult Function(_getFormsListEvent value) getFormsListEvent,
    required TResult Function(_pickDocumentEvent value) pickDocumentEvent,
    required TResult Function(_uploadApiEvent value) uploadApiEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_downloadFileEvent value) downloadFileEvent,
    required TResult Function(_getProfileFilesAndFormsEvent value)
        getProfileFilesAndFormsEvent,
    required TResult Function(_formFileRegisterEvent value)
        formFileRegisterEvent,
    required TResult Function(_pdfPreviewEvent value) pdfPreviewEvent,
  }) {
    return pdfPreviewEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getFilesListEvent value)? getFilesListEvent,
    TResult? Function(_getFormsListEvent value)? getFormsListEvent,
    TResult? Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult? Function(_uploadApiEvent value)? uploadApiEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_downloadFileEvent value)? downloadFileEvent,
    TResult? Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult? Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult? Function(_pdfPreviewEvent value)? pdfPreviewEvent,
  }) {
    return pdfPreviewEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getFilesListEvent value)? getFilesListEvent,
    TResult Function(_getFormsListEvent value)? getFormsListEvent,
    TResult Function(_pickDocumentEvent value)? pickDocumentEvent,
    TResult Function(_uploadApiEvent value)? uploadApiEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_downloadFileEvent value)? downloadFileEvent,
    TResult Function(_getProfileFilesAndFormsEvent value)?
        getProfileFilesAndFormsEvent,
    TResult Function(_formFileRegisterEvent value)? formFileRegisterEvent,
    TResult Function(_pdfPreviewEvent value)? pdfPreviewEvent,
    required TResult orElse(),
  }) {
    if (pdfPreviewEvent != null) {
      return pdfPreviewEvent(this);
    }
    return orElse();
  }
}

abstract class _pdfPreviewEvent implements FileUploadEvent {
  factory _pdfPreviewEvent(
      {required final BuildContext context,
      required final int fileIndex}) = _$pdfPreviewEventImpl;

  @override
  BuildContext get context;
  int get fileIndex;
  @override
  @JsonKey(ignore: true)
  _$$pdfPreviewEventImplCopyWith<_$pdfPreviewEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
