// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'activity_time_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ActivityTimeEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ActivityTimeEventCopyWith<$Res> {
  factory $ActivityTimeEventCopyWith(
          ActivityTimeEvent value, $Res Function(ActivityTimeEvent) then) =
      _$ActivityTimeEventCopyWithImpl<$Res, ActivityTimeEvent>;
}

/// @nodoc
class _$ActivityTimeEventCopyWithImpl<$Res, $Val extends ActivityTimeEvent>
    implements $ActivityTimeEventCopyWith<$Res> {
  _$ActivityTimeEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$timePickerEventImplCopyWith<$Res> {
  factory _$$timePickerEventImplCopyWith(_$timePickerEventImpl value,
          $Res Function(_$timePickerEventImpl) then) =
      __$$timePickerEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext timePickerContext,
      int openingIndex,
      int rowIndex,
      int timeIndex,
      String time,
      BuildContext context,
      String previousTime});
}

/// @nodoc
class __$$timePickerEventImplCopyWithImpl<$Res>
    extends _$ActivityTimeEventCopyWithImpl<$Res, _$timePickerEventImpl>
    implements _$$timePickerEventImplCopyWith<$Res> {
  __$$timePickerEventImplCopyWithImpl(
      _$timePickerEventImpl _value, $Res Function(_$timePickerEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? timePickerContext = null,
    Object? openingIndex = null,
    Object? rowIndex = null,
    Object? timeIndex = null,
    Object? time = null,
    Object? context = null,
    Object? previousTime = null,
  }) {
    return _then(_$timePickerEventImpl(
      timePickerContext: null == timePickerContext
          ? _value.timePickerContext
          : timePickerContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      openingIndex: null == openingIndex
          ? _value.openingIndex
          : openingIndex // ignore: cast_nullable_to_non_nullable
              as int,
      rowIndex: null == rowIndex
          ? _value.rowIndex
          : rowIndex // ignore: cast_nullable_to_non_nullable
              as int,
      timeIndex: null == timeIndex
          ? _value.timeIndex
          : timeIndex // ignore: cast_nullable_to_non_nullable
              as int,
      time: null == time
          ? _value.time
          : time // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      previousTime: null == previousTime
          ? _value.previousTime
          : previousTime // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$timePickerEventImpl implements _timePickerEvent {
  _$timePickerEventImpl(
      {required this.timePickerContext,
      required this.openingIndex,
      required this.rowIndex,
      required this.timeIndex,
      required this.time,
      required this.context,
      required this.previousTime});

  @override
  final BuildContext timePickerContext;
  @override
  final int openingIndex;
  @override
  final int rowIndex;
  @override
  final int timeIndex;
  @override
  final String time;
  @override
  final BuildContext context;
  @override
  final String previousTime;

  @override
  String toString() {
    return 'ActivityTimeEvent.timePickerEvent(timePickerContext: $timePickerContext, openingIndex: $openingIndex, rowIndex: $rowIndex, timeIndex: $timeIndex, time: $time, context: $context, previousTime: $previousTime)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$timePickerEventImpl &&
            (identical(other.timePickerContext, timePickerContext) ||
                other.timePickerContext == timePickerContext) &&
            (identical(other.openingIndex, openingIndex) ||
                other.openingIndex == openingIndex) &&
            (identical(other.rowIndex, rowIndex) ||
                other.rowIndex == rowIndex) &&
            (identical(other.timeIndex, timeIndex) ||
                other.timeIndex == timeIndex) &&
            (identical(other.time, time) || other.time == time) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.previousTime, previousTime) ||
                other.previousTime == previousTime));
  }

  @override
  int get hashCode => Object.hash(runtimeType, timePickerContext, openingIndex,
      rowIndex, timeIndex, time, context, previousTime);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$timePickerEventImplCopyWith<_$timePickerEventImpl> get copyWith =>
      __$$timePickerEventImplCopyWithImpl<_$timePickerEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) {
    return timePickerEvent(timePickerContext, openingIndex, rowIndex, timeIndex,
        time, context, previousTime);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) {
    return timePickerEvent?.call(timePickerContext, openingIndex, rowIndex,
        timeIndex, time, context, previousTime);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (timePickerEvent != null) {
      return timePickerEvent(timePickerContext, openingIndex, rowIndex,
          timeIndex, time, context, previousTime);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) {
    return timePickerEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) {
    return timePickerEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (timePickerEvent != null) {
      return timePickerEvent(this);
    }
    return orElse();
  }
}

abstract class _timePickerEvent implements ActivityTimeEvent {
  factory _timePickerEvent(
      {required final BuildContext timePickerContext,
      required final int openingIndex,
      required final int rowIndex,
      required final int timeIndex,
      required final String time,
      required final BuildContext context,
      required final String previousTime}) = _$timePickerEventImpl;

  BuildContext get timePickerContext;
  int get openingIndex;
  int get rowIndex;
  int get timeIndex;
  String get time;
  BuildContext get context;
  String get previousTime;
  @JsonKey(ignore: true)
  _$$timePickerEventImplCopyWith<_$timePickerEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$defaultValueAddInListEventImplCopyWith<$Res> {
  factory _$$defaultValueAddInListEventImplCopyWith(
          _$defaultValueAddInListEventImpl value,
          $Res Function(_$defaultValueAddInListEventImpl) then) =
      __$$defaultValueAddInListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$defaultValueAddInListEventImplCopyWithImpl<$Res>
    extends _$ActivityTimeEventCopyWithImpl<$Res,
        _$defaultValueAddInListEventImpl>
    implements _$$defaultValueAddInListEventImplCopyWith<$Res> {
  __$$defaultValueAddInListEventImplCopyWithImpl(
      _$defaultValueAddInListEventImpl _value,
      $Res Function(_$defaultValueAddInListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$defaultValueAddInListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$defaultValueAddInListEventImpl implements _defaultValueAddInListEvent {
  _$defaultValueAddInListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ActivityTimeEvent.defaultValueAddInListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$defaultValueAddInListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$defaultValueAddInListEventImplCopyWith<_$defaultValueAddInListEventImpl>
      get copyWith => __$$defaultValueAddInListEventImplCopyWithImpl<
          _$defaultValueAddInListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) {
    return defaultValueAddInListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) {
    return defaultValueAddInListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (defaultValueAddInListEvent != null) {
      return defaultValueAddInListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) {
    return defaultValueAddInListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) {
    return defaultValueAddInListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (defaultValueAddInListEvent != null) {
      return defaultValueAddInListEvent(this);
    }
    return orElse();
  }
}

abstract class _defaultValueAddInListEvent implements ActivityTimeEvent {
  factory _defaultValueAddInListEvent({required final BuildContext context}) =
      _$defaultValueAddInListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$defaultValueAddInListEventImplCopyWith<_$defaultValueAddInListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$addMoreTimeZoneEventEventImplCopyWith<$Res> {
  factory _$$addMoreTimeZoneEventEventImplCopyWith(
          _$addMoreTimeZoneEventEventImpl value,
          $Res Function(_$addMoreTimeZoneEventEventImpl) then) =
      __$$addMoreTimeZoneEventEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int rowIndex, BuildContext context});
}

/// @nodoc
class __$$addMoreTimeZoneEventEventImplCopyWithImpl<$Res>
    extends _$ActivityTimeEventCopyWithImpl<$Res,
        _$addMoreTimeZoneEventEventImpl>
    implements _$$addMoreTimeZoneEventEventImplCopyWith<$Res> {
  __$$addMoreTimeZoneEventEventImplCopyWithImpl(
      _$addMoreTimeZoneEventEventImpl _value,
      $Res Function(_$addMoreTimeZoneEventEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rowIndex = null,
    Object? context = null,
  }) {
    return _then(_$addMoreTimeZoneEventEventImpl(
      rowIndex: null == rowIndex
          ? _value.rowIndex
          : rowIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$addMoreTimeZoneEventEventImpl implements _addMoreTimeZoneEventEvent {
  _$addMoreTimeZoneEventEventImpl(
      {required this.rowIndex, required this.context});

  @override
  final int rowIndex;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ActivityTimeEvent.addMoreTimeZoneEvent(rowIndex: $rowIndex, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$addMoreTimeZoneEventEventImpl &&
            (identical(other.rowIndex, rowIndex) ||
                other.rowIndex == rowIndex) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, rowIndex, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$addMoreTimeZoneEventEventImplCopyWith<_$addMoreTimeZoneEventEventImpl>
      get copyWith => __$$addMoreTimeZoneEventEventImplCopyWithImpl<
          _$addMoreTimeZoneEventEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) {
    return addMoreTimeZoneEvent(rowIndex, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) {
    return addMoreTimeZoneEvent?.call(rowIndex, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (addMoreTimeZoneEvent != null) {
      return addMoreTimeZoneEvent(rowIndex, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) {
    return addMoreTimeZoneEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) {
    return addMoreTimeZoneEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (addMoreTimeZoneEvent != null) {
      return addMoreTimeZoneEvent(this);
    }
    return orElse();
  }
}

abstract class _addMoreTimeZoneEventEvent implements ActivityTimeEvent {
  factory _addMoreTimeZoneEventEvent(
      {required final int rowIndex,
      required final BuildContext context}) = _$addMoreTimeZoneEventEventImpl;

  int get rowIndex;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$addMoreTimeZoneEventEventImplCopyWith<_$addMoreTimeZoneEventEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$deleteTimeZoneEventImplCopyWith<$Res> {
  factory _$$deleteTimeZoneEventImplCopyWith(_$deleteTimeZoneEventImpl value,
          $Res Function(_$deleteTimeZoneEventImpl) then) =
      __$$deleteTimeZoneEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int rowIndex, int timeIndex});
}

/// @nodoc
class __$$deleteTimeZoneEventImplCopyWithImpl<$Res>
    extends _$ActivityTimeEventCopyWithImpl<$Res, _$deleteTimeZoneEventImpl>
    implements _$$deleteTimeZoneEventImplCopyWith<$Res> {
  __$$deleteTimeZoneEventImplCopyWithImpl(_$deleteTimeZoneEventImpl _value,
      $Res Function(_$deleteTimeZoneEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rowIndex = null,
    Object? timeIndex = null,
  }) {
    return _then(_$deleteTimeZoneEventImpl(
      rowIndex: null == rowIndex
          ? _value.rowIndex
          : rowIndex // ignore: cast_nullable_to_non_nullable
              as int,
      timeIndex: null == timeIndex
          ? _value.timeIndex
          : timeIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$deleteTimeZoneEventImpl implements _deleteTimeZoneEvent {
  _$deleteTimeZoneEventImpl({required this.rowIndex, required this.timeIndex});

  @override
  final int rowIndex;
  @override
  final int timeIndex;

  @override
  String toString() {
    return 'ActivityTimeEvent.deleteTimeZoneEvent(rowIndex: $rowIndex, timeIndex: $timeIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deleteTimeZoneEventImpl &&
            (identical(other.rowIndex, rowIndex) ||
                other.rowIndex == rowIndex) &&
            (identical(other.timeIndex, timeIndex) ||
                other.timeIndex == timeIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, rowIndex, timeIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deleteTimeZoneEventImplCopyWith<_$deleteTimeZoneEventImpl> get copyWith =>
      __$$deleteTimeZoneEventImplCopyWithImpl<_$deleteTimeZoneEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) {
    return deleteTimeZoneEvent(rowIndex, timeIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) {
    return deleteTimeZoneEvent?.call(rowIndex, timeIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (deleteTimeZoneEvent != null) {
      return deleteTimeZoneEvent(rowIndex, timeIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) {
    return deleteTimeZoneEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) {
    return deleteTimeZoneEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (deleteTimeZoneEvent != null) {
      return deleteTimeZoneEvent(this);
    }
    return orElse();
  }
}

abstract class _deleteTimeZoneEvent implements ActivityTimeEvent {
  factory _deleteTimeZoneEvent(
      {required final int rowIndex,
      required final int timeIndex}) = _$deleteTimeZoneEventImpl;

  int get rowIndex;
  int get timeIndex;
  @JsonKey(ignore: true)
  _$$deleteTimeZoneEventImplCopyWith<_$deleteTimeZoneEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$activityTimeApiEventImplCopyWith<$Res> {
  factory _$$activityTimeApiEventImplCopyWith(_$activityTimeApiEventImpl value,
          $Res Function(_$activityTimeApiEventImpl) then) =
      __$$activityTimeApiEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$activityTimeApiEventImplCopyWithImpl<$Res>
    extends _$ActivityTimeEventCopyWithImpl<$Res, _$activityTimeApiEventImpl>
    implements _$$activityTimeApiEventImplCopyWith<$Res> {
  __$$activityTimeApiEventImplCopyWithImpl(_$activityTimeApiEventImpl _value,
      $Res Function(_$activityTimeApiEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$activityTimeApiEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$activityTimeApiEventImpl implements _activityTimeApiEvent {
  _$activityTimeApiEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ActivityTimeEvent.activityTimeApiEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$activityTimeApiEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$activityTimeApiEventImplCopyWith<_$activityTimeApiEventImpl>
      get copyWith =>
          __$$activityTimeApiEventImplCopyWithImpl<_$activityTimeApiEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) {
    return activityTimeApiEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) {
    return activityTimeApiEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (activityTimeApiEvent != null) {
      return activityTimeApiEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) {
    return activityTimeApiEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) {
    return activityTimeApiEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (activityTimeApiEvent != null) {
      return activityTimeApiEvent(this);
    }
    return orElse();
  }
}

abstract class _activityTimeApiEvent implements ActivityTimeEvent {
  factory _activityTimeApiEvent({required final BuildContext context}) =
      _$activityTimeApiEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$activityTimeApiEventImplCopyWith<_$activityTimeApiEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getActivityTimeListEventImplCopyWith<$Res> {
  factory _$$getActivityTimeListEventImplCopyWith(
          _$getActivityTimeListEventImpl value,
          $Res Function(_$getActivityTimeListEventImpl) then) =
      __$$getActivityTimeListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getActivityTimeListEventImplCopyWithImpl<$Res>
    extends _$ActivityTimeEventCopyWithImpl<$Res,
        _$getActivityTimeListEventImpl>
    implements _$$getActivityTimeListEventImplCopyWith<$Res> {
  __$$getActivityTimeListEventImplCopyWithImpl(
      _$getActivityTimeListEventImpl _value,
      $Res Function(_$getActivityTimeListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getActivityTimeListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getActivityTimeListEventImpl implements _getActivityTimeListEvent {
  _$getActivityTimeListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ActivityTimeEvent.getActivityTimeListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getActivityTimeListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getActivityTimeListEventImplCopyWith<_$getActivityTimeListEventImpl>
      get copyWith => __$$getActivityTimeListEventImplCopyWithImpl<
          _$getActivityTimeListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (getActivityTimeListEvent != null) {
      return getActivityTimeListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (getActivityTimeListEvent != null) {
      return getActivityTimeListEvent(this);
    }
    return orElse();
  }
}

abstract class _getActivityTimeListEvent implements ActivityTimeEvent {
  factory _getActivityTimeListEvent({required final BuildContext context}) =
      _$getActivityTimeListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getActivityTimeListEventImplCopyWith<_$getActivityTimeListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getActivityTimeDetailsEventImplCopyWith<$Res> {
  factory _$$getActivityTimeDetailsEventImplCopyWith(
          _$getActivityTimeDetailsEventImpl value,
          $Res Function(_$getActivityTimeDetailsEventImpl) then) =
      __$$getActivityTimeDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isUpdate});
}

/// @nodoc
class __$$getActivityTimeDetailsEventImplCopyWithImpl<$Res>
    extends _$ActivityTimeEventCopyWithImpl<$Res,
        _$getActivityTimeDetailsEventImpl>
    implements _$$getActivityTimeDetailsEventImplCopyWith<$Res> {
  __$$getActivityTimeDetailsEventImplCopyWithImpl(
      _$getActivityTimeDetailsEventImpl _value,
      $Res Function(_$getActivityTimeDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isUpdate = null,
  }) {
    return _then(_$getActivityTimeDetailsEventImpl(
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$getActivityTimeDetailsEventImpl
    implements _getActivityTimeDetailsEvent {
  _$getActivityTimeDetailsEventImpl({required this.isUpdate});

  @override
  final bool isUpdate;

  @override
  String toString() {
    return 'ActivityTimeEvent.getActivityTimeDetailsEvent(isUpdate: $isUpdate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getActivityTimeDetailsEventImpl &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getActivityTimeDetailsEventImplCopyWith<_$getActivityTimeDetailsEventImpl>
      get copyWith => __$$getActivityTimeDetailsEventImplCopyWithImpl<
          _$getActivityTimeDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)
        timePickerEvent,
    required TResult Function(BuildContext context) defaultValueAddInListEvent,
    required TResult Function(int rowIndex, BuildContext context)
        addMoreTimeZoneEvent,
    required TResult Function(int rowIndex, int timeIndex) deleteTimeZoneEvent,
    required TResult Function(BuildContext context) activityTimeApiEvent,
    required TResult Function(BuildContext context) getActivityTimeListEvent,
    required TResult Function(bool isUpdate) getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeDetailsEvent(isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult? Function(BuildContext context)? defaultValueAddInListEvent,
    TResult? Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult? Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult? Function(BuildContext context)? activityTimeApiEvent,
    TResult? Function(BuildContext context)? getActivityTimeListEvent,
    TResult? Function(bool isUpdate)? getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeDetailsEvent?.call(isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext timePickerContext,
            int openingIndex,
            int rowIndex,
            int timeIndex,
            String time,
            BuildContext context,
            String previousTime)?
        timePickerEvent,
    TResult Function(BuildContext context)? defaultValueAddInListEvent,
    TResult Function(int rowIndex, BuildContext context)? addMoreTimeZoneEvent,
    TResult Function(int rowIndex, int timeIndex)? deleteTimeZoneEvent,
    TResult Function(BuildContext context)? activityTimeApiEvent,
    TResult Function(BuildContext context)? getActivityTimeListEvent,
    TResult Function(bool isUpdate)? getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (getActivityTimeDetailsEvent != null) {
      return getActivityTimeDetailsEvent(isUpdate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_timePickerEvent value) timePickerEvent,
    required TResult Function(_defaultValueAddInListEvent value)
        defaultValueAddInListEvent,
    required TResult Function(_addMoreTimeZoneEventEvent value)
        addMoreTimeZoneEvent,
    required TResult Function(_deleteTimeZoneEvent value) deleteTimeZoneEvent,
    required TResult Function(_activityTimeApiEvent value) activityTimeApiEvent,
    required TResult Function(_getActivityTimeListEvent value)
        getActivityTimeListEvent,
    required TResult Function(_getActivityTimeDetailsEvent value)
        getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_timePickerEvent value)? timePickerEvent,
    TResult? Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult? Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult? Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult? Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult? Function(_getActivityTimeListEvent value)?
        getActivityTimeListEvent,
    TResult? Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
  }) {
    return getActivityTimeDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_timePickerEvent value)? timePickerEvent,
    TResult Function(_defaultValueAddInListEvent value)?
        defaultValueAddInListEvent,
    TResult Function(_addMoreTimeZoneEventEvent value)? addMoreTimeZoneEvent,
    TResult Function(_deleteTimeZoneEvent value)? deleteTimeZoneEvent,
    TResult Function(_activityTimeApiEvent value)? activityTimeApiEvent,
    TResult Function(_getActivityTimeListEvent value)? getActivityTimeListEvent,
    TResult Function(_getActivityTimeDetailsEvent value)?
        getActivityTimeDetailsEvent,
    required TResult orElse(),
  }) {
    if (getActivityTimeDetailsEvent != null) {
      return getActivityTimeDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _getActivityTimeDetailsEvent implements ActivityTimeEvent {
  factory _getActivityTimeDetailsEvent({required final bool isUpdate}) =
      _$getActivityTimeDetailsEventImpl;

  bool get isUpdate;
  @JsonKey(ignore: true)
  _$$getActivityTimeDetailsEventImplCopyWith<_$getActivityTimeDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ActivityTimeState {
  String get time => throw _privateConstructorUsedError;
  List<ActivityTimeModel> get OperationTimeList =>
      throw _privateConstructorUsedError;
  bool get isRefresh => throw _privateConstructorUsedError;
  String get errorMessage => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ActivityTimeStateCopyWith<ActivityTimeState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ActivityTimeStateCopyWith<$Res> {
  factory $ActivityTimeStateCopyWith(
          ActivityTimeState value, $Res Function(ActivityTimeState) then) =
      _$ActivityTimeStateCopyWithImpl<$Res, ActivityTimeState>;
  @useResult
  $Res call(
      {String time,
      List<ActivityTimeModel> OperationTimeList,
      bool isRefresh,
      String errorMessage,
      bool isUpdate,
      bool isLoading,
      bool isShimmering});
}

/// @nodoc
class _$ActivityTimeStateCopyWithImpl<$Res, $Val extends ActivityTimeState>
    implements $ActivityTimeStateCopyWith<$Res> {
  _$ActivityTimeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? time = null,
    Object? OperationTimeList = null,
    Object? isRefresh = null,
    Object? errorMessage = null,
    Object? isUpdate = null,
    Object? isLoading = null,
    Object? isShimmering = null,
  }) {
    return _then(_value.copyWith(
      time: null == time
          ? _value.time
          : time // ignore: cast_nullable_to_non_nullable
              as String,
      OperationTimeList: null == OperationTimeList
          ? _value.OperationTimeList
          : OperationTimeList // ignore: cast_nullable_to_non_nullable
              as List<ActivityTimeModel>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ActivityTimeStateImplCopyWith<$Res>
    implements $ActivityTimeStateCopyWith<$Res> {
  factory _$$ActivityTimeStateImplCopyWith(_$ActivityTimeStateImpl value,
          $Res Function(_$ActivityTimeStateImpl) then) =
      __$$ActivityTimeStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String time,
      List<ActivityTimeModel> OperationTimeList,
      bool isRefresh,
      String errorMessage,
      bool isUpdate,
      bool isLoading,
      bool isShimmering});
}

/// @nodoc
class __$$ActivityTimeStateImplCopyWithImpl<$Res>
    extends _$ActivityTimeStateCopyWithImpl<$Res, _$ActivityTimeStateImpl>
    implements _$$ActivityTimeStateImplCopyWith<$Res> {
  __$$ActivityTimeStateImplCopyWithImpl(_$ActivityTimeStateImpl _value,
      $Res Function(_$ActivityTimeStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? time = null,
    Object? OperationTimeList = null,
    Object? isRefresh = null,
    Object? errorMessage = null,
    Object? isUpdate = null,
    Object? isLoading = null,
    Object? isShimmering = null,
  }) {
    return _then(_$ActivityTimeStateImpl(
      time: null == time
          ? _value.time
          : time // ignore: cast_nullable_to_non_nullable
              as String,
      OperationTimeList: null == OperationTimeList
          ? _value._OperationTimeList
          : OperationTimeList // ignore: cast_nullable_to_non_nullable
              as List<ActivityTimeModel>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ActivityTimeStateImpl implements _ActivityTimeState {
  const _$ActivityTimeStateImpl(
      {required this.time,
      required final List<ActivityTimeModel> OperationTimeList,
      required this.isRefresh,
      required this.errorMessage,
      required this.isUpdate,
      required this.isLoading,
      required this.isShimmering})
      : _OperationTimeList = OperationTimeList;

  @override
  final String time;
  final List<ActivityTimeModel> _OperationTimeList;
  @override
  List<ActivityTimeModel> get OperationTimeList {
    if (_OperationTimeList is EqualUnmodifiableListView)
      return _OperationTimeList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_OperationTimeList);
  }

  @override
  final bool isRefresh;
  @override
  final String errorMessage;
  @override
  final bool isUpdate;
  @override
  final bool isLoading;
  @override
  final bool isShimmering;

  @override
  String toString() {
    return 'ActivityTimeState(time: $time, OperationTimeList: $OperationTimeList, isRefresh: $isRefresh, errorMessage: $errorMessage, isUpdate: $isUpdate, isLoading: $isLoading, isShimmering: $isShimmering)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ActivityTimeStateImpl &&
            (identical(other.time, time) || other.time == time) &&
            const DeepCollectionEquality()
                .equals(other._OperationTimeList, _OperationTimeList) &&
            (identical(other.isRefresh, isRefresh) ||
                other.isRefresh == isRefresh) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      time,
      const DeepCollectionEquality().hash(_OperationTimeList),
      isRefresh,
      errorMessage,
      isUpdate,
      isLoading,
      isShimmering);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ActivityTimeStateImplCopyWith<_$ActivityTimeStateImpl> get copyWith =>
      __$$ActivityTimeStateImplCopyWithImpl<_$ActivityTimeStateImpl>(
          this, _$identity);
}

abstract class _ActivityTimeState implements ActivityTimeState {
  const factory _ActivityTimeState(
      {required final String time,
      required final List<ActivityTimeModel> OperationTimeList,
      required final bool isRefresh,
      required final String errorMessage,
      required final bool isUpdate,
      required final bool isLoading,
      required final bool isShimmering}) = _$ActivityTimeStateImpl;

  @override
  String get time;
  @override
  List<ActivityTimeModel> get OperationTimeList;
  @override
  bool get isRefresh;
  @override
  String get errorMessage;
  @override
  bool get isUpdate;
  @override
  bool get isLoading;
  @override
  bool get isShimmering;
  @override
  @JsonKey(ignore: true)
  _$$ActivityTimeStateImplCopyWith<_$ActivityTimeStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
