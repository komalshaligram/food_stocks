// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'splash_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SplashState {
  bool get isRedirected => throw _privateConstructorUsedError;
  bool get isAnimate => throw _privateConstructorUsedError;
  String get pushNavigation => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SplashStateCopyWith<SplashState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SplashStateCopyWith<$Res> {
  factory $SplashStateCopyWith(
          SplashState value, $Res Function(SplashState) then) =
      _$SplashStateCopyWithImpl<$Res, SplashState>;
  @useResult
  $Res call({bool isRedirected, bool isAnimate, String pushNavigation});
}

/// @nodoc
class _$SplashStateCopyWithImpl<$Res, $Val extends SplashState>
    implements $SplashStateCopyWith<$Res> {
  _$SplashStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isRedirected = null,
    Object? isAnimate = null,
    Object? pushNavigation = null,
  }) {
    return _then(_value.copyWith(
      isRedirected: null == isRedirected
          ? _value.isRedirected
          : isRedirected // ignore: cast_nullable_to_non_nullable
              as bool,
      isAnimate: null == isAnimate
          ? _value.isAnimate
          : isAnimate // ignore: cast_nullable_to_non_nullable
              as bool,
      pushNavigation: null == pushNavigation
          ? _value.pushNavigation
          : pushNavigation // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SplashStateImplCopyWith<$Res>
    implements $SplashStateCopyWith<$Res> {
  factory _$$SplashStateImplCopyWith(
          _$SplashStateImpl value, $Res Function(_$SplashStateImpl) then) =
      __$$SplashStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool isRedirected, bool isAnimate, String pushNavigation});
}

/// @nodoc
class __$$SplashStateImplCopyWithImpl<$Res>
    extends _$SplashStateCopyWithImpl<$Res, _$SplashStateImpl>
    implements _$$SplashStateImplCopyWith<$Res> {
  __$$SplashStateImplCopyWithImpl(
      _$SplashStateImpl _value, $Res Function(_$SplashStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isRedirected = null,
    Object? isAnimate = null,
    Object? pushNavigation = null,
  }) {
    return _then(_$SplashStateImpl(
      isRedirected: null == isRedirected
          ? _value.isRedirected
          : isRedirected // ignore: cast_nullable_to_non_nullable
              as bool,
      isAnimate: null == isAnimate
          ? _value.isAnimate
          : isAnimate // ignore: cast_nullable_to_non_nullable
              as bool,
      pushNavigation: null == pushNavigation
          ? _value.pushNavigation
          : pushNavigation // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SplashStateImpl implements _SplashState {
  const _$SplashStateImpl(
      {required this.isRedirected,
      required this.isAnimate,
      required this.pushNavigation});

  @override
  final bool isRedirected;
  @override
  final bool isAnimate;
  @override
  final String pushNavigation;

  @override
  String toString() {
    return 'SplashState(isRedirected: $isRedirected, isAnimate: $isAnimate, pushNavigation: $pushNavigation)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SplashStateImpl &&
            (identical(other.isRedirected, isRedirected) ||
                other.isRedirected == isRedirected) &&
            (identical(other.isAnimate, isAnimate) ||
                other.isAnimate == isAnimate) &&
            (identical(other.pushNavigation, pushNavigation) ||
                other.pushNavigation == pushNavigation));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, isRedirected, isAnimate, pushNavigation);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SplashStateImplCopyWith<_$SplashStateImpl> get copyWith =>
      __$$SplashStateImplCopyWithImpl<_$SplashStateImpl>(this, _$identity);
}

abstract class _SplashState implements SplashState {
  const factory _SplashState(
      {required final bool isRedirected,
      required final bool isAnimate,
      required final String pushNavigation}) = _$SplashStateImpl;

  @override
  bool get isRedirected;
  @override
  bool get isAnimate;
  @override
  String get pushNavigation;
  @override
  @JsonKey(ignore: true)
  _$$SplashStateImplCopyWith<_$SplashStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SplashEvent {
  String get pushNavigation => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String pushNavigation) splashLoaded,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String pushNavigation)? splashLoaded,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String pushNavigation)? splashLoaded,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SplashLoadedEvent value) splashLoaded,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SplashLoadedEvent value)? splashLoaded,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SplashLoadedEvent value)? splashLoaded,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SplashEventCopyWith<SplashEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SplashEventCopyWith<$Res> {
  factory $SplashEventCopyWith(
          SplashEvent value, $Res Function(SplashEvent) then) =
      _$SplashEventCopyWithImpl<$Res, SplashEvent>;
  @useResult
  $Res call({String pushNavigation});
}

/// @nodoc
class _$SplashEventCopyWithImpl<$Res, $Val extends SplashEvent>
    implements $SplashEventCopyWith<$Res> {
  _$SplashEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pushNavigation = null,
  }) {
    return _then(_value.copyWith(
      pushNavigation: null == pushNavigation
          ? _value.pushNavigation
          : pushNavigation // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SplashLoadedEventImplCopyWith<$Res>
    implements $SplashEventCopyWith<$Res> {
  factory _$$SplashLoadedEventImplCopyWith(_$SplashLoadedEventImpl value,
          $Res Function(_$SplashLoadedEventImpl) then) =
      __$$SplashLoadedEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String pushNavigation});
}

/// @nodoc
class __$$SplashLoadedEventImplCopyWithImpl<$Res>
    extends _$SplashEventCopyWithImpl<$Res, _$SplashLoadedEventImpl>
    implements _$$SplashLoadedEventImplCopyWith<$Res> {
  __$$SplashLoadedEventImplCopyWithImpl(_$SplashLoadedEventImpl _value,
      $Res Function(_$SplashLoadedEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pushNavigation = null,
  }) {
    return _then(_$SplashLoadedEventImpl(
      pushNavigation: null == pushNavigation
          ? _value.pushNavigation
          : pushNavigation // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SplashLoadedEventImpl implements _SplashLoadedEvent {
  _$SplashLoadedEventImpl({required this.pushNavigation});

  @override
  final String pushNavigation;

  @override
  String toString() {
    return 'SplashEvent.splashLoaded(pushNavigation: $pushNavigation)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SplashLoadedEventImpl &&
            (identical(other.pushNavigation, pushNavigation) ||
                other.pushNavigation == pushNavigation));
  }

  @override
  int get hashCode => Object.hash(runtimeType, pushNavigation);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SplashLoadedEventImplCopyWith<_$SplashLoadedEventImpl> get copyWith =>
      __$$SplashLoadedEventImplCopyWithImpl<_$SplashLoadedEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String pushNavigation) splashLoaded,
  }) {
    return splashLoaded(pushNavigation);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String pushNavigation)? splashLoaded,
  }) {
    return splashLoaded?.call(pushNavigation);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String pushNavigation)? splashLoaded,
    required TResult orElse(),
  }) {
    if (splashLoaded != null) {
      return splashLoaded(pushNavigation);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SplashLoadedEvent value) splashLoaded,
  }) {
    return splashLoaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SplashLoadedEvent value)? splashLoaded,
  }) {
    return splashLoaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SplashLoadedEvent value)? splashLoaded,
    required TResult orElse(),
  }) {
    if (splashLoaded != null) {
      return splashLoaded(this);
    }
    return orElse();
  }
}

abstract class _SplashLoadedEvent implements SplashEvent {
  factory _SplashLoadedEvent({required final String pushNavigation}) =
      _$SplashLoadedEventImpl;

  @override
  String get pushNavigation;
  @override
  @JsonKey(ignore: true)
  _$$SplashLoadedEventImplCopyWith<_$SplashLoadedEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
