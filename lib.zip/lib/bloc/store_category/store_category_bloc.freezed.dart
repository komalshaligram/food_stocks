// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'store_category_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$StoreCategoryEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StoreCategoryEventCopyWith<$Res> {
  factory $StoreCategoryEventCopyWith(
          StoreCategoryEvent value, $Res Function(StoreCategoryEvent) then) =
      _$StoreCategoryEventCopyWithImpl<$Res, StoreCategoryEvent>;
}

/// @nodoc
class _$StoreCategoryEventCopyWithImpl<$Res, $Val extends StoreCategoryEvent>
    implements $StoreCategoryEventCopyWith<$Res> {
  _$StoreCategoryEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ChangeCategoryExpansionEventImplCopyWith<$Res> {
  factory _$$ChangeCategoryExpansionEventImplCopyWith(
          _$ChangeCategoryExpansionEventImpl value,
          $Res Function(_$ChangeCategoryExpansionEventImpl) then) =
      __$$ChangeCategoryExpansionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isOpened});
}

/// @nodoc
class __$$ChangeCategoryExpansionEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$ChangeCategoryExpansionEventImpl>
    implements _$$ChangeCategoryExpansionEventImplCopyWith<$Res> {
  __$$ChangeCategoryExpansionEventImplCopyWithImpl(
      _$ChangeCategoryExpansionEventImpl _value,
      $Res Function(_$ChangeCategoryExpansionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isOpened = freezed,
  }) {
    return _then(_$ChangeCategoryExpansionEventImpl(
      isOpened: freezed == isOpened
          ? _value.isOpened
          : isOpened // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeCategoryExpansionEventImpl
    implements _ChangeCategoryExpansionEvent {
  const _$ChangeCategoryExpansionEventImpl({this.isOpened});

  @override
  final bool? isOpened;

  @override
  String toString() {
    return 'StoreCategoryEvent.changeCategoryExpansionEvent(isOpened: $isOpened)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeCategoryExpansionEventImpl &&
            (identical(other.isOpened, isOpened) ||
                other.isOpened == isOpened));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isOpened);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeCategoryExpansionEventImplCopyWith<
          _$ChangeCategoryExpansionEventImpl>
      get copyWith => __$$ChangeCategoryExpansionEventImplCopyWithImpl<
          _$ChangeCategoryExpansionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeCategoryExpansionEvent(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeCategoryExpansionEvent?.call(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansionEvent != null) {
      return changeCategoryExpansionEvent(isOpened);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeCategoryExpansionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeCategoryExpansionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansionEvent != null) {
      return changeCategoryExpansionEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeCategoryExpansionEvent implements StoreCategoryEvent {
  const factory _ChangeCategoryExpansionEvent({final bool? isOpened}) =
      _$ChangeCategoryExpansionEventImpl;

  bool? get isOpened;
  @JsonKey(ignore: true)
  _$$ChangeCategoryExpansionEventImplCopyWith<
          _$ChangeCategoryExpansionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  factory _$$GetProductCategoriesListEventImplCopyWith(
          _$GetProductCategoriesListEventImpl value,
          $Res Function(_$GetProductCategoriesListEventImpl) then) =
      __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$GetProductCategoriesListEventImpl>
    implements _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  __$$GetProductCategoriesListEventImplCopyWithImpl(
      _$GetProductCategoriesListEventImpl _value,
      $Res Function(_$GetProductCategoriesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductCategoriesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductCategoriesListEventImpl
    implements _GetProductCategoriesListEvent {
  const _$GetProductCategoriesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.getProductCategoriesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductCategoriesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => __$$GetProductCategoriesListEventImplCopyWithImpl<
          _$GetProductCategoriesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductCategoriesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductCategoriesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductCategoriesListEvent implements StoreCategoryEvent {
  const factory _GetProductCategoriesListEvent(
          {required final BuildContext context}) =
      _$GetProductCategoriesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeCategoryDetailsEventImplCopyWith<$Res> {
  factory _$$ChangeCategoryDetailsEventImplCopyWith(
          _$ChangeCategoryDetailsEventImpl value,
          $Res Function(_$ChangeCategoryDetailsEventImpl) then) =
      __$$ChangeCategoryDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String categoryId,
      String categoryName,
      String isSubCategory,
      BuildContext context});
}

/// @nodoc
class __$$ChangeCategoryDetailsEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$ChangeCategoryDetailsEventImpl>
    implements _$$ChangeCategoryDetailsEventImplCopyWith<$Res> {
  __$$ChangeCategoryDetailsEventImplCopyWithImpl(
      _$ChangeCategoryDetailsEventImpl _value,
      $Res Function(_$ChangeCategoryDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? categoryId = null,
    Object? categoryName = null,
    Object? isSubCategory = null,
    Object? context = null,
  }) {
    return _then(_$ChangeCategoryDetailsEventImpl(
      categoryId: null == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String,
      categoryName: null == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String,
      isSubCategory: null == isSubCategory
          ? _value.isSubCategory
          : isSubCategory // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$ChangeCategoryDetailsEventImpl implements _ChangeCategoryDetailsEvent {
  const _$ChangeCategoryDetailsEventImpl(
      {required this.categoryId,
      required this.categoryName,
      required this.isSubCategory,
      required this.context});

  @override
  final String categoryId;
  @override
  final String categoryName;
  @override
  final String isSubCategory;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.changeCategoryDetailsEvent(categoryId: $categoryId, categoryName: $categoryName, isSubCategory: $isSubCategory, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeCategoryDetailsEventImpl &&
            (identical(other.categoryId, categoryId) ||
                other.categoryId == categoryId) &&
            (identical(other.categoryName, categoryName) ||
                other.categoryName == categoryName) &&
            (identical(other.isSubCategory, isSubCategory) ||
                other.isSubCategory == isSubCategory) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, categoryId, categoryName, isSubCategory, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeCategoryDetailsEventImplCopyWith<_$ChangeCategoryDetailsEventImpl>
      get copyWith => __$$ChangeCategoryDetailsEventImplCopyWithImpl<
          _$ChangeCategoryDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeCategoryDetailsEvent(
        categoryId, categoryName, isSubCategory, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeCategoryDetailsEvent?.call(
        categoryId, categoryName, isSubCategory, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryDetailsEvent != null) {
      return changeCategoryDetailsEvent(
          categoryId, categoryName, isSubCategory, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeCategoryDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeCategoryDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryDetailsEvent != null) {
      return changeCategoryDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeCategoryDetailsEvent implements StoreCategoryEvent {
  const factory _ChangeCategoryDetailsEvent(
      {required final String categoryId,
      required final String categoryName,
      required final String isSubCategory,
      required final BuildContext context}) = _$ChangeCategoryDetailsEventImpl;

  String get categoryId;
  String get categoryName;
  String get isSubCategory;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$ChangeCategoryDetailsEventImplCopyWith<_$ChangeCategoryDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSubCategoryDetailsEventImplCopyWith<$Res> {
  factory _$$ChangeSubCategoryDetailsEventImplCopyWith(
          _$ChangeSubCategoryDetailsEventImpl value,
          $Res Function(_$ChangeSubCategoryDetailsEventImpl) then) =
      __$$ChangeSubCategoryDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String subCategoryId, String subCategoryName, BuildContext context});
}

/// @nodoc
class __$$ChangeSubCategoryDetailsEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$ChangeSubCategoryDetailsEventImpl>
    implements _$$ChangeSubCategoryDetailsEventImplCopyWith<$Res> {
  __$$ChangeSubCategoryDetailsEventImplCopyWithImpl(
      _$ChangeSubCategoryDetailsEventImpl _value,
      $Res Function(_$ChangeSubCategoryDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? subCategoryId = null,
    Object? subCategoryName = null,
    Object? context = null,
  }) {
    return _then(_$ChangeSubCategoryDetailsEventImpl(
      subCategoryId: null == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String,
      subCategoryName: null == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$ChangeSubCategoryDetailsEventImpl
    implements _ChangeSubCategoryDetailsEvent {
  const _$ChangeSubCategoryDetailsEventImpl(
      {required this.subCategoryId,
      required this.subCategoryName,
      required this.context});

  @override
  final String subCategoryId;
  @override
  final String subCategoryName;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.changeSubCategoryDetailsEvent(subCategoryId: $subCategoryId, subCategoryName: $subCategoryName, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSubCategoryDetailsEventImpl &&
            (identical(other.subCategoryId, subCategoryId) ||
                other.subCategoryId == subCategoryId) &&
            (identical(other.subCategoryName, subCategoryName) ||
                other.subCategoryName == subCategoryName) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, subCategoryId, subCategoryName, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSubCategoryDetailsEventImplCopyWith<
          _$ChangeSubCategoryDetailsEventImpl>
      get copyWith => __$$ChangeSubCategoryDetailsEventImplCopyWithImpl<
          _$ChangeSubCategoryDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSubCategoryDetailsEvent(
        subCategoryId, subCategoryName, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSubCategoryDetailsEvent?.call(
        subCategoryId, subCategoryName, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSubCategoryDetailsEvent != null) {
      return changeSubCategoryDetailsEvent(
          subCategoryId, subCategoryName, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSubCategoryDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSubCategoryDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSubCategoryDetailsEvent != null) {
      return changeSubCategoryDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSubCategoryDetailsEvent implements StoreCategoryEvent {
  const factory _ChangeSubCategoryDetailsEvent(
          {required final String subCategoryId,
          required final String subCategoryName,
          required final BuildContext context}) =
      _$ChangeSubCategoryDetailsEventImpl;

  String get subCategoryId;
  String get subCategoryName;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$ChangeSubCategoryDetailsEventImplCopyWith<
          _$ChangeSubCategoryDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetSubCategoryListEventImplCopyWith<$Res> {
  factory _$$GetSubCategoryListEventImplCopyWith(
          _$GetSubCategoryListEventImpl value,
          $Res Function(_$GetSubCategoryListEventImpl) then) =
      __$$GetSubCategoryListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetSubCategoryListEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$GetSubCategoryListEventImpl>
    implements _$$GetSubCategoryListEventImplCopyWith<$Res> {
  __$$GetSubCategoryListEventImplCopyWithImpl(
      _$GetSubCategoryListEventImpl _value,
      $Res Function(_$GetSubCategoryListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetSubCategoryListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetSubCategoryListEventImpl implements _GetSubCategoryListEvent {
  const _$GetSubCategoryListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.getSubCategoryListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetSubCategoryListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetSubCategoryListEventImplCopyWith<_$GetSubCategoryListEventImpl>
      get copyWith => __$$GetSubCategoryListEventImplCopyWithImpl<
          _$GetSubCategoryListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getSubCategoryListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getSubCategoryListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSubCategoryListEvent != null) {
      return getSubCategoryListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getSubCategoryListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getSubCategoryListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSubCategoryListEvent != null) {
      return getSubCategoryListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetSubCategoryListEvent implements StoreCategoryEvent {
  const factory _GetSubCategoryListEvent(
      {required final BuildContext context}) = _$GetSubCategoryListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetSubCategoryListEventImplCopyWith<_$GetSubCategoryListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSubCategoryOrPlanogramEventImplCopyWith<$Res> {
  factory _$$ChangeSubCategoryOrPlanogramEventImplCopyWith(
          _$ChangeSubCategoryOrPlanogramEventImpl value,
          $Res Function(_$ChangeSubCategoryOrPlanogramEventImpl) then) =
      __$$ChangeSubCategoryOrPlanogramEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isSubCategory, BuildContext context});
}

/// @nodoc
class __$$ChangeSubCategoryOrPlanogramEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$ChangeSubCategoryOrPlanogramEventImpl>
    implements _$$ChangeSubCategoryOrPlanogramEventImplCopyWith<$Res> {
  __$$ChangeSubCategoryOrPlanogramEventImplCopyWithImpl(
      _$ChangeSubCategoryOrPlanogramEventImpl _value,
      $Res Function(_$ChangeSubCategoryOrPlanogramEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSubCategory = null,
    Object? context = null,
  }) {
    return _then(_$ChangeSubCategoryOrPlanogramEventImpl(
      isSubCategory: null == isSubCategory
          ? _value.isSubCategory
          : isSubCategory // ignore: cast_nullable_to_non_nullable
              as bool,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$ChangeSubCategoryOrPlanogramEventImpl
    implements _ChangeSubCategoryOrPlanogramEvent {
  const _$ChangeSubCategoryOrPlanogramEventImpl(
      {required this.isSubCategory, required this.context});

  @override
  final bool isSubCategory;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.changeSubCategoryOrPlanogramEvent(isSubCategory: $isSubCategory, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSubCategoryOrPlanogramEventImpl &&
            (identical(other.isSubCategory, isSubCategory) ||
                other.isSubCategory == isSubCategory) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSubCategory, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSubCategoryOrPlanogramEventImplCopyWith<
          _$ChangeSubCategoryOrPlanogramEventImpl>
      get copyWith => __$$ChangeSubCategoryOrPlanogramEventImplCopyWithImpl<
          _$ChangeSubCategoryOrPlanogramEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSubCategoryOrPlanogramEvent(isSubCategory, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSubCategoryOrPlanogramEvent?.call(isSubCategory, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSubCategoryOrPlanogramEvent != null) {
      return changeSubCategoryOrPlanogramEvent(isSubCategory, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSubCategoryOrPlanogramEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSubCategoryOrPlanogramEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSubCategoryOrPlanogramEvent != null) {
      return changeSubCategoryOrPlanogramEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSubCategoryOrPlanogramEvent
    implements StoreCategoryEvent {
  const factory _ChangeSubCategoryOrPlanogramEvent(
          {required final bool isSubCategory,
          required final BuildContext context}) =
      _$ChangeSubCategoryOrPlanogramEventImpl;

  bool get isSubCategory;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$ChangeSubCategoryOrPlanogramEventImplCopyWith<
          _$ChangeSubCategoryOrPlanogramEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetPlanoGramProductsEventImplCopyWith<$Res> {
  factory _$$GetPlanoGramProductsEventImplCopyWith(
          _$GetPlanoGramProductsEventImpl value,
          $Res Function(_$GetPlanoGramProductsEventImpl) then) =
      __$$GetPlanoGramProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetPlanoGramProductsEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$GetPlanoGramProductsEventImpl>
    implements _$$GetPlanoGramProductsEventImplCopyWith<$Res> {
  __$$GetPlanoGramProductsEventImplCopyWithImpl(
      _$GetPlanoGramProductsEventImpl _value,
      $Res Function(_$GetPlanoGramProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetPlanoGramProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetPlanoGramProductsEventImpl implements _GetPlanoGramProductsEvent {
  const _$GetPlanoGramProductsEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.getPlanoGramProductsEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetPlanoGramProductsEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetPlanoGramProductsEventImplCopyWith<_$GetPlanoGramProductsEventImpl>
      get copyWith => __$$GetPlanoGramProductsEventImplCopyWithImpl<
          _$GetPlanoGramProductsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPlanoGramProductsEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPlanoGramProductsEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanoGramProductsEvent != null) {
      return getPlanoGramProductsEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPlanoGramProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPlanoGramProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanoGramProductsEvent != null) {
      return getPlanoGramProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetPlanoGramProductsEvent implements StoreCategoryEvent {
  const factory _GetPlanoGramProductsEvent(
      {required final BuildContext context}) = _$GetPlanoGramProductsEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetPlanoGramProductsEventImplCopyWith<_$GetPlanoGramProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductDetailsEventImplCopyWith<$Res> {
  factory _$$GetProductDetailsEventImplCopyWith(
          _$GetProductDetailsEventImpl value,
          $Res Function(_$GetProductDetailsEventImpl) then) =
      __$$GetProductDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      String productId,
      int planoGramIndex,
      bool isBarcode});
}

/// @nodoc
class __$$GetProductDetailsEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$GetProductDetailsEventImpl>
    implements _$$GetProductDetailsEventImplCopyWith<$Res> {
  __$$GetProductDetailsEventImplCopyWithImpl(
      _$GetProductDetailsEventImpl _value,
      $Res Function(_$GetProductDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
    Object? planoGramIndex = null,
    Object? isBarcode = null,
  }) {
    return _then(_$GetProductDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      planoGramIndex: null == planoGramIndex
          ? _value.planoGramIndex
          : planoGramIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$GetProductDetailsEventImpl implements _GetProductDetailsEvent {
  const _$GetProductDetailsEventImpl(
      {required this.context,
      required this.productId,
      required this.planoGramIndex,
      required this.isBarcode});

  @override
  final BuildContext context;
  @override
  final String productId;
  @override
  final int planoGramIndex;
  @override
  final bool isBarcode;

  @override
  String toString() {
    return 'StoreCategoryEvent.getProductDetailsEvent(context: $context, productId: $productId, planoGramIndex: $planoGramIndex, isBarcode: $isBarcode)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.planoGramIndex, planoGramIndex) ||
                other.planoGramIndex == planoGramIndex) &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, productId, planoGramIndex, isBarcode);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => __$$GetProductDetailsEventImplCopyWithImpl<
          _$GetProductDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductDetailsEvent(
        context, productId, planoGramIndex, isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(
        context, productId, planoGramIndex, isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(
          context, productId, planoGramIndex, isBarcode);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductDetailsEvent implements StoreCategoryEvent {
  const factory _GetProductDetailsEvent(
      {required final BuildContext context,
      required final String productId,
      required final int planoGramIndex,
      required final bool isBarcode}) = _$GetProductDetailsEventImpl;

  BuildContext get context;
  String get productId;
  int get planoGramIndex;
  bool get isBarcode;
  @JsonKey(ignore: true)
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$IncreaseQuantityOfProductImplCopyWith(
          _$IncreaseQuantityOfProductImpl value,
          $Res Function(_$IncreaseQuantityOfProductImpl) then) =
      __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$IncreaseQuantityOfProductImpl>
    implements _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  __$$IncreaseQuantityOfProductImplCopyWithImpl(
      _$IncreaseQuantityOfProductImpl _value,
      $Res Function(_$IncreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$IncreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$IncreaseQuantityOfProductImpl implements _IncreaseQuantityOfProduct {
  const _$IncreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.increaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => __$$IncreaseQuantityOfProductImplCopyWithImpl<
          _$IncreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return increaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return increaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _IncreaseQuantityOfProduct implements StoreCategoryEvent {
  const factory _IncreaseQuantityOfProduct(
      {required final BuildContext context}) = _$IncreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$DecreaseQuantityOfProductImplCopyWith(
          _$DecreaseQuantityOfProductImpl value,
          $Res Function(_$DecreaseQuantityOfProductImpl) then) =
      __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$DecreaseQuantityOfProductImpl>
    implements _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  __$$DecreaseQuantityOfProductImplCopyWithImpl(
      _$DecreaseQuantityOfProductImpl _value,
      $Res Function(_$DecreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DecreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DecreaseQuantityOfProductImpl implements _DecreaseQuantityOfProduct {
  const _$DecreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.decreaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DecreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => __$$DecreaseQuantityOfProductImplCopyWithImpl<
          _$DecreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _DecreaseQuantityOfProduct implements StoreCategoryEvent {
  const factory _DecreaseQuantityOfProduct(
      {required final BuildContext context}) = _$DecreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  factory _$$UpdateQuantityOfProductImplCopyWith(
          _$UpdateQuantityOfProductImpl value,
          $Res Function(_$UpdateQuantityOfProductImpl) then) =
      __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String quantity});
}

/// @nodoc
class __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$UpdateQuantityOfProductImpl>
    implements _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  __$$UpdateQuantityOfProductImplCopyWithImpl(
      _$UpdateQuantityOfProductImpl _value,
      $Res Function(_$UpdateQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? quantity = null,
  }) {
    return _then(_$UpdateQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UpdateQuantityOfProductImpl implements _UpdateQuantityOfProduct {
  const _$UpdateQuantityOfProductImpl(
      {required this.context, required this.quantity});

  @override
  final BuildContext context;
  @override
  final String quantity;

  @override
  String toString() {
    return 'StoreCategoryEvent.updateQuantityOfProduct(context: $context, quantity: $quantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, quantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => __$$UpdateQuantityOfProductImplCopyWithImpl<
          _$UpdateQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateQuantityOfProduct(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(context, quantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _UpdateQuantityOfProduct implements StoreCategoryEvent {
  const factory _UpdateQuantityOfProduct(
      {required final BuildContext context,
      required final String quantity}) = _$UpdateQuantityOfProductImpl;

  BuildContext get context;
  String get quantity;
  @JsonKey(ignore: true)
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeNoteOfProductImplCopyWith<$Res> {
  factory _$$ChangeNoteOfProductImplCopyWith(_$ChangeNoteOfProductImpl value,
          $Res Function(_$ChangeNoteOfProductImpl) then) =
      __$$ChangeNoteOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String newNote});
}

/// @nodoc
class __$$ChangeNoteOfProductImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$ChangeNoteOfProductImpl>
    implements _$$ChangeNoteOfProductImplCopyWith<$Res> {
  __$$ChangeNoteOfProductImplCopyWithImpl(_$ChangeNoteOfProductImpl _value,
      $Res Function(_$ChangeNoteOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newNote = null,
  }) {
    return _then(_$ChangeNoteOfProductImpl(
      newNote: null == newNote
          ? _value.newNote
          : newNote // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeNoteOfProductImpl implements _ChangeNoteOfProduct {
  const _$ChangeNoteOfProductImpl({required this.newNote});

  @override
  final String newNote;

  @override
  String toString() {
    return 'StoreCategoryEvent.changeNoteOfProduct(newNote: $newNote)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeNoteOfProductImpl &&
            (identical(other.newNote, newNote) || other.newNote == newNote));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newNote);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      __$$ChangeNoteOfProductImplCopyWithImpl<_$ChangeNoteOfProductImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeNoteOfProduct(newNote);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(newNote);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(newNote);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeNoteOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(this);
    }
    return orElse();
  }
}

abstract class _ChangeNoteOfProduct implements StoreCategoryEvent {
  const factory _ChangeNoteOfProduct({required final String newNote}) =
      _$ChangeNoteOfProductImpl;

  String get newNote;
  @JsonKey(ignore: true)
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  factory _$$ChangeSupplierSelectionExpansionEventImplCopyWith(
          _$ChangeSupplierSelectionExpansionEventImpl value,
          $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) then) =
      __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isSelectSupplier});
}

/// @nodoc
class __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$ChangeSupplierSelectionExpansionEventImpl>
    implements _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl(
      _$ChangeSupplierSelectionExpansionEventImpl _value,
      $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSelectSupplier = freezed,
  }) {
    return _then(_$ChangeSupplierSelectionExpansionEventImpl(
      isSelectSupplier: freezed == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeSupplierSelectionExpansionEventImpl
    implements _ChangeSupplierSelectionExpansionEvent {
  const _$ChangeSupplierSelectionExpansionEventImpl({this.isSelectSupplier});

  @override
  final bool? isSelectSupplier;

  @override
  String toString() {
    return 'StoreCategoryEvent.changeSupplierSelectionExpansionEvent(isSelectSupplier: $isSelectSupplier)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSupplierSelectionExpansionEventImpl &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSelectSupplier);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<
          _$ChangeSupplierSelectionExpansionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(isSelectSupplier);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSupplierSelectionExpansionEvent
    implements StoreCategoryEvent {
  const factory _ChangeSupplierSelectionExpansionEvent(
          {final bool? isSelectSupplier}) =
      _$ChangeSupplierSelectionExpansionEventImpl;

  bool? get isSelectSupplier;
  @JsonKey(ignore: true)
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SupplierSelectionEventImplCopyWith<$Res> {
  factory _$$SupplierSelectionEventImplCopyWith(
          _$SupplierSelectionEventImpl value,
          $Res Function(_$SupplierSelectionEventImpl) then) =
      __$$SupplierSelectionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int supplierIndex, BuildContext context, int supplierSaleIndex});
}

/// @nodoc
class __$$SupplierSelectionEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$SupplierSelectionEventImpl>
    implements _$$SupplierSelectionEventImplCopyWith<$Res> {
  __$$SupplierSelectionEventImplCopyWithImpl(
      _$SupplierSelectionEventImpl _value,
      $Res Function(_$SupplierSelectionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierIndex = null,
    Object? context = null,
    Object? supplierSaleIndex = null,
  }) {
    return _then(_$SupplierSelectionEventImpl(
      supplierIndex: null == supplierIndex
          ? _value.supplierIndex
          : supplierIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierSaleIndex: null == supplierSaleIndex
          ? _value.supplierSaleIndex
          : supplierSaleIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SupplierSelectionEventImpl implements _SupplierSelectionEvent {
  const _$SupplierSelectionEventImpl(
      {required this.supplierIndex,
      required this.context,
      required this.supplierSaleIndex});

  @override
  final int supplierIndex;
  @override
  final BuildContext context;
  @override
  final int supplierSaleIndex;

  @override
  String toString() {
    return 'StoreCategoryEvent.supplierSelectionEvent(supplierIndex: $supplierIndex, context: $context, supplierSaleIndex: $supplierSaleIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSelectionEventImpl &&
            (identical(other.supplierIndex, supplierIndex) ||
                other.supplierIndex == supplierIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierSaleIndex, supplierSaleIndex) ||
                other.supplierSaleIndex == supplierSaleIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, supplierIndex, context, supplierSaleIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => __$$SupplierSelectionEventImplCopyWithImpl<
          _$SupplierSelectionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(
        supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return supplierSelectionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(this);
    }
    return orElse();
  }
}

abstract class _SupplierSelectionEvent implements StoreCategoryEvent {
  const factory _SupplierSelectionEvent(
      {required final int supplierIndex,
      required final BuildContext context,
      required final int supplierSaleIndex}) = _$SupplierSelectionEventImpl;

  int get supplierIndex;
  BuildContext get context;
  int get supplierSaleIndex;
  @JsonKey(ignore: true)
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddToCartProductEventImplCopyWith<$Res> {
  factory _$$AddToCartProductEventImplCopyWith(
          _$AddToCartProductEventImpl value,
          $Res Function(_$AddToCartProductEventImpl) then) =
      __$$AddToCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$AddToCartProductEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$AddToCartProductEventImpl>
    implements _$$AddToCartProductEventImplCopyWith<$Res> {
  __$$AddToCartProductEventImplCopyWithImpl(_$AddToCartProductEventImpl _value,
      $Res Function(_$AddToCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$AddToCartProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AddToCartProductEventImpl implements _AddToCartProductEvent {
  const _$AddToCartProductEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'StoreCategoryEvent.addToCartProductEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddToCartProductEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => __$$AddToCartProductEventImplCopyWithImpl<
          _$AddToCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return addToCartProductEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return addToCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _AddToCartProductEvent implements StoreCategoryEvent {
  const factory _AddToCartProductEvent(
      {required final BuildContext context,
      required final String productId}) = _$AddToCartProductEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetCartCountEventImplCopyWith<$Res> {
  factory _$$SetCartCountEventImplCopyWith(_$SetCartCountEventImpl value,
          $Res Function(_$SetCartCountEventImpl) then) =
      __$$SetCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SetCartCountEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$SetCartCountEventImpl>
    implements _$$SetCartCountEventImplCopyWith<$Res> {
  __$$SetCartCountEventImplCopyWithImpl(_$SetCartCountEventImpl _value,
      $Res Function(_$SetCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SetCartCountEventImpl implements _SetCartCountEvent {
  const _$SetCartCountEventImpl();

  @override
  String toString() {
    return 'StoreCategoryEvent.setCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SetCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return setCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return setCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return setCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return setCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetCartCountEvent implements StoreCategoryEvent {
  const factory _SetCartCountEvent() = _$SetCartCountEventImpl;
}

/// @nodoc
abstract class _$$GlobalSearchEventImplCopyWith<$Res> {
  factory _$$GlobalSearchEventImplCopyWith(_$GlobalSearchEventImpl value,
          $Res Function(_$GlobalSearchEventImpl) then) =
      __$$GlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GlobalSearchEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$GlobalSearchEventImpl>
    implements _$$GlobalSearchEventImplCopyWith<$Res> {
  __$$GlobalSearchEventImplCopyWithImpl(_$GlobalSearchEventImpl _value,
      $Res Function(_$GlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GlobalSearchEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GlobalSearchEventImpl implements _GlobalSearchEvent {
  const _$GlobalSearchEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.globalSearchEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalSearchEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      __$$GlobalSearchEventImplCopyWithImpl<_$GlobalSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return globalSearchEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return globalSearchEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return globalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return globalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _GlobalSearchEvent implements StoreCategoryEvent {
  const factory _GlobalSearchEvent({required final BuildContext context}) =
      _$GlobalSearchEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateImageIndexEventImplCopyWith<$Res> {
  factory _$$UpdateImageIndexEventImplCopyWith(
          _$UpdateImageIndexEventImpl value,
          $Res Function(_$UpdateImageIndexEventImpl) then) =
      __$$UpdateImageIndexEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$UpdateImageIndexEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$UpdateImageIndexEventImpl>
    implements _$$UpdateImageIndexEventImplCopyWith<$Res> {
  __$$UpdateImageIndexEventImplCopyWithImpl(_$UpdateImageIndexEventImpl _value,
      $Res Function(_$UpdateImageIndexEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$UpdateImageIndexEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$UpdateImageIndexEventImpl implements _UpdateImageIndexEvent {
  const _$UpdateImageIndexEventImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'StoreCategoryEvent.updateImageIndexEvent(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateImageIndexEventImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => __$$UpdateImageIndexEventImplCopyWithImpl<
          _$UpdateImageIndexEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateImageIndexEvent(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateImageIndexEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateImageIndexEvent implements StoreCategoryEvent {
  const factory _UpdateImageIndexEvent({required final int index}) =
      _$UpdateImageIndexEventImpl;

  int get index;
  @JsonKey(ignore: true)
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  factory _$$UpdateGlobalSearchEventImplCopyWith(
          _$UpdateGlobalSearchEventImpl value,
          $Res Function(_$UpdateGlobalSearchEventImpl) then) =
      __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String search, BuildContext context, List<SearchModel> searchList});
}

/// @nodoc
class __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$UpdateGlobalSearchEventImpl>
    implements _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  __$$UpdateGlobalSearchEventImplCopyWithImpl(
      _$UpdateGlobalSearchEventImpl _value,
      $Res Function(_$UpdateGlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
    Object? context = null,
    Object? searchList = null,
  }) {
    return _then(_$UpdateGlobalSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
    ));
  }
}

/// @nodoc

class _$UpdateGlobalSearchEventImpl implements _UpdateGlobalSearchEvent {
  const _$UpdateGlobalSearchEventImpl(
      {required this.search,
      required this.context,
      required final List<SearchModel> searchList})
      : _searchList = searchList;

  @override
  final String search;
  @override
  final BuildContext context;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  String toString() {
    return 'StoreCategoryEvent.updateGlobalSearchEvent(search: $search, context: $context, searchList: $searchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateGlobalSearchEventImpl &&
            (identical(other.search, search) || other.search == search) &&
            (identical(other.context, context) || other.context == context) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList));
  }

  @override
  int get hashCode => Object.hash(runtimeType, search, context,
      const DeepCollectionEquality().hash(_searchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => __$$UpdateGlobalSearchEventImplCopyWithImpl<
          _$UpdateGlobalSearchEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateGlobalSearchEvent(search, context, searchList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(search, context, searchList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(search, context, searchList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateGlobalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateGlobalSearchEvent implements StoreCategoryEvent {
  const factory _UpdateGlobalSearchEvent(
          {required final String search,
          required final BuildContext context,
          required final List<SearchModel> searchList}) =
      _$UpdateGlobalSearchEventImpl;

  String get search;
  BuildContext get context;
  List<SearchModel> get searchList;
  @JsonKey(ignore: true)
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ToggleNoteEventImplCopyWith<$Res> {
  factory _$$ToggleNoteEventImplCopyWith(_$ToggleNoteEventImpl value,
          $Res Function(_$ToggleNoteEventImpl) then) =
      __$$ToggleNoteEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isBarcode});
}

/// @nodoc
class __$$ToggleNoteEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$ToggleNoteEventImpl>
    implements _$$ToggleNoteEventImplCopyWith<$Res> {
  __$$ToggleNoteEventImplCopyWithImpl(
      _$ToggleNoteEventImpl _value, $Res Function(_$ToggleNoteEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isBarcode = null,
  }) {
    return _then(_$ToggleNoteEventImpl(
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ToggleNoteEventImpl implements _ToggleNoteEvent {
  const _$ToggleNoteEventImpl({required this.isBarcode});

  @override
  final bool isBarcode;

  @override
  String toString() {
    return 'StoreCategoryEvent.toggleNoteEvent(isBarcode: $isBarcode)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ToggleNoteEventImpl &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isBarcode);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ToggleNoteEventImplCopyWith<_$ToggleNoteEventImpl> get copyWith =>
      __$$ToggleNoteEventImplCopyWithImpl<_$ToggleNoteEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return toggleNoteEvent(isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(isBarcode);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(isBarcode);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return toggleNoteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(this);
    }
    return orElse();
  }
}

abstract class _ToggleNoteEvent implements StoreCategoryEvent {
  const factory _ToggleNoteEvent({required final bool isBarcode}) =
      _$ToggleNoteEventImpl;

  bool get isBarcode;
  @JsonKey(ignore: true)
  _$$ToggleNoteEventImplCopyWith<_$ToggleNoteEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SubCategoryRefreshListEventImplCopyWith<$Res> {
  factory _$$SubCategoryRefreshListEventImplCopyWith(
          _$SubCategoryRefreshListEventImpl value,
          $Res Function(_$SubCategoryRefreshListEventImpl) then) =
      __$$SubCategoryRefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$SubCategoryRefreshListEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$SubCategoryRefreshListEventImpl>
    implements _$$SubCategoryRefreshListEventImplCopyWith<$Res> {
  __$$SubCategoryRefreshListEventImplCopyWithImpl(
      _$SubCategoryRefreshListEventImpl _value,
      $Res Function(_$SubCategoryRefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$SubCategoryRefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$SubCategoryRefreshListEventImpl
    implements _SubCategoryRefreshListEvent {
  const _$SubCategoryRefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.subCategoryRefreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubCategoryRefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubCategoryRefreshListEventImplCopyWith<_$SubCategoryRefreshListEventImpl>
      get copyWith => __$$SubCategoryRefreshListEventImplCopyWithImpl<
          _$SubCategoryRefreshListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return subCategoryRefreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return subCategoryRefreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (subCategoryRefreshListEvent != null) {
      return subCategoryRefreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return subCategoryRefreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return subCategoryRefreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (subCategoryRefreshListEvent != null) {
      return subCategoryRefreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _SubCategoryRefreshListEvent implements StoreCategoryEvent {
  const factory _SubCategoryRefreshListEvent(
          {required final BuildContext context}) =
      _$SubCategoryRefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$SubCategoryRefreshListEventImplCopyWith<_$SubCategoryRefreshListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$PlanogramRefreshListEventImplCopyWith<$Res> {
  factory _$$PlanogramRefreshListEventImplCopyWith(
          _$PlanogramRefreshListEventImpl value,
          $Res Function(_$PlanogramRefreshListEventImpl) then) =
      __$$PlanogramRefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$PlanogramRefreshListEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$PlanogramRefreshListEventImpl>
    implements _$$PlanogramRefreshListEventImplCopyWith<$Res> {
  __$$PlanogramRefreshListEventImplCopyWithImpl(
      _$PlanogramRefreshListEventImpl _value,
      $Res Function(_$PlanogramRefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$PlanogramRefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$PlanogramRefreshListEventImpl implements _PlanogramRefreshListEvent {
  const _$PlanogramRefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.planogramRefreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramRefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramRefreshListEventImplCopyWith<_$PlanogramRefreshListEventImpl>
      get copyWith => __$$PlanogramRefreshListEventImplCopyWithImpl<
          _$PlanogramRefreshListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return planogramRefreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return planogramRefreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (planogramRefreshListEvent != null) {
      return planogramRefreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return planogramRefreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return planogramRefreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (planogramRefreshListEvent != null) {
      return planogramRefreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _PlanogramRefreshListEvent implements StoreCategoryEvent {
  const factory _PlanogramRefreshListEvent(
      {required final BuildContext context}) = _$PlanogramRefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$PlanogramRefreshListEventImplCopyWith<_$PlanogramRefreshListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$isCategoryEventImplCopyWith<$Res> {
  factory _$$isCategoryEventImplCopyWith(_$isCategoryEventImpl value,
          $Res Function(_$isCategoryEventImpl) then) =
      __$$isCategoryEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isSubCategory});
}

/// @nodoc
class __$$isCategoryEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$isCategoryEventImpl>
    implements _$$isCategoryEventImplCopyWith<$Res> {
  __$$isCategoryEventImplCopyWithImpl(
      _$isCategoryEventImpl _value, $Res Function(_$isCategoryEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSubCategory = null,
  }) {
    return _then(_$isCategoryEventImpl(
      isSubCategory: null == isSubCategory
          ? _value.isSubCategory
          : isSubCategory // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$isCategoryEventImpl implements _isCategoryEvent {
  const _$isCategoryEventImpl({required this.isSubCategory});

  @override
  final bool isSubCategory;

  @override
  String toString() {
    return 'StoreCategoryEvent.isCategoryEvent(isSubCategory: $isSubCategory)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$isCategoryEventImpl &&
            (identical(other.isSubCategory, isSubCategory) ||
                other.isSubCategory == isSubCategory));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSubCategory);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$isCategoryEventImplCopyWith<_$isCategoryEventImpl> get copyWith =>
      __$$isCategoryEventImplCopyWithImpl<_$isCategoryEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return isCategoryEvent(isSubCategory);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return isCategoryEvent?.call(isSubCategory);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (isCategoryEvent != null) {
      return isCategoryEvent(isSubCategory);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return isCategoryEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return isCategoryEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (isCategoryEvent != null) {
      return isCategoryEvent(this);
    }
    return orElse();
  }
}

abstract class _isCategoryEvent implements StoreCategoryEvent {
  const factory _isCategoryEvent({required final bool isSubCategory}) =
      _$isCategoryEventImpl;

  bool get isSubCategory;
  @JsonKey(ignore: true)
  _$$isCategoryEventImplCopyWith<_$isCategoryEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPlanogramByIdEventImplCopyWith<$Res> {
  factory _$$getPlanogramByIdEventImplCopyWith(
          _$getPlanogramByIdEventImpl value,
          $Res Function(_$getPlanogramByIdEventImpl) then) =
      __$$getPlanogramByIdEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPlanogramByIdEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$getPlanogramByIdEventImpl>
    implements _$$getPlanogramByIdEventImplCopyWith<$Res> {
  __$$getPlanogramByIdEventImplCopyWithImpl(_$getPlanogramByIdEventImpl _value,
      $Res Function(_$getPlanogramByIdEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPlanogramByIdEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPlanogramByIdEventImpl implements _getPlanogramByIdEvent {
  const _$getPlanogramByIdEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.getPlanogramByIdEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPlanogramByIdEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPlanogramByIdEventImplCopyWith<_$getPlanogramByIdEventImpl>
      get copyWith => __$$getPlanogramByIdEventImplCopyWithImpl<
          _$getPlanogramByIdEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPlanogramByIdEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPlanogramByIdEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramByIdEvent != null) {
      return getPlanogramByIdEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPlanogramByIdEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPlanogramByIdEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramByIdEvent != null) {
      return getPlanogramByIdEvent(this);
    }
    return orElse();
  }
}

abstract class _getPlanogramByIdEvent implements StoreCategoryEvent {
  const factory _getPlanogramByIdEvent({required final BuildContext context}) =
      _$getPlanogramByIdEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPlanogramByIdEventImplCopyWith<_$getPlanogramByIdEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPlanogramAllProductEventImplCopyWith<$Res> {
  factory _$$getPlanogramAllProductEventImplCopyWith(
          _$getPlanogramAllProductEventImpl value,
          $Res Function(_$getPlanogramAllProductEventImpl) then) =
      __$$getPlanogramAllProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPlanogramAllProductEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$getPlanogramAllProductEventImpl>
    implements _$$getPlanogramAllProductEventImplCopyWith<$Res> {
  __$$getPlanogramAllProductEventImplCopyWithImpl(
      _$getPlanogramAllProductEventImpl _value,
      $Res Function(_$getPlanogramAllProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPlanogramAllProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPlanogramAllProductEventImpl
    implements _getPlanogramAllProductEvent {
  const _$getPlanogramAllProductEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.getPlanogramAllProductEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPlanogramAllProductEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPlanogramAllProductEventImplCopyWith<_$getPlanogramAllProductEventImpl>
      get copyWith => __$$getPlanogramAllProductEventImplCopyWithImpl<
          _$getPlanogramAllProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPlanogramAllProductEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPlanogramAllProductEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramAllProductEvent != null) {
      return getPlanogramAllProductEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPlanogramAllProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPlanogramAllProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramAllProductEvent != null) {
      return getPlanogramAllProductEvent(this);
    }
    return orElse();
  }
}

abstract class _getPlanogramAllProductEvent implements StoreCategoryEvent {
  const factory _getPlanogramAllProductEvent(
          {required final BuildContext context}) =
      _$getPlanogramAllProductEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPlanogramAllProductEventImplCopyWith<_$getPlanogramAllProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getSubCategoryProductEventImplCopyWith<$Res> {
  factory _$$getSubCategoryProductEventImplCopyWith(
          _$getSubCategoryProductEventImpl value,
          $Res Function(_$getSubCategoryProductEventImpl) then) =
      __$$getSubCategoryProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getSubCategoryProductEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$getSubCategoryProductEventImpl>
    implements _$$getSubCategoryProductEventImplCopyWith<$Res> {
  __$$getSubCategoryProductEventImplCopyWithImpl(
      _$getSubCategoryProductEventImpl _value,
      $Res Function(_$getSubCategoryProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getSubCategoryProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getSubCategoryProductEventImpl implements _getSubCategoryProductEvent {
  const _$getSubCategoryProductEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.getSubCategoryProductEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getSubCategoryProductEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getSubCategoryProductEventImplCopyWith<_$getSubCategoryProductEventImpl>
      get copyWith => __$$getSubCategoryProductEventImplCopyWithImpl<
          _$getSubCategoryProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getSubCategoryProductEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getSubCategoryProductEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSubCategoryProductEvent != null) {
      return getSubCategoryProductEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getSubCategoryProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getSubCategoryProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSubCategoryProductEvent != null) {
      return getSubCategoryProductEvent(this);
    }
    return orElse();
  }
}

abstract class _getSubCategoryProductEvent implements StoreCategoryEvent {
  const factory _getSubCategoryProductEvent(
      {required final BuildContext context}) = _$getSubCategoryProductEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getSubCategoryProductEventImplCopyWith<_$getSubCategoryProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$changeGridToListViewEventImplCopyWith<$Res> {
  factory _$$changeGridToListViewEventImplCopyWith(
          _$changeGridToListViewEventImpl value,
          $Res Function(_$changeGridToListViewEventImpl) then) =
      __$$changeGridToListViewEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isGridView});
}

/// @nodoc
class __$$changeGridToListViewEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$changeGridToListViewEventImpl>
    implements _$$changeGridToListViewEventImplCopyWith<$Res> {
  __$$changeGridToListViewEventImplCopyWithImpl(
      _$changeGridToListViewEventImpl _value,
      $Res Function(_$changeGridToListViewEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isGridView = null,
  }) {
    return _then(_$changeGridToListViewEventImpl(
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$changeGridToListViewEventImpl implements _changeGridToListViewEvent {
  const _$changeGridToListViewEventImpl({required this.isGridView});

  @override
  final bool isGridView;

  @override
  String toString() {
    return 'StoreCategoryEvent.changeGridToListViewEvent(isGridView: $isGridView)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$changeGridToListViewEventImpl &&
            (identical(other.isGridView, isGridView) ||
                other.isGridView == isGridView));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isGridView);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$changeGridToListViewEventImplCopyWith<_$changeGridToListViewEventImpl>
      get copyWith => __$$changeGridToListViewEventImplCopyWithImpl<
          _$changeGridToListViewEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeGridToListViewEvent(isGridView);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeGridToListViewEvent?.call(isGridView);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeGridToListViewEvent != null) {
      return changeGridToListViewEvent(isGridView);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeGridToListViewEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeGridToListViewEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeGridToListViewEvent != null) {
      return changeGridToListViewEvent(this);
    }
    return orElse();
  }
}

abstract class _changeGridToListViewEvent implements StoreCategoryEvent {
  const factory _changeGridToListViewEvent({required final bool isGridView}) =
      _$changeGridToListViewEventImpl;

  bool get isGridView;
  @JsonKey(ignore: true)
  _$$changeGridToListViewEventImplCopyWith<_$changeGridToListViewEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getCartCountEventImplCopyWith<$Res> {
  factory _$$getCartCountEventImplCopyWith(_$getCartCountEventImpl value,
          $Res Function(_$getCartCountEventImpl) then) =
      __$$getCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getCartCountEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$getCartCountEventImpl>
    implements _$$getCartCountEventImplCopyWith<$Res> {
  __$$getCartCountEventImplCopyWithImpl(_$getCartCountEventImpl _value,
      $Res Function(_$getCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getCartCountEventImpl implements _getCartCountEvent {
  const _$getCartCountEventImpl();

  @override
  String toString() {
    return 'StoreCategoryEvent.getCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _getCartCountEvent implements StoreCategoryEvent {
  const factory _getCartCountEvent() = _$getCartCountEventImpl;
}

/// @nodoc
abstract class _$$AllProductsRefreshListEventImplCopyWith<$Res> {
  factory _$$AllProductsRefreshListEventImplCopyWith(
          _$AllProductsRefreshListEventImpl value,
          $Res Function(_$AllProductsRefreshListEventImpl) then) =
      __$$AllProductsRefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$AllProductsRefreshListEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$AllProductsRefreshListEventImpl>
    implements _$$AllProductsRefreshListEventImplCopyWith<$Res> {
  __$$AllProductsRefreshListEventImplCopyWithImpl(
      _$AllProductsRefreshListEventImpl _value,
      $Res Function(_$AllProductsRefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$AllProductsRefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$AllProductsRefreshListEventImpl
    implements _AllProductsRefreshListEvent {
  const _$AllProductsRefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.AllProductsRefreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AllProductsRefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AllProductsRefreshListEventImplCopyWith<_$AllProductsRefreshListEventImpl>
      get copyWith => __$$AllProductsRefreshListEventImplCopyWithImpl<
          _$AllProductsRefreshListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return AllProductsRefreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return AllProductsRefreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (AllProductsRefreshListEvent != null) {
      return AllProductsRefreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return AllProductsRefreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return AllProductsRefreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (AllProductsRefreshListEvent != null) {
      return AllProductsRefreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _AllProductsRefreshListEvent implements StoreCategoryEvent {
  const factory _AllProductsRefreshListEvent(
          {required final BuildContext context}) =
      _$AllProductsRefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$AllProductsRefreshListEventImplCopyWith<_$AllProductsRefreshListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RelatedProductsEventImplCopyWith<$Res> {
  factory _$$RelatedProductsEventImplCopyWith(_$RelatedProductsEventImpl value,
          $Res Function(_$RelatedProductsEventImpl) then) =
      __$$RelatedProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$RelatedProductsEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$RelatedProductsEventImpl>
    implements _$$RelatedProductsEventImplCopyWith<$Res> {
  __$$RelatedProductsEventImplCopyWithImpl(_$RelatedProductsEventImpl _value,
      $Res Function(_$RelatedProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$RelatedProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RelatedProductsEventImpl implements _RelatedProductsEvent {
  const _$RelatedProductsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'StoreCategoryEvent.RelatedProductsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith =>
          __$$RelatedProductsEventImplCopyWithImpl<_$RelatedProductsEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RelatedProductsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RelatedProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _RelatedProductsEvent implements StoreCategoryEvent {
  const factory _RelatedProductsEvent(
      {required final BuildContext context,
      required final String productId}) = _$RelatedProductsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  factory _$$RemoveRelatedProductEventImplCopyWith(
          _$RemoveRelatedProductEventImpl value,
          $Res Function(_$RemoveRelatedProductEventImpl) then) =
      __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res,
        _$RemoveRelatedProductEventImpl>
    implements _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  __$$RemoveRelatedProductEventImplCopyWithImpl(
      _$RemoveRelatedProductEventImpl _value,
      $Res Function(_$RemoveRelatedProductEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$RemoveRelatedProductEventImpl implements _RemoveRelatedProductEvent {
  const _$RemoveRelatedProductEventImpl();

  @override
  String toString() {
    return 'StoreCategoryEvent.RemoveRelatedProductEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveRelatedProductEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RemoveRelatedProductEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RemoveRelatedProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveRelatedProductEvent implements StoreCategoryEvent {
  const factory _RemoveRelatedProductEvent() = _$RemoveRelatedProductEventImpl;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$StoreCategoryEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'StoreCategoryEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool? isOpened) changeCategoryExpansionEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)
        changeCategoryDetailsEvent,
    required TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)
        changeSubCategoryDetailsEvent,
    required TResult Function(BuildContext context) getSubCategoryListEvent,
    required TResult Function(bool isSubCategory, BuildContext context)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(BuildContext context) getPlanoGramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(bool isBarcode) toggleNoteEvent,
    required TResult Function(BuildContext context) subCategoryRefreshListEvent,
    required TResult Function(BuildContext context) planogramRefreshListEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function(bool isGridView) changeGridToListViewEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) AllProductsRefreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult? Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult? Function(BuildContext context)? getSubCategoryListEvent,
    TResult? Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult? Function(BuildContext context, String productId,
            int planoGramIndex, bool isBarcode)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(bool isBarcode)? toggleNoteEvent,
    TResult? Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult? Function(BuildContext context)? planogramRefreshListEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function(bool isGridView)? changeGridToListViewEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool? isOpened)? changeCategoryExpansionEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(String categoryId, String categoryName,
            String isSubCategory, BuildContext context)?
        changeCategoryDetailsEvent,
    TResult Function(
            String subCategoryId, String subCategoryName, BuildContext context)?
        changeSubCategoryDetailsEvent,
    TResult Function(BuildContext context)? getSubCategoryListEvent,
    TResult Function(bool isSubCategory, BuildContext context)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(BuildContext context)? getPlanoGramProductsEvent,
    TResult Function(BuildContext context, String productId, int planoGramIndex,
            bool isBarcode)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(
            String search, BuildContext context, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(bool isBarcode)? toggleNoteEvent,
    TResult Function(BuildContext context)? subCategoryRefreshListEvent,
    TResult Function(BuildContext context)? planogramRefreshListEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function(bool isGridView)? changeGridToListViewEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? AllProductsRefreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ChangeCategoryExpansionEvent value)
        changeCategoryExpansionEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_ChangeCategoryDetailsEvent value)
        changeCategoryDetailsEvent,
    required TResult Function(_ChangeSubCategoryDetailsEvent value)
        changeSubCategoryDetailsEvent,
    required TResult Function(_GetSubCategoryListEvent value)
        getSubCategoryListEvent,
    required TResult Function(_ChangeSubCategoryOrPlanogramEvent value)
        changeSubCategoryOrPlanogramEvent,
    required TResult Function(_GetPlanoGramProductsEvent value)
        getPlanoGramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_SubCategoryRefreshListEvent value)
        subCategoryRefreshListEvent,
    required TResult Function(_PlanogramRefreshListEvent value)
        planogramRefreshListEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_changeGridToListViewEvent value)
        changeGridToListViewEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_AllProductsRefreshListEvent value)
        AllProductsRefreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult? Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult? Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult? Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult? Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult? Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ChangeCategoryExpansionEvent value)?
        changeCategoryExpansionEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_ChangeCategoryDetailsEvent value)?
        changeCategoryDetailsEvent,
    TResult Function(_ChangeSubCategoryDetailsEvent value)?
        changeSubCategoryDetailsEvent,
    TResult Function(_GetSubCategoryListEvent value)? getSubCategoryListEvent,
    TResult Function(_ChangeSubCategoryOrPlanogramEvent value)?
        changeSubCategoryOrPlanogramEvent,
    TResult Function(_GetPlanoGramProductsEvent value)?
        getPlanoGramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_SubCategoryRefreshListEvent value)?
        subCategoryRefreshListEvent,
    TResult Function(_PlanogramRefreshListEvent value)?
        planogramRefreshListEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_changeGridToListViewEvent value)?
        changeGridToListViewEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_AllProductsRefreshListEvent value)?
        AllProductsRefreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements StoreCategoryEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$StoreCategoryState {
  bool get isCategoryExpand => throw _privateConstructorUsedError;
  bool get isSubCategory => throw _privateConstructorUsedError;
  String get categoryId => throw _privateConstructorUsedError;
  String get subCategoryId => throw _privateConstructorUsedError;
  String get categoryName => throw _privateConstructorUsedError;
  String get subCategoryName => throw _privateConstructorUsedError;
  List<SubCategory> get subCategoryList => throw _privateConstructorUsedError;
  List<PlanogramDatum> get planoGramsList => throw _privateConstructorUsedError;
  List<PlanogramDatum> get subPlanoGramsList =>
      throw _privateConstructorUsedError;
  List<PlanogramProduct> get planoGramsByIdList =>
      throw _privateConstructorUsedError;
  List<Category> get productCategoryList => throw _privateConstructorUsedError;
  List<List<ProductStockModel>> get productStockList =>
      throw _privateConstructorUsedError;
  bool get isPlanogramShimmering => throw _privateConstructorUsedError;
  bool get isSubCategoryShimmering => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isProductLoading => throw _privateConstructorUsedError;
  int get planogramPageNum => throw _privateConstructorUsedError;
  int get subProductPageNum => throw _privateConstructorUsedError;
  int get subPlanogramPageNum => throw _privateConstructorUsedError;
  int get subCategoryPageNum => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfPlanoGrams => throw _privateConstructorUsedError;
  bool get isBottomOfSubCategory => throw _privateConstructorUsedError;
  List<Product> get productDetails => throw _privateConstructorUsedError;
  int get planoGramUpdateIndex => throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  bool get isSelectSupplier => throw _privateConstructorUsedError;
  List<ProductSupplierModel> get productSupplierList =>
      throw _privateConstructorUsedError;
  List<SearchModel> get searchList => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  bool get isSearching => throw _privateConstructorUsedError;
  int get imageIndex => throw _privateConstructorUsedError;
  TextEditingController get searchController =>
      throw _privateConstructorUsedError;
  TextEditingController get noteController =>
      throw _privateConstructorUsedError;
  RefreshController get subCategoryRefreshController =>
      throw _privateConstructorUsedError;
  RefreshController get planogramRefreshController =>
      throw _privateConstructorUsedError;
  List<PlanogramAllProduct> get planogramProductList =>
      throw _privateConstructorUsedError;
  List<Planogramproduct> get categoryPlanogramList =>
      throw _privateConstructorUsedError;
  List<Planogramproduct> get subCategoryPlanogramList =>
      throw _privateConstructorUsedError;
  List<PlanogramDatum> get subCatPlanoGramsList =>
      throw _privateConstructorUsedError;
  bool get isBottomOfProducts => throw _privateConstructorUsedError;
  bool get isPlanogramProductShimmering => throw _privateConstructorUsedError;
  bool get isGridView => throw _privateConstructorUsedError;
  bool get isGuestUser => throw _privateConstructorUsedError;
  bool get isBottomProducts => throw _privateConstructorUsedError;
  int get cartCount => throw _privateConstructorUsedError;
  bool get duringCelebration => throw _privateConstructorUsedError;
  int get allProductPageNum => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get relatedProductList =>
      throw _privateConstructorUsedError;
  bool get isRelatedShimmering => throw _privateConstructorUsedError;
  double get bottleDeposit => throw _privateConstructorUsedError;
  bool get isSubUserAddToBasket => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $StoreCategoryStateCopyWith<StoreCategoryState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StoreCategoryStateCopyWith<$Res> {
  factory $StoreCategoryStateCopyWith(
          StoreCategoryState value, $Res Function(StoreCategoryState) then) =
      _$StoreCategoryStateCopyWithImpl<$Res, StoreCategoryState>;
  @useResult
  $Res call(
      {bool isCategoryExpand,
      bool isSubCategory,
      String categoryId,
      String subCategoryId,
      String categoryName,
      String subCategoryName,
      List<SubCategory> subCategoryList,
      List<PlanogramDatum> planoGramsList,
      List<PlanogramDatum> subPlanoGramsList,
      List<PlanogramProduct> planoGramsByIdList,
      List<Category> productCategoryList,
      List<List<ProductStockModel>> productStockList,
      bool isPlanogramShimmering,
      bool isSubCategoryShimmering,
      bool isLoading,
      bool isProductLoading,
      int planogramPageNum,
      int subProductPageNum,
      int subPlanogramPageNum,
      int subCategoryPageNum,
      bool isLoadMore,
      bool isBottomOfPlanoGrams,
      bool isBottomOfSubCategory,
      List<Product> productDetails,
      int planoGramUpdateIndex,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      List<SearchModel> searchList,
      String search,
      bool isSearching,
      int imageIndex,
      TextEditingController searchController,
      TextEditingController noteController,
      RefreshController subCategoryRefreshController,
      RefreshController planogramRefreshController,
      List<PlanogramAllProduct> planogramProductList,
      List<Planogramproduct> categoryPlanogramList,
      List<Planogramproduct> subCategoryPlanogramList,
      List<PlanogramDatum> subCatPlanoGramsList,
      bool isBottomOfProducts,
      bool isPlanogramProductShimmering,
      bool isGridView,
      bool isGuestUser,
      bool isBottomProducts,
      int cartCount,
      bool duringCelebration,
      int allProductPageNum,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      double bottleDeposit,
      bool isSubUserAddToBasket});
}

/// @nodoc
class _$StoreCategoryStateCopyWithImpl<$Res, $Val extends StoreCategoryState>
    implements $StoreCategoryStateCopyWith<$Res> {
  _$StoreCategoryStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isCategoryExpand = null,
    Object? isSubCategory = null,
    Object? categoryId = null,
    Object? subCategoryId = null,
    Object? categoryName = null,
    Object? subCategoryName = null,
    Object? subCategoryList = null,
    Object? planoGramsList = null,
    Object? subPlanoGramsList = null,
    Object? planoGramsByIdList = null,
    Object? productCategoryList = null,
    Object? productStockList = null,
    Object? isPlanogramShimmering = null,
    Object? isSubCategoryShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? planogramPageNum = null,
    Object? subProductPageNum = null,
    Object? subPlanogramPageNum = null,
    Object? subCategoryPageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfPlanoGrams = null,
    Object? isBottomOfSubCategory = null,
    Object? productDetails = null,
    Object? planoGramUpdateIndex = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? searchList = null,
    Object? search = null,
    Object? isSearching = null,
    Object? imageIndex = null,
    Object? searchController = null,
    Object? noteController = null,
    Object? subCategoryRefreshController = null,
    Object? planogramRefreshController = null,
    Object? planogramProductList = null,
    Object? categoryPlanogramList = null,
    Object? subCategoryPlanogramList = null,
    Object? subCatPlanoGramsList = null,
    Object? isBottomOfProducts = null,
    Object? isPlanogramProductShimmering = null,
    Object? isGridView = null,
    Object? isGuestUser = null,
    Object? isBottomProducts = null,
    Object? cartCount = null,
    Object? duringCelebration = null,
    Object? allProductPageNum = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
  }) {
    return _then(_value.copyWith(
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubCategory: null == isSubCategory
          ? _value.isSubCategory
          : isSubCategory // ignore: cast_nullable_to_non_nullable
              as bool,
      categoryId: null == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String,
      subCategoryId: null == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String,
      categoryName: null == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String,
      subCategoryName: null == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String,
      subCategoryList: null == subCategoryList
          ? _value.subCategoryList
          : subCategoryList // ignore: cast_nullable_to_non_nullable
              as List<SubCategory>,
      planoGramsList: null == planoGramsList
          ? _value.planoGramsList
          : planoGramsList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>,
      subPlanoGramsList: null == subPlanoGramsList
          ? _value.subPlanoGramsList
          : subPlanoGramsList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>,
      planoGramsByIdList: null == planoGramsByIdList
          ? _value.planoGramsByIdList
          : planoGramsByIdList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramProduct>,
      productCategoryList: null == productCategoryList
          ? _value.productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      isPlanogramShimmering: null == isPlanogramShimmering
          ? _value.isPlanogramShimmering
          : isPlanogramShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubCategoryShimmering: null == isSubCategoryShimmering
          ? _value.isSubCategoryShimmering
          : isSubCategoryShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      planogramPageNum: null == planogramPageNum
          ? _value.planogramPageNum
          : planogramPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      subProductPageNum: null == subProductPageNum
          ? _value.subProductPageNum
          : subProductPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      subPlanogramPageNum: null == subPlanogramPageNum
          ? _value.subPlanogramPageNum
          : subPlanogramPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      subCategoryPageNum: null == subCategoryPageNum
          ? _value.subCategoryPageNum
          : subCategoryPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfPlanoGrams: null == isBottomOfPlanoGrams
          ? _value.isBottomOfPlanoGrams
          : isBottomOfPlanoGrams // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfSubCategory: null == isBottomOfSubCategory
          ? _value.isBottomOfSubCategory
          : isBottomOfSubCategory // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      planoGramUpdateIndex: null == planoGramUpdateIndex
          ? _value.planoGramUpdateIndex
          : planoGramUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value.productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      searchList: null == searchList
          ? _value.searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      subCategoryRefreshController: null == subCategoryRefreshController
          ? _value.subCategoryRefreshController
          : subCategoryRefreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      planogramRefreshController: null == planogramRefreshController
          ? _value.planogramRefreshController
          : planogramRefreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      planogramProductList: null == planogramProductList
          ? _value.planogramProductList
          : planogramProductList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramAllProduct>,
      categoryPlanogramList: null == categoryPlanogramList
          ? _value.categoryPlanogramList
          : categoryPlanogramList // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>,
      subCategoryPlanogramList: null == subCategoryPlanogramList
          ? _value.subCategoryPlanogramList
          : subCategoryPlanogramList // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>,
      subCatPlanoGramsList: null == subCatPlanoGramsList
          ? _value.subCatPlanoGramsList
          : subCatPlanoGramsList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isPlanogramProductShimmering: null == isPlanogramProductShimmering
          ? _value.isPlanogramProductShimmering
          : isPlanogramProductShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomProducts: null == isBottomProducts
          ? _value.isBottomProducts
          : isBottomProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      allProductPageNum: null == allProductPageNum
          ? _value.allProductPageNum
          : allProductPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      relatedProductList: null == relatedProductList
          ? _value.relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StoreCategoryStateImplCopyWith<$Res>
    implements $StoreCategoryStateCopyWith<$Res> {
  factory _$$StoreCategoryStateImplCopyWith(_$StoreCategoryStateImpl value,
          $Res Function(_$StoreCategoryStateImpl) then) =
      __$$StoreCategoryStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isCategoryExpand,
      bool isSubCategory,
      String categoryId,
      String subCategoryId,
      String categoryName,
      String subCategoryName,
      List<SubCategory> subCategoryList,
      List<PlanogramDatum> planoGramsList,
      List<PlanogramDatum> subPlanoGramsList,
      List<PlanogramProduct> planoGramsByIdList,
      List<Category> productCategoryList,
      List<List<ProductStockModel>> productStockList,
      bool isPlanogramShimmering,
      bool isSubCategoryShimmering,
      bool isLoading,
      bool isProductLoading,
      int planogramPageNum,
      int subProductPageNum,
      int subPlanogramPageNum,
      int subCategoryPageNum,
      bool isLoadMore,
      bool isBottomOfPlanoGrams,
      bool isBottomOfSubCategory,
      List<Product> productDetails,
      int planoGramUpdateIndex,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      List<SearchModel> searchList,
      String search,
      bool isSearching,
      int imageIndex,
      TextEditingController searchController,
      TextEditingController noteController,
      RefreshController subCategoryRefreshController,
      RefreshController planogramRefreshController,
      List<PlanogramAllProduct> planogramProductList,
      List<Planogramproduct> categoryPlanogramList,
      List<Planogramproduct> subCategoryPlanogramList,
      List<PlanogramDatum> subCatPlanoGramsList,
      bool isBottomOfProducts,
      bool isPlanogramProductShimmering,
      bool isGridView,
      bool isGuestUser,
      bool isBottomProducts,
      int cartCount,
      bool duringCelebration,
      int allProductPageNum,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      double bottleDeposit,
      bool isSubUserAddToBasket});
}

/// @nodoc
class __$$StoreCategoryStateImplCopyWithImpl<$Res>
    extends _$StoreCategoryStateCopyWithImpl<$Res, _$StoreCategoryStateImpl>
    implements _$$StoreCategoryStateImplCopyWith<$Res> {
  __$$StoreCategoryStateImplCopyWithImpl(_$StoreCategoryStateImpl _value,
      $Res Function(_$StoreCategoryStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isCategoryExpand = null,
    Object? isSubCategory = null,
    Object? categoryId = null,
    Object? subCategoryId = null,
    Object? categoryName = null,
    Object? subCategoryName = null,
    Object? subCategoryList = null,
    Object? planoGramsList = null,
    Object? subPlanoGramsList = null,
    Object? planoGramsByIdList = null,
    Object? productCategoryList = null,
    Object? productStockList = null,
    Object? isPlanogramShimmering = null,
    Object? isSubCategoryShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? planogramPageNum = null,
    Object? subProductPageNum = null,
    Object? subPlanogramPageNum = null,
    Object? subCategoryPageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfPlanoGrams = null,
    Object? isBottomOfSubCategory = null,
    Object? productDetails = null,
    Object? planoGramUpdateIndex = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? searchList = null,
    Object? search = null,
    Object? isSearching = null,
    Object? imageIndex = null,
    Object? searchController = null,
    Object? noteController = null,
    Object? subCategoryRefreshController = null,
    Object? planogramRefreshController = null,
    Object? planogramProductList = null,
    Object? categoryPlanogramList = null,
    Object? subCategoryPlanogramList = null,
    Object? subCatPlanoGramsList = null,
    Object? isBottomOfProducts = null,
    Object? isPlanogramProductShimmering = null,
    Object? isGridView = null,
    Object? isGuestUser = null,
    Object? isBottomProducts = null,
    Object? cartCount = null,
    Object? duringCelebration = null,
    Object? allProductPageNum = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
  }) {
    return _then(_$StoreCategoryStateImpl(
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubCategory: null == isSubCategory
          ? _value.isSubCategory
          : isSubCategory // ignore: cast_nullable_to_non_nullable
              as bool,
      categoryId: null == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as String,
      subCategoryId: null == subCategoryId
          ? _value.subCategoryId
          : subCategoryId // ignore: cast_nullable_to_non_nullable
              as String,
      categoryName: null == categoryName
          ? _value.categoryName
          : categoryName // ignore: cast_nullable_to_non_nullable
              as String,
      subCategoryName: null == subCategoryName
          ? _value.subCategoryName
          : subCategoryName // ignore: cast_nullable_to_non_nullable
              as String,
      subCategoryList: null == subCategoryList
          ? _value._subCategoryList
          : subCategoryList // ignore: cast_nullable_to_non_nullable
              as List<SubCategory>,
      planoGramsList: null == planoGramsList
          ? _value._planoGramsList
          : planoGramsList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>,
      subPlanoGramsList: null == subPlanoGramsList
          ? _value._subPlanoGramsList
          : subPlanoGramsList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>,
      planoGramsByIdList: null == planoGramsByIdList
          ? _value._planoGramsByIdList
          : planoGramsByIdList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramProduct>,
      productCategoryList: null == productCategoryList
          ? _value._productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      isPlanogramShimmering: null == isPlanogramShimmering
          ? _value.isPlanogramShimmering
          : isPlanogramShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubCategoryShimmering: null == isSubCategoryShimmering
          ? _value.isSubCategoryShimmering
          : isSubCategoryShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      planogramPageNum: null == planogramPageNum
          ? _value.planogramPageNum
          : planogramPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      subProductPageNum: null == subProductPageNum
          ? _value.subProductPageNum
          : subProductPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      subPlanogramPageNum: null == subPlanogramPageNum
          ? _value.subPlanogramPageNum
          : subPlanogramPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      subCategoryPageNum: null == subCategoryPageNum
          ? _value.subCategoryPageNum
          : subCategoryPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfPlanoGrams: null == isBottomOfPlanoGrams
          ? _value.isBottomOfPlanoGrams
          : isBottomOfPlanoGrams // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfSubCategory: null == isBottomOfSubCategory
          ? _value.isBottomOfSubCategory
          : isBottomOfSubCategory // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value._productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      planoGramUpdateIndex: null == planoGramUpdateIndex
          ? _value.planoGramUpdateIndex
          : planoGramUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value._productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      subCategoryRefreshController: null == subCategoryRefreshController
          ? _value.subCategoryRefreshController
          : subCategoryRefreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      planogramRefreshController: null == planogramRefreshController
          ? _value.planogramRefreshController
          : planogramRefreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      planogramProductList: null == planogramProductList
          ? _value._planogramProductList
          : planogramProductList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramAllProduct>,
      categoryPlanogramList: null == categoryPlanogramList
          ? _value._categoryPlanogramList
          : categoryPlanogramList // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>,
      subCategoryPlanogramList: null == subCategoryPlanogramList
          ? _value._subCategoryPlanogramList
          : subCategoryPlanogramList // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>,
      subCatPlanoGramsList: null == subCatPlanoGramsList
          ? _value._subCatPlanoGramsList
          : subCatPlanoGramsList // ignore: cast_nullable_to_non_nullable
              as List<PlanogramDatum>,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isPlanogramProductShimmering: null == isPlanogramProductShimmering
          ? _value.isPlanogramProductShimmering
          : isPlanogramProductShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomProducts: null == isBottomProducts
          ? _value.isBottomProducts
          : isBottomProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      allProductPageNum: null == allProductPageNum
          ? _value.allProductPageNum
          : allProductPageNum // ignore: cast_nullable_to_non_nullable
              as int,
      relatedProductList: null == relatedProductList
          ? _value._relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$StoreCategoryStateImpl implements _StoreCategoryState {
  const _$StoreCategoryStateImpl(
      {required this.isCategoryExpand,
      required this.isSubCategory,
      required this.categoryId,
      required this.subCategoryId,
      required this.categoryName,
      required this.subCategoryName,
      required final List<SubCategory> subCategoryList,
      required final List<PlanogramDatum> planoGramsList,
      required final List<PlanogramDatum> subPlanoGramsList,
      required final List<PlanogramProduct> planoGramsByIdList,
      required final List<Category> productCategoryList,
      required final List<List<ProductStockModel>> productStockList,
      required this.isPlanogramShimmering,
      required this.isSubCategoryShimmering,
      required this.isLoading,
      required this.isProductLoading,
      required this.planogramPageNum,
      required this.subProductPageNum,
      required this.subPlanogramPageNum,
      required this.subCategoryPageNum,
      required this.isLoadMore,
      required this.isBottomOfPlanoGrams,
      required this.isBottomOfSubCategory,
      required final List<Product> productDetails,
      required this.planoGramUpdateIndex,
      required this.productStockUpdateIndex,
      required this.isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required final List<SearchModel> searchList,
      required this.search,
      required this.isSearching,
      required this.imageIndex,
      required this.searchController,
      required this.noteController,
      required this.subCategoryRefreshController,
      required this.planogramRefreshController,
      required final List<PlanogramAllProduct> planogramProductList,
      required final List<Planogramproduct> categoryPlanogramList,
      required final List<Planogramproduct> subCategoryPlanogramList,
      required final List<PlanogramDatum> subCatPlanoGramsList,
      required this.isBottomOfProducts,
      required this.isPlanogramProductShimmering,
      required this.isGridView,
      required this.isGuestUser,
      required this.isBottomProducts,
      required this.cartCount,
      required this.duringCelebration,
      required this.allProductPageNum,
      required final List<RelatedProductDatum> relatedProductList,
      required this.isRelatedShimmering,
      required this.bottleDeposit,
      required this.isSubUserAddToBasket})
      : _subCategoryList = subCategoryList,
        _planoGramsList = planoGramsList,
        _subPlanoGramsList = subPlanoGramsList,
        _planoGramsByIdList = planoGramsByIdList,
        _productCategoryList = productCategoryList,
        _productStockList = productStockList,
        _productDetails = productDetails,
        _productSupplierList = productSupplierList,
        _searchList = searchList,
        _planogramProductList = planogramProductList,
        _categoryPlanogramList = categoryPlanogramList,
        _subCategoryPlanogramList = subCategoryPlanogramList,
        _subCatPlanoGramsList = subCatPlanoGramsList,
        _relatedProductList = relatedProductList;

  @override
  final bool isCategoryExpand;
  @override
  final bool isSubCategory;
  @override
  final String categoryId;
  @override
  final String subCategoryId;
  @override
  final String categoryName;
  @override
  final String subCategoryName;
  final List<SubCategory> _subCategoryList;
  @override
  List<SubCategory> get subCategoryList {
    if (_subCategoryList is EqualUnmodifiableListView) return _subCategoryList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_subCategoryList);
  }

  final List<PlanogramDatum> _planoGramsList;
  @override
  List<PlanogramDatum> get planoGramsList {
    if (_planoGramsList is EqualUnmodifiableListView) return _planoGramsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_planoGramsList);
  }

  final List<PlanogramDatum> _subPlanoGramsList;
  @override
  List<PlanogramDatum> get subPlanoGramsList {
    if (_subPlanoGramsList is EqualUnmodifiableListView)
      return _subPlanoGramsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_subPlanoGramsList);
  }

  final List<PlanogramProduct> _planoGramsByIdList;
  @override
  List<PlanogramProduct> get planoGramsByIdList {
    if (_planoGramsByIdList is EqualUnmodifiableListView)
      return _planoGramsByIdList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_planoGramsByIdList);
  }

  final List<Category> _productCategoryList;
  @override
  List<Category> get productCategoryList {
    if (_productCategoryList is EqualUnmodifiableListView)
      return _productCategoryList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productCategoryList);
  }

  final List<List<ProductStockModel>> _productStockList;
  @override
  List<List<ProductStockModel>> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final bool isPlanogramShimmering;
  @override
  final bool isSubCategoryShimmering;
  @override
  final bool isLoading;
  @override
  final bool isProductLoading;
  @override
  final int planogramPageNum;
  @override
  final int subProductPageNum;
  @override
  final int subPlanogramPageNum;
  @override
  final int subCategoryPageNum;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfPlanoGrams;
  @override
  final bool isBottomOfSubCategory;
  final List<Product> _productDetails;
  @override
  List<Product> get productDetails {
    if (_productDetails is EqualUnmodifiableListView) return _productDetails;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productDetails);
  }

  @override
  final int planoGramUpdateIndex;
  @override
  final int productStockUpdateIndex;
  @override
  final bool isSelectSupplier;
  final List<ProductSupplierModel> _productSupplierList;
  @override
  List<ProductSupplierModel> get productSupplierList {
    if (_productSupplierList is EqualUnmodifiableListView)
      return _productSupplierList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSupplierList);
  }

  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  final String search;
  @override
  final bool isSearching;
  @override
  final int imageIndex;
  @override
  final TextEditingController searchController;
  @override
  final TextEditingController noteController;
  @override
  final RefreshController subCategoryRefreshController;
  @override
  final RefreshController planogramRefreshController;
  final List<PlanogramAllProduct> _planogramProductList;
  @override
  List<PlanogramAllProduct> get planogramProductList {
    if (_planogramProductList is EqualUnmodifiableListView)
      return _planogramProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_planogramProductList);
  }

  final List<Planogramproduct> _categoryPlanogramList;
  @override
  List<Planogramproduct> get categoryPlanogramList {
    if (_categoryPlanogramList is EqualUnmodifiableListView)
      return _categoryPlanogramList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_categoryPlanogramList);
  }

  final List<Planogramproduct> _subCategoryPlanogramList;
  @override
  List<Planogramproduct> get subCategoryPlanogramList {
    if (_subCategoryPlanogramList is EqualUnmodifiableListView)
      return _subCategoryPlanogramList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_subCategoryPlanogramList);
  }

  final List<PlanogramDatum> _subCatPlanoGramsList;
  @override
  List<PlanogramDatum> get subCatPlanoGramsList {
    if (_subCatPlanoGramsList is EqualUnmodifiableListView)
      return _subCatPlanoGramsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_subCatPlanoGramsList);
  }

  @override
  final bool isBottomOfProducts;
  @override
  final bool isPlanogramProductShimmering;
  @override
  final bool isGridView;
  @override
  final bool isGuestUser;
  @override
  final bool isBottomProducts;
  @override
  final int cartCount;
  @override
  final bool duringCelebration;
  @override
  final int allProductPageNum;
  final List<RelatedProductDatum> _relatedProductList;
  @override
  List<RelatedProductDatum> get relatedProductList {
    if (_relatedProductList is EqualUnmodifiableListView)
      return _relatedProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedProductList);
  }

  @override
  final bool isRelatedShimmering;
  @override
  final double bottleDeposit;
  @override
  final bool isSubUserAddToBasket;

  @override
  String toString() {
    return 'StoreCategoryState(isCategoryExpand: $isCategoryExpand, isSubCategory: $isSubCategory, categoryId: $categoryId, subCategoryId: $subCategoryId, categoryName: $categoryName, subCategoryName: $subCategoryName, subCategoryList: $subCategoryList, planoGramsList: $planoGramsList, subPlanoGramsList: $subPlanoGramsList, planoGramsByIdList: $planoGramsByIdList, productCategoryList: $productCategoryList, productStockList: $productStockList, isPlanogramShimmering: $isPlanogramShimmering, isSubCategoryShimmering: $isSubCategoryShimmering, isLoading: $isLoading, isProductLoading: $isProductLoading, planogramPageNum: $planogramPageNum, subProductPageNum: $subProductPageNum, subPlanogramPageNum: $subPlanogramPageNum, subCategoryPageNum: $subCategoryPageNum, isLoadMore: $isLoadMore, isBottomOfPlanoGrams: $isBottomOfPlanoGrams, isBottomOfSubCategory: $isBottomOfSubCategory, productDetails: $productDetails, planoGramUpdateIndex: $planoGramUpdateIndex, productStockUpdateIndex: $productStockUpdateIndex, isSelectSupplier: $isSelectSupplier, productSupplierList: $productSupplierList, searchList: $searchList, search: $search, isSearching: $isSearching, imageIndex: $imageIndex, searchController: $searchController, noteController: $noteController, subCategoryRefreshController: $subCategoryRefreshController, planogramRefreshController: $planogramRefreshController, planogramProductList: $planogramProductList, categoryPlanogramList: $categoryPlanogramList, subCategoryPlanogramList: $subCategoryPlanogramList, subCatPlanoGramsList: $subCatPlanoGramsList, isBottomOfProducts: $isBottomOfProducts, isPlanogramProductShimmering: $isPlanogramProductShimmering, isGridView: $isGridView, isGuestUser: $isGuestUser, isBottomProducts: $isBottomProducts, cartCount: $cartCount, duringCelebration: $duringCelebration, allProductPageNum: $allProductPageNum, relatedProductList: $relatedProductList, isRelatedShimmering: $isRelatedShimmering, bottleDeposit: $bottleDeposit, isSubUserAddToBasket: $isSubUserAddToBasket)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StoreCategoryStateImpl &&
            (identical(other.isCategoryExpand, isCategoryExpand) ||
                other.isCategoryExpand == isCategoryExpand) &&
            (identical(other.isSubCategory, isSubCategory) ||
                other.isSubCategory == isSubCategory) &&
            (identical(other.categoryId, categoryId) ||
                other.categoryId == categoryId) &&
            (identical(other.subCategoryId, subCategoryId) ||
                other.subCategoryId == subCategoryId) &&
            (identical(other.categoryName, categoryName) ||
                other.categoryName == categoryName) &&
            (identical(other.subCategoryName, subCategoryName) ||
                other.subCategoryName == subCategoryName) &&
            const DeepCollectionEquality()
                .equals(other._subCategoryList, _subCategoryList) &&
            const DeepCollectionEquality()
                .equals(other._planoGramsList, _planoGramsList) &&
            const DeepCollectionEquality()
                .equals(other._subPlanoGramsList, _subPlanoGramsList) &&
            const DeepCollectionEquality()
                .equals(other._planoGramsByIdList, _planoGramsByIdList) &&
            const DeepCollectionEquality()
                .equals(other._productCategoryList, _productCategoryList) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(other.isPlanogramShimmering, isPlanogramShimmering) ||
                other.isPlanogramShimmering == isPlanogramShimmering) &&
            (identical(other.isSubCategoryShimmering, isSubCategoryShimmering) ||
                other.isSubCategoryShimmering == isSubCategoryShimmering) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isProductLoading, isProductLoading) ||
                other.isProductLoading == isProductLoading) &&
            (identical(other.planogramPageNum, planogramPageNum) ||
                other.planogramPageNum == planogramPageNum) &&
            (identical(other.subProductPageNum, subProductPageNum) ||
                other.subProductPageNum == subProductPageNum) &&
            (identical(other.subPlanogramPageNum, subPlanogramPageNum) ||
                other.subPlanogramPageNum == subPlanogramPageNum) &&
            (identical(other.subCategoryPageNum, subCategoryPageNum) ||
                other.subCategoryPageNum == subCategoryPageNum) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfPlanoGrams, isBottomOfPlanoGrams) ||
                other.isBottomOfPlanoGrams == isBottomOfPlanoGrams) &&
            (identical(other.isBottomOfSubCategory, isBottomOfSubCategory) ||
                other.isBottomOfSubCategory == isBottomOfSubCategory) &&
            const DeepCollectionEquality()
                .equals(other._productDetails, _productDetails) &&
            (identical(other.planoGramUpdateIndex, planoGramUpdateIndex) ||
                other.planoGramUpdateIndex == planoGramUpdateIndex) &&
            (identical(other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier) &&
            const DeepCollectionEquality()
                .equals(other._productSupplierList, _productSupplierList) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList) &&
            (identical(other.search, search) || other.search == search) &&
            (identical(other.isSearching, isSearching) ||
                other.isSearching == isSearching) &&
            (identical(other.imageIndex, imageIndex) ||
                other.imageIndex == imageIndex) &&
            (identical(other.searchController, searchController) ||
                other.searchController == searchController) &&
            (identical(other.noteController, noteController) ||
                other.noteController == noteController) &&
            (identical(other.subCategoryRefreshController, subCategoryRefreshController) ||
                other.subCategoryRefreshController ==
                    subCategoryRefreshController) &&
            (identical(other.planogramRefreshController, planogramRefreshController) ||
                other.planogramRefreshController == planogramRefreshController) &&
            const DeepCollectionEquality().equals(other._planogramProductList, _planogramProductList) &&
            const DeepCollectionEquality().equals(other._categoryPlanogramList, _categoryPlanogramList) &&
            const DeepCollectionEquality().equals(other._subCategoryPlanogramList, _subCategoryPlanogramList) &&
            const DeepCollectionEquality().equals(other._subCatPlanoGramsList, _subCatPlanoGramsList) &&
            (identical(other.isBottomOfProducts, isBottomOfProducts) || other.isBottomOfProducts == isBottomOfProducts) &&
            (identical(other.isPlanogramProductShimmering, isPlanogramProductShimmering) || other.isPlanogramProductShimmering == isPlanogramProductShimmering) &&
            (identical(other.isGridView, isGridView) || other.isGridView == isGridView) &&
            (identical(other.isGuestUser, isGuestUser) || other.isGuestUser == isGuestUser) &&
            (identical(other.isBottomProducts, isBottomProducts) || other.isBottomProducts == isBottomProducts) &&
            (identical(other.cartCount, cartCount) || other.cartCount == cartCount) &&
            (identical(other.duringCelebration, duringCelebration) || other.duringCelebration == duringCelebration) &&
            (identical(other.allProductPageNum, allProductPageNum) || other.allProductPageNum == allProductPageNum) &&
            const DeepCollectionEquality().equals(other._relatedProductList, _relatedProductList) &&
            (identical(other.isRelatedShimmering, isRelatedShimmering) || other.isRelatedShimmering == isRelatedShimmering) &&
            (identical(other.bottleDeposit, bottleDeposit) || other.bottleDeposit == bottleDeposit) &&
            (identical(other.isSubUserAddToBasket, isSubUserAddToBasket) || other.isSubUserAddToBasket == isSubUserAddToBasket));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        isCategoryExpand,
        isSubCategory,
        categoryId,
        subCategoryId,
        categoryName,
        subCategoryName,
        const DeepCollectionEquality().hash(_subCategoryList),
        const DeepCollectionEquality().hash(_planoGramsList),
        const DeepCollectionEquality().hash(_subPlanoGramsList),
        const DeepCollectionEquality().hash(_planoGramsByIdList),
        const DeepCollectionEquality().hash(_productCategoryList),
        const DeepCollectionEquality().hash(_productStockList),
        isPlanogramShimmering,
        isSubCategoryShimmering,
        isLoading,
        isProductLoading,
        planogramPageNum,
        subProductPageNum,
        subPlanogramPageNum,
        subCategoryPageNum,
        isLoadMore,
        isBottomOfPlanoGrams,
        isBottomOfSubCategory,
        const DeepCollectionEquality().hash(_productDetails),
        planoGramUpdateIndex,
        productStockUpdateIndex,
        isSelectSupplier,
        const DeepCollectionEquality().hash(_productSupplierList),
        const DeepCollectionEquality().hash(_searchList),
        search,
        isSearching,
        imageIndex,
        searchController,
        noteController,
        subCategoryRefreshController,
        planogramRefreshController,
        const DeepCollectionEquality().hash(_planogramProductList),
        const DeepCollectionEquality().hash(_categoryPlanogramList),
        const DeepCollectionEquality().hash(_subCategoryPlanogramList),
        const DeepCollectionEquality().hash(_subCatPlanoGramsList),
        isBottomOfProducts,
        isPlanogramProductShimmering,
        isGridView,
        isGuestUser,
        isBottomProducts,
        cartCount,
        duringCelebration,
        allProductPageNum,
        const DeepCollectionEquality().hash(_relatedProductList),
        isRelatedShimmering,
        bottleDeposit,
        isSubUserAddToBasket
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StoreCategoryStateImplCopyWith<_$StoreCategoryStateImpl> get copyWith =>
      __$$StoreCategoryStateImplCopyWithImpl<_$StoreCategoryStateImpl>(
          this, _$identity);
}

abstract class _StoreCategoryState implements StoreCategoryState {
  const factory _StoreCategoryState(
      {required final bool isCategoryExpand,
      required final bool isSubCategory,
      required final String categoryId,
      required final String subCategoryId,
      required final String categoryName,
      required final String subCategoryName,
      required final List<SubCategory> subCategoryList,
      required final List<PlanogramDatum> planoGramsList,
      required final List<PlanogramDatum> subPlanoGramsList,
      required final List<PlanogramProduct> planoGramsByIdList,
      required final List<Category> productCategoryList,
      required final List<List<ProductStockModel>> productStockList,
      required final bool isPlanogramShimmering,
      required final bool isSubCategoryShimmering,
      required final bool isLoading,
      required final bool isProductLoading,
      required final int planogramPageNum,
      required final int subProductPageNum,
      required final int subPlanogramPageNum,
      required final int subCategoryPageNum,
      required final bool isLoadMore,
      required final bool isBottomOfPlanoGrams,
      required final bool isBottomOfSubCategory,
      required final List<Product> productDetails,
      required final int planoGramUpdateIndex,
      required final int productStockUpdateIndex,
      required final bool isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required final List<SearchModel> searchList,
      required final String search,
      required final bool isSearching,
      required final int imageIndex,
      required final TextEditingController searchController,
      required final TextEditingController noteController,
      required final RefreshController subCategoryRefreshController,
      required final RefreshController planogramRefreshController,
      required final List<PlanogramAllProduct> planogramProductList,
      required final List<Planogramproduct> categoryPlanogramList,
      required final List<Planogramproduct> subCategoryPlanogramList,
      required final List<PlanogramDatum> subCatPlanoGramsList,
      required final bool isBottomOfProducts,
      required final bool isPlanogramProductShimmering,
      required final bool isGridView,
      required final bool isGuestUser,
      required final bool isBottomProducts,
      required final int cartCount,
      required final bool duringCelebration,
      required final int allProductPageNum,
      required final List<RelatedProductDatum> relatedProductList,
      required final bool isRelatedShimmering,
      required final double bottleDeposit,
      required final bool isSubUserAddToBasket}) = _$StoreCategoryStateImpl;

  @override
  bool get isCategoryExpand;
  @override
  bool get isSubCategory;
  @override
  String get categoryId;
  @override
  String get subCategoryId;
  @override
  String get categoryName;
  @override
  String get subCategoryName;
  @override
  List<SubCategory> get subCategoryList;
  @override
  List<PlanogramDatum> get planoGramsList;
  @override
  List<PlanogramDatum> get subPlanoGramsList;
  @override
  List<PlanogramProduct> get planoGramsByIdList;
  @override
  List<Category> get productCategoryList;
  @override
  List<List<ProductStockModel>> get productStockList;
  @override
  bool get isPlanogramShimmering;
  @override
  bool get isSubCategoryShimmering;
  @override
  bool get isLoading;
  @override
  bool get isProductLoading;
  @override
  int get planogramPageNum;
  @override
  int get subProductPageNum;
  @override
  int get subPlanogramPageNum;
  @override
  int get subCategoryPageNum;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfPlanoGrams;
  @override
  bool get isBottomOfSubCategory;
  @override
  List<Product> get productDetails;
  @override
  int get planoGramUpdateIndex;
  @override
  int get productStockUpdateIndex;
  @override
  bool get isSelectSupplier;
  @override
  List<ProductSupplierModel> get productSupplierList;
  @override
  List<SearchModel> get searchList;
  @override
  String get search;
  @override
  bool get isSearching;
  @override
  int get imageIndex;
  @override
  TextEditingController get searchController;
  @override
  TextEditingController get noteController;
  @override
  RefreshController get subCategoryRefreshController;
  @override
  RefreshController get planogramRefreshController;
  @override
  List<PlanogramAllProduct> get planogramProductList;
  @override
  List<Planogramproduct> get categoryPlanogramList;
  @override
  List<Planogramproduct> get subCategoryPlanogramList;
  @override
  List<PlanogramDatum> get subCatPlanoGramsList;
  @override
  bool get isBottomOfProducts;
  @override
  bool get isPlanogramProductShimmering;
  @override
  bool get isGridView;
  @override
  bool get isGuestUser;
  @override
  bool get isBottomProducts;
  @override
  int get cartCount;
  @override
  bool get duringCelebration;
  @override
  int get allProductPageNum;
  @override
  List<RelatedProductDatum> get relatedProductList;
  @override
  bool get isRelatedShimmering;
  @override
  double get bottleDeposit;
  @override
  bool get isSubUserAddToBasket;
  @override
  @JsonKey(ignore: true)
  _$$StoreCategoryStateImplCopyWith<_$StoreCategoryStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
