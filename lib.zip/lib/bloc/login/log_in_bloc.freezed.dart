// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'log_in_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$LogInEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String contactNumber, BuildContext context)
        logInApiDataEvent,
    required TResult Function(bool isRegister) changeAuthEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult? Function(bool isRegister)? changeAuthEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult Function(bool isRegister)? changeAuthEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
    required TResult Function(_ChangeAuthEvent value) changeAuthEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult? Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LogInEventCopyWith<$Res> {
  factory $LogInEventCopyWith(
          LogInEvent value, $Res Function(LogInEvent) then) =
      _$LogInEventCopyWithImpl<$Res, LogInEvent>;
}

/// @nodoc
class _$LogInEventCopyWithImpl<$Res, $Val extends LogInEvent>
    implements $LogInEventCopyWith<$Res> {
  _$LogInEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$logInApiDataEventImplCopyWith<$Res> {
  factory _$$logInApiDataEventImplCopyWith(_$logInApiDataEventImpl value,
          $Res Function(_$logInApiDataEventImpl) then) =
      __$$logInApiDataEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String contactNumber, BuildContext context});
}

/// @nodoc
class __$$logInApiDataEventImplCopyWithImpl<$Res>
    extends _$LogInEventCopyWithImpl<$Res, _$logInApiDataEventImpl>
    implements _$$logInApiDataEventImplCopyWith<$Res> {
  __$$logInApiDataEventImplCopyWithImpl(_$logInApiDataEventImpl _value,
      $Res Function(_$logInApiDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? contactNumber = null,
    Object? context = null,
  }) {
    return _then(_$logInApiDataEventImpl(
      contactNumber: null == contactNumber
          ? _value.contactNumber
          : contactNumber // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$logInApiDataEventImpl implements _logInApiDataEvent {
  _$logInApiDataEventImpl({required this.contactNumber, required this.context});

  @override
  final String contactNumber;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'LogInEvent.logInApiDataEvent(contactNumber: $contactNumber, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$logInApiDataEventImpl &&
            (identical(other.contactNumber, contactNumber) ||
                other.contactNumber == contactNumber) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, contactNumber, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$logInApiDataEventImplCopyWith<_$logInApiDataEventImpl> get copyWith =>
      __$$logInApiDataEventImplCopyWithImpl<_$logInApiDataEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String contactNumber, BuildContext context)
        logInApiDataEvent,
    required TResult Function(bool isRegister) changeAuthEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
  }) {
    return logInApiDataEvent(contactNumber, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult? Function(bool isRegister)? changeAuthEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
  }) {
    return logInApiDataEvent?.call(contactNumber, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult Function(bool isRegister)? changeAuthEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) {
    if (logInApiDataEvent != null) {
      return logInApiDataEvent(contactNumber, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
    required TResult Function(_ChangeAuthEvent value) changeAuthEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
  }) {
    return logInApiDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult? Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
  }) {
    return logInApiDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) {
    if (logInApiDataEvent != null) {
      return logInApiDataEvent(this);
    }
    return orElse();
  }
}

abstract class _logInApiDataEvent implements LogInEvent {
  factory _logInApiDataEvent(
      {required final String contactNumber,
      required final BuildContext context}) = _$logInApiDataEventImpl;

  String get contactNumber;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$logInApiDataEventImplCopyWith<_$logInApiDataEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeAuthEventImplCopyWith<$Res> {
  factory _$$ChangeAuthEventImplCopyWith(_$ChangeAuthEventImpl value,
          $Res Function(_$ChangeAuthEventImpl) then) =
      __$$ChangeAuthEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isRegister});
}

/// @nodoc
class __$$ChangeAuthEventImplCopyWithImpl<$Res>
    extends _$LogInEventCopyWithImpl<$Res, _$ChangeAuthEventImpl>
    implements _$$ChangeAuthEventImplCopyWith<$Res> {
  __$$ChangeAuthEventImplCopyWithImpl(
      _$ChangeAuthEventImpl _value, $Res Function(_$ChangeAuthEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isRegister = null,
  }) {
    return _then(_$ChangeAuthEventImpl(
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ChangeAuthEventImpl implements _ChangeAuthEvent {
  _$ChangeAuthEventImpl({required this.isRegister});

  @override
  final bool isRegister;

  @override
  String toString() {
    return 'LogInEvent.changeAuthEvent(isRegister: $isRegister)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeAuthEventImpl &&
            (identical(other.isRegister, isRegister) ||
                other.isRegister == isRegister));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isRegister);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeAuthEventImplCopyWith<_$ChangeAuthEventImpl> get copyWith =>
      __$$ChangeAuthEventImplCopyWithImpl<_$ChangeAuthEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String contactNumber, BuildContext context)
        logInApiDataEvent,
    required TResult Function(bool isRegister) changeAuthEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
  }) {
    return changeAuthEvent(isRegister);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult? Function(bool isRegister)? changeAuthEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
  }) {
    return changeAuthEvent?.call(isRegister);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult Function(bool isRegister)? changeAuthEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) {
    if (changeAuthEvent != null) {
      return changeAuthEvent(isRegister);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
    required TResult Function(_ChangeAuthEvent value) changeAuthEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
  }) {
    return changeAuthEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult? Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
  }) {
    return changeAuthEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) {
    if (changeAuthEvent != null) {
      return changeAuthEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeAuthEvent implements LogInEvent {
  factory _ChangeAuthEvent({required final bool isRegister}) =
      _$ChangeAuthEventImpl;

  bool get isRegister;
  @JsonKey(ignore: true)
  _$$ChangeAuthEventImplCopyWith<_$ChangeAuthEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$checkVersionOfAppEventImplCopyWith<$Res> {
  factory _$$checkVersionOfAppEventImplCopyWith(
          _$checkVersionOfAppEventImpl value,
          $Res Function(_$checkVersionOfAppEventImpl) then) =
      __$$checkVersionOfAppEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$checkVersionOfAppEventImplCopyWithImpl<$Res>
    extends _$LogInEventCopyWithImpl<$Res, _$checkVersionOfAppEventImpl>
    implements _$$checkVersionOfAppEventImplCopyWith<$Res> {
  __$$checkVersionOfAppEventImplCopyWithImpl(
      _$checkVersionOfAppEventImpl _value,
      $Res Function(_$checkVersionOfAppEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$checkVersionOfAppEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$checkVersionOfAppEventImpl implements _checkVersionOfAppEvent {
  const _$checkVersionOfAppEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'LogInEvent.checkVersionOfAppEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$checkVersionOfAppEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$checkVersionOfAppEventImplCopyWith<_$checkVersionOfAppEventImpl>
      get copyWith => __$$checkVersionOfAppEventImplCopyWithImpl<
          _$checkVersionOfAppEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String contactNumber, BuildContext context)
        logInApiDataEvent,
    required TResult Function(bool isRegister) changeAuthEvent,
    required TResult Function(BuildContext context) checkVersionOfAppEvent,
  }) {
    return checkVersionOfAppEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult? Function(bool isRegister)? changeAuthEvent,
    TResult? Function(BuildContext context)? checkVersionOfAppEvent,
  }) {
    return checkVersionOfAppEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String contactNumber, BuildContext context)?
        logInApiDataEvent,
    TResult Function(bool isRegister)? changeAuthEvent,
    TResult Function(BuildContext context)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) {
    if (checkVersionOfAppEvent != null) {
      return checkVersionOfAppEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
    required TResult Function(_ChangeAuthEvent value) changeAuthEvent,
    required TResult Function(_checkVersionOfAppEvent value)
        checkVersionOfAppEvent,
  }) {
    return checkVersionOfAppEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult? Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult? Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
  }) {
    return checkVersionOfAppEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    TResult Function(_ChangeAuthEvent value)? changeAuthEvent,
    TResult Function(_checkVersionOfAppEvent value)? checkVersionOfAppEvent,
    required TResult orElse(),
  }) {
    if (checkVersionOfAppEvent != null) {
      return checkVersionOfAppEvent(this);
    }
    return orElse();
  }
}

abstract class _checkVersionOfAppEvent implements LogInEvent {
  const factory _checkVersionOfAppEvent({required final BuildContext context}) =
      _$checkVersionOfAppEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$checkVersionOfAppEventImplCopyWith<_$checkVersionOfAppEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$LogInState {
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isRegister => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $LogInStateCopyWith<LogInState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LogInStateCopyWith<$Res> {
  factory $LogInStateCopyWith(
          LogInState value, $Res Function(LogInState) then) =
      _$LogInStateCopyWithImpl<$Res, LogInState>;
  @useResult
  $Res call({bool isLoading, bool isRegister});
}

/// @nodoc
class _$LogInStateCopyWithImpl<$Res, $Val extends LogInState>
    implements $LogInStateCopyWith<$Res> {
  _$LogInStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? isRegister = null,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$LogInStateImplCopyWith<$Res>
    implements $LogInStateCopyWith<$Res> {
  factory _$$LogInStateImplCopyWith(
          _$LogInStateImpl value, $Res Function(_$LogInStateImpl) then) =
      __$$LogInStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool isLoading, bool isRegister});
}

/// @nodoc
class __$$LogInStateImplCopyWithImpl<$Res>
    extends _$LogInStateCopyWithImpl<$Res, _$LogInStateImpl>
    implements _$$LogInStateImplCopyWith<$Res> {
  __$$LogInStateImplCopyWithImpl(
      _$LogInStateImpl _value, $Res Function(_$LogInStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? isRegister = null,
  }) {
    return _then(_$LogInStateImpl(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$LogInStateImpl implements _LogInState {
  const _$LogInStateImpl({required this.isLoading, required this.isRegister});

  @override
  final bool isLoading;
  @override
  final bool isRegister;

  @override
  String toString() {
    return 'LogInState(isLoading: $isLoading, isRegister: $isRegister)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LogInStateImpl &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isRegister, isRegister) ||
                other.isRegister == isRegister));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoading, isRegister);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LogInStateImplCopyWith<_$LogInStateImpl> get copyWith =>
      __$$LogInStateImplCopyWithImpl<_$LogInStateImpl>(this, _$identity);
}

abstract class _LogInState implements LogInState {
  const factory _LogInState(
      {required final bool isLoading,
      required final bool isRegister}) = _$LogInStateImpl;

  @override
  bool get isLoading;
  @override
  bool get isRegister;
  @override
  @JsonKey(ignore: true)
  _$$LogInStateImplCopyWith<_$LogInStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
