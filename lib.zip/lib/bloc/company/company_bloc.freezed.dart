// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'company_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$CompanyEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompanyEventCopyWith<$Res> {
  factory $CompanyEventCopyWith(
          CompanyEvent value, $Res Function(CompanyEvent) then) =
      _$CompanyEventCopyWithImpl<$Res, CompanyEvent>;
}

/// @nodoc
class _$CompanyEventCopyWithImpl<$Res, $Val extends CompanyEvent>
    implements $CompanyEventCopyWith<$Res> {
  _$CompanyEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetCompaniesListEventImplCopyWith<$Res> {
  factory _$$GetCompaniesListEventImplCopyWith(
          _$GetCompaniesListEventImpl value,
          $Res Function(_$GetCompaniesListEventImpl) then) =
      __$$GetCompaniesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetCompaniesListEventImplCopyWithImpl<$Res>
    extends _$CompanyEventCopyWithImpl<$Res, _$GetCompaniesListEventImpl>
    implements _$$GetCompaniesListEventImplCopyWith<$Res> {
  __$$GetCompaniesListEventImplCopyWithImpl(_$GetCompaniesListEventImpl _value,
      $Res Function(_$GetCompaniesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetCompaniesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetCompaniesListEventImpl implements _GetCompaniesListEvent {
  const _$GetCompaniesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'CompanyEvent.getCompaniesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetCompaniesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetCompaniesListEventImplCopyWith<_$GetCompaniesListEventImpl>
      get copyWith => __$$GetCompaniesListEventImplCopyWithImpl<
          _$GetCompaniesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return getCompaniesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return getCompaniesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getCompaniesListEvent != null) {
      return getCompaniesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return getCompaniesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return getCompaniesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getCompaniesListEvent != null) {
      return getCompaniesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetCompaniesListEvent implements CompanyEvent {
  const factory _GetCompaniesListEvent({required final BuildContext context}) =
      _$GetCompaniesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetCompaniesListEventImplCopyWith<_$GetCompaniesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetSearchEventImplCopyWith<$Res> {
  factory _$$SetSearchEventImplCopyWith(_$SetSearchEventImpl value,
          $Res Function(_$SetSearchEventImpl) then) =
      __$$SetSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search});
}

/// @nodoc
class __$$SetSearchEventImplCopyWithImpl<$Res>
    extends _$CompanyEventCopyWithImpl<$Res, _$SetSearchEventImpl>
    implements _$$SetSearchEventImplCopyWith<$Res> {
  __$$SetSearchEventImplCopyWithImpl(
      _$SetSearchEventImpl _value, $Res Function(_$SetSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
  }) {
    return _then(_$SetSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SetSearchEventImpl implements _SetSearchEvent {
  const _$SetSearchEventImpl({required this.search});

  @override
  final String search;

  @override
  String toString() {
    return 'CompanyEvent.setSearchEvent(search: $search)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SetSearchEventImpl &&
            (identical(other.search, search) || other.search == search));
  }

  @override
  int get hashCode => Object.hash(runtimeType, search);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SetSearchEventImplCopyWith<_$SetSearchEventImpl> get copyWith =>
      __$$SetSearchEventImplCopyWithImpl<_$SetSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return setSearchEvent(search);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return setSearchEvent?.call(search);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (setSearchEvent != null) {
      return setSearchEvent(search);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return setSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return setSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (setSearchEvent != null) {
      return setSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _SetSearchEvent implements CompanyEvent {
  const factory _SetSearchEvent({required final String search}) =
      _$SetSearchEventImpl;

  String get search;
  @JsonKey(ignore: true)
  _$$SetSearchEventImplCopyWith<_$SetSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$CompanyEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'CompanyEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getCompaniesListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getCompaniesListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getCompaniesListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetCompaniesListEvent value)
        getCompaniesListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetCompaniesListEvent value)? getCompaniesListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements CompanyEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$CompanyState {
  List<Brand> get companiesList => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfCompanies => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CompanyStateCopyWith<CompanyState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CompanyStateCopyWith<$Res> {
  factory $CompanyStateCopyWith(
          CompanyState value, $Res Function(CompanyState) then) =
      _$CompanyStateCopyWithImpl<$Res, CompanyState>;
  @useResult
  $Res call(
      {List<Brand> companiesList,
      String search,
      bool isShimmering,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfCompanies,
      RefreshController refreshController,
      String language});
}

/// @nodoc
class _$CompanyStateCopyWithImpl<$Res, $Val extends CompanyState>
    implements $CompanyStateCopyWith<$Res> {
  _$CompanyStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companiesList = null,
    Object? search = null,
    Object? isShimmering = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfCompanies = null,
    Object? refreshController = null,
    Object? language = null,
  }) {
    return _then(_value.copyWith(
      companiesList: null == companiesList
          ? _value.companiesList
          : companiesList // ignore: cast_nullable_to_non_nullable
              as List<Brand>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfCompanies: null == isBottomOfCompanies
          ? _value.isBottomOfCompanies
          : isBottomOfCompanies // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CompanyStateImplCopyWith<$Res>
    implements $CompanyStateCopyWith<$Res> {
  factory _$$CompanyStateImplCopyWith(
          _$CompanyStateImpl value, $Res Function(_$CompanyStateImpl) then) =
      __$$CompanyStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Brand> companiesList,
      String search,
      bool isShimmering,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfCompanies,
      RefreshController refreshController,
      String language});
}

/// @nodoc
class __$$CompanyStateImplCopyWithImpl<$Res>
    extends _$CompanyStateCopyWithImpl<$Res, _$CompanyStateImpl>
    implements _$$CompanyStateImplCopyWith<$Res> {
  __$$CompanyStateImplCopyWithImpl(
      _$CompanyStateImpl _value, $Res Function(_$CompanyStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companiesList = null,
    Object? search = null,
    Object? isShimmering = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfCompanies = null,
    Object? refreshController = null,
    Object? language = null,
  }) {
    return _then(_$CompanyStateImpl(
      companiesList: null == companiesList
          ? _value._companiesList
          : companiesList // ignore: cast_nullable_to_non_nullable
              as List<Brand>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfCompanies: null == isBottomOfCompanies
          ? _value.isBottomOfCompanies
          : isBottomOfCompanies // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$CompanyStateImpl implements _CompanyState {
  const _$CompanyStateImpl(
      {required final List<Brand> companiesList,
      required this.search,
      required this.isShimmering,
      required this.pageNum,
      required this.isLoadMore,
      required this.isBottomOfCompanies,
      required this.refreshController,
      required this.language})
      : _companiesList = companiesList;

  final List<Brand> _companiesList;
  @override
  List<Brand> get companiesList {
    if (_companiesList is EqualUnmodifiableListView) return _companiesList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_companiesList);
  }

  @override
  final String search;
  @override
  final bool isShimmering;
  @override
  final int pageNum;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfCompanies;
  @override
  final RefreshController refreshController;
  @override
  final String language;

  @override
  String toString() {
    return 'CompanyState(companiesList: $companiesList, search: $search, isShimmering: $isShimmering, pageNum: $pageNum, isLoadMore: $isLoadMore, isBottomOfCompanies: $isBottomOfCompanies, refreshController: $refreshController, language: $language)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CompanyStateImpl &&
            const DeepCollectionEquality()
                .equals(other._companiesList, _companiesList) &&
            (identical(other.search, search) || other.search == search) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfCompanies, isBottomOfCompanies) ||
                other.isBottomOfCompanies == isBottomOfCompanies) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.language, language) ||
                other.language == language));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_companiesList),
      search,
      isShimmering,
      pageNum,
      isLoadMore,
      isBottomOfCompanies,
      refreshController,
      language);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CompanyStateImplCopyWith<_$CompanyStateImpl> get copyWith =>
      __$$CompanyStateImplCopyWithImpl<_$CompanyStateImpl>(this, _$identity);
}

abstract class _CompanyState implements CompanyState {
  const factory _CompanyState(
      {required final List<Brand> companiesList,
      required final String search,
      required final bool isShimmering,
      required final int pageNum,
      required final bool isLoadMore,
      required final bool isBottomOfCompanies,
      required final RefreshController refreshController,
      required final String language}) = _$CompanyStateImpl;

  @override
  List<Brand> get companiesList;
  @override
  String get search;
  @override
  bool get isShimmering;
  @override
  int get pageNum;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfCompanies;
  @override
  RefreshController get refreshController;
  @override
  String get language;
  @override
  @JsonKey(ignore: true)
  _$$CompanyStateImplCopyWith<_$CompanyStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
