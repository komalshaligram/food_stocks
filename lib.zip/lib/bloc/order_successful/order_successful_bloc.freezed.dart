// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'order_successful_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$OrderSuccessfulEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function() celebrationEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function()? celebrationEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function()? celebrationEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_celebrationEvent value) celebrationEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_celebrationEvent value)? celebrationEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_celebrationEvent value)? celebrationEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderSuccessfulEventCopyWith<$Res> {
  factory $OrderSuccessfulEventCopyWith(OrderSuccessfulEvent value,
          $Res Function(OrderSuccessfulEvent) then) =
      _$OrderSuccessfulEventCopyWithImpl<$Res, OrderSuccessfulEvent>;
}

/// @nodoc
class _$OrderSuccessfulEventCopyWithImpl<$Res,
        $Val extends OrderSuccessfulEvent>
    implements $OrderSuccessfulEventCopyWith<$Res> {
  _$OrderSuccessfulEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getWalletRecordEventImplCopyWith<$Res> {
  factory _$$getWalletRecordEventImplCopyWith(_$getWalletRecordEventImpl value,
          $Res Function(_$getWalletRecordEventImpl) then) =
      __$$getWalletRecordEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getWalletRecordEventImplCopyWithImpl<$Res>
    extends _$OrderSuccessfulEventCopyWithImpl<$Res, _$getWalletRecordEventImpl>
    implements _$$getWalletRecordEventImplCopyWith<$Res> {
  __$$getWalletRecordEventImplCopyWithImpl(_$getWalletRecordEventImpl _value,
      $Res Function(_$getWalletRecordEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getWalletRecordEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getWalletRecordEventImpl implements _getWalletRecordEvent {
  const _$getWalletRecordEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'OrderSuccessfulEvent.getWalletRecordEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getWalletRecordEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getWalletRecordEventImplCopyWith<_$getWalletRecordEventImpl>
      get copyWith =>
          __$$getWalletRecordEventImplCopyWithImpl<_$getWalletRecordEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function() celebrationEvent,
  }) {
    return getWalletRecordEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function()? celebrationEvent,
  }) {
    return getWalletRecordEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function()? celebrationEvent,
    required TResult orElse(),
  }) {
    if (getWalletRecordEvent != null) {
      return getWalletRecordEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_celebrationEvent value) celebrationEvent,
  }) {
    return getWalletRecordEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_celebrationEvent value)? celebrationEvent,
  }) {
    return getWalletRecordEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_celebrationEvent value)? celebrationEvent,
    required TResult orElse(),
  }) {
    if (getWalletRecordEvent != null) {
      return getWalletRecordEvent(this);
    }
    return orElse();
  }
}

abstract class _getWalletRecordEvent implements OrderSuccessfulEvent {
  const factory _getWalletRecordEvent({required final BuildContext context}) =
      _$getWalletRecordEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getWalletRecordEventImplCopyWith<_$getWalletRecordEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getOrderCountEventImplCopyWith<$Res> {
  factory _$$getOrderCountEventImplCopyWith(_$getOrderCountEventImpl value,
          $Res Function(_$getOrderCountEventImpl) then) =
      __$$getOrderCountEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getOrderCountEventImplCopyWithImpl<$Res>
    extends _$OrderSuccessfulEventCopyWithImpl<$Res, _$getOrderCountEventImpl>
    implements _$$getOrderCountEventImplCopyWith<$Res> {
  __$$getOrderCountEventImplCopyWithImpl(_$getOrderCountEventImpl _value,
      $Res Function(_$getOrderCountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getOrderCountEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getOrderCountEventImpl implements _getOrderCountEvent {
  const _$getOrderCountEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'OrderSuccessfulEvent.getOrderCountEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getOrderCountEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getOrderCountEventImplCopyWith<_$getOrderCountEventImpl> get copyWith =>
      __$$getOrderCountEventImplCopyWithImpl<_$getOrderCountEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function() celebrationEvent,
  }) {
    return getOrderCountEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function()? celebrationEvent,
  }) {
    return getOrderCountEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function()? celebrationEvent,
    required TResult orElse(),
  }) {
    if (getOrderCountEvent != null) {
      return getOrderCountEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_celebrationEvent value) celebrationEvent,
  }) {
    return getOrderCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_celebrationEvent value)? celebrationEvent,
  }) {
    return getOrderCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_celebrationEvent value)? celebrationEvent,
    required TResult orElse(),
  }) {
    if (getOrderCountEvent != null) {
      return getOrderCountEvent(this);
    }
    return orElse();
  }
}

abstract class _getOrderCountEvent implements OrderSuccessfulEvent {
  const factory _getOrderCountEvent({required final BuildContext context}) =
      _$getOrderCountEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getOrderCountEventImplCopyWith<_$getOrderCountEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$celebrationEventImplCopyWith<$Res> {
  factory _$$celebrationEventImplCopyWith(_$celebrationEventImpl value,
          $Res Function(_$celebrationEventImpl) then) =
      __$$celebrationEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$celebrationEventImplCopyWithImpl<$Res>
    extends _$OrderSuccessfulEventCopyWithImpl<$Res, _$celebrationEventImpl>
    implements _$$celebrationEventImplCopyWith<$Res> {
  __$$celebrationEventImplCopyWithImpl(_$celebrationEventImpl _value,
      $Res Function(_$celebrationEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$celebrationEventImpl implements _celebrationEvent {
  const _$celebrationEventImpl();

  @override
  String toString() {
    return 'OrderSuccessfulEvent.celebrationEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$celebrationEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
    required TResult Function() celebrationEvent,
  }) {
    return celebrationEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
    TResult? Function()? celebrationEvent,
  }) {
    return celebrationEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    TResult Function()? celebrationEvent,
    required TResult orElse(),
  }) {
    if (celebrationEvent != null) {
      return celebrationEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
    required TResult Function(_celebrationEvent value) celebrationEvent,
  }) {
    return celebrationEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult? Function(_celebrationEvent value)? celebrationEvent,
  }) {
    return celebrationEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    TResult Function(_celebrationEvent value)? celebrationEvent,
    required TResult orElse(),
  }) {
    if (celebrationEvent != null) {
      return celebrationEvent(this);
    }
    return orElse();
  }
}

abstract class _celebrationEvent implements OrderSuccessfulEvent {
  const factory _celebrationEvent() = _$celebrationEventImpl;
}

/// @nodoc
mixin _$OrderSuccessfulState {
  double get totalCredit => throw _privateConstructorUsedError;
  double get thisMonthExpense => throw _privateConstructorUsedError;
  double get lastMonthExpense => throw _privateConstructorUsedError;
  int get orderThisMonth => throw _privateConstructorUsedError;
  double get balance => throw _privateConstructorUsedError;
  double get expensePercentage => throw _privateConstructorUsedError;
  bool get duringCelebration => throw _privateConstructorUsedError;
  bool get isSubUserCanSeeWallet => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OrderSuccessfulStateCopyWith<OrderSuccessfulState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderSuccessfulStateCopyWith<$Res> {
  factory $OrderSuccessfulStateCopyWith(OrderSuccessfulState value,
          $Res Function(OrderSuccessfulState) then) =
      _$OrderSuccessfulStateCopyWithImpl<$Res, OrderSuccessfulState>;
  @useResult
  $Res call(
      {double totalCredit,
      double thisMonthExpense,
      double lastMonthExpense,
      int orderThisMonth,
      double balance,
      double expensePercentage,
      bool duringCelebration,
      bool isSubUserCanSeeWallet});
}

/// @nodoc
class _$OrderSuccessfulStateCopyWithImpl<$Res,
        $Val extends OrderSuccessfulState>
    implements $OrderSuccessfulStateCopyWith<$Res> {
  _$OrderSuccessfulStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalCredit = null,
    Object? thisMonthExpense = null,
    Object? lastMonthExpense = null,
    Object? orderThisMonth = null,
    Object? balance = null,
    Object? expensePercentage = null,
    Object? duringCelebration = null,
    Object? isSubUserCanSeeWallet = null,
  }) {
    return _then(_value.copyWith(
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      thisMonthExpense: null == thisMonthExpense
          ? _value.thisMonthExpense
          : thisMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      lastMonthExpense: null == lastMonthExpense
          ? _value.lastMonthExpense
          : lastMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      orderThisMonth: null == orderThisMonth
          ? _value.orderThisMonth
          : orderThisMonth // ignore: cast_nullable_to_non_nullable
              as int,
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as double,
      expensePercentage: null == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCanSeeWallet: null == isSubUserCanSeeWallet
          ? _value.isSubUserCanSeeWallet
          : isSubUserCanSeeWallet // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$OrderSuccessfulStateImplCopyWith<$Res>
    implements $OrderSuccessfulStateCopyWith<$Res> {
  factory _$$OrderSuccessfulStateImplCopyWith(_$OrderSuccessfulStateImpl value,
          $Res Function(_$OrderSuccessfulStateImpl) then) =
      __$$OrderSuccessfulStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {double totalCredit,
      double thisMonthExpense,
      double lastMonthExpense,
      int orderThisMonth,
      double balance,
      double expensePercentage,
      bool duringCelebration,
      bool isSubUserCanSeeWallet});
}

/// @nodoc
class __$$OrderSuccessfulStateImplCopyWithImpl<$Res>
    extends _$OrderSuccessfulStateCopyWithImpl<$Res, _$OrderSuccessfulStateImpl>
    implements _$$OrderSuccessfulStateImplCopyWith<$Res> {
  __$$OrderSuccessfulStateImplCopyWithImpl(_$OrderSuccessfulStateImpl _value,
      $Res Function(_$OrderSuccessfulStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalCredit = null,
    Object? thisMonthExpense = null,
    Object? lastMonthExpense = null,
    Object? orderThisMonth = null,
    Object? balance = null,
    Object? expensePercentage = null,
    Object? duringCelebration = null,
    Object? isSubUserCanSeeWallet = null,
  }) {
    return _then(_$OrderSuccessfulStateImpl(
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      thisMonthExpense: null == thisMonthExpense
          ? _value.thisMonthExpense
          : thisMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      lastMonthExpense: null == lastMonthExpense
          ? _value.lastMonthExpense
          : lastMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      orderThisMonth: null == orderThisMonth
          ? _value.orderThisMonth
          : orderThisMonth // ignore: cast_nullable_to_non_nullable
              as int,
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as double,
      expensePercentage: null == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCanSeeWallet: null == isSubUserCanSeeWallet
          ? _value.isSubUserCanSeeWallet
          : isSubUserCanSeeWallet // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$OrderSuccessfulStateImpl implements _OrderSuccessfulState {
  const _$OrderSuccessfulStateImpl(
      {required this.totalCredit,
      required this.thisMonthExpense,
      required this.lastMonthExpense,
      required this.orderThisMonth,
      required this.balance,
      required this.expensePercentage,
      required this.duringCelebration,
      required this.isSubUserCanSeeWallet});

  @override
  final double totalCredit;
  @override
  final double thisMonthExpense;
  @override
  final double lastMonthExpense;
  @override
  final int orderThisMonth;
  @override
  final double balance;
  @override
  final double expensePercentage;
  @override
  final bool duringCelebration;
  @override
  final bool isSubUserCanSeeWallet;

  @override
  String toString() {
    return 'OrderSuccessfulState(totalCredit: $totalCredit, thisMonthExpense: $thisMonthExpense, lastMonthExpense: $lastMonthExpense, orderThisMonth: $orderThisMonth, balance: $balance, expensePercentage: $expensePercentage, duringCelebration: $duringCelebration, isSubUserCanSeeWallet: $isSubUserCanSeeWallet)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OrderSuccessfulStateImpl &&
            (identical(other.totalCredit, totalCredit) ||
                other.totalCredit == totalCredit) &&
            (identical(other.thisMonthExpense, thisMonthExpense) ||
                other.thisMonthExpense == thisMonthExpense) &&
            (identical(other.lastMonthExpense, lastMonthExpense) ||
                other.lastMonthExpense == lastMonthExpense) &&
            (identical(other.orderThisMonth, orderThisMonth) ||
                other.orderThisMonth == orderThisMonth) &&
            (identical(other.balance, balance) || other.balance == balance) &&
            (identical(other.expensePercentage, expensePercentage) ||
                other.expensePercentage == expensePercentage) &&
            (identical(other.duringCelebration, duringCelebration) ||
                other.duringCelebration == duringCelebration) &&
            (identical(other.isSubUserCanSeeWallet, isSubUserCanSeeWallet) ||
                other.isSubUserCanSeeWallet == isSubUserCanSeeWallet));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      totalCredit,
      thisMonthExpense,
      lastMonthExpense,
      orderThisMonth,
      balance,
      expensePercentage,
      duringCelebration,
      isSubUserCanSeeWallet);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OrderSuccessfulStateImplCopyWith<_$OrderSuccessfulStateImpl>
      get copyWith =>
          __$$OrderSuccessfulStateImplCopyWithImpl<_$OrderSuccessfulStateImpl>(
              this, _$identity);
}

abstract class _OrderSuccessfulState implements OrderSuccessfulState {
  const factory _OrderSuccessfulState(
      {required final double totalCredit,
      required final double thisMonthExpense,
      required final double lastMonthExpense,
      required final int orderThisMonth,
      required final double balance,
      required final double expensePercentage,
      required final bool duringCelebration,
      required final bool isSubUserCanSeeWallet}) = _$OrderSuccessfulStateImpl;

  @override
  double get totalCredit;
  @override
  double get thisMonthExpense;
  @override
  double get lastMonthExpense;
  @override
  int get orderThisMonth;
  @override
  double get balance;
  @override
  double get expensePercentage;
  @override
  bool get duringCelebration;
  @override
  bool get isSubUserCanSeeWallet;
  @override
  @JsonKey(ignore: true)
  _$$OrderSuccessfulStateImplCopyWith<_$OrderSuccessfulStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
