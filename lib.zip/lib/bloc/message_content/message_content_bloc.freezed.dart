// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'message_content_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MessageContentEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(MessageData messageData, bool isReadMore)
        getMessageDataEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
    required TResult Function(String messageId, BuildContext context)
        MessageUpdateEvent,
    required TResult Function() ImagePreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult? Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult? Function()? ImagePreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult Function()? ImagePreviewEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageDataEvent value) getMessageDataEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
    required TResult Function(_MessageUpdateEvent value) MessageUpdateEvent,
    required TResult Function(_ImagePreviewEvent value) ImagePreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult? Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult? Function(_ImagePreviewEvent value)? ImagePreviewEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult Function(_ImagePreviewEvent value)? ImagePreviewEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageContentEventCopyWith<$Res> {
  factory $MessageContentEventCopyWith(
          MessageContentEvent value, $Res Function(MessageContentEvent) then) =
      _$MessageContentEventCopyWithImpl<$Res, MessageContentEvent>;
}

/// @nodoc
class _$MessageContentEventCopyWithImpl<$Res, $Val extends MessageContentEvent>
    implements $MessageContentEventCopyWith<$Res> {
  _$MessageContentEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetMessageDataEventImplCopyWith<$Res> {
  factory _$$GetMessageDataEventImplCopyWith(_$GetMessageDataEventImpl value,
          $Res Function(_$GetMessageDataEventImpl) then) =
      __$$GetMessageDataEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({MessageData messageData, bool isReadMore});

  $MessageDataCopyWith<$Res> get messageData;
}

/// @nodoc
class __$$GetMessageDataEventImplCopyWithImpl<$Res>
    extends _$MessageContentEventCopyWithImpl<$Res, _$GetMessageDataEventImpl>
    implements _$$GetMessageDataEventImplCopyWith<$Res> {
  __$$GetMessageDataEventImplCopyWithImpl(_$GetMessageDataEventImpl _value,
      $Res Function(_$GetMessageDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageData = null,
    Object? isReadMore = null,
  }) {
    return _then(_$GetMessageDataEventImpl(
      messageData: null == messageData
          ? _value.messageData
          : messageData // ignore: cast_nullable_to_non_nullable
              as MessageData,
      isReadMore: null == isReadMore
          ? _value.isReadMore
          : isReadMore // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $MessageDataCopyWith<$Res> get messageData {
    return $MessageDataCopyWith<$Res>(_value.messageData, (value) {
      return _then(_value.copyWith(messageData: value));
    });
  }
}

/// @nodoc

class _$GetMessageDataEventImpl implements _GetMessageDataEvent {
  const _$GetMessageDataEventImpl(
      {required this.messageData, required this.isReadMore});

  @override
  final MessageData messageData;
  @override
  final bool isReadMore;

  @override
  String toString() {
    return 'MessageContentEvent.getMessageDataEvent(messageData: $messageData, isReadMore: $isReadMore)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetMessageDataEventImpl &&
            (identical(other.messageData, messageData) ||
                other.messageData == messageData) &&
            (identical(other.isReadMore, isReadMore) ||
                other.isReadMore == isReadMore));
  }

  @override
  int get hashCode => Object.hash(runtimeType, messageData, isReadMore);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetMessageDataEventImplCopyWith<_$GetMessageDataEventImpl> get copyWith =>
      __$$GetMessageDataEventImplCopyWithImpl<_$GetMessageDataEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(MessageData messageData, bool isReadMore)
        getMessageDataEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
    required TResult Function(String messageId, BuildContext context)
        MessageUpdateEvent,
    required TResult Function() ImagePreviewEvent,
  }) {
    return getMessageDataEvent(messageData, isReadMore);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult? Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult? Function()? ImagePreviewEvent,
  }) {
    return getMessageDataEvent?.call(messageData, isReadMore);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult Function()? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (getMessageDataEvent != null) {
      return getMessageDataEvent(messageData, isReadMore);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageDataEvent value) getMessageDataEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
    required TResult Function(_MessageUpdateEvent value) MessageUpdateEvent,
    required TResult Function(_ImagePreviewEvent value) ImagePreviewEvent,
  }) {
    return getMessageDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult? Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult? Function(_ImagePreviewEvent value)? ImagePreviewEvent,
  }) {
    return getMessageDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult Function(_ImagePreviewEvent value)? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (getMessageDataEvent != null) {
      return getMessageDataEvent(this);
    }
    return orElse();
  }
}

abstract class _GetMessageDataEvent implements MessageContentEvent {
  const factory _GetMessageDataEvent(
      {required final MessageData messageData,
      required final bool isReadMore}) = _$GetMessageDataEventImpl;

  MessageData get messageData;
  bool get isReadMore;
  @JsonKey(ignore: true)
  _$$GetMessageDataEventImplCopyWith<_$GetMessageDataEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$MessageDeleteEventImplCopyWith<$Res> {
  factory _$$MessageDeleteEventImplCopyWith(_$MessageDeleteEventImpl value,
          $Res Function(_$MessageDeleteEventImpl) then) =
      __$$MessageDeleteEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String messageId, BuildContext context, BuildContext dialogContext});
}

/// @nodoc
class __$$MessageDeleteEventImplCopyWithImpl<$Res>
    extends _$MessageContentEventCopyWithImpl<$Res, _$MessageDeleteEventImpl>
    implements _$$MessageDeleteEventImplCopyWith<$Res> {
  __$$MessageDeleteEventImplCopyWithImpl(_$MessageDeleteEventImpl _value,
      $Res Function(_$MessageDeleteEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageId = null,
    Object? context = null,
    Object? dialogContext = null,
  }) {
    return _then(_$MessageDeleteEventImpl(
      messageId: null == messageId
          ? _value.messageId
          : messageId // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      dialogContext: null == dialogContext
          ? _value.dialogContext
          : dialogContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$MessageDeleteEventImpl implements _MessageDeleteEvent {
  const _$MessageDeleteEventImpl(
      {required this.messageId,
      required this.context,
      required this.dialogContext});

  @override
  final String messageId;
  @override
  final BuildContext context;
  @override
  final BuildContext dialogContext;

  @override
  String toString() {
    return 'MessageContentEvent.MessageDeleteEvent(messageId: $messageId, context: $context, dialogContext: $dialogContext)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MessageDeleteEventImpl &&
            (identical(other.messageId, messageId) ||
                other.messageId == messageId) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.dialogContext, dialogContext) ||
                other.dialogContext == dialogContext));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, messageId, context, dialogContext);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MessageDeleteEventImplCopyWith<_$MessageDeleteEventImpl> get copyWith =>
      __$$MessageDeleteEventImplCopyWithImpl<_$MessageDeleteEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(MessageData messageData, bool isReadMore)
        getMessageDataEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
    required TResult Function(String messageId, BuildContext context)
        MessageUpdateEvent,
    required TResult Function() ImagePreviewEvent,
  }) {
    return MessageDeleteEvent(messageId, context, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult? Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult? Function()? ImagePreviewEvent,
  }) {
    return MessageDeleteEvent?.call(messageId, context, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult Function()? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (MessageDeleteEvent != null) {
      return MessageDeleteEvent(messageId, context, dialogContext);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageDataEvent value) getMessageDataEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
    required TResult Function(_MessageUpdateEvent value) MessageUpdateEvent,
    required TResult Function(_ImagePreviewEvent value) ImagePreviewEvent,
  }) {
    return MessageDeleteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult? Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult? Function(_ImagePreviewEvent value)? ImagePreviewEvent,
  }) {
    return MessageDeleteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult Function(_ImagePreviewEvent value)? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (MessageDeleteEvent != null) {
      return MessageDeleteEvent(this);
    }
    return orElse();
  }
}

abstract class _MessageDeleteEvent implements MessageContentEvent {
  const factory _MessageDeleteEvent(
      {required final String messageId,
      required final BuildContext context,
      required final BuildContext dialogContext}) = _$MessageDeleteEventImpl;

  String get messageId;
  BuildContext get context;
  BuildContext get dialogContext;
  @JsonKey(ignore: true)
  _$$MessageDeleteEventImplCopyWith<_$MessageDeleteEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$MessageUpdateEventImplCopyWith<$Res> {
  factory _$$MessageUpdateEventImplCopyWith(_$MessageUpdateEventImpl value,
          $Res Function(_$MessageUpdateEventImpl) then) =
      __$$MessageUpdateEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String messageId, BuildContext context});
}

/// @nodoc
class __$$MessageUpdateEventImplCopyWithImpl<$Res>
    extends _$MessageContentEventCopyWithImpl<$Res, _$MessageUpdateEventImpl>
    implements _$$MessageUpdateEventImplCopyWith<$Res> {
  __$$MessageUpdateEventImplCopyWithImpl(_$MessageUpdateEventImpl _value,
      $Res Function(_$MessageUpdateEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageId = null,
    Object? context = null,
  }) {
    return _then(_$MessageUpdateEventImpl(
      messageId: null == messageId
          ? _value.messageId
          : messageId // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$MessageUpdateEventImpl implements _MessageUpdateEvent {
  const _$MessageUpdateEventImpl(
      {required this.messageId, required this.context});

  @override
  final String messageId;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MessageContentEvent.MessageUpdateEvent(messageId: $messageId, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MessageUpdateEventImpl &&
            (identical(other.messageId, messageId) ||
                other.messageId == messageId) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, messageId, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MessageUpdateEventImplCopyWith<_$MessageUpdateEventImpl> get copyWith =>
      __$$MessageUpdateEventImplCopyWithImpl<_$MessageUpdateEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(MessageData messageData, bool isReadMore)
        getMessageDataEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
    required TResult Function(String messageId, BuildContext context)
        MessageUpdateEvent,
    required TResult Function() ImagePreviewEvent,
  }) {
    return MessageUpdateEvent(messageId, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult? Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult? Function()? ImagePreviewEvent,
  }) {
    return MessageUpdateEvent?.call(messageId, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult Function()? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (MessageUpdateEvent != null) {
      return MessageUpdateEvent(messageId, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageDataEvent value) getMessageDataEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
    required TResult Function(_MessageUpdateEvent value) MessageUpdateEvent,
    required TResult Function(_ImagePreviewEvent value) ImagePreviewEvent,
  }) {
    return MessageUpdateEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult? Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult? Function(_ImagePreviewEvent value)? ImagePreviewEvent,
  }) {
    return MessageUpdateEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult Function(_ImagePreviewEvent value)? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (MessageUpdateEvent != null) {
      return MessageUpdateEvent(this);
    }
    return orElse();
  }
}

abstract class _MessageUpdateEvent implements MessageContentEvent {
  const factory _MessageUpdateEvent(
      {required final String messageId,
      required final BuildContext context}) = _$MessageUpdateEventImpl;

  String get messageId;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$MessageUpdateEventImplCopyWith<_$MessageUpdateEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ImagePreviewEventImplCopyWith<$Res> {
  factory _$$ImagePreviewEventImplCopyWith(_$ImagePreviewEventImpl value,
          $Res Function(_$ImagePreviewEventImpl) then) =
      __$$ImagePreviewEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ImagePreviewEventImplCopyWithImpl<$Res>
    extends _$MessageContentEventCopyWithImpl<$Res, _$ImagePreviewEventImpl>
    implements _$$ImagePreviewEventImplCopyWith<$Res> {
  __$$ImagePreviewEventImplCopyWithImpl(_$ImagePreviewEventImpl _value,
      $Res Function(_$ImagePreviewEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ImagePreviewEventImpl implements _ImagePreviewEvent {
  const _$ImagePreviewEventImpl();

  @override
  String toString() {
    return 'MessageContentEvent.ImagePreviewEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ImagePreviewEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(MessageData messageData, bool isReadMore)
        getMessageDataEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
    required TResult Function(String messageId, BuildContext context)
        MessageUpdateEvent,
    required TResult Function() ImagePreviewEvent,
  }) {
    return ImagePreviewEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult? Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult? Function()? ImagePreviewEvent,
  }) {
    return ImagePreviewEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(MessageData messageData, bool isReadMore)?
        getMessageDataEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    TResult Function(String messageId, BuildContext context)?
        MessageUpdateEvent,
    TResult Function()? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (ImagePreviewEvent != null) {
      return ImagePreviewEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageDataEvent value) getMessageDataEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
    required TResult Function(_MessageUpdateEvent value) MessageUpdateEvent,
    required TResult Function(_ImagePreviewEvent value) ImagePreviewEvent,
  }) {
    return ImagePreviewEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult? Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult? Function(_ImagePreviewEvent value)? ImagePreviewEvent,
  }) {
    return ImagePreviewEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageDataEvent value)? getMessageDataEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    TResult Function(_MessageUpdateEvent value)? MessageUpdateEvent,
    TResult Function(_ImagePreviewEvent value)? ImagePreviewEvent,
    required TResult orElse(),
  }) {
    if (ImagePreviewEvent != null) {
      return ImagePreviewEvent(this);
    }
    return orElse();
  }
}

abstract class _ImagePreviewEvent implements MessageContentEvent {
  const factory _ImagePreviewEvent() = _$ImagePreviewEventImpl;
}

/// @nodoc
mixin _$MessageContentState {
  MessageData get message => throw _privateConstructorUsedError;
  bool get isReadMore => throw _privateConstructorUsedError;
  bool get isPreview => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MessageContentStateCopyWith<MessageContentState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageContentStateCopyWith<$Res> {
  factory $MessageContentStateCopyWith(
          MessageContentState value, $Res Function(MessageContentState) then) =
      _$MessageContentStateCopyWithImpl<$Res, MessageContentState>;
  @useResult
  $Res call(
      {MessageData message, bool isReadMore, bool isPreview, String language});

  $MessageDataCopyWith<$Res> get message;
}

/// @nodoc
class _$MessageContentStateCopyWithImpl<$Res, $Val extends MessageContentState>
    implements $MessageContentStateCopyWith<$Res> {
  _$MessageContentStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? message = null,
    Object? isReadMore = null,
    Object? isPreview = null,
    Object? language = null,
  }) {
    return _then(_value.copyWith(
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as MessageData,
      isReadMore: null == isReadMore
          ? _value.isReadMore
          : isReadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isPreview: null == isPreview
          ? _value.isPreview
          : isPreview // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MessageDataCopyWith<$Res> get message {
    return $MessageDataCopyWith<$Res>(_value.message, (value) {
      return _then(_value.copyWith(message: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$MessageContentStateImplCopyWith<$Res>
    implements $MessageContentStateCopyWith<$Res> {
  factory _$$MessageContentStateImplCopyWith(_$MessageContentStateImpl value,
          $Res Function(_$MessageContentStateImpl) then) =
      __$$MessageContentStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {MessageData message, bool isReadMore, bool isPreview, String language});

  @override
  $MessageDataCopyWith<$Res> get message;
}

/// @nodoc
class __$$MessageContentStateImplCopyWithImpl<$Res>
    extends _$MessageContentStateCopyWithImpl<$Res, _$MessageContentStateImpl>
    implements _$$MessageContentStateImplCopyWith<$Res> {
  __$$MessageContentStateImplCopyWithImpl(_$MessageContentStateImpl _value,
      $Res Function(_$MessageContentStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? message = null,
    Object? isReadMore = null,
    Object? isPreview = null,
    Object? language = null,
  }) {
    return _then(_$MessageContentStateImpl(
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as MessageData,
      isReadMore: null == isReadMore
          ? _value.isReadMore
          : isReadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isPreview: null == isPreview
          ? _value.isPreview
          : isPreview // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$MessageContentStateImpl implements _MessageContentState {
  const _$MessageContentStateImpl(
      {required this.message,
      required this.isReadMore,
      required this.isPreview,
      required this.language});

  @override
  final MessageData message;
  @override
  final bool isReadMore;
  @override
  final bool isPreview;
  @override
  final String language;

  @override
  String toString() {
    return 'MessageContentState(message: $message, isReadMore: $isReadMore, isPreview: $isPreview, language: $language)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MessageContentStateImpl &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.isReadMore, isReadMore) ||
                other.isReadMore == isReadMore) &&
            (identical(other.isPreview, isPreview) ||
                other.isPreview == isPreview) &&
            (identical(other.language, language) ||
                other.language == language));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, message, isReadMore, isPreview, language);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MessageContentStateImplCopyWith<_$MessageContentStateImpl> get copyWith =>
      __$$MessageContentStateImplCopyWithImpl<_$MessageContentStateImpl>(
          this, _$identity);
}

abstract class _MessageContentState implements MessageContentState {
  const factory _MessageContentState(
      {required final MessageData message,
      required final bool isReadMore,
      required final bool isPreview,
      required final String language}) = _$MessageContentStateImpl;

  @override
  MessageData get message;
  @override
  bool get isReadMore;
  @override
  bool get isPreview;
  @override
  String get language;
  @override
  @JsonKey(ignore: true)
  _$$MessageContentStateImplCopyWith<_$MessageContentStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
