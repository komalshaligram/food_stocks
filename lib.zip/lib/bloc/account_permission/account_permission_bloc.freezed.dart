// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'account_permission_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AccountPermissionEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateAccountPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateAccountPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateAccountPermissionEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateAccountPermissionEvent value)
        updateAccountPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $AccountPermissionEventCopyWith<AccountPermissionEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AccountPermissionEventCopyWith<$Res> {
  factory $AccountPermissionEventCopyWith(AccountPermissionEvent value,
          $Res Function(AccountPermissionEvent) then) =
      _$AccountPermissionEventCopyWithImpl<$Res, AccountPermissionEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$AccountPermissionEventCopyWithImpl<$Res,
        $Val extends AccountPermissionEvent>
    implements $AccountPermissionEventCopyWith<$Res> {
  _$AccountPermissionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$switchButtonEventImplCopyWith<$Res>
    implements $AccountPermissionEventCopyWith<$Res> {
  factory _$$switchButtonEventImplCopyWith(_$switchButtonEventImpl value,
          $Res Function(_$switchButtonEventImpl) then) =
      __$$switchButtonEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, int index});
}

/// @nodoc
class __$$switchButtonEventImplCopyWithImpl<$Res>
    extends _$AccountPermissionEventCopyWithImpl<$Res, _$switchButtonEventImpl>
    implements _$$switchButtonEventImplCopyWith<$Res> {
  __$$switchButtonEventImplCopyWithImpl(_$switchButtonEventImpl _value,
      $Res Function(_$switchButtonEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? index = null,
  }) {
    return _then(_$switchButtonEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$switchButtonEventImpl implements _switchButtonEvent {
  const _$switchButtonEventImpl({required this.context, required this.index});

  @override
  final BuildContext context;
  @override
  final int index;

  @override
  String toString() {
    return 'AccountPermissionEvent.switchButtonEvent(context: $context, index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$switchButtonEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$switchButtonEventImplCopyWith<_$switchButtonEventImpl> get copyWith =>
      __$$switchButtonEventImplCopyWithImpl<_$switchButtonEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateAccountPermissionEvent,
  }) {
    return switchButtonEvent(context, index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateAccountPermissionEvent,
  }) {
    return switchButtonEvent?.call(context, index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateAccountPermissionEvent,
    required TResult orElse(),
  }) {
    if (switchButtonEvent != null) {
      return switchButtonEvent(context, index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateAccountPermissionEvent value)
        updateAccountPermissionEvent,
  }) {
    return switchButtonEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
  }) {
    return switchButtonEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
    required TResult orElse(),
  }) {
    if (switchButtonEvent != null) {
      return switchButtonEvent(this);
    }
    return orElse();
  }
}

abstract class _switchButtonEvent implements AccountPermissionEvent {
  const factory _switchButtonEvent(
      {required final BuildContext context,
      required final int index}) = _$switchButtonEventImpl;

  @override
  BuildContext get context;
  int get index;
  @override
  @JsonKey(ignore: true)
  _$$switchButtonEventImplCopyWith<_$switchButtonEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res>
    implements $AccountPermissionEventCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, String subUserId});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$AccountPermissionEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? subUserId = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl(
      {required this.context, required this.subUserId});

  @override
  final BuildContext context;
  @override
  final String subUserId;

  @override
  String toString() {
    return 'AccountPermissionEvent.getPermissionList(context: $context, subUserId: $subUserId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, subUserId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateAccountPermissionEvent,
  }) {
    return getPermissionList(context, subUserId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateAccountPermissionEvent,
  }) {
    return getPermissionList?.call(context, subUserId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateAccountPermissionEvent,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context, subUserId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateAccountPermissionEvent value)
        updateAccountPermissionEvent,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements AccountPermissionEvent {
  const factory _getPermissionList(
      {required final BuildContext context,
      required final String subUserId}) = _$getPermissionListImpl;

  @override
  BuildContext get context;
  String get subUserId;
  @override
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$updateAccountPermissionEventImplCopyWith<$Res>
    implements $AccountPermissionEventCopyWith<$Res> {
  factory _$$updateAccountPermissionEventImplCopyWith(
          _$updateAccountPermissionEventImpl value,
          $Res Function(_$updateAccountPermissionEventImpl) then) =
      __$$updateAccountPermissionEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$updateAccountPermissionEventImplCopyWithImpl<$Res>
    extends _$AccountPermissionEventCopyWithImpl<$Res,
        _$updateAccountPermissionEventImpl>
    implements _$$updateAccountPermissionEventImplCopyWith<$Res> {
  __$$updateAccountPermissionEventImplCopyWithImpl(
      _$updateAccountPermissionEventImpl _value,
      $Res Function(_$updateAccountPermissionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$updateAccountPermissionEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$updateAccountPermissionEventImpl
    implements _updateAccountPermissionEvent {
  const _$updateAccountPermissionEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'AccountPermissionEvent.updateAccountPermissionEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateAccountPermissionEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateAccountPermissionEventImplCopyWith<
          _$updateAccountPermissionEventImpl>
      get copyWith => __$$updateAccountPermissionEventImplCopyWithImpl<
          _$updateAccountPermissionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateAccountPermissionEvent,
  }) {
    return updateAccountPermissionEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateAccountPermissionEvent,
  }) {
    return updateAccountPermissionEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateAccountPermissionEvent,
    required TResult orElse(),
  }) {
    if (updateAccountPermissionEvent != null) {
      return updateAccountPermissionEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateAccountPermissionEvent value)
        updateAccountPermissionEvent,
  }) {
    return updateAccountPermissionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
  }) {
    return updateAccountPermissionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateAccountPermissionEvent value)?
        updateAccountPermissionEvent,
    required TResult orElse(),
  }) {
    if (updateAccountPermissionEvent != null) {
      return updateAccountPermissionEvent(this);
    }
    return orElse();
  }
}

abstract class _updateAccountPermissionEvent implements AccountPermissionEvent {
  const factory _updateAccountPermissionEvent(
          {required final BuildContext context}) =
      _$updateAccountPermissionEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$updateAccountPermissionEventImplCopyWith<
          _$updateAccountPermissionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$AccountPermissionState {
  bool get isShimmering => throw _privateConstructorUsedError;
  List<permissionModel> get permissionList =>
      throw _privateConstructorUsedError;
  bool get isRefresh => throw _privateConstructorUsedError;
  bool get isUpdateProcess => throw _privateConstructorUsedError;
  String get subUserId => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $AccountPermissionStateCopyWith<AccountPermissionState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AccountPermissionStateCopyWith<$Res> {
  factory $AccountPermissionStateCopyWith(AccountPermissionState value,
          $Res Function(AccountPermissionState) then) =
      _$AccountPermissionStateCopyWithImpl<$Res, AccountPermissionState>;
  @useResult
  $Res call(
      {bool isShimmering,
      List<permissionModel> permissionList,
      bool isRefresh,
      bool isUpdateProcess,
      String subUserId});
}

/// @nodoc
class _$AccountPermissionStateCopyWithImpl<$Res,
        $Val extends AccountPermissionState>
    implements $AccountPermissionStateCopyWith<$Res> {
  _$AccountPermissionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? permissionList = null,
    Object? isRefresh = null,
    Object? isUpdateProcess = null,
    Object? subUserId = null,
  }) {
    return _then(_value.copyWith(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      permissionList: null == permissionList
          ? _value.permissionList
          : permissionList // ignore: cast_nullable_to_non_nullable
              as List<permissionModel>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdateProcess: null == isUpdateProcess
          ? _value.isUpdateProcess
          : isUpdateProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AccountPermissionStateImplCopyWith<$Res>
    implements $AccountPermissionStateCopyWith<$Res> {
  factory _$$AccountPermissionStateImplCopyWith(
          _$AccountPermissionStateImpl value,
          $Res Function(_$AccountPermissionStateImpl) then) =
      __$$AccountPermissionStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isShimmering,
      List<permissionModel> permissionList,
      bool isRefresh,
      bool isUpdateProcess,
      String subUserId});
}

/// @nodoc
class __$$AccountPermissionStateImplCopyWithImpl<$Res>
    extends _$AccountPermissionStateCopyWithImpl<$Res,
        _$AccountPermissionStateImpl>
    implements _$$AccountPermissionStateImplCopyWith<$Res> {
  __$$AccountPermissionStateImplCopyWithImpl(
      _$AccountPermissionStateImpl _value,
      $Res Function(_$AccountPermissionStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? permissionList = null,
    Object? isRefresh = null,
    Object? isUpdateProcess = null,
    Object? subUserId = null,
  }) {
    return _then(_$AccountPermissionStateImpl(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      permissionList: null == permissionList
          ? _value._permissionList
          : permissionList // ignore: cast_nullable_to_non_nullable
              as List<permissionModel>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdateProcess: null == isUpdateProcess
          ? _value.isUpdateProcess
          : isUpdateProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AccountPermissionStateImpl implements _AccountPermissionState {
  const _$AccountPermissionStateImpl(
      {required this.isShimmering,
      required final List<permissionModel> permissionList,
      required this.isRefresh,
      required this.isUpdateProcess,
      required this.subUserId})
      : _permissionList = permissionList;

  @override
  final bool isShimmering;
  final List<permissionModel> _permissionList;
  @override
  List<permissionModel> get permissionList {
    if (_permissionList is EqualUnmodifiableListView) return _permissionList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_permissionList);
  }

  @override
  final bool isRefresh;
  @override
  final bool isUpdateProcess;
  @override
  final String subUserId;

  @override
  String toString() {
    return 'AccountPermissionState(isShimmering: $isShimmering, permissionList: $permissionList, isRefresh: $isRefresh, isUpdateProcess: $isUpdateProcess, subUserId: $subUserId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AccountPermissionStateImpl &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            const DeepCollectionEquality()
                .equals(other._permissionList, _permissionList) &&
            (identical(other.isRefresh, isRefresh) ||
                other.isRefresh == isRefresh) &&
            (identical(other.isUpdateProcess, isUpdateProcess) ||
                other.isUpdateProcess == isUpdateProcess) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isShimmering,
      const DeepCollectionEquality().hash(_permissionList),
      isRefresh,
      isUpdateProcess,
      subUserId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AccountPermissionStateImplCopyWith<_$AccountPermissionStateImpl>
      get copyWith => __$$AccountPermissionStateImplCopyWithImpl<
          _$AccountPermissionStateImpl>(this, _$identity);
}

abstract class _AccountPermissionState implements AccountPermissionState {
  const factory _AccountPermissionState(
      {required final bool isShimmering,
      required final List<permissionModel> permissionList,
      required final bool isRefresh,
      required final bool isUpdateProcess,
      required final String subUserId}) = _$AccountPermissionStateImpl;

  @override
  bool get isShimmering;
  @override
  List<permissionModel> get permissionList;
  @override
  bool get isRefresh;
  @override
  bool get isUpdateProcess;
  @override
  String get subUserId;
  @override
  @JsonKey(ignore: true)
  _$$AccountPermissionStateImplCopyWith<_$AccountPermissionStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
