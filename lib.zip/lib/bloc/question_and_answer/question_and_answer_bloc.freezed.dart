// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'question_and_answer_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$QuestionAndAnswerEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getQNAListEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getQNAListEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getQNAListEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetQNAListEvent value) getQNAListEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetQNAListEvent value)? getQNAListEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetQNAListEvent value)? getQNAListEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $QuestionAndAnswerEventCopyWith<QuestionAndAnswerEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $QuestionAndAnswerEventCopyWith<$Res> {
  factory $QuestionAndAnswerEventCopyWith(QuestionAndAnswerEvent value,
          $Res Function(QuestionAndAnswerEvent) then) =
      _$QuestionAndAnswerEventCopyWithImpl<$Res, QuestionAndAnswerEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$QuestionAndAnswerEventCopyWithImpl<$Res,
        $Val extends QuestionAndAnswerEvent>
    implements $QuestionAndAnswerEventCopyWith<$Res> {
  _$QuestionAndAnswerEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetQNAListEventImplCopyWith<$Res>
    implements $QuestionAndAnswerEventCopyWith<$Res> {
  factory _$$GetQNAListEventImplCopyWith(_$GetQNAListEventImpl value,
          $Res Function(_$GetQNAListEventImpl) then) =
      __$$GetQNAListEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetQNAListEventImplCopyWithImpl<$Res>
    extends _$QuestionAndAnswerEventCopyWithImpl<$Res, _$GetQNAListEventImpl>
    implements _$$GetQNAListEventImplCopyWith<$Res> {
  __$$GetQNAListEventImplCopyWithImpl(
      _$GetQNAListEventImpl _value, $Res Function(_$GetQNAListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetQNAListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetQNAListEventImpl implements _GetQNAListEvent {
  const _$GetQNAListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'QuestionAndAnswerEvent.getQNAListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetQNAListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetQNAListEventImplCopyWith<_$GetQNAListEventImpl> get copyWith =>
      __$$GetQNAListEventImplCopyWithImpl<_$GetQNAListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getQNAListEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return getQNAListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getQNAListEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return getQNAListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getQNAListEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getQNAListEvent != null) {
      return getQNAListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetQNAListEvent value) getQNAListEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return getQNAListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetQNAListEvent value)? getQNAListEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return getQNAListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetQNAListEvent value)? getQNAListEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getQNAListEvent != null) {
      return getQNAListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetQNAListEvent implements QuestionAndAnswerEvent {
  const factory _GetQNAListEvent({required final BuildContext context}) =
      _$GetQNAListEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$GetQNAListEventImplCopyWith<_$GetQNAListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res>
    implements $QuestionAndAnswerEventCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$QuestionAndAnswerEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'QuestionAndAnswerEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getQNAListEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getQNAListEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getQNAListEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetQNAListEvent value) getQNAListEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetQNAListEvent value)? getQNAListEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetQNAListEvent value)? getQNAListEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements QuestionAndAnswerEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$QuestionAndAnswerState {
  List<Datum> get qnaList => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isBottomOfQNA => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $QuestionAndAnswerStateCopyWith<QuestionAndAnswerState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $QuestionAndAnswerStateCopyWith<$Res> {
  factory $QuestionAndAnswerStateCopyWith(QuestionAndAnswerState value,
          $Res Function(QuestionAndAnswerState) then) =
      _$QuestionAndAnswerStateCopyWithImpl<$Res, QuestionAndAnswerState>;
  @useResult
  $Res call(
      {List<Datum> qnaList,
      int pageNum,
      bool isBottomOfQNA,
      bool isLoadMore,
      bool isShimmering,
      RefreshController refreshController});
}

/// @nodoc
class _$QuestionAndAnswerStateCopyWithImpl<$Res,
        $Val extends QuestionAndAnswerState>
    implements $QuestionAndAnswerStateCopyWith<$Res> {
  _$QuestionAndAnswerStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? qnaList = null,
    Object? pageNum = null,
    Object? isBottomOfQNA = null,
    Object? isLoadMore = null,
    Object? isShimmering = null,
    Object? refreshController = null,
  }) {
    return _then(_value.copyWith(
      qnaList: null == qnaList
          ? _value.qnaList
          : qnaList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isBottomOfQNA: null == isBottomOfQNA
          ? _value.isBottomOfQNA
          : isBottomOfQNA // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$QuestionAndAnswerStateImplCopyWith<$Res>
    implements $QuestionAndAnswerStateCopyWith<$Res> {
  factory _$$QuestionAndAnswerStateImplCopyWith(
          _$QuestionAndAnswerStateImpl value,
          $Res Function(_$QuestionAndAnswerStateImpl) then) =
      __$$QuestionAndAnswerStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Datum> qnaList,
      int pageNum,
      bool isBottomOfQNA,
      bool isLoadMore,
      bool isShimmering,
      RefreshController refreshController});
}

/// @nodoc
class __$$QuestionAndAnswerStateImplCopyWithImpl<$Res>
    extends _$QuestionAndAnswerStateCopyWithImpl<$Res,
        _$QuestionAndAnswerStateImpl>
    implements _$$QuestionAndAnswerStateImplCopyWith<$Res> {
  __$$QuestionAndAnswerStateImplCopyWithImpl(
      _$QuestionAndAnswerStateImpl _value,
      $Res Function(_$QuestionAndAnswerStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? qnaList = null,
    Object? pageNum = null,
    Object? isBottomOfQNA = null,
    Object? isLoadMore = null,
    Object? isShimmering = null,
    Object? refreshController = null,
  }) {
    return _then(_$QuestionAndAnswerStateImpl(
      qnaList: null == qnaList
          ? _value._qnaList
          : qnaList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isBottomOfQNA: null == isBottomOfQNA
          ? _value.isBottomOfQNA
          : isBottomOfQNA // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
    ));
  }
}

/// @nodoc

class _$QuestionAndAnswerStateImpl implements _QuestionAndAnswerState {
  const _$QuestionAndAnswerStateImpl(
      {required final List<Datum> qnaList,
      required this.pageNum,
      required this.isBottomOfQNA,
      required this.isLoadMore,
      required this.isShimmering,
      required this.refreshController})
      : _qnaList = qnaList;

  final List<Datum> _qnaList;
  @override
  List<Datum> get qnaList {
    if (_qnaList is EqualUnmodifiableListView) return _qnaList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_qnaList);
  }

  @override
  final int pageNum;
  @override
  final bool isBottomOfQNA;
  @override
  final bool isLoadMore;
  @override
  final bool isShimmering;
  @override
  final RefreshController refreshController;

  @override
  String toString() {
    return 'QuestionAndAnswerState(qnaList: $qnaList, pageNum: $pageNum, isBottomOfQNA: $isBottomOfQNA, isLoadMore: $isLoadMore, isShimmering: $isShimmering, refreshController: $refreshController)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$QuestionAndAnswerStateImpl &&
            const DeepCollectionEquality().equals(other._qnaList, _qnaList) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isBottomOfQNA, isBottomOfQNA) ||
                other.isBottomOfQNA == isBottomOfQNA) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_qnaList),
      pageNum,
      isBottomOfQNA,
      isLoadMore,
      isShimmering,
      refreshController);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$QuestionAndAnswerStateImplCopyWith<_$QuestionAndAnswerStateImpl>
      get copyWith => __$$QuestionAndAnswerStateImplCopyWithImpl<
          _$QuestionAndAnswerStateImpl>(this, _$identity);
}

abstract class _QuestionAndAnswerState implements QuestionAndAnswerState {
  const factory _QuestionAndAnswerState(
          {required final List<Datum> qnaList,
          required final int pageNum,
          required final bool isBottomOfQNA,
          required final bool isLoadMore,
          required final bool isShimmering,
          required final RefreshController refreshController}) =
      _$QuestionAndAnswerStateImpl;

  @override
  List<Datum> get qnaList;
  @override
  int get pageNum;
  @override
  bool get isBottomOfQNA;
  @override
  bool get isLoadMore;
  @override
  bool get isShimmering;
  @override
  RefreshController get refreshController;
  @override
  @JsonKey(ignore: true)
  _$$QuestionAndAnswerStateImplCopyWith<_$QuestionAndAnswerStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
