// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'otp_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$OtpEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OtpEventCopyWith<$Res> {
  factory $OtpEventCopyWith(OtpEvent value, $Res Function(OtpEvent) then) =
      _$OtpEventCopyWithImpl<$Res, OtpEvent>;
}

/// @nodoc
class _$OtpEventCopyWithImpl<$Res, $Val extends OtpEvent>
    implements $OtpEventCopyWith<$Res> {
  _$OtpEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$SetOtpTimerEventImplCopyWith<$Res> {
  factory _$$SetOtpTimerEventImplCopyWith(_$SetOtpTimerEventImpl value,
          $Res Function(_$SetOtpTimerEventImpl) then) =
      __$$SetOtpTimerEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SetOtpTimerEventImplCopyWithImpl<$Res>
    extends _$OtpEventCopyWithImpl<$Res, _$SetOtpTimerEventImpl>
    implements _$$SetOtpTimerEventImplCopyWith<$Res> {
  __$$SetOtpTimerEventImplCopyWithImpl(_$SetOtpTimerEventImpl _value,
      $Res Function(_$SetOtpTimerEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SetOtpTimerEventImpl implements _SetOtpTimerEvent {
  const _$SetOtpTimerEventImpl();

  @override
  String toString() {
    return 'OtpEvent.setOtpTimer()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SetOtpTimerEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) {
    return setOtpTimer();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) {
    return setOtpTimer?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (setOtpTimer != null) {
      return setOtpTimer();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) {
    return setOtpTimer(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) {
    return setOtpTimer?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (setOtpTimer != null) {
      return setOtpTimer(this);
    }
    return orElse();
  }
}

abstract class _SetOtpTimerEvent implements OtpEvent {
  const factory _SetOtpTimerEvent() = _$SetOtpTimerEventImpl;
}

/// @nodoc
abstract class _$$ChangeOtpEventImplCopyWith<$Res> {
  factory _$$ChangeOtpEventImplCopyWith(_$ChangeOtpEventImpl value,
          $Res Function(_$ChangeOtpEventImpl) then) =
      __$$ChangeOtpEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String otp});
}

/// @nodoc
class __$$ChangeOtpEventImplCopyWithImpl<$Res>
    extends _$OtpEventCopyWithImpl<$Res, _$ChangeOtpEventImpl>
    implements _$$ChangeOtpEventImplCopyWith<$Res> {
  __$$ChangeOtpEventImplCopyWithImpl(
      _$ChangeOtpEventImpl _value, $Res Function(_$ChangeOtpEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? otp = null,
  }) {
    return _then(_$ChangeOtpEventImpl(
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeOtpEventImpl implements _ChangeOtpEvent {
  const _$ChangeOtpEventImpl({required this.otp});

  @override
  final String otp;

  @override
  String toString() {
    return 'OtpEvent.changeOtpEvent(otp: $otp)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeOtpEventImpl &&
            (identical(other.otp, otp) || other.otp == otp));
  }

  @override
  int get hashCode => Object.hash(runtimeType, otp);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeOtpEventImplCopyWith<_$ChangeOtpEventImpl> get copyWith =>
      __$$ChangeOtpEventImplCopyWithImpl<_$ChangeOtpEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) {
    return changeOtpEvent(otp);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) {
    return changeOtpEvent?.call(otp);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (changeOtpEvent != null) {
      return changeOtpEvent(otp);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) {
    return changeOtpEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) {
    return changeOtpEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (changeOtpEvent != null) {
      return changeOtpEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeOtpEvent implements OtpEvent {
  const factory _ChangeOtpEvent({required final String otp}) =
      _$ChangeOtpEventImpl;

  String get otp;
  @JsonKey(ignore: true)
  _$$ChangeOtpEventImplCopyWith<_$ChangeOtpEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateTimerEventImplCopyWith<$Res> {
  factory _$$UpdateTimerEventImplCopyWith(_$UpdateTimerEventImpl value,
          $Res Function(_$UpdateTimerEventImpl) then) =
      __$$UpdateTimerEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$UpdateTimerEventImplCopyWithImpl<$Res>
    extends _$OtpEventCopyWithImpl<$Res, _$UpdateTimerEventImpl>
    implements _$$UpdateTimerEventImplCopyWith<$Res> {
  __$$UpdateTimerEventImplCopyWithImpl(_$UpdateTimerEventImpl _value,
      $Res Function(_$UpdateTimerEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$UpdateTimerEventImpl implements _UpdateTimerEvent {
  const _$UpdateTimerEventImpl();

  @override
  String toString() {
    return 'OtpEvent.updateOtpTimer()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$UpdateTimerEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) {
    return updateOtpTimer();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) {
    return updateOtpTimer?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (updateOtpTimer != null) {
      return updateOtpTimer();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) {
    return updateOtpTimer(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) {
    return updateOtpTimer?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (updateOtpTimer != null) {
      return updateOtpTimer(this);
    }
    return orElse();
  }
}

abstract class _UpdateTimerEvent implements OtpEvent {
  const factory _UpdateTimerEvent() = _$UpdateTimerEventImpl;
}

/// @nodoc
abstract class _$$cancelTimerscriptionEventImplCopyWith<$Res> {
  factory _$$cancelTimerscriptionEventImplCopyWith(
          _$cancelTimerscriptionEventImpl value,
          $Res Function(_$cancelTimerscriptionEventImpl) then) =
      __$$cancelTimerscriptionEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$cancelTimerscriptionEventImplCopyWithImpl<$Res>
    extends _$OtpEventCopyWithImpl<$Res, _$cancelTimerscriptionEventImpl>
    implements _$$cancelTimerscriptionEventImplCopyWith<$Res> {
  __$$cancelTimerscriptionEventImplCopyWithImpl(
      _$cancelTimerscriptionEventImpl _value,
      $Res Function(_$cancelTimerscriptionEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$cancelTimerscriptionEventImpl implements _cancelTimerscriptionEvent {
  const _$cancelTimerscriptionEventImpl();

  @override
  String toString() {
    return 'OtpEvent.cancelOtpTimerSubscription()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$cancelTimerscriptionEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) {
    return cancelOtpTimerSubscription();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) {
    return cancelOtpTimerSubscription?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (cancelOtpTimerSubscription != null) {
      return cancelOtpTimerSubscription();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) {
    return cancelOtpTimerSubscription(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) {
    return cancelOtpTimerSubscription?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (cancelOtpTimerSubscription != null) {
      return cancelOtpTimerSubscription(this);
    }
    return orElse();
  }
}

abstract class _cancelTimerscriptionEvent implements OtpEvent {
  const factory _cancelTimerscriptionEvent() = _$cancelTimerscriptionEventImpl;
}

/// @nodoc
abstract class _$$otpApiEventImplCopyWith<$Res> {
  factory _$$otpApiEventImplCopyWith(
          _$otpApiEventImpl value, $Res Function(_$otpApiEventImpl) then) =
      __$$otpApiEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String contact, String otp, bool isRegister, BuildContext context});
}

/// @nodoc
class __$$otpApiEventImplCopyWithImpl<$Res>
    extends _$OtpEventCopyWithImpl<$Res, _$otpApiEventImpl>
    implements _$$otpApiEventImplCopyWith<$Res> {
  __$$otpApiEventImplCopyWithImpl(
      _$otpApiEventImpl _value, $Res Function(_$otpApiEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? contact = null,
    Object? otp = null,
    Object? isRegister = null,
    Object? context = null,
  }) {
    return _then(_$otpApiEventImpl(
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$otpApiEventImpl implements _otpApiEvent {
  const _$otpApiEventImpl(
      {required this.contact,
      required this.otp,
      required this.isRegister,
      required this.context});

  @override
  final String contact;
  @override
  final String otp;
  @override
  final bool isRegister;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'OtpEvent.otpApiEvent(contact: $contact, otp: $otp, isRegister: $isRegister, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$otpApiEventImpl &&
            (identical(other.contact, contact) || other.contact == contact) &&
            (identical(other.otp, otp) || other.otp == otp) &&
            (identical(other.isRegister, isRegister) ||
                other.isRegister == isRegister) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, contact, otp, isRegister, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$otpApiEventImplCopyWith<_$otpApiEventImpl> get copyWith =>
      __$$otpApiEventImplCopyWithImpl<_$otpApiEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) {
    return otpApiEvent(contact, otp, isRegister, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) {
    return otpApiEvent?.call(contact, otp, isRegister, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (otpApiEvent != null) {
      return otpApiEvent(contact, otp, isRegister, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) {
    return otpApiEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) {
    return otpApiEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (otpApiEvent != null) {
      return otpApiEvent(this);
    }
    return orElse();
  }
}

abstract class _otpApiEvent implements OtpEvent {
  const factory _otpApiEvent(
      {required final String contact,
      required final String otp,
      required final bool isRegister,
      required final BuildContext context}) = _$otpApiEventImpl;

  String get contact;
  String get otp;
  bool get isRegister;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$otpApiEventImplCopyWith<_$otpApiEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$registerApiEventImplCopyWith<$Res> {
  factory _$$registerApiEventImplCopyWith(_$registerApiEventImpl value,
          $Res Function(_$registerApiEventImpl) then) =
      __$$registerApiEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String contact, String otp, bool isRegister, BuildContext context});
}

/// @nodoc
class __$$registerApiEventImplCopyWithImpl<$Res>
    extends _$OtpEventCopyWithImpl<$Res, _$registerApiEventImpl>
    implements _$$registerApiEventImplCopyWith<$Res> {
  __$$registerApiEventImplCopyWithImpl(_$registerApiEventImpl _value,
      $Res Function(_$registerApiEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? contact = null,
    Object? otp = null,
    Object? isRegister = null,
    Object? context = null,
  }) {
    return _then(_$registerApiEventImpl(
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$registerApiEventImpl implements _registerApiEvent {
  const _$registerApiEventImpl(
      {required this.contact,
      required this.otp,
      required this.isRegister,
      required this.context});

  @override
  final String contact;
  @override
  final String otp;
  @override
  final bool isRegister;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'OtpEvent.registerApiEvent(contact: $contact, otp: $otp, isRegister: $isRegister, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$registerApiEventImpl &&
            (identical(other.contact, contact) || other.contact == contact) &&
            (identical(other.otp, otp) || other.otp == otp) &&
            (identical(other.isRegister, isRegister) ||
                other.isRegister == isRegister) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, contact, otp, isRegister, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$registerApiEventImplCopyWith<_$registerApiEventImpl> get copyWith =>
      __$$registerApiEventImplCopyWithImpl<_$registerApiEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) {
    return registerApiEvent(contact, otp, isRegister, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) {
    return registerApiEvent?.call(contact, otp, isRegister, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (registerApiEvent != null) {
      return registerApiEvent(contact, otp, isRegister, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) {
    return registerApiEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) {
    return registerApiEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (registerApiEvent != null) {
      return registerApiEvent(this);
    }
    return orElse();
  }
}

abstract class _registerApiEvent implements OtpEvent {
  const factory _registerApiEvent(
      {required final String contact,
      required final String otp,
      required final bool isRegister,
      required final BuildContext context}) = _$registerApiEventImpl;

  String get contact;
  String get otp;
  bool get isRegister;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$registerApiEventImplCopyWith<_$registerApiEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$logInApiDataEventImplCopyWith<$Res> {
  factory _$$logInApiDataEventImplCopyWith(_$logInApiDataEventImpl value,
          $Res Function(_$logInApiDataEventImpl) then) =
      __$$logInApiDataEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String contactNumber, BuildContext context, bool isRegister});
}

/// @nodoc
class __$$logInApiDataEventImplCopyWithImpl<$Res>
    extends _$OtpEventCopyWithImpl<$Res, _$logInApiDataEventImpl>
    implements _$$logInApiDataEventImplCopyWith<$Res> {
  __$$logInApiDataEventImplCopyWithImpl(_$logInApiDataEventImpl _value,
      $Res Function(_$logInApiDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? contactNumber = null,
    Object? context = null,
    Object? isRegister = null,
  }) {
    return _then(_$logInApiDataEventImpl(
      contactNumber: null == contactNumber
          ? _value.contactNumber
          : contactNumber // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$logInApiDataEventImpl implements _logInApiDataEvent {
  _$logInApiDataEventImpl(
      {required this.contactNumber,
      required this.context,
      required this.isRegister});

  @override
  final String contactNumber;
  @override
  final BuildContext context;
  @override
  final bool isRegister;

  @override
  String toString() {
    return 'OtpEvent.logInApiDataEvent(contactNumber: $contactNumber, context: $context, isRegister: $isRegister)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$logInApiDataEventImpl &&
            (identical(other.contactNumber, contactNumber) ||
                other.contactNumber == contactNumber) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isRegister, isRegister) ||
                other.isRegister == isRegister));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, contactNumber, context, isRegister);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$logInApiDataEventImplCopyWith<_$logInApiDataEventImpl> get copyWith =>
      __$$logInApiDataEventImplCopyWithImpl<_$logInApiDataEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() setOtpTimer,
    required TResult Function(String otp) changeOtpEvent,
    required TResult Function() updateOtpTimer,
    required TResult Function() cancelOtpTimerSubscription,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        otpApiEvent,
    required TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)
        registerApiEvent,
    required TResult Function(
            String contactNumber, BuildContext context, bool isRegister)
        logInApiDataEvent,
  }) {
    return logInApiDataEvent(contactNumber, context, isRegister);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? setOtpTimer,
    TResult? Function(String otp)? changeOtpEvent,
    TResult? Function()? updateOtpTimer,
    TResult? Function()? cancelOtpTimerSubscription,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult? Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult? Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
  }) {
    return logInApiDataEvent?.call(contactNumber, context, isRegister);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? setOtpTimer,
    TResult Function(String otp)? changeOtpEvent,
    TResult Function()? updateOtpTimer,
    TResult Function()? cancelOtpTimerSubscription,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        otpApiEvent,
    TResult Function(
            String contact, String otp, bool isRegister, BuildContext context)?
        registerApiEvent,
    TResult Function(
            String contactNumber, BuildContext context, bool isRegister)?
        logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (logInApiDataEvent != null) {
      return logInApiDataEvent(contactNumber, context, isRegister);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SetOtpTimerEvent value) setOtpTimer,
    required TResult Function(_ChangeOtpEvent value) changeOtpEvent,
    required TResult Function(_UpdateTimerEvent value) updateOtpTimer,
    required TResult Function(_cancelTimerscriptionEvent value)
        cancelOtpTimerSubscription,
    required TResult Function(_otpApiEvent value) otpApiEvent,
    required TResult Function(_registerApiEvent value) registerApiEvent,
    required TResult Function(_logInApiDataEvent value) logInApiDataEvent,
  }) {
    return logInApiDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult? Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult? Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult? Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult? Function(_otpApiEvent value)? otpApiEvent,
    TResult? Function(_registerApiEvent value)? registerApiEvent,
    TResult? Function(_logInApiDataEvent value)? logInApiDataEvent,
  }) {
    return logInApiDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SetOtpTimerEvent value)? setOtpTimer,
    TResult Function(_ChangeOtpEvent value)? changeOtpEvent,
    TResult Function(_UpdateTimerEvent value)? updateOtpTimer,
    TResult Function(_cancelTimerscriptionEvent value)?
        cancelOtpTimerSubscription,
    TResult Function(_otpApiEvent value)? otpApiEvent,
    TResult Function(_registerApiEvent value)? registerApiEvent,
    TResult Function(_logInApiDataEvent value)? logInApiDataEvent,
    required TResult orElse(),
  }) {
    if (logInApiDataEvent != null) {
      return logInApiDataEvent(this);
    }
    return orElse();
  }
}

abstract class _logInApiDataEvent implements OtpEvent {
  factory _logInApiDataEvent(
      {required final String contactNumber,
      required final BuildContext context,
      required final bool isRegister}) = _$logInApiDataEventImpl;

  String get contactNumber;
  BuildContext get context;
  bool get isRegister;
  @JsonKey(ignore: true)
  _$$logInApiDataEventImplCopyWith<_$logInApiDataEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$OtpState {
  int get otpTimer => throw _privateConstructorUsedError;
  String get otp => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  String get errorMessage => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OtpStateCopyWith<OtpState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OtpStateCopyWith<$Res> {
  factory $OtpStateCopyWith(OtpState value, $Res Function(OtpState) then) =
      _$OtpStateCopyWithImpl<$Res, OtpState>;
  @useResult
  $Res call({int otpTimer, String otp, bool isLoading, String errorMessage});
}

/// @nodoc
class _$OtpStateCopyWithImpl<$Res, $Val extends OtpState>
    implements $OtpStateCopyWith<$Res> {
  _$OtpStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? otpTimer = null,
    Object? otp = null,
    Object? isLoading = null,
    Object? errorMessage = null,
  }) {
    return _then(_value.copyWith(
      otpTimer: null == otpTimer
          ? _value.otpTimer
          : otpTimer // ignore: cast_nullable_to_non_nullable
              as int,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$OtpStateImplCopyWith<$Res>
    implements $OtpStateCopyWith<$Res> {
  factory _$$OtpStateImplCopyWith(
          _$OtpStateImpl value, $Res Function(_$OtpStateImpl) then) =
      __$$OtpStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int otpTimer, String otp, bool isLoading, String errorMessage});
}

/// @nodoc
class __$$OtpStateImplCopyWithImpl<$Res>
    extends _$OtpStateCopyWithImpl<$Res, _$OtpStateImpl>
    implements _$$OtpStateImplCopyWith<$Res> {
  __$$OtpStateImplCopyWithImpl(
      _$OtpStateImpl _value, $Res Function(_$OtpStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? otpTimer = null,
    Object? otp = null,
    Object? isLoading = null,
    Object? errorMessage = null,
  }) {
    return _then(_$OtpStateImpl(
      otpTimer: null == otpTimer
          ? _value.otpTimer
          : otpTimer // ignore: cast_nullable_to_non_nullable
              as int,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$OtpStateImpl implements _OtpState {
  const _$OtpStateImpl(
      {required this.otpTimer,
      required this.otp,
      required this.isLoading,
      required this.errorMessage});

  @override
  final int otpTimer;
  @override
  final String otp;
  @override
  final bool isLoading;
  @override
  final String errorMessage;

  @override
  String toString() {
    return 'OtpState(otpTimer: $otpTimer, otp: $otp, isLoading: $isLoading, errorMessage: $errorMessage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OtpStateImpl &&
            (identical(other.otpTimer, otpTimer) ||
                other.otpTimer == otpTimer) &&
            (identical(other.otp, otp) || other.otp == otp) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, otpTimer, otp, isLoading, errorMessage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OtpStateImplCopyWith<_$OtpStateImpl> get copyWith =>
      __$$OtpStateImplCopyWithImpl<_$OtpStateImpl>(this, _$identity);
}

abstract class _OtpState implements OtpState {
  const factory _OtpState(
      {required final int otpTimer,
      required final String otp,
      required final bool isLoading,
      required final String errorMessage}) = _$OtpStateImpl;

  @override
  int get otpTimer;
  @override
  String get otp;
  @override
  bool get isLoading;
  @override
  String get errorMessage;
  @override
  @JsonKey(ignore: true)
  _$$OtpStateImplCopyWith<_$OtpStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
