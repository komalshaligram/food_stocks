// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'order_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$OrderEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAllOrderEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAllOrderEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAllOrderEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAllOrderEvent value) getAllOrderEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAllOrderEvent value)? getAllOrderEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAllOrderEvent value)? getAllOrderEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OrderEventCopyWith<OrderEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderEventCopyWith<$Res> {
  factory $OrderEventCopyWith(
          OrderEvent value, $Res Function(OrderEvent) then) =
      _$OrderEventCopyWithImpl<$Res, OrderEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$OrderEventCopyWithImpl<$Res, $Val extends OrderEvent>
    implements $OrderEventCopyWith<$Res> {
  _$OrderEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$getAllOrderEventImplCopyWith<$Res>
    implements $OrderEventCopyWith<$Res> {
  factory _$$getAllOrderEventImplCopyWith(_$getAllOrderEventImpl value,
          $Res Function(_$getAllOrderEventImpl) then) =
      __$$getAllOrderEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getAllOrderEventImplCopyWithImpl<$Res>
    extends _$OrderEventCopyWithImpl<$Res, _$getAllOrderEventImpl>
    implements _$$getAllOrderEventImplCopyWith<$Res> {
  __$$getAllOrderEventImplCopyWithImpl(_$getAllOrderEventImpl _value,
      $Res Function(_$getAllOrderEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getAllOrderEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getAllOrderEventImpl implements _getAllOrderEvent {
  const _$getAllOrderEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'OrderEvent.getAllOrderEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getAllOrderEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getAllOrderEventImplCopyWith<_$getAllOrderEventImpl> get copyWith =>
      __$$getAllOrderEventImplCopyWithImpl<_$getAllOrderEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAllOrderEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return getAllOrderEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAllOrderEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return getAllOrderEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAllOrderEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getAllOrderEvent != null) {
      return getAllOrderEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAllOrderEvent value) getAllOrderEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return getAllOrderEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAllOrderEvent value)? getAllOrderEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return getAllOrderEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAllOrderEvent value)? getAllOrderEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getAllOrderEvent != null) {
      return getAllOrderEvent(this);
    }
    return orElse();
  }
}

abstract class _getAllOrderEvent implements OrderEvent {
  const factory _getAllOrderEvent({required final BuildContext context}) =
      _$getAllOrderEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$getAllOrderEventImplCopyWith<_$getAllOrderEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res>
    implements $OrderEventCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$OrderEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'OrderEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAllOrderEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAllOrderEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAllOrderEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAllOrderEvent value) getAllOrderEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAllOrderEvent value)? getAllOrderEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAllOrderEvent value)? getAllOrderEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements OrderEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$OrderState {
  GetAllOrderResModel get orderList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  List<Datum> get orderDetailsList => throw _privateConstructorUsedError;
  bool get isBottomOfProducts => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OrderStateCopyWith<OrderState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OrderStateCopyWith<$Res> {
  factory $OrderStateCopyWith(
          OrderState value, $Res Function(OrderState) then) =
      _$OrderStateCopyWithImpl<$Res, OrderState>;
  @useResult
  $Res call(
      {GetAllOrderResModel orderList,
      bool isShimmering,
      bool isLoadMore,
      int pageNum,
      List<Datum> orderDetailsList,
      bool isBottomOfProducts,
      RefreshController refreshController});

  $GetAllOrderResModelCopyWith<$Res> get orderList;
}

/// @nodoc
class _$OrderStateCopyWithImpl<$Res, $Val extends OrderState>
    implements $OrderStateCopyWith<$Res> {
  _$OrderStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderList = null,
    Object? isShimmering = null,
    Object? isLoadMore = null,
    Object? pageNum = null,
    Object? orderDetailsList = null,
    Object? isBottomOfProducts = null,
    Object? refreshController = null,
  }) {
    return _then(_value.copyWith(
      orderList: null == orderList
          ? _value.orderList
          : orderList // ignore: cast_nullable_to_non_nullable
              as GetAllOrderResModel,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      orderDetailsList: null == orderDetailsList
          ? _value.orderDetailsList
          : orderDetailsList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $GetAllOrderResModelCopyWith<$Res> get orderList {
    return $GetAllOrderResModelCopyWith<$Res>(_value.orderList, (value) {
      return _then(_value.copyWith(orderList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$OrderStateImplCopyWith<$Res>
    implements $OrderStateCopyWith<$Res> {
  factory _$$OrderStateImplCopyWith(
          _$OrderStateImpl value, $Res Function(_$OrderStateImpl) then) =
      __$$OrderStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {GetAllOrderResModel orderList,
      bool isShimmering,
      bool isLoadMore,
      int pageNum,
      List<Datum> orderDetailsList,
      bool isBottomOfProducts,
      RefreshController refreshController});

  @override
  $GetAllOrderResModelCopyWith<$Res> get orderList;
}

/// @nodoc
class __$$OrderStateImplCopyWithImpl<$Res>
    extends _$OrderStateCopyWithImpl<$Res, _$OrderStateImpl>
    implements _$$OrderStateImplCopyWith<$Res> {
  __$$OrderStateImplCopyWithImpl(
      _$OrderStateImpl _value, $Res Function(_$OrderStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? orderList = null,
    Object? isShimmering = null,
    Object? isLoadMore = null,
    Object? pageNum = null,
    Object? orderDetailsList = null,
    Object? isBottomOfProducts = null,
    Object? refreshController = null,
  }) {
    return _then(_$OrderStateImpl(
      orderList: null == orderList
          ? _value.orderList
          : orderList // ignore: cast_nullable_to_non_nullable
              as GetAllOrderResModel,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      orderDetailsList: null == orderDetailsList
          ? _value._orderDetailsList
          : orderDetailsList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
    ));
  }
}

/// @nodoc

class _$OrderStateImpl implements _OrderState {
  const _$OrderStateImpl(
      {required this.orderList,
      required this.isShimmering,
      required this.isLoadMore,
      required this.pageNum,
      required final List<Datum> orderDetailsList,
      required this.isBottomOfProducts,
      required this.refreshController})
      : _orderDetailsList = orderDetailsList;

  @override
  final GetAllOrderResModel orderList;
  @override
  final bool isShimmering;
  @override
  final bool isLoadMore;
  @override
  final int pageNum;
  final List<Datum> _orderDetailsList;
  @override
  List<Datum> get orderDetailsList {
    if (_orderDetailsList is EqualUnmodifiableListView)
      return _orderDetailsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_orderDetailsList);
  }

  @override
  final bool isBottomOfProducts;
  @override
  final RefreshController refreshController;

  @override
  String toString() {
    return 'OrderState(orderList: $orderList, isShimmering: $isShimmering, isLoadMore: $isLoadMore, pageNum: $pageNum, orderDetailsList: $orderDetailsList, isBottomOfProducts: $isBottomOfProducts, refreshController: $refreshController)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OrderStateImpl &&
            (identical(other.orderList, orderList) ||
                other.orderList == orderList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            const DeepCollectionEquality()
                .equals(other._orderDetailsList, _orderDetailsList) &&
            (identical(other.isBottomOfProducts, isBottomOfProducts) ||
                other.isBottomOfProducts == isBottomOfProducts) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      orderList,
      isShimmering,
      isLoadMore,
      pageNum,
      const DeepCollectionEquality().hash(_orderDetailsList),
      isBottomOfProducts,
      refreshController);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OrderStateImplCopyWith<_$OrderStateImpl> get copyWith =>
      __$$OrderStateImplCopyWithImpl<_$OrderStateImpl>(this, _$identity);
}

abstract class _OrderState implements OrderState {
  const factory _OrderState(
      {required final GetAllOrderResModel orderList,
      required final bool isShimmering,
      required final bool isLoadMore,
      required final int pageNum,
      required final List<Datum> orderDetailsList,
      required final bool isBottomOfProducts,
      required final RefreshController refreshController}) = _$OrderStateImpl;

  @override
  GetAllOrderResModel get orderList;
  @override
  bool get isShimmering;
  @override
  bool get isLoadMore;
  @override
  int get pageNum;
  @override
  List<Datum> get orderDetailsList;
  @override
  bool get isBottomOfProducts;
  @override
  RefreshController get refreshController;
  @override
  @JsonKey(ignore: true)
  _$$OrderStateImplCopyWith<_$OrderStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
