// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'message_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MessageEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageEventCopyWith<$Res> {
  factory $MessageEventCopyWith(
          MessageEvent value, $Res Function(MessageEvent) then) =
      _$MessageEventCopyWithImpl<$Res, MessageEvent>;
}

/// @nodoc
class _$MessageEventCopyWithImpl<$Res, $Val extends MessageEvent>
    implements $MessageEventCopyWith<$Res> {
  _$MessageEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetMessageListEventImplCopyWith<$Res> {
  factory _$$GetMessageListEventImplCopyWith(_$GetMessageListEventImpl value,
          $Res Function(_$GetMessageListEventImpl) then) =
      __$$GetMessageListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetMessageListEventImplCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res, _$GetMessageListEventImpl>
    implements _$$GetMessageListEventImplCopyWith<$Res> {
  __$$GetMessageListEventImplCopyWithImpl(_$GetMessageListEventImpl _value,
      $Res Function(_$GetMessageListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetMessageListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetMessageListEventImpl implements _GetMessageListEvent {
  const _$GetMessageListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MessageEvent.getMessageListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetMessageListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetMessageListEventImplCopyWith<_$GetMessageListEventImpl> get copyWith =>
      __$$GetMessageListEventImplCopyWithImpl<_$GetMessageListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
  }) {
    return getMessageListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
  }) {
    return getMessageListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (getMessageListEvent != null) {
      return getMessageListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
  }) {
    return getMessageListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
  }) {
    return getMessageListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (getMessageListEvent != null) {
      return getMessageListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetMessageListEvent implements MessageEvent {
  const factory _GetMessageListEvent({required final BuildContext context}) =
      _$GetMessageListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetMessageListEventImplCopyWith<_$GetMessageListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveOrUpdateMessageEventImplCopyWith<$Res> {
  factory _$$RemoveOrUpdateMessageEventImplCopyWith(
          _$RemoveOrUpdateMessageEventImpl value,
          $Res Function(_$RemoveOrUpdateMessageEventImpl) then) =
      __$$RemoveOrUpdateMessageEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String messageId, bool isRead, bool isDelete});
}

/// @nodoc
class __$$RemoveOrUpdateMessageEventImplCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res, _$RemoveOrUpdateMessageEventImpl>
    implements _$$RemoveOrUpdateMessageEventImplCopyWith<$Res> {
  __$$RemoveOrUpdateMessageEventImplCopyWithImpl(
      _$RemoveOrUpdateMessageEventImpl _value,
      $Res Function(_$RemoveOrUpdateMessageEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageId = null,
    Object? isRead = null,
    Object? isDelete = null,
  }) {
    return _then(_$RemoveOrUpdateMessageEventImpl(
      messageId: null == messageId
          ? _value.messageId
          : messageId // ignore: cast_nullable_to_non_nullable
              as String,
      isRead: null == isRead
          ? _value.isRead
          : isRead // ignore: cast_nullable_to_non_nullable
              as bool,
      isDelete: null == isDelete
          ? _value.isDelete
          : isDelete // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$RemoveOrUpdateMessageEventImpl implements _RemoveOrUpdateMessageEvent {
  const _$RemoveOrUpdateMessageEventImpl(
      {required this.messageId, required this.isRead, required this.isDelete});

  @override
  final String messageId;
  @override
  final bool isRead;
  @override
  final bool isDelete;

  @override
  String toString() {
    return 'MessageEvent.removeOrUpdateMessageEvent(messageId: $messageId, isRead: $isRead, isDelete: $isDelete)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveOrUpdateMessageEventImpl &&
            (identical(other.messageId, messageId) ||
                other.messageId == messageId) &&
            (identical(other.isRead, isRead) || other.isRead == isRead) &&
            (identical(other.isDelete, isDelete) ||
                other.isDelete == isDelete));
  }

  @override
  int get hashCode => Object.hash(runtimeType, messageId, isRead, isDelete);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RemoveOrUpdateMessageEventImplCopyWith<_$RemoveOrUpdateMessageEventImpl>
      get copyWith => __$$RemoveOrUpdateMessageEventImplCopyWithImpl<
          _$RemoveOrUpdateMessageEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
  }) {
    return removeOrUpdateMessageEvent(messageId, isRead, isDelete);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
  }) {
    return removeOrUpdateMessageEvent?.call(messageId, isRead, isDelete);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (removeOrUpdateMessageEvent != null) {
      return removeOrUpdateMessageEvent(messageId, isRead, isDelete);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
  }) {
    return removeOrUpdateMessageEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
  }) {
    return removeOrUpdateMessageEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (removeOrUpdateMessageEvent != null) {
      return removeOrUpdateMessageEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveOrUpdateMessageEvent implements MessageEvent {
  const factory _RemoveOrUpdateMessageEvent(
      {required final String messageId,
      required final bool isRead,
      required final bool isDelete}) = _$RemoveOrUpdateMessageEventImpl;

  String get messageId;
  bool get isRead;
  bool get isDelete;
  @JsonKey(ignore: true)
  _$$RemoveOrUpdateMessageEventImplCopyWith<_$RemoveOrUpdateMessageEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MessageEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements MessageEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$MessageDeleteEventImplCopyWith<$Res> {
  factory _$$MessageDeleteEventImplCopyWith(_$MessageDeleteEventImpl value,
          $Res Function(_$MessageDeleteEventImpl) then) =
      __$$MessageDeleteEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String messageId, BuildContext context, BuildContext dialogContext});
}

/// @nodoc
class __$$MessageDeleteEventImplCopyWithImpl<$Res>
    extends _$MessageEventCopyWithImpl<$Res, _$MessageDeleteEventImpl>
    implements _$$MessageDeleteEventImplCopyWith<$Res> {
  __$$MessageDeleteEventImplCopyWithImpl(_$MessageDeleteEventImpl _value,
      $Res Function(_$MessageDeleteEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageId = null,
    Object? context = null,
    Object? dialogContext = null,
  }) {
    return _then(_$MessageDeleteEventImpl(
      messageId: null == messageId
          ? _value.messageId
          : messageId // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      dialogContext: null == dialogContext
          ? _value.dialogContext
          : dialogContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$MessageDeleteEventImpl implements _MessageDeleteEvent {
  const _$MessageDeleteEventImpl(
      {required this.messageId,
      required this.context,
      required this.dialogContext});

  @override
  final String messageId;
  @override
  final BuildContext context;
  @override
  final BuildContext dialogContext;

  @override
  String toString() {
    return 'MessageEvent.MessageDeleteEvent(messageId: $messageId, context: $context, dialogContext: $dialogContext)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MessageDeleteEventImpl &&
            (identical(other.messageId, messageId) ||
                other.messageId == messageId) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.dialogContext, dialogContext) ||
                other.dialogContext == dialogContext));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, messageId, context, dialogContext);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MessageDeleteEventImplCopyWith<_$MessageDeleteEventImpl> get copyWith =>
      __$$MessageDeleteEventImplCopyWithImpl<_$MessageDeleteEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getMessageListEvent,
    required TResult Function(String messageId, bool isRead, bool isDelete)
        removeOrUpdateMessageEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)
        MessageDeleteEvent,
  }) {
    return MessageDeleteEvent(messageId, context, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getMessageListEvent,
    TResult? Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
  }) {
    return MessageDeleteEvent?.call(messageId, context, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getMessageListEvent,
    TResult Function(String messageId, bool isRead, bool isDelete)?
        removeOrUpdateMessageEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(
            String messageId, BuildContext context, BuildContext dialogContext)?
        MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (MessageDeleteEvent != null) {
      return MessageDeleteEvent(messageId, context, dialogContext);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMessageListEvent value) getMessageListEvent,
    required TResult Function(_RemoveOrUpdateMessageEvent value)
        removeOrUpdateMessageEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_MessageDeleteEvent value) MessageDeleteEvent,
  }) {
    return MessageDeleteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult? Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_MessageDeleteEvent value)? MessageDeleteEvent,
  }) {
    return MessageDeleteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMessageListEvent value)? getMessageListEvent,
    TResult Function(_RemoveOrUpdateMessageEvent value)?
        removeOrUpdateMessageEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_MessageDeleteEvent value)? MessageDeleteEvent,
    required TResult orElse(),
  }) {
    if (MessageDeleteEvent != null) {
      return MessageDeleteEvent(this);
    }
    return orElse();
  }
}

abstract class _MessageDeleteEvent implements MessageEvent {
  const factory _MessageDeleteEvent(
      {required final String messageId,
      required final BuildContext context,
      required final BuildContext dialogContext}) = _$MessageDeleteEventImpl;

  String get messageId;
  BuildContext get context;
  BuildContext get dialogContext;
  @JsonKey(ignore: true)
  _$$MessageDeleteEventImplCopyWith<_$MessageDeleteEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MessageState {
  List<MessageData> get messageList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isBottomOfMessage => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isMessageRead => throw _privateConstructorUsedError;
  List<String> get deletedMessageList => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  bool get isRemoveProcess => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MessageStateCopyWith<MessageState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageStateCopyWith<$Res> {
  factory $MessageStateCopyWith(
          MessageState value, $Res Function(MessageState) then) =
      _$MessageStateCopyWithImpl<$Res, MessageState>;
  @useResult
  $Res call(
      {List<MessageData> messageList,
      bool isShimmering,
      int pageNum,
      bool isBottomOfMessage,
      bool isLoadMore,
      bool isMessageRead,
      List<String> deletedMessageList,
      RefreshController refreshController,
      String language,
      bool isRemoveProcess});
}

/// @nodoc
class _$MessageStateCopyWithImpl<$Res, $Val extends MessageState>
    implements $MessageStateCopyWith<$Res> {
  _$MessageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageList = null,
    Object? isShimmering = null,
    Object? pageNum = null,
    Object? isBottomOfMessage = null,
    Object? isLoadMore = null,
    Object? isMessageRead = null,
    Object? deletedMessageList = null,
    Object? refreshController = null,
    Object? language = null,
    Object? isRemoveProcess = null,
  }) {
    return _then(_value.copyWith(
      messageList: null == messageList
          ? _value.messageList
          : messageList // ignore: cast_nullable_to_non_nullable
              as List<MessageData>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isBottomOfMessage: null == isBottomOfMessage
          ? _value.isBottomOfMessage
          : isBottomOfMessage // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isMessageRead: null == isMessageRead
          ? _value.isMessageRead
          : isMessageRead // ignore: cast_nullable_to_non_nullable
              as bool,
      deletedMessageList: null == deletedMessageList
          ? _value.deletedMessageList
          : deletedMessageList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MessageStateImplCopyWith<$Res>
    implements $MessageStateCopyWith<$Res> {
  factory _$$MessageStateImplCopyWith(
          _$MessageStateImpl value, $Res Function(_$MessageStateImpl) then) =
      __$$MessageStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<MessageData> messageList,
      bool isShimmering,
      int pageNum,
      bool isBottomOfMessage,
      bool isLoadMore,
      bool isMessageRead,
      List<String> deletedMessageList,
      RefreshController refreshController,
      String language,
      bool isRemoveProcess});
}

/// @nodoc
class __$$MessageStateImplCopyWithImpl<$Res>
    extends _$MessageStateCopyWithImpl<$Res, _$MessageStateImpl>
    implements _$$MessageStateImplCopyWith<$Res> {
  __$$MessageStateImplCopyWithImpl(
      _$MessageStateImpl _value, $Res Function(_$MessageStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? messageList = null,
    Object? isShimmering = null,
    Object? pageNum = null,
    Object? isBottomOfMessage = null,
    Object? isLoadMore = null,
    Object? isMessageRead = null,
    Object? deletedMessageList = null,
    Object? refreshController = null,
    Object? language = null,
    Object? isRemoveProcess = null,
  }) {
    return _then(_$MessageStateImpl(
      messageList: null == messageList
          ? _value._messageList
          : messageList // ignore: cast_nullable_to_non_nullable
              as List<MessageData>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isBottomOfMessage: null == isBottomOfMessage
          ? _value.isBottomOfMessage
          : isBottomOfMessage // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isMessageRead: null == isMessageRead
          ? _value.isMessageRead
          : isMessageRead // ignore: cast_nullable_to_non_nullable
              as bool,
      deletedMessageList: null == deletedMessageList
          ? _value._deletedMessageList
          : deletedMessageList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$MessageStateImpl implements _MessageState {
  const _$MessageStateImpl(
      {required final List<MessageData> messageList,
      required this.isShimmering,
      required this.pageNum,
      required this.isBottomOfMessage,
      required this.isLoadMore,
      required this.isMessageRead,
      required final List<String> deletedMessageList,
      required this.refreshController,
      required this.language,
      required this.isRemoveProcess})
      : _messageList = messageList,
        _deletedMessageList = deletedMessageList;

  final List<MessageData> _messageList;
  @override
  List<MessageData> get messageList {
    if (_messageList is EqualUnmodifiableListView) return _messageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_messageList);
  }

  @override
  final bool isShimmering;
  @override
  final int pageNum;
  @override
  final bool isBottomOfMessage;
  @override
  final bool isLoadMore;
  @override
  final bool isMessageRead;
  final List<String> _deletedMessageList;
  @override
  List<String> get deletedMessageList {
    if (_deletedMessageList is EqualUnmodifiableListView)
      return _deletedMessageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_deletedMessageList);
  }

  @override
  final RefreshController refreshController;
  @override
  final String language;
  @override
  final bool isRemoveProcess;

  @override
  String toString() {
    return 'MessageState(messageList: $messageList, isShimmering: $isShimmering, pageNum: $pageNum, isBottomOfMessage: $isBottomOfMessage, isLoadMore: $isLoadMore, isMessageRead: $isMessageRead, deletedMessageList: $deletedMessageList, refreshController: $refreshController, language: $language, isRemoveProcess: $isRemoveProcess)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MessageStateImpl &&
            const DeepCollectionEquality()
                .equals(other._messageList, _messageList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isBottomOfMessage, isBottomOfMessage) ||
                other.isBottomOfMessage == isBottomOfMessage) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isMessageRead, isMessageRead) ||
                other.isMessageRead == isMessageRead) &&
            const DeepCollectionEquality()
                .equals(other._deletedMessageList, _deletedMessageList) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.isRemoveProcess, isRemoveProcess) ||
                other.isRemoveProcess == isRemoveProcess));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_messageList),
      isShimmering,
      pageNum,
      isBottomOfMessage,
      isLoadMore,
      isMessageRead,
      const DeepCollectionEquality().hash(_deletedMessageList),
      refreshController,
      language,
      isRemoveProcess);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MessageStateImplCopyWith<_$MessageStateImpl> get copyWith =>
      __$$MessageStateImplCopyWithImpl<_$MessageStateImpl>(this, _$identity);
}

abstract class _MessageState implements MessageState {
  const factory _MessageState(
      {required final List<MessageData> messageList,
      required final bool isShimmering,
      required final int pageNum,
      required final bool isBottomOfMessage,
      required final bool isLoadMore,
      required final bool isMessageRead,
      required final List<String> deletedMessageList,
      required final RefreshController refreshController,
      required final String language,
      required final bool isRemoveProcess}) = _$MessageStateImpl;

  @override
  List<MessageData> get messageList;
  @override
  bool get isShimmering;
  @override
  int get pageNum;
  @override
  bool get isBottomOfMessage;
  @override
  bool get isLoadMore;
  @override
  bool get isMessageRead;
  @override
  List<String> get deletedMessageList;
  @override
  RefreshController get refreshController;
  @override
  String get language;
  @override
  bool get isRemoveProcess;
  @override
  @JsonKey(ignore: true)
  _$$MessageStateImplCopyWith<_$MessageStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
