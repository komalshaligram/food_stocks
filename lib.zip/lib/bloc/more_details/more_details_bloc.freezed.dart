// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'more_details_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MoreDetailsEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MoreDetailsEventCopyWith<$Res> {
  factory $MoreDetailsEventCopyWith(
          MoreDetailsEvent value, $Res Function(MoreDetailsEvent) then) =
      _$MoreDetailsEventCopyWithImpl<$Res, MoreDetailsEvent>;
}

/// @nodoc
class _$MoreDetailsEventCopyWithImpl<$Res, $Val extends MoreDetailsEvent>
    implements $MoreDetailsEventCopyWith<$Res> {
  _$MoreDetailsEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$dropDownEventImplCopyWith<$Res> {
  factory _$$dropDownEventImplCopyWith(
          _$dropDownEventImpl value, $Res Function(_$dropDownEventImpl) then) =
      __$$dropDownEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$dropDownEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$dropDownEventImpl>
    implements _$$dropDownEventImplCopyWith<$Res> {
  __$$dropDownEventImplCopyWithImpl(
      _$dropDownEventImpl _value, $Res Function(_$dropDownEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$dropDownEventImpl implements _dropDownEvent {
  _$dropDownEventImpl();

  @override
  String toString() {
    return 'MoreDetailsEvent.dropDownEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$dropDownEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return dropDownEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return dropDownEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (dropDownEvent != null) {
      return dropDownEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return dropDownEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return dropDownEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (dropDownEvent != null) {
      return dropDownEvent(this);
    }
    return orElse();
  }
}

abstract class _dropDownEvent implements MoreDetailsEvent {
  factory _dropDownEvent() = _$dropDownEventImpl;
}

/// @nodoc
abstract class _$$pickLogoImageEventImplCopyWith<$Res> {
  factory _$$pickLogoImageEventImplCopyWith(_$pickLogoImageEventImpl value,
          $Res Function(_$pickLogoImageEventImpl) then) =
      __$$pickLogoImageEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, bool isFromCamera});
}

/// @nodoc
class __$$pickLogoImageEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$pickLogoImageEventImpl>
    implements _$$pickLogoImageEventImplCopyWith<$Res> {
  __$$pickLogoImageEventImplCopyWithImpl(_$pickLogoImageEventImpl _value,
      $Res Function(_$pickLogoImageEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isFromCamera = null,
  }) {
    return _then(_$pickLogoImageEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isFromCamera: null == isFromCamera
          ? _value.isFromCamera
          : isFromCamera // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$pickLogoImageEventImpl implements _pickLogoImageEvent {
  _$pickLogoImageEventImpl({required this.context, required this.isFromCamera});

  @override
  final BuildContext context;
  @override
  final bool isFromCamera;

  @override
  String toString() {
    return 'MoreDetailsEvent.pickLogoImageEvent(context: $context, isFromCamera: $isFromCamera)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$pickLogoImageEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isFromCamera, isFromCamera) ||
                other.isFromCamera == isFromCamera));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isFromCamera);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$pickLogoImageEventImplCopyWith<_$pickLogoImageEventImpl> get copyWith =>
      __$$pickLogoImageEventImplCopyWithImpl<_$pickLogoImageEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return pickLogoImageEvent(context, isFromCamera);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return pickLogoImageEvent?.call(context, isFromCamera);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (pickLogoImageEvent != null) {
      return pickLogoImageEvent(context, isFromCamera);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return pickLogoImageEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return pickLogoImageEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (pickLogoImageEvent != null) {
      return pickLogoImageEvent(this);
    }
    return orElse();
  }
}

abstract class _pickLogoImageEvent implements MoreDetailsEvent {
  factory _pickLogoImageEvent(
      {required final BuildContext context,
      required final bool isFromCamera}) = _$pickLogoImageEventImpl;

  BuildContext get context;
  bool get isFromCamera;
  @JsonKey(ignore: true)
  _$$pickLogoImageEventImplCopyWith<_$pickLogoImageEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getProfileModelEventImplCopyWith<$Res> {
  factory _$$getProfileModelEventImplCopyWith(_$getProfileModelEventImpl value,
          $Res Function(_$getProfileModelEventImpl) then) =
      __$$getProfileModelEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({ProfileModel profileModel, BuildContext context});

  $ProfileModelCopyWith<$Res> get profileModel;
}

/// @nodoc
class __$$getProfileModelEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$getProfileModelEventImpl>
    implements _$$getProfileModelEventImplCopyWith<$Res> {
  __$$getProfileModelEventImplCopyWithImpl(_$getProfileModelEventImpl _value,
      $Res Function(_$getProfileModelEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? profileModel = null,
    Object? context = null,
  }) {
    return _then(_$getProfileModelEventImpl(
      profileModel: null == profileModel
          ? _value.profileModel
          : profileModel // ignore: cast_nullable_to_non_nullable
              as ProfileModel,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ProfileModelCopyWith<$Res> get profileModel {
    return $ProfileModelCopyWith<$Res>(_value.profileModel, (value) {
      return _then(_value.copyWith(profileModel: value));
    });
  }
}

/// @nodoc

class _$getProfileModelEventImpl implements _getProfileModelEvent {
  _$getProfileModelEventImpl(
      {required this.profileModel, required this.context});

  @override
  final ProfileModel profileModel;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MoreDetailsEvent.getProfileModelEvent(profileModel: $profileModel, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getProfileModelEventImpl &&
            (identical(other.profileModel, profileModel) ||
                other.profileModel == profileModel) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, profileModel, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getProfileModelEventImplCopyWith<_$getProfileModelEventImpl>
      get copyWith =>
          __$$getProfileModelEventImplCopyWithImpl<_$getProfileModelEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return getProfileModelEvent(profileModel, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return getProfileModelEvent?.call(profileModel, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getProfileModelEvent != null) {
      return getProfileModelEvent(profileModel, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return getProfileModelEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return getProfileModelEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getProfileModelEvent != null) {
      return getProfileModelEvent(this);
    }
    return orElse();
  }
}

abstract class _getProfileModelEvent implements MoreDetailsEvent {
  factory _getProfileModelEvent(
      {required final ProfileModel profileModel,
      required final BuildContext context}) = _$getProfileModelEventImpl;

  ProfileModel get profileModel;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getProfileModelEventImplCopyWith<_$getProfileModelEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$registrationApiEventImplCopyWith<$Res> {
  factory _$$registrationApiEventImplCopyWith(_$registrationApiEventImpl value,
          $Res Function(_$registrationApiEventImpl) then) =
      __$$registrationApiEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$registrationApiEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$registrationApiEventImpl>
    implements _$$registrationApiEventImplCopyWith<$Res> {
  __$$registrationApiEventImplCopyWithImpl(_$registrationApiEventImpl _value,
      $Res Function(_$registrationApiEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$registrationApiEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$registrationApiEventImpl implements _registrationApiEvent {
  _$registrationApiEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MoreDetailsEvent.registrationApiEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$registrationApiEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$registrationApiEventImplCopyWith<_$registrationApiEventImpl>
      get copyWith =>
          __$$registrationApiEventImplCopyWithImpl<_$registrationApiEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return registrationApiEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return registrationApiEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (registrationApiEvent != null) {
      return registrationApiEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return registrationApiEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return registrationApiEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (registrationApiEvent != null) {
      return registrationApiEvent(this);
    }
    return orElse();
  }
}

abstract class _registrationApiEvent implements MoreDetailsEvent {
  factory _registrationApiEvent({required final BuildContext context}) =
      _$registrationApiEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$registrationApiEventImplCopyWith<_$registrationApiEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$citySearchEventImplCopyWith<$Res> {
  factory _$$citySearchEventImplCopyWith(_$citySearchEventImpl value,
          $Res Function(_$citySearchEventImpl) then) =
      __$$citySearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search});
}

/// @nodoc
class __$$citySearchEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$citySearchEventImpl>
    implements _$$citySearchEventImplCopyWith<$Res> {
  __$$citySearchEventImplCopyWithImpl(
      _$citySearchEventImpl _value, $Res Function(_$citySearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
  }) {
    return _then(_$citySearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$citySearchEventImpl implements _citySearchEvent {
  _$citySearchEventImpl({required this.search});

  @override
  final String search;

  @override
  String toString() {
    return 'MoreDetailsEvent.citySearchEvent(search: $search)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$citySearchEventImpl &&
            (identical(other.search, search) || other.search == search));
  }

  @override
  int get hashCode => Object.hash(runtimeType, search);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$citySearchEventImplCopyWith<_$citySearchEventImpl> get copyWith =>
      __$$citySearchEventImplCopyWithImpl<_$citySearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return citySearchEvent(search);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return citySearchEvent?.call(search);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (citySearchEvent != null) {
      return citySearchEvent(search);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return citySearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return citySearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (citySearchEvent != null) {
      return citySearchEvent(this);
    }
    return orElse();
  }
}

abstract class _citySearchEvent implements MoreDetailsEvent {
  factory _citySearchEvent({required final String search}) =
      _$citySearchEventImpl;

  String get search;
  @JsonKey(ignore: true)
  _$$citySearchEventImplCopyWith<_$citySearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$selectCityEventImplCopyWith<$Res> {
  factory _$$selectCityEventImplCopyWith(_$selectCityEventImpl value,
          $Res Function(_$selectCityEventImpl) then) =
      __$$selectCityEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String city, BuildContext context});
}

/// @nodoc
class __$$selectCityEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$selectCityEventImpl>
    implements _$$selectCityEventImplCopyWith<$Res> {
  __$$selectCityEventImplCopyWithImpl(
      _$selectCityEventImpl _value, $Res Function(_$selectCityEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? city = null,
    Object? context = null,
  }) {
    return _then(_$selectCityEventImpl(
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$selectCityEventImpl implements _selectCityEvent {
  _$selectCityEventImpl({required this.city, required this.context});

  @override
  final String city;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MoreDetailsEvent.selectCityEvent(city: $city, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$selectCityEventImpl &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, city, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$selectCityEventImplCopyWith<_$selectCityEventImpl> get copyWith =>
      __$$selectCityEventImplCopyWithImpl<_$selectCityEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return selectCityEvent(city, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return selectCityEvent?.call(city, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (selectCityEvent != null) {
      return selectCityEvent(city, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return selectCityEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return selectCityEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (selectCityEvent != null) {
      return selectCityEvent(this);
    }
    return orElse();
  }
}

abstract class _selectCityEvent implements MoreDetailsEvent {
  factory _selectCityEvent(
      {required final String city,
      required final BuildContext context}) = _$selectCityEventImpl;

  String get city;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$selectCityEventImplCopyWith<_$selectCityEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getProfileMoreDetailsEventImplCopyWith<$Res> {
  factory _$$getProfileMoreDetailsEventImplCopyWith(
          _$getProfileMoreDetailsEventImpl value,
          $Res Function(_$getProfileMoreDetailsEventImpl) then) =
      __$$getProfileMoreDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, bool isUpdate});
}

/// @nodoc
class __$$getProfileMoreDetailsEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res,
        _$getProfileMoreDetailsEventImpl>
    implements _$$getProfileMoreDetailsEventImplCopyWith<$Res> {
  __$$getProfileMoreDetailsEventImplCopyWithImpl(
      _$getProfileMoreDetailsEventImpl _value,
      $Res Function(_$getProfileMoreDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isUpdate = null,
  }) {
    return _then(_$getProfileMoreDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$getProfileMoreDetailsEventImpl implements _getProfileMoreDetailsEvent {
  _$getProfileMoreDetailsEventImpl(
      {required this.context, required this.isUpdate});

  @override
  final BuildContext context;
  @override
  final bool isUpdate;

  @override
  String toString() {
    return 'MoreDetailsEvent.getProfileMoreDetailsEvent(context: $context, isUpdate: $isUpdate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getProfileMoreDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getProfileMoreDetailsEventImplCopyWith<_$getProfileMoreDetailsEventImpl>
      get copyWith => __$$getProfileMoreDetailsEventImplCopyWithImpl<
          _$getProfileMoreDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return getProfileMoreDetailsEvent(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return getProfileMoreDetailsEvent?.call(context, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getProfileMoreDetailsEvent != null) {
      return getProfileMoreDetailsEvent(context, isUpdate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return getProfileMoreDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return getProfileMoreDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getProfileMoreDetailsEvent != null) {
      return getProfileMoreDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _getProfileMoreDetailsEvent implements MoreDetailsEvent {
  factory _getProfileMoreDetailsEvent(
      {required final BuildContext context,
      required final bool isUpdate}) = _$getProfileMoreDetailsEventImpl;

  BuildContext get context;
  bool get isUpdate;
  @JsonKey(ignore: true)
  _$$getProfileMoreDetailsEventImplCopyWith<_$getProfileMoreDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetFAXFormatEventImplCopyWith<$Res> {
  factory _$$SetFAXFormatEventImplCopyWith(_$SetFAXFormatEventImpl value,
          $Res Function(_$SetFAXFormatEventImpl) then) =
      __$$SetFAXFormatEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String FAX});
}

/// @nodoc
class __$$SetFAXFormatEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$SetFAXFormatEventImpl>
    implements _$$SetFAXFormatEventImplCopyWith<$Res> {
  __$$SetFAXFormatEventImplCopyWithImpl(_$SetFAXFormatEventImpl _value,
      $Res Function(_$SetFAXFormatEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? FAX = null,
  }) {
    return _then(_$SetFAXFormatEventImpl(
      FAX: null == FAX
          ? _value.FAX
          : FAX // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SetFAXFormatEventImpl implements _SetFAXFormatEvent {
  _$SetFAXFormatEventImpl({required this.FAX});

  @override
  final String FAX;

  @override
  String toString() {
    return 'MoreDetailsEvent.setFAXFormatEvent(FAX: $FAX)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SetFAXFormatEventImpl &&
            (identical(other.FAX, FAX) || other.FAX == FAX));
  }

  @override
  int get hashCode => Object.hash(runtimeType, FAX);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SetFAXFormatEventImplCopyWith<_$SetFAXFormatEventImpl> get copyWith =>
      __$$SetFAXFormatEventImplCopyWithImpl<_$SetFAXFormatEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return setFAXFormatEvent(FAX);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return setFAXFormatEvent?.call(FAX);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (setFAXFormatEvent != null) {
      return setFAXFormatEvent(FAX);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return setFAXFormatEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return setFAXFormatEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (setFAXFormatEvent != null) {
      return setFAXFormatEvent(this);
    }
    return orElse();
  }
}

abstract class _SetFAXFormatEvent implements MoreDetailsEvent {
  factory _SetFAXFormatEvent({required final String FAX}) =
      _$SetFAXFormatEventImpl;

  String get FAX;
  @JsonKey(ignore: true)
  _$$SetFAXFormatEventImplCopyWith<_$SetFAXFormatEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$deleteFileEventImplCopyWith<$Res> {
  factory _$$deleteFileEventImplCopyWith(_$deleteFileEventImpl value,
          $Res Function(_$deleteFileEventImpl) then) =
      __$$deleteFileEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$deleteFileEventImplCopyWithImpl<$Res>
    extends _$MoreDetailsEventCopyWithImpl<$Res, _$deleteFileEventImpl>
    implements _$$deleteFileEventImplCopyWith<$Res> {
  __$$deleteFileEventImplCopyWithImpl(
      _$deleteFileEventImpl _value, $Res Function(_$deleteFileEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$deleteFileEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$deleteFileEventImpl implements _deleteFileEvent {
  _$deleteFileEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'MoreDetailsEvent.deleteFileEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deleteFileEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      __$$deleteFileEventImplCopyWithImpl<_$deleteFileEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickLogoImageEvent,
    required TResult Function(ProfileModel profileModel, BuildContext context)
        getProfileModelEvent,
    required TResult Function(BuildContext context) registrationApiEvent,
    required TResult Function(String search) citySearchEvent,
    required TResult Function(String city, BuildContext context)
        selectCityEvent,
    required TResult Function(BuildContext context, bool isUpdate)
        getProfileMoreDetailsEvent,
    required TResult Function(String FAX) setFAXFormatEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return deleteFileEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult? Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult? Function(BuildContext context)? registrationApiEvent,
    TResult? Function(String search)? citySearchEvent,
    TResult? Function(String city, BuildContext context)? selectCityEvent,
    TResult? Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult? Function(String FAX)? setFAXFormatEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return deleteFileEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickLogoImageEvent,
    TResult Function(ProfileModel profileModel, BuildContext context)?
        getProfileModelEvent,
    TResult Function(BuildContext context)? registrationApiEvent,
    TResult Function(String search)? citySearchEvent,
    TResult Function(String city, BuildContext context)? selectCityEvent,
    TResult Function(BuildContext context, bool isUpdate)?
        getProfileMoreDetailsEvent,
    TResult Function(String FAX)? setFAXFormatEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickLogoImageEvent value) pickLogoImageEvent,
    required TResult Function(_getProfileModelEvent value) getProfileModelEvent,
    required TResult Function(_registrationApiEvent value) registrationApiEvent,
    required TResult Function(_citySearchEvent value) citySearchEvent,
    required TResult Function(_selectCityEvent value) selectCityEvent,
    required TResult Function(_getProfileMoreDetailsEvent value)
        getProfileMoreDetailsEvent,
    required TResult Function(_SetFAXFormatEvent value) setFAXFormatEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return deleteFileEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult? Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult? Function(_registrationApiEvent value)? registrationApiEvent,
    TResult? Function(_citySearchEvent value)? citySearchEvent,
    TResult? Function(_selectCityEvent value)? selectCityEvent,
    TResult? Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult? Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return deleteFileEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickLogoImageEvent value)? pickLogoImageEvent,
    TResult Function(_getProfileModelEvent value)? getProfileModelEvent,
    TResult Function(_registrationApiEvent value)? registrationApiEvent,
    TResult Function(_citySearchEvent value)? citySearchEvent,
    TResult Function(_selectCityEvent value)? selectCityEvent,
    TResult Function(_getProfileMoreDetailsEvent value)?
        getProfileMoreDetailsEvent,
    TResult Function(_SetFAXFormatEvent value)? setFAXFormatEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(this);
    }
    return orElse();
  }
}

abstract class _deleteFileEvent implements MoreDetailsEvent {
  factory _deleteFileEvent({required final BuildContext context}) =
      _$deleteFileEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MoreDetailsState {
  String get selectCity => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;
  List<String> get cityList => throw _privateConstructorUsedError;
  List<String> get filterList => throw _privateConstructorUsedError;
  TextEditingController get streetNameController =>
      throw _privateConstructorUsedError;
  TextEditingController get streetNumberController =>
      throw _privateConstructorUsedError;
  TextEditingController get emailController =>
      throw _privateConstructorUsedError;
  TextEditingController get faxController => throw _privateConstructorUsedError;
  TextEditingController get cityController =>
      throw _privateConstructorUsedError;
  TextEditingController get zipController => throw _privateConstructorUsedError;
  File get image => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isUpdating => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  CityListResModel? get cityListResModel => throw _privateConstructorUsedError;
  String get companyLogo => throw _privateConstructorUsedError;
  bool get isFileSizeExceeds => throw _privateConstructorUsedError;
  bool get isUploadProcess => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MoreDetailsStateCopyWith<MoreDetailsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MoreDetailsStateCopyWith<$Res> {
  factory $MoreDetailsStateCopyWith(
          MoreDetailsState value, $Res Function(MoreDetailsState) then) =
      _$MoreDetailsStateCopyWithImpl<$Res, MoreDetailsState>;
  @useResult
  $Res call(
      {String selectCity,
      bool isUpdate,
      List<String> cityList,
      List<String> filterList,
      TextEditingController streetNameController,
      TextEditingController streetNumberController,
      TextEditingController emailController,
      TextEditingController faxController,
      TextEditingController cityController,
      TextEditingController zipController,
      File image,
      bool isLoading,
      bool isUpdating,
      bool isShimmering,
      CityListResModel? cityListResModel,
      String companyLogo,
      bool isFileSizeExceeds,
      bool isUploadProcess,
      String language});

  $CityListResModelCopyWith<$Res>? get cityListResModel;
}

/// @nodoc
class _$MoreDetailsStateCopyWithImpl<$Res, $Val extends MoreDetailsState>
    implements $MoreDetailsStateCopyWith<$Res> {
  _$MoreDetailsStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? selectCity = null,
    Object? isUpdate = null,
    Object? cityList = null,
    Object? filterList = null,
    Object? streetNameController = null,
    Object? streetNumberController = null,
    Object? emailController = null,
    Object? faxController = null,
    Object? cityController = null,
    Object? zipController = null,
    Object? image = null,
    Object? isLoading = null,
    Object? isUpdating = null,
    Object? isShimmering = null,
    Object? cityListResModel = freezed,
    Object? companyLogo = null,
    Object? isFileSizeExceeds = null,
    Object? isUploadProcess = null,
    Object? language = null,
  }) {
    return _then(_value.copyWith(
      selectCity: null == selectCity
          ? _value.selectCity
          : selectCity // ignore: cast_nullable_to_non_nullable
              as String,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      cityList: null == cityList
          ? _value.cityList
          : cityList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      filterList: null == filterList
          ? _value.filterList
          : filterList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      streetNameController: null == streetNameController
          ? _value.streetNameController
          : streetNameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      streetNumberController: null == streetNumberController
          ? _value.streetNumberController
          : streetNumberController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      emailController: null == emailController
          ? _value.emailController
          : emailController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      faxController: null == faxController
          ? _value.faxController
          : faxController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      cityController: null == cityController
          ? _value.cityController
          : cityController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      zipController: null == zipController
          ? _value.zipController
          : zipController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as File,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdating: null == isUpdating
          ? _value.isUpdating
          : isUpdating // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      cityListResModel: freezed == cityListResModel
          ? _value.cityListResModel
          : cityListResModel // ignore: cast_nullable_to_non_nullable
              as CityListResModel?,
      companyLogo: null == companyLogo
          ? _value.companyLogo
          : companyLogo // ignore: cast_nullable_to_non_nullable
              as String,
      isFileSizeExceeds: null == isFileSizeExceeds
          ? _value.isFileSizeExceeds
          : isFileSizeExceeds // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadProcess: null == isUploadProcess
          ? _value.isUploadProcess
          : isUploadProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $CityListResModelCopyWith<$Res>? get cityListResModel {
    if (_value.cityListResModel == null) {
      return null;
    }

    return $CityListResModelCopyWith<$Res>(_value.cityListResModel!, (value) {
      return _then(_value.copyWith(cityListResModel: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$MoreDetailsStateImplCopyWith<$Res>
    implements $MoreDetailsStateCopyWith<$Res> {
  factory _$$MoreDetailsStateImplCopyWith(_$MoreDetailsStateImpl value,
          $Res Function(_$MoreDetailsStateImpl) then) =
      __$$MoreDetailsStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String selectCity,
      bool isUpdate,
      List<String> cityList,
      List<String> filterList,
      TextEditingController streetNameController,
      TextEditingController streetNumberController,
      TextEditingController emailController,
      TextEditingController faxController,
      TextEditingController cityController,
      TextEditingController zipController,
      File image,
      bool isLoading,
      bool isUpdating,
      bool isShimmering,
      CityListResModel? cityListResModel,
      String companyLogo,
      bool isFileSizeExceeds,
      bool isUploadProcess,
      String language});

  @override
  $CityListResModelCopyWith<$Res>? get cityListResModel;
}

/// @nodoc
class __$$MoreDetailsStateImplCopyWithImpl<$Res>
    extends _$MoreDetailsStateCopyWithImpl<$Res, _$MoreDetailsStateImpl>
    implements _$$MoreDetailsStateImplCopyWith<$Res> {
  __$$MoreDetailsStateImplCopyWithImpl(_$MoreDetailsStateImpl _value,
      $Res Function(_$MoreDetailsStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? selectCity = null,
    Object? isUpdate = null,
    Object? cityList = null,
    Object? filterList = null,
    Object? streetNameController = null,
    Object? streetNumberController = null,
    Object? emailController = null,
    Object? faxController = null,
    Object? cityController = null,
    Object? zipController = null,
    Object? image = null,
    Object? isLoading = null,
    Object? isUpdating = null,
    Object? isShimmering = null,
    Object? cityListResModel = freezed,
    Object? companyLogo = null,
    Object? isFileSizeExceeds = null,
    Object? isUploadProcess = null,
    Object? language = null,
  }) {
    return _then(_$MoreDetailsStateImpl(
      selectCity: null == selectCity
          ? _value.selectCity
          : selectCity // ignore: cast_nullable_to_non_nullable
              as String,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      cityList: null == cityList
          ? _value._cityList
          : cityList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      filterList: null == filterList
          ? _value._filterList
          : filterList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      streetNameController: null == streetNameController
          ? _value.streetNameController
          : streetNameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      streetNumberController: null == streetNumberController
          ? _value.streetNumberController
          : streetNumberController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      emailController: null == emailController
          ? _value.emailController
          : emailController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      faxController: null == faxController
          ? _value.faxController
          : faxController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      cityController: null == cityController
          ? _value.cityController
          : cityController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      zipController: null == zipController
          ? _value.zipController
          : zipController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as File,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdating: null == isUpdating
          ? _value.isUpdating
          : isUpdating // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      cityListResModel: freezed == cityListResModel
          ? _value.cityListResModel
          : cityListResModel // ignore: cast_nullable_to_non_nullable
              as CityListResModel?,
      companyLogo: null == companyLogo
          ? _value.companyLogo
          : companyLogo // ignore: cast_nullable_to_non_nullable
              as String,
      isFileSizeExceeds: null == isFileSizeExceeds
          ? _value.isFileSizeExceeds
          : isFileSizeExceeds // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadProcess: null == isUploadProcess
          ? _value.isUploadProcess
          : isUploadProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$MoreDetailsStateImpl implements _MoreDetailsState {
  const _$MoreDetailsStateImpl(
      {required this.selectCity,
      required this.isUpdate,
      required final List<String> cityList,
      required final List<String> filterList,
      required this.streetNameController,
      required this.streetNumberController,
      required this.emailController,
      required this.faxController,
      required this.cityController,
      required this.zipController,
      required this.image,
      required this.isLoading,
      required this.isUpdating,
      required this.isShimmering,
      required this.cityListResModel,
      required this.companyLogo,
      required this.isFileSizeExceeds,
      required this.isUploadProcess,
      required this.language})
      : _cityList = cityList,
        _filterList = filterList;

  @override
  final String selectCity;
  @override
  final bool isUpdate;
  final List<String> _cityList;
  @override
  List<String> get cityList {
    if (_cityList is EqualUnmodifiableListView) return _cityList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_cityList);
  }

  final List<String> _filterList;
  @override
  List<String> get filterList {
    if (_filterList is EqualUnmodifiableListView) return _filterList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_filterList);
  }

  @override
  final TextEditingController streetNameController;
  @override
  final TextEditingController streetNumberController;
  @override
  final TextEditingController emailController;
  @override
  final TextEditingController faxController;
  @override
  final TextEditingController cityController;
  @override
  final TextEditingController zipController;
  @override
  final File image;
  @override
  final bool isLoading;
  @override
  final bool isUpdating;
  @override
  final bool isShimmering;
  @override
  final CityListResModel? cityListResModel;
  @override
  final String companyLogo;
  @override
  final bool isFileSizeExceeds;
  @override
  final bool isUploadProcess;
  @override
  final String language;

  @override
  String toString() {
    return 'MoreDetailsState(selectCity: $selectCity, isUpdate: $isUpdate, cityList: $cityList, filterList: $filterList, streetNameController: $streetNameController, streetNumberController: $streetNumberController, emailController: $emailController, faxController: $faxController, cityController: $cityController, zipController: $zipController, image: $image, isLoading: $isLoading, isUpdating: $isUpdating, isShimmering: $isShimmering, cityListResModel: $cityListResModel, companyLogo: $companyLogo, isFileSizeExceeds: $isFileSizeExceeds, isUploadProcess: $isUploadProcess, language: $language)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MoreDetailsStateImpl &&
            (identical(other.selectCity, selectCity) ||
                other.selectCity == selectCity) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            const DeepCollectionEquality().equals(other._cityList, _cityList) &&
            const DeepCollectionEquality()
                .equals(other._filterList, _filterList) &&
            (identical(other.streetNameController, streetNameController) ||
                other.streetNameController == streetNameController) &&
            (identical(other.streetNumberController, streetNumberController) ||
                other.streetNumberController == streetNumberController) &&
            (identical(other.emailController, emailController) ||
                other.emailController == emailController) &&
            (identical(other.faxController, faxController) ||
                other.faxController == faxController) &&
            (identical(other.cityController, cityController) ||
                other.cityController == cityController) &&
            (identical(other.zipController, zipController) ||
                other.zipController == zipController) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isUpdating, isUpdating) ||
                other.isUpdating == isUpdating) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.cityListResModel, cityListResModel) ||
                other.cityListResModel == cityListResModel) &&
            (identical(other.companyLogo, companyLogo) ||
                other.companyLogo == companyLogo) &&
            (identical(other.isFileSizeExceeds, isFileSizeExceeds) ||
                other.isFileSizeExceeds == isFileSizeExceeds) &&
            (identical(other.isUploadProcess, isUploadProcess) ||
                other.isUploadProcess == isUploadProcess) &&
            (identical(other.language, language) ||
                other.language == language));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        selectCity,
        isUpdate,
        const DeepCollectionEquality().hash(_cityList),
        const DeepCollectionEquality().hash(_filterList),
        streetNameController,
        streetNumberController,
        emailController,
        faxController,
        cityController,
        zipController,
        image,
        isLoading,
        isUpdating,
        isShimmering,
        cityListResModel,
        companyLogo,
        isFileSizeExceeds,
        isUploadProcess,
        language
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MoreDetailsStateImplCopyWith<_$MoreDetailsStateImpl> get copyWith =>
      __$$MoreDetailsStateImplCopyWithImpl<_$MoreDetailsStateImpl>(
          this, _$identity);
}

abstract class _MoreDetailsState implements MoreDetailsState {
  const factory _MoreDetailsState(
      {required final String selectCity,
      required final bool isUpdate,
      required final List<String> cityList,
      required final List<String> filterList,
      required final TextEditingController streetNameController,
      required final TextEditingController streetNumberController,
      required final TextEditingController emailController,
      required final TextEditingController faxController,
      required final TextEditingController cityController,
      required final TextEditingController zipController,
      required final File image,
      required final bool isLoading,
      required final bool isUpdating,
      required final bool isShimmering,
      required final CityListResModel? cityListResModel,
      required final String companyLogo,
      required final bool isFileSizeExceeds,
      required final bool isUploadProcess,
      required final String language}) = _$MoreDetailsStateImpl;

  @override
  String get selectCity;
  @override
  bool get isUpdate;
  @override
  List<String> get cityList;
  @override
  List<String> get filterList;
  @override
  TextEditingController get streetNameController;
  @override
  TextEditingController get streetNumberController;
  @override
  TextEditingController get emailController;
  @override
  TextEditingController get faxController;
  @override
  TextEditingController get cityController;
  @override
  TextEditingController get zipController;
  @override
  File get image;
  @override
  bool get isLoading;
  @override
  bool get isUpdating;
  @override
  bool get isShimmering;
  @override
  CityListResModel? get cityListResModel;
  @override
  String get companyLogo;
  @override
  bool get isFileSizeExceeds;
  @override
  bool get isUploadProcess;
  @override
  String get language;
  @override
  @JsonKey(ignore: true)
  _$$MoreDetailsStateImplCopyWith<_$MoreDetailsStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
