// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'connect_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ConnectEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) logInAsGuest,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? logInAsGuest,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? logInAsGuest,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LogInAsGuest value) logInAsGuest,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LogInAsGuest value)? logInAsGuest,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LogInAsGuest value)? logInAsGuest,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ConnectEventCopyWith<ConnectEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ConnectEventCopyWith<$Res> {
  factory $ConnectEventCopyWith(
          ConnectEvent value, $Res Function(ConnectEvent) then) =
      _$ConnectEventCopyWithImpl<$Res, ConnectEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$ConnectEventCopyWithImpl<$Res, $Val extends ConnectEvent>
    implements $ConnectEventCopyWith<$Res> {
  _$ConnectEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$LogInAsGuestImplCopyWith<$Res>
    implements $ConnectEventCopyWith<$Res> {
  factory _$$LogInAsGuestImplCopyWith(
          _$LogInAsGuestImpl value, $Res Function(_$LogInAsGuestImpl) then) =
      __$$LogInAsGuestImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$LogInAsGuestImplCopyWithImpl<$Res>
    extends _$ConnectEventCopyWithImpl<$Res, _$LogInAsGuestImpl>
    implements _$$LogInAsGuestImplCopyWith<$Res> {
  __$$LogInAsGuestImplCopyWithImpl(
      _$LogInAsGuestImpl _value, $Res Function(_$LogInAsGuestImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$LogInAsGuestImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$LogInAsGuestImpl implements _LogInAsGuest {
  _$LogInAsGuestImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ConnectEvent.logInAsGuest(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LogInAsGuestImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LogInAsGuestImplCopyWith<_$LogInAsGuestImpl> get copyWith =>
      __$$LogInAsGuestImplCopyWithImpl<_$LogInAsGuestImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) logInAsGuest,
  }) {
    return logInAsGuest(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? logInAsGuest,
  }) {
    return logInAsGuest?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? logInAsGuest,
    required TResult orElse(),
  }) {
    if (logInAsGuest != null) {
      return logInAsGuest(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LogInAsGuest value) logInAsGuest,
  }) {
    return logInAsGuest(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LogInAsGuest value)? logInAsGuest,
  }) {
    return logInAsGuest?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LogInAsGuest value)? logInAsGuest,
    required TResult orElse(),
  }) {
    if (logInAsGuest != null) {
      return logInAsGuest(this);
    }
    return orElse();
  }
}

abstract class _LogInAsGuest implements ConnectEvent {
  factory _LogInAsGuest({required final BuildContext context}) =
      _$LogInAsGuestImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$LogInAsGuestImplCopyWith<_$LogInAsGuestImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ConnectState {
  bool get isLoginSuccess => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isRegister => throw _privateConstructorUsedError;
  String get errorMessage => throw _privateConstructorUsedError;
  String get mobileErrorMessage => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ConnectStateCopyWith<ConnectState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ConnectStateCopyWith<$Res> {
  factory $ConnectStateCopyWith(
          ConnectState value, $Res Function(ConnectState) then) =
      _$ConnectStateCopyWithImpl<$Res, ConnectState>;
  @useResult
  $Res call(
      {bool isLoginSuccess,
      bool isLoading,
      bool isRegister,
      String errorMessage,
      String mobileErrorMessage});
}

/// @nodoc
class _$ConnectStateCopyWithImpl<$Res, $Val extends ConnectState>
    implements $ConnectStateCopyWith<$Res> {
  _$ConnectStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoginSuccess = null,
    Object? isLoading = null,
    Object? isRegister = null,
    Object? errorMessage = null,
    Object? mobileErrorMessage = null,
  }) {
    return _then(_value.copyWith(
      isLoginSuccess: null == isLoginSuccess
          ? _value.isLoginSuccess
          : isLoginSuccess // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      mobileErrorMessage: null == mobileErrorMessage
          ? _value.mobileErrorMessage
          : mobileErrorMessage // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ConnectStateImplCopyWith<$Res>
    implements $ConnectStateCopyWith<$Res> {
  factory _$$ConnectStateImplCopyWith(
          _$ConnectStateImpl value, $Res Function(_$ConnectStateImpl) then) =
      __$$ConnectStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isLoginSuccess,
      bool isLoading,
      bool isRegister,
      String errorMessage,
      String mobileErrorMessage});
}

/// @nodoc
class __$$ConnectStateImplCopyWithImpl<$Res>
    extends _$ConnectStateCopyWithImpl<$Res, _$ConnectStateImpl>
    implements _$$ConnectStateImplCopyWith<$Res> {
  __$$ConnectStateImplCopyWithImpl(
      _$ConnectStateImpl _value, $Res Function(_$ConnectStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoginSuccess = null,
    Object? isLoading = null,
    Object? isRegister = null,
    Object? errorMessage = null,
    Object? mobileErrorMessage = null,
  }) {
    return _then(_$ConnectStateImpl(
      isLoginSuccess: null == isLoginSuccess
          ? _value.isLoginSuccess
          : isLoginSuccess // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRegister: null == isRegister
          ? _value.isRegister
          : isRegister // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      mobileErrorMessage: null == mobileErrorMessage
          ? _value.mobileErrorMessage
          : mobileErrorMessage // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ConnectStateImpl implements _ConnectState {
  const _$ConnectStateImpl(
      {required this.isLoginSuccess,
      required this.isLoading,
      required this.isRegister,
      required this.errorMessage,
      required this.mobileErrorMessage});

  @override
  final bool isLoginSuccess;
  @override
  final bool isLoading;
  @override
  final bool isRegister;
  @override
  final String errorMessage;
  @override
  final String mobileErrorMessage;

  @override
  String toString() {
    return 'ConnectState(isLoginSuccess: $isLoginSuccess, isLoading: $isLoading, isRegister: $isRegister, errorMessage: $errorMessage, mobileErrorMessage: $mobileErrorMessage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ConnectStateImpl &&
            (identical(other.isLoginSuccess, isLoginSuccess) ||
                other.isLoginSuccess == isLoginSuccess) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isRegister, isRegister) ||
                other.isRegister == isRegister) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            (identical(other.mobileErrorMessage, mobileErrorMessage) ||
                other.mobileErrorMessage == mobileErrorMessage));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoginSuccess, isLoading,
      isRegister, errorMessage, mobileErrorMessage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ConnectStateImplCopyWith<_$ConnectStateImpl> get copyWith =>
      __$$ConnectStateImplCopyWithImpl<_$ConnectStateImpl>(this, _$identity);
}

abstract class _ConnectState implements ConnectState {
  const factory _ConnectState(
      {required final bool isLoginSuccess,
      required final bool isLoading,
      required final bool isRegister,
      required final String errorMessage,
      required final String mobileErrorMessage}) = _$ConnectStateImpl;

  @override
  bool get isLoginSuccess;
  @override
  bool get isLoading;
  @override
  bool get isRegister;
  @override
  String get errorMessage;
  @override
  String get mobileErrorMessage;
  @override
  @JsonKey(ignore: true)
  _$$ConnectStateImplCopyWith<_$ConnectStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
