// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'basket_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$BasketEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BasketEventCopyWith<$Res> {
  factory $BasketEventCopyWith(
          BasketEvent value, $Res Function(BasketEvent) then) =
      _$BasketEventCopyWithImpl<$Res, BasketEvent>;
}

/// @nodoc
class _$BasketEventCopyWithImpl<$Res, $Val extends BasketEvent>
    implements $BasketEventCopyWith<$Res> {
  _$BasketEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$productUpdateEventImplCopyWith<$Res> {
  factory _$$productUpdateEventImplCopyWith(_$productUpdateEventImpl value,
          $Res Function(_$productUpdateEventImpl) then) =
      __$$productUpdateEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {int productWeight,
      int listIndex,
      BuildContext context,
      String supplierId,
      String productId,
      String cartProductId,
      double totalPayment,
      String saleId});
}

/// @nodoc
class __$$productUpdateEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$productUpdateEventImpl>
    implements _$$productUpdateEventImplCopyWith<$Res> {
  __$$productUpdateEventImplCopyWithImpl(_$productUpdateEventImpl _value,
      $Res Function(_$productUpdateEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productWeight = null,
    Object? listIndex = null,
    Object? context = null,
    Object? supplierId = null,
    Object? productId = null,
    Object? cartProductId = null,
    Object? totalPayment = null,
    Object? saleId = null,
  }) {
    return _then(_$productUpdateEventImpl(
      productWeight: null == productWeight
          ? _value.productWeight
          : productWeight // ignore: cast_nullable_to_non_nullable
              as int,
      listIndex: null == listIndex
          ? _value.listIndex
          : listIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      cartProductId: null == cartProductId
          ? _value.cartProductId
          : cartProductId // ignore: cast_nullable_to_non_nullable
              as String,
      totalPayment: null == totalPayment
          ? _value.totalPayment
          : totalPayment // ignore: cast_nullable_to_non_nullable
              as double,
      saleId: null == saleId
          ? _value.saleId
          : saleId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$productUpdateEventImpl implements _productUpdateEvent {
  const _$productUpdateEventImpl(
      {required this.productWeight,
      required this.listIndex,
      required this.context,
      required this.supplierId,
      required this.productId,
      required this.cartProductId,
      required this.totalPayment,
      required this.saleId});

  @override
  final int productWeight;
  @override
  final int listIndex;
  @override
  final BuildContext context;
  @override
  final String supplierId;
  @override
  final String productId;
  @override
  final String cartProductId;
  @override
  final double totalPayment;
  @override
  final String saleId;

  @override
  String toString() {
    return 'BasketEvent.productUpdateEvent(productWeight: $productWeight, listIndex: $listIndex, context: $context, supplierId: $supplierId, productId: $productId, cartProductId: $cartProductId, totalPayment: $totalPayment, saleId: $saleId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$productUpdateEventImpl &&
            (identical(other.productWeight, productWeight) ||
                other.productWeight == productWeight) &&
            (identical(other.listIndex, listIndex) ||
                other.listIndex == listIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.cartProductId, cartProductId) ||
                other.cartProductId == cartProductId) &&
            (identical(other.totalPayment, totalPayment) ||
                other.totalPayment == totalPayment) &&
            (identical(other.saleId, saleId) || other.saleId == saleId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, productWeight, listIndex,
      context, supplierId, productId, cartProductId, totalPayment, saleId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$productUpdateEventImplCopyWith<_$productUpdateEventImpl> get copyWith =>
      __$$productUpdateEventImplCopyWithImpl<_$productUpdateEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return productUpdateEvent(productWeight, listIndex, context, supplierId,
        productId, cartProductId, totalPayment, saleId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return productUpdateEvent?.call(productWeight, listIndex, context,
        supplierId, productId, cartProductId, totalPayment, saleId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productUpdateEvent != null) {
      return productUpdateEvent(productWeight, listIndex, context, supplierId,
          productId, cartProductId, totalPayment, saleId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return productUpdateEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return productUpdateEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productUpdateEvent != null) {
      return productUpdateEvent(this);
    }
    return orElse();
  }
}

abstract class _productUpdateEvent implements BasketEvent {
  const factory _productUpdateEvent(
      {required final int productWeight,
      required final int listIndex,
      required final BuildContext context,
      required final String supplierId,
      required final String productId,
      required final String cartProductId,
      required final double totalPayment,
      required final String saleId}) = _$productUpdateEventImpl;

  int get productWeight;
  int get listIndex;
  BuildContext get context;
  String get supplierId;
  String get productId;
  String get cartProductId;
  double get totalPayment;
  String get saleId;
  @JsonKey(ignore: true)
  _$$productUpdateEventImplCopyWith<_$productUpdateEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$removeCartProductEventImplCopyWith<$Res> {
  factory _$$removeCartProductEventImplCopyWith(
          _$removeCartProductEventImpl value,
          $Res Function(_$removeCartProductEventImpl) then) =
      __$$removeCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {int listIndex,
      BuildContext dialogContext,
      BuildContext context,
      String cartProductId,
      double totalAmount});
}

/// @nodoc
class __$$removeCartProductEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$removeCartProductEventImpl>
    implements _$$removeCartProductEventImplCopyWith<$Res> {
  __$$removeCartProductEventImplCopyWithImpl(
      _$removeCartProductEventImpl _value,
      $Res Function(_$removeCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? listIndex = null,
    Object? dialogContext = null,
    Object? context = null,
    Object? cartProductId = null,
    Object? totalAmount = null,
  }) {
    return _then(_$removeCartProductEventImpl(
      listIndex: null == listIndex
          ? _value.listIndex
          : listIndex // ignore: cast_nullable_to_non_nullable
              as int,
      dialogContext: null == dialogContext
          ? _value.dialogContext
          : dialogContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      cartProductId: null == cartProductId
          ? _value.cartProductId
          : cartProductId // ignore: cast_nullable_to_non_nullable
              as String,
      totalAmount: null == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc

class _$removeCartProductEventImpl implements _removeCartProductEvent {
  const _$removeCartProductEventImpl(
      {required this.listIndex,
      required this.dialogContext,
      required this.context,
      required this.cartProductId,
      required this.totalAmount});

  @override
  final int listIndex;
  @override
  final BuildContext dialogContext;
  @override
  final BuildContext context;
  @override
  final String cartProductId;
  @override
  final double totalAmount;

  @override
  String toString() {
    return 'BasketEvent.removeCartProductEvent(listIndex: $listIndex, dialogContext: $dialogContext, context: $context, cartProductId: $cartProductId, totalAmount: $totalAmount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$removeCartProductEventImpl &&
            (identical(other.listIndex, listIndex) ||
                other.listIndex == listIndex) &&
            (identical(other.dialogContext, dialogContext) ||
                other.dialogContext == dialogContext) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.cartProductId, cartProductId) ||
                other.cartProductId == cartProductId) &&
            (identical(other.totalAmount, totalAmount) ||
                other.totalAmount == totalAmount));
  }

  @override
  int get hashCode => Object.hash(runtimeType, listIndex, dialogContext,
      context, cartProductId, totalAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$removeCartProductEventImplCopyWith<_$removeCartProductEventImpl>
      get copyWith => __$$removeCartProductEventImplCopyWithImpl<
          _$removeCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return removeCartProductEvent(
        listIndex, dialogContext, context, cartProductId, totalAmount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return removeCartProductEvent?.call(
        listIndex, dialogContext, context, cartProductId, totalAmount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (removeCartProductEvent != null) {
      return removeCartProductEvent(
          listIndex, dialogContext, context, cartProductId, totalAmount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return removeCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return removeCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (removeCartProductEvent != null) {
      return removeCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _removeCartProductEvent implements BasketEvent {
  const factory _removeCartProductEvent(
      {required final int listIndex,
      required final BuildContext dialogContext,
      required final BuildContext context,
      required final String cartProductId,
      required final double totalAmount}) = _$removeCartProductEventImpl;

  int get listIndex;
  BuildContext get dialogContext;
  BuildContext get context;
  String get cartProductId;
  double get totalAmount;
  @JsonKey(ignore: true)
  _$$removeCartProductEventImplCopyWith<_$removeCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getAllCartEventImplCopyWith<$Res> {
  factory _$$getAllCartEventImplCopyWith(_$getAllCartEventImpl value,
          $Res Function(_$getAllCartEventImpl) then) =
      __$$getAllCartEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getAllCartEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$getAllCartEventImpl>
    implements _$$getAllCartEventImplCopyWith<$Res> {
  __$$getAllCartEventImplCopyWithImpl(
      _$getAllCartEventImpl _value, $Res Function(_$getAllCartEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getAllCartEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getAllCartEventImpl implements _getAllCartEvent {
  const _$getAllCartEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BasketEvent.getAllCartEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getAllCartEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getAllCartEventImplCopyWith<_$getAllCartEventImpl> get copyWith =>
      __$$getAllCartEventImplCopyWithImpl<_$getAllCartEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getAllCartEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getAllCartEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAllCartEvent != null) {
      return getAllCartEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getAllCartEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getAllCartEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAllCartEvent != null) {
      return getAllCartEvent(this);
    }
    return orElse();
  }
}

abstract class _getAllCartEvent implements BasketEvent {
  const factory _getAllCartEvent({required final BuildContext context}) =
      _$getAllCartEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getAllCartEventImplCopyWith<_$getAllCartEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$clearCartEventImplCopyWith<$Res> {
  factory _$$clearCartEventImplCopyWith(_$clearCartEventImpl value,
          $Res Function(_$clearCartEventImpl) then) =
      __$$clearCartEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$clearCartEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$clearCartEventImpl>
    implements _$$clearCartEventImplCopyWith<$Res> {
  __$$clearCartEventImplCopyWithImpl(
      _$clearCartEventImpl _value, $Res Function(_$clearCartEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$clearCartEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$clearCartEventImpl implements _clearCartEvent {
  const _$clearCartEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BasketEvent.clearCartEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$clearCartEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$clearCartEventImplCopyWith<_$clearCartEventImpl> get copyWith =>
      __$$clearCartEventImplCopyWithImpl<_$clearCartEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return clearCartEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return clearCartEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (clearCartEvent != null) {
      return clearCartEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return clearCartEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return clearCartEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (clearCartEvent != null) {
      return clearCartEvent(this);
    }
    return orElse();
  }
}

abstract class _clearCartEvent implements BasketEvent {
  const factory _clearCartEvent({required final BuildContext context}) =
      _$clearCartEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$clearCartEventImplCopyWith<_$clearCartEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetCartCountEventImplCopyWith<$Res> {
  factory _$$SetCartCountEventImplCopyWith(_$SetCartCountEventImpl value,
          $Res Function(_$SetCartCountEventImpl) then) =
      __$$SetCartCountEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isClearCart});
}

/// @nodoc
class __$$SetCartCountEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$SetCartCountEventImpl>
    implements _$$SetCartCountEventImplCopyWith<$Res> {
  __$$SetCartCountEventImplCopyWithImpl(_$SetCartCountEventImpl _value,
      $Res Function(_$SetCartCountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isClearCart = null,
  }) {
    return _then(_$SetCartCountEventImpl(
      isClearCart: null == isClearCart
          ? _value.isClearCart
          : isClearCart // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$SetCartCountEventImpl implements _SetCartCountEvent {
  const _$SetCartCountEventImpl({required this.isClearCart});

  @override
  final bool isClearCart;

  @override
  String toString() {
    return 'BasketEvent.setCartCountEvent(isClearCart: $isClearCart)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SetCartCountEventImpl &&
            (identical(other.isClearCart, isClearCart) ||
                other.isClearCart == isClearCart));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isClearCart);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SetCartCountEventImplCopyWith<_$SetCartCountEventImpl> get copyWith =>
      __$$SetCartCountEventImplCopyWithImpl<_$SetCartCountEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return setCartCountEvent(isClearCart);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return setCartCountEvent?.call(isClearCart);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(isClearCart);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return setCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return setCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetCartCountEvent implements BasketEvent {
  const factory _SetCartCountEvent({required final bool isClearCart}) =
      _$SetCartCountEventImpl;

  bool get isClearCart;
  @JsonKey(ignore: true)
  _$$SetCartCountEventImplCopyWith<_$SetCartCountEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$updateImageIndexEventImplCopyWith<$Res> {
  factory _$$updateImageIndexEventImplCopyWith(
          _$updateImageIndexEventImpl value,
          $Res Function(_$updateImageIndexEventImpl) then) =
      __$$updateImageIndexEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$updateImageIndexEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$updateImageIndexEventImpl>
    implements _$$updateImageIndexEventImplCopyWith<$Res> {
  __$$updateImageIndexEventImplCopyWithImpl(_$updateImageIndexEventImpl _value,
      $Res Function(_$updateImageIndexEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$updateImageIndexEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$updateImageIndexEventImpl implements _updateImageIndexEvent {
  const _$updateImageIndexEventImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'BasketEvent.updateImageIndexEvent(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateImageIndexEventImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateImageIndexEventImplCopyWith<_$updateImageIndexEventImpl>
      get copyWith => __$$updateImageIndexEventImplCopyWithImpl<
          _$updateImageIndexEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateImageIndexEvent(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateImageIndexEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(this);
    }
    return orElse();
  }
}

abstract class _updateImageIndexEvent implements BasketEvent {
  const factory _updateImageIndexEvent({required final int index}) =
      _$updateImageIndexEventImpl;

  int get index;
  @JsonKey(ignore: true)
  _$$updateImageIndexEventImplCopyWith<_$updateImageIndexEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$orderSendEventImplCopyWith<$Res> {
  factory _$$orderSendEventImplCopyWith(_$orderSendEventImpl value,
          $Res Function(_$orderSendEventImpl) then) =
      __$$orderSendEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$orderSendEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$orderSendEventImpl>
    implements _$$orderSendEventImplCopyWith<$Res> {
  __$$orderSendEventImplCopyWithImpl(
      _$orderSendEventImpl _value, $Res Function(_$orderSendEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$orderSendEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$orderSendEventImpl implements _orderSendEvent {
  const _$orderSendEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BasketEvent.orderSendEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$orderSendEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$orderSendEventImplCopyWith<_$orderSendEventImpl> get copyWith =>
      __$$orderSendEventImplCopyWithImpl<_$orderSendEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return orderSendEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return orderSendEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (orderSendEvent != null) {
      return orderSendEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return orderSendEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return orderSendEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (orderSendEvent != null) {
      return orderSendEvent(this);
    }
    return orElse();
  }
}

abstract class _orderSendEvent implements BasketEvent {
  const factory _orderSendEvent({required final BuildContext context}) =
      _$orderSendEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$orderSendEventImplCopyWith<_$orderSendEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$IncreaseQuantityOfProductImplCopyWith(
          _$IncreaseQuantityOfProductImpl value,
          $Res Function(_$IncreaseQuantityOfProductImpl) then) =
      __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$IncreaseQuantityOfProductImpl>
    implements _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  __$$IncreaseQuantityOfProductImplCopyWithImpl(
      _$IncreaseQuantityOfProductImpl _value,
      $Res Function(_$IncreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$IncreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$IncreaseQuantityOfProductImpl implements _IncreaseQuantityOfProduct {
  const _$IncreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BasketEvent.increaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => __$$IncreaseQuantityOfProductImplCopyWithImpl<
          _$IncreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return increaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return increaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _IncreaseQuantityOfProduct implements BasketEvent {
  const factory _IncreaseQuantityOfProduct(
      {required final BuildContext context}) = _$IncreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$DecreaseQuantityOfProductImplCopyWith(
          _$DecreaseQuantityOfProductImpl value,
          $Res Function(_$DecreaseQuantityOfProductImpl) then) =
      __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$DecreaseQuantityOfProductImpl>
    implements _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  __$$DecreaseQuantityOfProductImplCopyWithImpl(
      _$DecreaseQuantityOfProductImpl _value,
      $Res Function(_$DecreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DecreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DecreaseQuantityOfProductImpl implements _DecreaseQuantityOfProduct {
  const _$DecreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BasketEvent.decreaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DecreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => __$$DecreaseQuantityOfProductImplCopyWithImpl<
          _$DecreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _DecreaseQuantityOfProduct implements BasketEvent {
  const factory _DecreaseQuantityOfProduct(
      {required final BuildContext context}) = _$DecreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  factory _$$UpdateQuantityOfProductImplCopyWith(
          _$UpdateQuantityOfProductImpl value,
          $Res Function(_$UpdateQuantityOfProductImpl) then) =
      __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String quantity});
}

/// @nodoc
class __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$UpdateQuantityOfProductImpl>
    implements _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  __$$UpdateQuantityOfProductImplCopyWithImpl(
      _$UpdateQuantityOfProductImpl _value,
      $Res Function(_$UpdateQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? quantity = null,
  }) {
    return _then(_$UpdateQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UpdateQuantityOfProductImpl implements _UpdateQuantityOfProduct {
  const _$UpdateQuantityOfProductImpl(
      {required this.context, required this.quantity});

  @override
  final BuildContext context;
  @override
  final String quantity;

  @override
  String toString() {
    return 'BasketEvent.updateQuantityOfProduct(context: $context, quantity: $quantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, quantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => __$$UpdateQuantityOfProductImplCopyWithImpl<
          _$UpdateQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateQuantityOfProduct(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(context, quantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _UpdateQuantityOfProduct implements BasketEvent {
  const factory _UpdateQuantityOfProduct(
      {required final BuildContext context,
      required final String quantity}) = _$UpdateQuantityOfProductImpl;

  BuildContext get context;
  String get quantity;
  @JsonKey(ignore: true)
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductDetailsEventImplCopyWith<$Res> {
  factory _$$GetProductDetailsEventImplCopyWith(
          _$GetProductDetailsEventImpl value,
          $Res Function(_$GetProductDetailsEventImpl) then) =
      __$$GetProductDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      bool isBarcode,
      int productListIndex,
      String productId});
}

/// @nodoc
class __$$GetProductDetailsEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$GetProductDetailsEventImpl>
    implements _$$GetProductDetailsEventImplCopyWith<$Res> {
  __$$GetProductDetailsEventImplCopyWithImpl(
      _$GetProductDetailsEventImpl _value,
      $Res Function(_$GetProductDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isBarcode = null,
    Object? productListIndex = null,
    Object? productId = null,
  }) {
    return _then(_$GetProductDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetProductDetailsEventImpl implements _GetProductDetailsEvent {
  const _$GetProductDetailsEventImpl(
      {required this.context,
      required this.isBarcode,
      required this.productListIndex,
      required this.productId});

  @override
  final BuildContext context;
  @override
  final bool isBarcode;
  @override
  final int productListIndex;
  @override
  final String productId;

  @override
  String toString() {
    return 'BasketEvent.getProductDetailsEvent(context: $context, isBarcode: $isBarcode, productListIndex: $productListIndex, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode) &&
            (identical(other.productListIndex, productListIndex) ||
                other.productListIndex == productListIndex) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, isBarcode, productListIndex, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => __$$GetProductDetailsEventImplCopyWithImpl<
          _$GetProductDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductDetailsEvent(
        context, isBarcode, productListIndex, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(
        context, isBarcode, productListIndex, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(
          context, isBarcode, productListIndex, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductDetailsEvent implements BasketEvent {
  const factory _GetProductDetailsEvent(
      {required final BuildContext context,
      required final bool isBarcode,
      required final int productListIndex,
      required final String productId}) = _$GetProductDetailsEventImpl;

  BuildContext get context;
  bool get isBarcode;
  int get productListIndex;
  String get productId;
  @JsonKey(ignore: true)
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddToCartProductEventImplCopyWith<$Res> {
  factory _$$AddToCartProductEventImplCopyWith(
          _$AddToCartProductEventImpl value,
          $Res Function(_$AddToCartProductEventImpl) then) =
      __$$AddToCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$AddToCartProductEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$AddToCartProductEventImpl>
    implements _$$AddToCartProductEventImplCopyWith<$Res> {
  __$$AddToCartProductEventImplCopyWithImpl(_$AddToCartProductEventImpl _value,
      $Res Function(_$AddToCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$AddToCartProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AddToCartProductEventImpl implements _AddToCartProductEvent {
  const _$AddToCartProductEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'BasketEvent.addToCartProductEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddToCartProductEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => __$$AddToCartProductEventImplCopyWithImpl<
          _$AddToCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return addToCartProductEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return addToCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _AddToCartProductEvent implements BasketEvent {
  const factory _AddToCartProductEvent(
      {required final BuildContext context,
      required final String productId}) = _$AddToCartProductEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SupplierSelectionEventImplCopyWith<$Res> {
  factory _$$SupplierSelectionEventImplCopyWith(
          _$SupplierSelectionEventImpl value,
          $Res Function(_$SupplierSelectionEventImpl) then) =
      __$$SupplierSelectionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int supplierIndex, BuildContext context, int supplierSaleIndex});
}

/// @nodoc
class __$$SupplierSelectionEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$SupplierSelectionEventImpl>
    implements _$$SupplierSelectionEventImplCopyWith<$Res> {
  __$$SupplierSelectionEventImplCopyWithImpl(
      _$SupplierSelectionEventImpl _value,
      $Res Function(_$SupplierSelectionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierIndex = null,
    Object? context = null,
    Object? supplierSaleIndex = null,
  }) {
    return _then(_$SupplierSelectionEventImpl(
      supplierIndex: null == supplierIndex
          ? _value.supplierIndex
          : supplierIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierSaleIndex: null == supplierSaleIndex
          ? _value.supplierSaleIndex
          : supplierSaleIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SupplierSelectionEventImpl implements _SupplierSelectionEvent {
  const _$SupplierSelectionEventImpl(
      {required this.supplierIndex,
      required this.context,
      required this.supplierSaleIndex});

  @override
  final int supplierIndex;
  @override
  final BuildContext context;
  @override
  final int supplierSaleIndex;

  @override
  String toString() {
    return 'BasketEvent.supplierSelectionEvent(supplierIndex: $supplierIndex, context: $context, supplierSaleIndex: $supplierSaleIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSelectionEventImpl &&
            (identical(other.supplierIndex, supplierIndex) ||
                other.supplierIndex == supplierIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierSaleIndex, supplierSaleIndex) ||
                other.supplierSaleIndex == supplierSaleIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, supplierIndex, context, supplierSaleIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => __$$SupplierSelectionEventImplCopyWithImpl<
          _$SupplierSelectionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(
        supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return supplierSelectionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(this);
    }
    return orElse();
  }
}

abstract class _SupplierSelectionEvent implements BasketEvent {
  const factory _SupplierSelectionEvent(
      {required final int supplierIndex,
      required final BuildContext context,
      required final int supplierSaleIndex}) = _$SupplierSelectionEventImpl;

  int get supplierIndex;
  BuildContext get context;
  int get supplierSaleIndex;
  @JsonKey(ignore: true)
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RelatedProductsEventImplCopyWith<$Res> {
  factory _$$RelatedProductsEventImplCopyWith(_$RelatedProductsEventImpl value,
          $Res Function(_$RelatedProductsEventImpl) then) =
      __$$RelatedProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$RelatedProductsEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$RelatedProductsEventImpl>
    implements _$$RelatedProductsEventImplCopyWith<$Res> {
  __$$RelatedProductsEventImplCopyWithImpl(_$RelatedProductsEventImpl _value,
      $Res Function(_$RelatedProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$RelatedProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RelatedProductsEventImpl implements _RelatedProductsEvent {
  const _$RelatedProductsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'BasketEvent.RelatedProductsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith =>
          __$$RelatedProductsEventImplCopyWithImpl<_$RelatedProductsEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RelatedProductsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RelatedProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _RelatedProductsEvent implements BasketEvent {
  const factory _RelatedProductsEvent(
      {required final BuildContext context,
      required final String productId}) = _$RelatedProductsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  factory _$$RemoveRelatedProductEventImplCopyWith(
          _$RemoveRelatedProductEventImpl value,
          $Res Function(_$RemoveRelatedProductEventImpl) then) =
      __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$RemoveRelatedProductEventImpl>
    implements _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  __$$RemoveRelatedProductEventImplCopyWithImpl(
      _$RemoveRelatedProductEventImpl _value,
      $Res Function(_$RemoveRelatedProductEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$RemoveRelatedProductEventImpl implements _RemoveRelatedProductEvent {
  const _$RemoveRelatedProductEventImpl();

  @override
  String toString() {
    return 'BasketEvent.RemoveRelatedProductEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveRelatedProductEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RemoveRelatedProductEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RemoveRelatedProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveRelatedProductEvent implements BasketEvent {
  const factory _RemoveRelatedProductEvent() = _$RemoveRelatedProductEventImpl;
}

/// @nodoc
abstract class _$$refreshEventImplCopyWith<$Res> {
  factory _$$refreshEventImplCopyWith(
          _$refreshEventImpl value, $Res Function(_$refreshEventImpl) then) =
      __$$refreshEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$refreshEventImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$refreshEventImpl>
    implements _$$refreshEventImplCopyWith<$Res> {
  __$$refreshEventImplCopyWithImpl(
      _$refreshEventImpl _value, $Res Function(_$refreshEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$refreshEventImpl implements _refreshEvent {
  const _$refreshEventImpl();

  @override
  String toString() {
    return 'BasketEvent.refreshEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$refreshEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return refreshEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return refreshEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (refreshEvent != null) {
      return refreshEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return refreshEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return refreshEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (refreshEvent != null) {
      return refreshEvent(this);
    }
    return orElse();
  }
}

abstract class _refreshEvent implements BasketEvent {
  const factory _refreshEvent() = _$refreshEventImpl;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$BasketEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'BasketEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)
        productUpdateEvent,
    required TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)
        removeCartProductEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) clearCartEvent,
    required TResult Function(bool isClearCart) setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(BuildContext context) orderSendEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() refreshEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult? Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? clearCartEvent,
    TResult? Function(bool isClearCart)? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(BuildContext context)? orderSendEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(BuildContext context, bool isBarcode,
            int productListIndex, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? refreshEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            int productWeight,
            int listIndex,
            BuildContext context,
            String supplierId,
            String productId,
            String cartProductId,
            double totalPayment,
            String saleId)?
        productUpdateEvent,
    TResult Function(int listIndex, BuildContext dialogContext,
            BuildContext context, String cartProductId, double totalAmount)?
        removeCartProductEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? clearCartEvent,
    TResult Function(bool isClearCart)? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(BuildContext context)? orderSendEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(BuildContext context, bool isBarcode, int productListIndex,
            String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? refreshEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productUpdateEvent value) productUpdateEvent,
    required TResult Function(_removeCartProductEvent value)
        removeCartProductEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_clearCartEvent value) clearCartEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_updateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_orderSendEvent value) orderSendEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_refreshEvent value) refreshEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productUpdateEvent value)? productUpdateEvent,
    TResult? Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_clearCartEvent value)? clearCartEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_orderSendEvent value)? orderSendEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_refreshEvent value)? refreshEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productUpdateEvent value)? productUpdateEvent,
    TResult Function(_removeCartProductEvent value)? removeCartProductEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_clearCartEvent value)? clearCartEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_updateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_orderSendEvent value)? orderSendEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_refreshEvent value)? refreshEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements BasketEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$BasketState {
  GetAllCartResModel get CartItemList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  double get productWeight => throw _privateConstructorUsedError;
  List<ProductDetailsModel> get basketProductList =>
      throw _privateConstructorUsedError;
  double get totalPayment => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  int get productImageIndex => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  int get cartCount => throw _privateConstructorUsedError;
  bool get isRemoveProcess => throw _privateConstructorUsedError;
  double get vatPercentage => throw _privateConstructorUsedError;
  int get supplierCount => throw _privateConstructorUsedError;
  double get bottleTax => throw _privateConstructorUsedError;
  int? get bottleQty => throw _privateConstructorUsedError;
  List<List<ProductStockModel>> get productStockList =>
      throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  bool get isCartCountChange => throw _privateConstructorUsedError;
  List<Product> get productDetails => throw _privateConstructorUsedError;
  bool get isProductLoading => throw _privateConstructorUsedError;
  List<ProductSupplierModel> get productSupplierList =>
      throw _privateConstructorUsedError;
  bool get isQtyUpdated => throw _privateConstructorUsedError;
  bool get isSelectSupplier => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get relatedProductList =>
      throw _privateConstructorUsedError;
  bool get isRelatedShimmering => throw _privateConstructorUsedError;
  int get productListIndex => throw _privateConstructorUsedError;
  bool get isAnimation => throw _privateConstructorUsedError;
  bool get isOrderPending => throw _privateConstructorUsedError;
  bool get isSubUserAddToBasket => throw _privateConstructorUsedError;
  bool get isSubUserCanCreateOrder => throw _privateConstructorUsedError;
  bool get isAccountPermissionShimmering => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $BasketStateCopyWith<BasketState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BasketStateCopyWith<$Res> {
  factory $BasketStateCopyWith(
          BasketState value, $Res Function(BasketState) then) =
      _$BasketStateCopyWithImpl<$Res, BasketState>;
  @useResult
  $Res call(
      {GetAllCartResModel CartItemList,
      bool isShimmering,
      double productWeight,
      List<ProductDetailsModel> basketProductList,
      double totalPayment,
      bool isLoading,
      int productImageIndex,
      String language,
      int cartCount,
      bool isRemoveProcess,
      double vatPercentage,
      int supplierCount,
      double bottleTax,
      int? bottleQty,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      bool isCartCountChange,
      List<Product> productDetails,
      bool isProductLoading,
      List<ProductSupplierModel> productSupplierList,
      bool isQtyUpdated,
      bool isSelectSupplier,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      int productListIndex,
      bool isAnimation,
      bool isOrderPending,
      bool isSubUserAddToBasket,
      bool isSubUserCanCreateOrder,
      bool isAccountPermissionShimmering});

  $GetAllCartResModelCopyWith<$Res> get CartItemList;
}

/// @nodoc
class _$BasketStateCopyWithImpl<$Res, $Val extends BasketState>
    implements $BasketStateCopyWith<$Res> {
  _$BasketStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? CartItemList = null,
    Object? isShimmering = null,
    Object? productWeight = null,
    Object? basketProductList = null,
    Object? totalPayment = null,
    Object? isLoading = null,
    Object? productImageIndex = null,
    Object? language = null,
    Object? cartCount = null,
    Object? isRemoveProcess = null,
    Object? vatPercentage = null,
    Object? supplierCount = null,
    Object? bottleTax = null,
    Object? bottleQty = freezed,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isCartCountChange = null,
    Object? productDetails = null,
    Object? isProductLoading = null,
    Object? productSupplierList = null,
    Object? isQtyUpdated = null,
    Object? isSelectSupplier = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? productListIndex = null,
    Object? isAnimation = null,
    Object? isOrderPending = null,
    Object? isSubUserAddToBasket = null,
    Object? isSubUserCanCreateOrder = null,
    Object? isAccountPermissionShimmering = null,
  }) {
    return _then(_value.copyWith(
      CartItemList: null == CartItemList
          ? _value.CartItemList
          : CartItemList // ignore: cast_nullable_to_non_nullable
              as GetAllCartResModel,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      productWeight: null == productWeight
          ? _value.productWeight
          : productWeight // ignore: cast_nullable_to_non_nullable
              as double,
      basketProductList: null == basketProductList
          ? _value.basketProductList
          : basketProductList // ignore: cast_nullable_to_non_nullable
              as List<ProductDetailsModel>,
      totalPayment: null == totalPayment
          ? _value.totalPayment
          : totalPayment // ignore: cast_nullable_to_non_nullable
              as double,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productImageIndex: null == productImageIndex
          ? _value.productImageIndex
          : productImageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      vatPercentage: null == vatPercentage
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      supplierCount: null == supplierCount
          ? _value.supplierCount
          : supplierCount // ignore: cast_nullable_to_non_nullable
              as int,
      bottleTax: null == bottleTax
          ? _value.bottleTax
          : bottleTax // ignore: cast_nullable_to_non_nullable
              as double,
      bottleQty: freezed == bottleQty
          ? _value.bottleQty
          : bottleQty // ignore: cast_nullable_to_non_nullable
              as int?,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value.productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isQtyUpdated: null == isQtyUpdated
          ? _value.isQtyUpdated
          : isQtyUpdated // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value.relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isAnimation: null == isAnimation
          ? _value.isAnimation
          : isAnimation // ignore: cast_nullable_to_non_nullable
              as bool,
      isOrderPending: null == isOrderPending
          ? _value.isOrderPending
          : isOrderPending // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCanCreateOrder: null == isSubUserCanCreateOrder
          ? _value.isSubUserCanCreateOrder
          : isSubUserCanCreateOrder // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $GetAllCartResModelCopyWith<$Res> get CartItemList {
    return $GetAllCartResModelCopyWith<$Res>(_value.CartItemList, (value) {
      return _then(_value.copyWith(CartItemList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$BasketStateImplCopyWith<$Res>
    implements $BasketStateCopyWith<$Res> {
  factory _$$BasketStateImplCopyWith(
          _$BasketStateImpl value, $Res Function(_$BasketStateImpl) then) =
      __$$BasketStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {GetAllCartResModel CartItemList,
      bool isShimmering,
      double productWeight,
      List<ProductDetailsModel> basketProductList,
      double totalPayment,
      bool isLoading,
      int productImageIndex,
      String language,
      int cartCount,
      bool isRemoveProcess,
      double vatPercentage,
      int supplierCount,
      double bottleTax,
      int? bottleQty,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      bool isCartCountChange,
      List<Product> productDetails,
      bool isProductLoading,
      List<ProductSupplierModel> productSupplierList,
      bool isQtyUpdated,
      bool isSelectSupplier,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      int productListIndex,
      bool isAnimation,
      bool isOrderPending,
      bool isSubUserAddToBasket,
      bool isSubUserCanCreateOrder,
      bool isAccountPermissionShimmering});

  @override
  $GetAllCartResModelCopyWith<$Res> get CartItemList;
}

/// @nodoc
class __$$BasketStateImplCopyWithImpl<$Res>
    extends _$BasketStateCopyWithImpl<$Res, _$BasketStateImpl>
    implements _$$BasketStateImplCopyWith<$Res> {
  __$$BasketStateImplCopyWithImpl(
      _$BasketStateImpl _value, $Res Function(_$BasketStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? CartItemList = null,
    Object? isShimmering = null,
    Object? productWeight = null,
    Object? basketProductList = null,
    Object? totalPayment = null,
    Object? isLoading = null,
    Object? productImageIndex = null,
    Object? language = null,
    Object? cartCount = null,
    Object? isRemoveProcess = null,
    Object? vatPercentage = null,
    Object? supplierCount = null,
    Object? bottleTax = null,
    Object? bottleQty = freezed,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isCartCountChange = null,
    Object? productDetails = null,
    Object? isProductLoading = null,
    Object? productSupplierList = null,
    Object? isQtyUpdated = null,
    Object? isSelectSupplier = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? productListIndex = null,
    Object? isAnimation = null,
    Object? isOrderPending = null,
    Object? isSubUserAddToBasket = null,
    Object? isSubUserCanCreateOrder = null,
    Object? isAccountPermissionShimmering = null,
  }) {
    return _then(_$BasketStateImpl(
      CartItemList: null == CartItemList
          ? _value.CartItemList
          : CartItemList // ignore: cast_nullable_to_non_nullable
              as GetAllCartResModel,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      productWeight: null == productWeight
          ? _value.productWeight
          : productWeight // ignore: cast_nullable_to_non_nullable
              as double,
      basketProductList: null == basketProductList
          ? _value._basketProductList
          : basketProductList // ignore: cast_nullable_to_non_nullable
              as List<ProductDetailsModel>,
      totalPayment: null == totalPayment
          ? _value.totalPayment
          : totalPayment // ignore: cast_nullable_to_non_nullable
              as double,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productImageIndex: null == productImageIndex
          ? _value.productImageIndex
          : productImageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      vatPercentage: null == vatPercentage
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      supplierCount: null == supplierCount
          ? _value.supplierCount
          : supplierCount // ignore: cast_nullable_to_non_nullable
              as int,
      bottleTax: null == bottleTax
          ? _value.bottleTax
          : bottleTax // ignore: cast_nullable_to_non_nullable
              as double,
      bottleQty: freezed == bottleQty
          ? _value.bottleQty
          : bottleQty // ignore: cast_nullable_to_non_nullable
              as int?,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value._productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value._productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isQtyUpdated: null == isQtyUpdated
          ? _value.isQtyUpdated
          : isQtyUpdated // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value._relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isAnimation: null == isAnimation
          ? _value.isAnimation
          : isAnimation // ignore: cast_nullable_to_non_nullable
              as bool,
      isOrderPending: null == isOrderPending
          ? _value.isOrderPending
          : isOrderPending // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCanCreateOrder: null == isSubUserCanCreateOrder
          ? _value.isSubUserCanCreateOrder
          : isSubUserCanCreateOrder // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$BasketStateImpl implements _BasketState {
  const _$BasketStateImpl(
      {required this.CartItemList,
      required this.isShimmering,
      required this.productWeight,
      required final List<ProductDetailsModel> basketProductList,
      required this.totalPayment,
      required this.isLoading,
      required this.productImageIndex,
      required this.language,
      required this.cartCount,
      required this.isRemoveProcess,
      required this.vatPercentage,
      required this.supplierCount,
      required this.bottleTax,
      required this.bottleQty,
      required final List<List<ProductStockModel>> productStockList,
      required this.productStockUpdateIndex,
      required this.isCartCountChange,
      required final List<Product> productDetails,
      required this.isProductLoading,
      required final List<ProductSupplierModel> productSupplierList,
      required this.isQtyUpdated,
      required this.isSelectSupplier,
      required final List<RelatedProductDatum> relatedProductList,
      required this.isRelatedShimmering,
      required this.productListIndex,
      required this.isAnimation,
      required this.isOrderPending,
      required this.isSubUserAddToBasket,
      required this.isSubUserCanCreateOrder,
      required this.isAccountPermissionShimmering})
      : _basketProductList = basketProductList,
        _productStockList = productStockList,
        _productDetails = productDetails,
        _productSupplierList = productSupplierList,
        _relatedProductList = relatedProductList;

  @override
  final GetAllCartResModel CartItemList;
  @override
  final bool isShimmering;
  @override
  final double productWeight;
  final List<ProductDetailsModel> _basketProductList;
  @override
  List<ProductDetailsModel> get basketProductList {
    if (_basketProductList is EqualUnmodifiableListView)
      return _basketProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_basketProductList);
  }

  @override
  final double totalPayment;
  @override
  final bool isLoading;
  @override
  final int productImageIndex;
  @override
  final String language;
  @override
  final int cartCount;
  @override
  final bool isRemoveProcess;
  @override
  final double vatPercentage;
  @override
  final int supplierCount;
  @override
  final double bottleTax;
  @override
  final int? bottleQty;
  final List<List<ProductStockModel>> _productStockList;
  @override
  List<List<ProductStockModel>> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final int productStockUpdateIndex;
  @override
  final bool isCartCountChange;
  final List<Product> _productDetails;
  @override
  List<Product> get productDetails {
    if (_productDetails is EqualUnmodifiableListView) return _productDetails;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productDetails);
  }

  @override
  final bool isProductLoading;
  final List<ProductSupplierModel> _productSupplierList;
  @override
  List<ProductSupplierModel> get productSupplierList {
    if (_productSupplierList is EqualUnmodifiableListView)
      return _productSupplierList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSupplierList);
  }

  @override
  final bool isQtyUpdated;
  @override
  final bool isSelectSupplier;
  final List<RelatedProductDatum> _relatedProductList;
  @override
  List<RelatedProductDatum> get relatedProductList {
    if (_relatedProductList is EqualUnmodifiableListView)
      return _relatedProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedProductList);
  }

  @override
  final bool isRelatedShimmering;
  @override
  final int productListIndex;
  @override
  final bool isAnimation;
  @override
  final bool isOrderPending;
  @override
  final bool isSubUserAddToBasket;
  @override
  final bool isSubUserCanCreateOrder;
  @override
  final bool isAccountPermissionShimmering;

  @override
  String toString() {
    return 'BasketState(CartItemList: $CartItemList, isShimmering: $isShimmering, productWeight: $productWeight, basketProductList: $basketProductList, totalPayment: $totalPayment, isLoading: $isLoading, productImageIndex: $productImageIndex, language: $language, cartCount: $cartCount, isRemoveProcess: $isRemoveProcess, vatPercentage: $vatPercentage, supplierCount: $supplierCount, bottleTax: $bottleTax, bottleQty: $bottleQty, productStockList: $productStockList, productStockUpdateIndex: $productStockUpdateIndex, isCartCountChange: $isCartCountChange, productDetails: $productDetails, isProductLoading: $isProductLoading, productSupplierList: $productSupplierList, isQtyUpdated: $isQtyUpdated, isSelectSupplier: $isSelectSupplier, relatedProductList: $relatedProductList, isRelatedShimmering: $isRelatedShimmering, productListIndex: $productListIndex, isAnimation: $isAnimation, isOrderPending: $isOrderPending, isSubUserAddToBasket: $isSubUserAddToBasket, isSubUserCanCreateOrder: $isSubUserCanCreateOrder, isAccountPermissionShimmering: $isAccountPermissionShimmering)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BasketStateImpl &&
            (identical(other.CartItemList, CartItemList) ||
                other.CartItemList == CartItemList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.productWeight, productWeight) ||
                other.productWeight == productWeight) &&
            const DeepCollectionEquality()
                .equals(other._basketProductList, _basketProductList) &&
            (identical(other.totalPayment, totalPayment) ||
                other.totalPayment == totalPayment) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.productImageIndex, productImageIndex) ||
                other.productImageIndex == productImageIndex) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.cartCount, cartCount) ||
                other.cartCount == cartCount) &&
            (identical(other.isRemoveProcess, isRemoveProcess) ||
                other.isRemoveProcess == isRemoveProcess) &&
            (identical(other.vatPercentage, vatPercentage) ||
                other.vatPercentage == vatPercentage) &&
            (identical(other.supplierCount, supplierCount) ||
                other.supplierCount == supplierCount) &&
            (identical(other.bottleTax, bottleTax) ||
                other.bottleTax == bottleTax) &&
            (identical(other.bottleQty, bottleQty) ||
                other.bottleQty == bottleQty) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(
                    other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(other.isCartCountChange, isCartCountChange) ||
                other.isCartCountChange == isCartCountChange) &&
            const DeepCollectionEquality()
                .equals(other._productDetails, _productDetails) &&
            (identical(other.isProductLoading, isProductLoading) ||
                other.isProductLoading == isProductLoading) &&
            const DeepCollectionEquality()
                .equals(other._productSupplierList, _productSupplierList) &&
            (identical(other.isQtyUpdated, isQtyUpdated) ||
                other.isQtyUpdated == isQtyUpdated) &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier) &&
            const DeepCollectionEquality()
                .equals(other._relatedProductList, _relatedProductList) &&
            (identical(other.isRelatedShimmering, isRelatedShimmering) ||
                other.isRelatedShimmering == isRelatedShimmering) &&
            (identical(other.productListIndex, productListIndex) ||
                other.productListIndex == productListIndex) &&
            (identical(other.isAnimation, isAnimation) ||
                other.isAnimation == isAnimation) &&
            (identical(other.isOrderPending, isOrderPending) ||
                other.isOrderPending == isOrderPending) &&
            (identical(other.isSubUserAddToBasket, isSubUserAddToBasket) ||
                other.isSubUserAddToBasket == isSubUserAddToBasket) &&
            (identical(
                    other.isSubUserCanCreateOrder, isSubUserCanCreateOrder) ||
                other.isSubUserCanCreateOrder == isSubUserCanCreateOrder) &&
            (identical(other.isAccountPermissionShimmering,
                    isAccountPermissionShimmering) ||
                other.isAccountPermissionShimmering ==
                    isAccountPermissionShimmering));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        CartItemList,
        isShimmering,
        productWeight,
        const DeepCollectionEquality().hash(_basketProductList),
        totalPayment,
        isLoading,
        productImageIndex,
        language,
        cartCount,
        isRemoveProcess,
        vatPercentage,
        supplierCount,
        bottleTax,
        bottleQty,
        const DeepCollectionEquality().hash(_productStockList),
        productStockUpdateIndex,
        isCartCountChange,
        const DeepCollectionEquality().hash(_productDetails),
        isProductLoading,
        const DeepCollectionEquality().hash(_productSupplierList),
        isQtyUpdated,
        isSelectSupplier,
        const DeepCollectionEquality().hash(_relatedProductList),
        isRelatedShimmering,
        productListIndex,
        isAnimation,
        isOrderPending,
        isSubUserAddToBasket,
        isSubUserCanCreateOrder,
        isAccountPermissionShimmering
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BasketStateImplCopyWith<_$BasketStateImpl> get copyWith =>
      __$$BasketStateImplCopyWithImpl<_$BasketStateImpl>(this, _$identity);
}

abstract class _BasketState implements BasketState {
  const factory _BasketState(
      {required final GetAllCartResModel CartItemList,
      required final bool isShimmering,
      required final double productWeight,
      required final List<ProductDetailsModel> basketProductList,
      required final double totalPayment,
      required final bool isLoading,
      required final int productImageIndex,
      required final String language,
      required final int cartCount,
      required final bool isRemoveProcess,
      required final double vatPercentage,
      required final int supplierCount,
      required final double bottleTax,
      required final int? bottleQty,
      required final List<List<ProductStockModel>> productStockList,
      required final int productStockUpdateIndex,
      required final bool isCartCountChange,
      required final List<Product> productDetails,
      required final bool isProductLoading,
      required final List<ProductSupplierModel> productSupplierList,
      required final bool isQtyUpdated,
      required final bool isSelectSupplier,
      required final List<RelatedProductDatum> relatedProductList,
      required final bool isRelatedShimmering,
      required final int productListIndex,
      required final bool isAnimation,
      required final bool isOrderPending,
      required final bool isSubUserAddToBasket,
      required final bool isSubUserCanCreateOrder,
      required final bool isAccountPermissionShimmering}) = _$BasketStateImpl;

  @override
  GetAllCartResModel get CartItemList;
  @override
  bool get isShimmering;
  @override
  double get productWeight;
  @override
  List<ProductDetailsModel> get basketProductList;
  @override
  double get totalPayment;
  @override
  bool get isLoading;
  @override
  int get productImageIndex;
  @override
  String get language;
  @override
  int get cartCount;
  @override
  bool get isRemoveProcess;
  @override
  double get vatPercentage;
  @override
  int get supplierCount;
  @override
  double get bottleTax;
  @override
  int? get bottleQty;
  @override
  List<List<ProductStockModel>> get productStockList;
  @override
  int get productStockUpdateIndex;
  @override
  bool get isCartCountChange;
  @override
  List<Product> get productDetails;
  @override
  bool get isProductLoading;
  @override
  List<ProductSupplierModel> get productSupplierList;
  @override
  bool get isQtyUpdated;
  @override
  bool get isSelectSupplier;
  @override
  List<RelatedProductDatum> get relatedProductList;
  @override
  bool get isRelatedShimmering;
  @override
  int get productListIndex;
  @override
  bool get isAnimation;
  @override
  bool get isOrderPending;
  @override
  bool get isSubUserAddToBasket;
  @override
  bool get isSubUserCanCreateOrder;
  @override
  bool get isAccountPermissionShimmering;
  @override
  @JsonKey(ignore: true)
  _$$BasketStateImplCopyWith<_$BasketStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
