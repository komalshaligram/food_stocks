// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'invoice_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$InvoiceState {
  List<Invoice> get invoiceDetailsList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfProducts => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $InvoiceStateCopyWith<InvoiceState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InvoiceStateCopyWith<$Res> {
  factory $InvoiceStateCopyWith(
          InvoiceState value, $Res Function(InvoiceState) then) =
      _$InvoiceStateCopyWithImpl<$Res, InvoiceState>;
  @useResult
  $Res call(
      {List<Invoice> invoiceDetailsList,
      bool isShimmering,
      bool isLoadMore,
      bool isBottomOfProducts,
      RefreshController refreshController,
      int pageNum});
}

/// @nodoc
class _$InvoiceStateCopyWithImpl<$Res, $Val extends InvoiceState>
    implements $InvoiceStateCopyWith<$Res> {
  _$InvoiceStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? invoiceDetailsList = null,
    Object? isShimmering = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? refreshController = null,
    Object? pageNum = null,
  }) {
    return _then(_value.copyWith(
      invoiceDetailsList: null == invoiceDetailsList
          ? _value.invoiceDetailsList
          : invoiceDetailsList // ignore: cast_nullable_to_non_nullable
              as List<Invoice>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$InvoiceStateImplCopyWith<$Res>
    implements $InvoiceStateCopyWith<$Res> {
  factory _$$InvoiceStateImplCopyWith(
          _$InvoiceStateImpl value, $Res Function(_$InvoiceStateImpl) then) =
      __$$InvoiceStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Invoice> invoiceDetailsList,
      bool isShimmering,
      bool isLoadMore,
      bool isBottomOfProducts,
      RefreshController refreshController,
      int pageNum});
}

/// @nodoc
class __$$InvoiceStateImplCopyWithImpl<$Res>
    extends _$InvoiceStateCopyWithImpl<$Res, _$InvoiceStateImpl>
    implements _$$InvoiceStateImplCopyWith<$Res> {
  __$$InvoiceStateImplCopyWithImpl(
      _$InvoiceStateImpl _value, $Res Function(_$InvoiceStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? invoiceDetailsList = null,
    Object? isShimmering = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? refreshController = null,
    Object? pageNum = null,
  }) {
    return _then(_$InvoiceStateImpl(
      invoiceDetailsList: null == invoiceDetailsList
          ? _value._invoiceDetailsList
          : invoiceDetailsList // ignore: cast_nullable_to_non_nullable
              as List<Invoice>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$InvoiceStateImpl implements _InvoiceState {
  const _$InvoiceStateImpl(
      {required final List<Invoice> invoiceDetailsList,
      required this.isShimmering,
      required this.isLoadMore,
      required this.isBottomOfProducts,
      required this.refreshController,
      required this.pageNum})
      : _invoiceDetailsList = invoiceDetailsList;

  final List<Invoice> _invoiceDetailsList;
  @override
  List<Invoice> get invoiceDetailsList {
    if (_invoiceDetailsList is EqualUnmodifiableListView)
      return _invoiceDetailsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_invoiceDetailsList);
  }

  @override
  final bool isShimmering;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfProducts;
  @override
  final RefreshController refreshController;
  @override
  final int pageNum;

  @override
  String toString() {
    return 'InvoiceState(invoiceDetailsList: $invoiceDetailsList, isShimmering: $isShimmering, isLoadMore: $isLoadMore, isBottomOfProducts: $isBottomOfProducts, refreshController: $refreshController, pageNum: $pageNum)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InvoiceStateImpl &&
            const DeepCollectionEquality()
                .equals(other._invoiceDetailsList, _invoiceDetailsList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfProducts, isBottomOfProducts) ||
                other.isBottomOfProducts == isBottomOfProducts) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_invoiceDetailsList),
      isShimmering,
      isLoadMore,
      isBottomOfProducts,
      refreshController,
      pageNum);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$InvoiceStateImplCopyWith<_$InvoiceStateImpl> get copyWith =>
      __$$InvoiceStateImplCopyWithImpl<_$InvoiceStateImpl>(this, _$identity);
}

abstract class _InvoiceState implements InvoiceState {
  const factory _InvoiceState(
      {required final List<Invoice> invoiceDetailsList,
      required final bool isShimmering,
      required final bool isLoadMore,
      required final bool isBottomOfProducts,
      required final RefreshController refreshController,
      required final int pageNum}) = _$InvoiceStateImpl;

  @override
  List<Invoice> get invoiceDetailsList;
  @override
  bool get isShimmering;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfProducts;
  @override
  RefreshController get refreshController;
  @override
  int get pageNum;
  @override
  @JsonKey(ignore: true)
  _$$InvoiceStateImplCopyWith<_$InvoiceStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$InvoiceEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getInvoicesDataEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getInvoicesDataEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getInvoicesDataEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getInvoicesDataEvent value) getInvoicesDataEvent,
    required TResult Function(_refreshListEvent value) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getInvoicesDataEvent value)? getInvoicesDataEvent,
    TResult? Function(_refreshListEvent value)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getInvoicesDataEvent value)? getInvoicesDataEvent,
    TResult Function(_refreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $InvoiceEventCopyWith<InvoiceEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InvoiceEventCopyWith<$Res> {
  factory $InvoiceEventCopyWith(
          InvoiceEvent value, $Res Function(InvoiceEvent) then) =
      _$InvoiceEventCopyWithImpl<$Res, InvoiceEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$InvoiceEventCopyWithImpl<$Res, $Val extends InvoiceEvent>
    implements $InvoiceEventCopyWith<$Res> {
  _$InvoiceEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$getInvoicesDataEventImplCopyWith<$Res>
    implements $InvoiceEventCopyWith<$Res> {
  factory _$$getInvoicesDataEventImplCopyWith(_$getInvoicesDataEventImpl value,
          $Res Function(_$getInvoicesDataEventImpl) then) =
      __$$getInvoicesDataEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getInvoicesDataEventImplCopyWithImpl<$Res>
    extends _$InvoiceEventCopyWithImpl<$Res, _$getInvoicesDataEventImpl>
    implements _$$getInvoicesDataEventImplCopyWith<$Res> {
  __$$getInvoicesDataEventImplCopyWithImpl(_$getInvoicesDataEventImpl _value,
      $Res Function(_$getInvoicesDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getInvoicesDataEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getInvoicesDataEventImpl implements _getInvoicesDataEvent {
  _$getInvoicesDataEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'InvoiceEvent.getInvoicesDataEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getInvoicesDataEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getInvoicesDataEventImplCopyWith<_$getInvoicesDataEventImpl>
      get copyWith =>
          __$$getInvoicesDataEventImplCopyWithImpl<_$getInvoicesDataEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getInvoicesDataEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return getInvoicesDataEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getInvoicesDataEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return getInvoicesDataEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getInvoicesDataEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getInvoicesDataEvent != null) {
      return getInvoicesDataEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getInvoicesDataEvent value) getInvoicesDataEvent,
    required TResult Function(_refreshListEvent value) refreshListEvent,
  }) {
    return getInvoicesDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getInvoicesDataEvent value)? getInvoicesDataEvent,
    TResult? Function(_refreshListEvent value)? refreshListEvent,
  }) {
    return getInvoicesDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getInvoicesDataEvent value)? getInvoicesDataEvent,
    TResult Function(_refreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getInvoicesDataEvent != null) {
      return getInvoicesDataEvent(this);
    }
    return orElse();
  }
}

abstract class _getInvoicesDataEvent implements InvoiceEvent {
  factory _getInvoicesDataEvent({required final BuildContext context}) =
      _$getInvoicesDataEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$getInvoicesDataEventImplCopyWith<_$getInvoicesDataEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$refreshListEventImplCopyWith<$Res>
    implements $InvoiceEventCopyWith<$Res> {
  factory _$$refreshListEventImplCopyWith(_$refreshListEventImpl value,
          $Res Function(_$refreshListEventImpl) then) =
      __$$refreshListEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$refreshListEventImplCopyWithImpl<$Res>
    extends _$InvoiceEventCopyWithImpl<$Res, _$refreshListEventImpl>
    implements _$$refreshListEventImplCopyWith<$Res> {
  __$$refreshListEventImplCopyWithImpl(_$refreshListEventImpl _value,
      $Res Function(_$refreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$refreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$refreshListEventImpl implements _refreshListEvent {
  _$refreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'InvoiceEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$refreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$refreshListEventImplCopyWith<_$refreshListEventImpl> get copyWith =>
      __$$refreshListEventImplCopyWithImpl<_$refreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getInvoicesDataEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getInvoicesDataEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getInvoicesDataEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getInvoicesDataEvent value) getInvoicesDataEvent,
    required TResult Function(_refreshListEvent value) refreshListEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getInvoicesDataEvent value)? getInvoicesDataEvent,
    TResult? Function(_refreshListEvent value)? refreshListEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getInvoicesDataEvent value)? getInvoicesDataEvent,
    TResult Function(_refreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _refreshListEvent implements InvoiceEvent {
  factory _refreshListEvent({required final BuildContext context}) =
      _$refreshListEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$refreshListEventImplCopyWith<_$refreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
