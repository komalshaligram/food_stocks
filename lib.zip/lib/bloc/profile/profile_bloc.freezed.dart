// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProfileEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileEventCopyWith<$Res> {
  factory $ProfileEventCopyWith(
          ProfileEvent value, $Res Function(ProfileEvent) then) =
      _$ProfileEventCopyWithImpl<$Res, ProfileEvent>;
}

/// @nodoc
class _$ProfileEventCopyWithImpl<$Res, $Val extends ProfileEvent>
    implements $ProfileEventCopyWith<$Res> {
  _$ProfileEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl with DiagnosticableTreeMixin implements _Started {
  const _$StartedImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.started()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'ProfileEvent.started'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProfileEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$dropDownEventImplCopyWith<$Res> {
  factory _$$dropDownEventImplCopyWith(
          _$dropDownEventImpl value, $Res Function(_$dropDownEventImpl) then) =
      __$$dropDownEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$dropDownEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$dropDownEventImpl>
    implements _$$dropDownEventImplCopyWith<$Res> {
  __$$dropDownEventImplCopyWithImpl(
      _$dropDownEventImpl _value, $Res Function(_$dropDownEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$dropDownEventImpl
    with DiagnosticableTreeMixin
    implements _dropDownEvent {
  _$dropDownEventImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.dropDownEvent()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'ProfileEvent.dropDownEvent'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$dropDownEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return dropDownEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return dropDownEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (dropDownEvent != null) {
      return dropDownEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return dropDownEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return dropDownEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (dropDownEvent != null) {
      return dropDownEvent(this);
    }
    return orElse();
  }
}

abstract class _dropDownEvent implements ProfileEvent {
  factory _dropDownEvent() = _$dropDownEventImpl;
}

/// @nodoc
abstract class _$$pickProfileImageEventImplCopyWith<$Res> {
  factory _$$pickProfileImageEventImplCopyWith(
          _$pickProfileImageEventImpl value,
          $Res Function(_$pickProfileImageEventImpl) then) =
      __$$pickProfileImageEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, bool isFromCamera});
}

/// @nodoc
class __$$pickProfileImageEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$pickProfileImageEventImpl>
    implements _$$pickProfileImageEventImplCopyWith<$Res> {
  __$$pickProfileImageEventImplCopyWithImpl(_$pickProfileImageEventImpl _value,
      $Res Function(_$pickProfileImageEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isFromCamera = null,
  }) {
    return _then(_$pickProfileImageEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isFromCamera: null == isFromCamera
          ? _value.isFromCamera
          : isFromCamera // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$pickProfileImageEventImpl
    with DiagnosticableTreeMixin
    implements _pickProfileImageEvent {
  _$pickProfileImageEventImpl(
      {required this.context, required this.isFromCamera});

  @override
  final BuildContext context;
  @override
  final bool isFromCamera;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.pickProfileImageEvent(context: $context, isFromCamera: $isFromCamera)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'ProfileEvent.pickProfileImageEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('isFromCamera', isFromCamera));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$pickProfileImageEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isFromCamera, isFromCamera) ||
                other.isFromCamera == isFromCamera));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isFromCamera);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$pickProfileImageEventImplCopyWith<_$pickProfileImageEventImpl>
      get copyWith => __$$pickProfileImageEventImplCopyWithImpl<
          _$pickProfileImageEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return pickProfileImageEvent(context, isFromCamera);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return pickProfileImageEvent?.call(context, isFromCamera);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (pickProfileImageEvent != null) {
      return pickProfileImageEvent(context, isFromCamera);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return pickProfileImageEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return pickProfileImageEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (pickProfileImageEvent != null) {
      return pickProfileImageEvent(this);
    }
    return orElse();
  }
}

abstract class _pickProfileImageEvent implements ProfileEvent {
  factory _pickProfileImageEvent(
      {required final BuildContext context,
      required final bool isFromCamera}) = _$pickProfileImageEventImpl;

  BuildContext get context;
  bool get isFromCamera;
  @JsonKey(ignore: true)
  _$$pickProfileImageEventImplCopyWith<_$pickProfileImageEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getBusinessTypeListEventImplCopyWith<$Res> {
  factory _$$getBusinessTypeListEventImplCopyWith(
          _$getBusinessTypeListEventImpl value,
          $Res Function(_$getBusinessTypeListEventImpl) then) =
      __$$getBusinessTypeListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getBusinessTypeListEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$getBusinessTypeListEventImpl>
    implements _$$getBusinessTypeListEventImplCopyWith<$Res> {
  __$$getBusinessTypeListEventImplCopyWithImpl(
      _$getBusinessTypeListEventImpl _value,
      $Res Function(_$getBusinessTypeListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getBusinessTypeListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getBusinessTypeListEventImpl
    with DiagnosticableTreeMixin
    implements _getBusinessTypeListEvent {
  _$getBusinessTypeListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.getBusinessTypeListEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(
          DiagnosticsProperty('type', 'ProfileEvent.getBusinessTypeListEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getBusinessTypeListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getBusinessTypeListEventImplCopyWith<_$getBusinessTypeListEventImpl>
      get copyWith => __$$getBusinessTypeListEventImplCopyWithImpl<
          _$getBusinessTypeListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return getBusinessTypeListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return getBusinessTypeListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getBusinessTypeListEvent != null) {
      return getBusinessTypeListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return getBusinessTypeListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return getBusinessTypeListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getBusinessTypeListEvent != null) {
      return getBusinessTypeListEvent(this);
    }
    return orElse();
  }
}

abstract class _getBusinessTypeListEvent implements ProfileEvent {
  factory _getBusinessTypeListEvent({required final BuildContext context}) =
      _$getBusinessTypeListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getBusinessTypeListEventImplCopyWith<_$getBusinessTypeListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$navigateToMoreDetailsScreenEventImplCopyWith<$Res> {
  factory _$$navigateToMoreDetailsScreenEventImplCopyWith(
          _$navigateToMoreDetailsScreenEventImpl value,
          $Res Function(_$navigateToMoreDetailsScreenEventImpl) then) =
      __$$navigateToMoreDetailsScreenEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$navigateToMoreDetailsScreenEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res,
        _$navigateToMoreDetailsScreenEventImpl>
    implements _$$navigateToMoreDetailsScreenEventImplCopyWith<$Res> {
  __$$navigateToMoreDetailsScreenEventImplCopyWithImpl(
      _$navigateToMoreDetailsScreenEventImpl _value,
      $Res Function(_$navigateToMoreDetailsScreenEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$navigateToMoreDetailsScreenEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$navigateToMoreDetailsScreenEventImpl
    with DiagnosticableTreeMixin
    implements _navigateToMoreDetailsScreenEvent {
  _$navigateToMoreDetailsScreenEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.navigateToMoreDetailsScreenEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty(
          'type', 'ProfileEvent.navigateToMoreDetailsScreenEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$navigateToMoreDetailsScreenEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$navigateToMoreDetailsScreenEventImplCopyWith<
          _$navigateToMoreDetailsScreenEventImpl>
      get copyWith => __$$navigateToMoreDetailsScreenEventImplCopyWithImpl<
          _$navigateToMoreDetailsScreenEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return navigateToMoreDetailsScreenEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return navigateToMoreDetailsScreenEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (navigateToMoreDetailsScreenEvent != null) {
      return navigateToMoreDetailsScreenEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return navigateToMoreDetailsScreenEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return navigateToMoreDetailsScreenEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (navigateToMoreDetailsScreenEvent != null) {
      return navigateToMoreDetailsScreenEvent(this);
    }
    return orElse();
  }
}

abstract class _navigateToMoreDetailsScreenEvent implements ProfileEvent {
  factory _navigateToMoreDetailsScreenEvent(
          {required final BuildContext context}) =
      _$navigateToMoreDetailsScreenEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$navigateToMoreDetailsScreenEventImplCopyWith<
          _$navigateToMoreDetailsScreenEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getProfileDetailsEventImplCopyWith<$Res> {
  factory _$$getProfileDetailsEventImplCopyWith(
          _$getProfileDetailsEventImpl value,
          $Res Function(_$getProfileDetailsEventImpl) then) =
      __$$getProfileDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, bool isUpdate, String mobileNo});
}

/// @nodoc
class __$$getProfileDetailsEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$getProfileDetailsEventImpl>
    implements _$$getProfileDetailsEventImplCopyWith<$Res> {
  __$$getProfileDetailsEventImplCopyWithImpl(
      _$getProfileDetailsEventImpl _value,
      $Res Function(_$getProfileDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isUpdate = null,
    Object? mobileNo = null,
  }) {
    return _then(_$getProfileDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      mobileNo: null == mobileNo
          ? _value.mobileNo
          : mobileNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getProfileDetailsEventImpl
    with DiagnosticableTreeMixin
    implements _getProfileDetailsEvent {
  _$getProfileDetailsEventImpl(
      {required this.context, required this.isUpdate, required this.mobileNo});

  @override
  final BuildContext context;
  @override
  final bool isUpdate;
  @override
  final String mobileNo;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.getProfileDetailsEvent(context: $context, isUpdate: $isUpdate, mobileNo: $mobileNo)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'ProfileEvent.getProfileDetailsEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('isUpdate', isUpdate))
      ..add(DiagnosticsProperty('mobileNo', mobileNo));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getProfileDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            (identical(other.mobileNo, mobileNo) ||
                other.mobileNo == mobileNo));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isUpdate, mobileNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getProfileDetailsEventImplCopyWith<_$getProfileDetailsEventImpl>
      get copyWith => __$$getProfileDetailsEventImplCopyWithImpl<
          _$getProfileDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return getProfileDetailsEvent(context, isUpdate, mobileNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return getProfileDetailsEvent?.call(context, isUpdate, mobileNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getProfileDetailsEvent != null) {
      return getProfileDetailsEvent(context, isUpdate, mobileNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return getProfileDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return getProfileDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (getProfileDetailsEvent != null) {
      return getProfileDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _getProfileDetailsEvent implements ProfileEvent {
  factory _getProfileDetailsEvent(
      {required final BuildContext context,
      required final bool isUpdate,
      required final String mobileNo}) = _$getProfileDetailsEventImpl;

  BuildContext get context;
  bool get isUpdate;
  String get mobileNo;
  @JsonKey(ignore: true)
  _$$getProfileDetailsEventImplCopyWith<_$getProfileDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$updateProfileDetailsEventImplCopyWith<$Res> {
  factory _$$updateProfileDetailsEventImplCopyWith(
          _$updateProfileDetailsEventImpl value,
          $Res Function(_$updateProfileDetailsEventImpl) then) =
      __$$updateProfileDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$updateProfileDetailsEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$updateProfileDetailsEventImpl>
    implements _$$updateProfileDetailsEventImplCopyWith<$Res> {
  __$$updateProfileDetailsEventImplCopyWithImpl(
      _$updateProfileDetailsEventImpl _value,
      $Res Function(_$updateProfileDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$updateProfileDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$updateProfileDetailsEventImpl
    with DiagnosticableTreeMixin
    implements _updateProfileDetailsEvent {
  _$updateProfileDetailsEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.updateProfileDetailsEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(
          DiagnosticsProperty('type', 'ProfileEvent.updateProfileDetailsEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateProfileDetailsEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateProfileDetailsEventImplCopyWith<_$updateProfileDetailsEventImpl>
      get copyWith => __$$updateProfileDetailsEventImplCopyWithImpl<
          _$updateProfileDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return updateProfileDetailsEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return updateProfileDetailsEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (updateProfileDetailsEvent != null) {
      return updateProfileDetailsEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return updateProfileDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return updateProfileDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (updateProfileDetailsEvent != null) {
      return updateProfileDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _updateProfileDetailsEvent implements ProfileEvent {
  factory _updateProfileDetailsEvent({required final BuildContext context}) =
      _$updateProfileDetailsEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$updateProfileDetailsEventImplCopyWith<_$updateProfileDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeBusinessTypeEventEventImplCopyWith<$Res> {
  factory _$$ChangeBusinessTypeEventEventImplCopyWith(
          _$ChangeBusinessTypeEventEventImpl value,
          $Res Function(_$ChangeBusinessTypeEventEventImpl) then) =
      __$$ChangeBusinessTypeEventEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String newBusinessType});
}

/// @nodoc
class __$$ChangeBusinessTypeEventEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$ChangeBusinessTypeEventEventImpl>
    implements _$$ChangeBusinessTypeEventEventImplCopyWith<$Res> {
  __$$ChangeBusinessTypeEventEventImplCopyWithImpl(
      _$ChangeBusinessTypeEventEventImpl _value,
      $Res Function(_$ChangeBusinessTypeEventEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newBusinessType = null,
  }) {
    return _then(_$ChangeBusinessTypeEventEventImpl(
      newBusinessType: null == newBusinessType
          ? _value.newBusinessType
          : newBusinessType // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeBusinessTypeEventEventImpl
    with DiagnosticableTreeMixin
    implements _ChangeBusinessTypeEventEvent {
  _$ChangeBusinessTypeEventEventImpl({required this.newBusinessType});

  @override
  final String newBusinessType;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.changeBusinessTypeEvent(newBusinessType: $newBusinessType)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'ProfileEvent.changeBusinessTypeEvent'))
      ..add(DiagnosticsProperty('newBusinessType', newBusinessType));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeBusinessTypeEventEventImpl &&
            (identical(other.newBusinessType, newBusinessType) ||
                other.newBusinessType == newBusinessType));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newBusinessType);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeBusinessTypeEventEventImplCopyWith<
          _$ChangeBusinessTypeEventEventImpl>
      get copyWith => __$$ChangeBusinessTypeEventEventImplCopyWithImpl<
          _$ChangeBusinessTypeEventEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return changeBusinessTypeEvent(newBusinessType);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return changeBusinessTypeEvent?.call(newBusinessType);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (changeBusinessTypeEvent != null) {
      return changeBusinessTypeEvent(newBusinessType);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return changeBusinessTypeEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return changeBusinessTypeEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (changeBusinessTypeEvent != null) {
      return changeBusinessTypeEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeBusinessTypeEventEvent implements ProfileEvent {
  factory _ChangeBusinessTypeEventEvent(
          {required final String newBusinessType}) =
      _$ChangeBusinessTypeEventEventImpl;

  String get newBusinessType;
  @JsonKey(ignore: true)
  _$$ChangeBusinessTypeEventEventImplCopyWith<
          _$ChangeBusinessTypeEventEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DeleteAccountEventImplCopyWith<$Res> {
  factory _$$DeleteAccountEventImplCopyWith(_$DeleteAccountEventImpl value,
          $Res Function(_$DeleteAccountEventImpl) then) =
      __$$DeleteAccountEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DeleteAccountEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$DeleteAccountEventImpl>
    implements _$$DeleteAccountEventImplCopyWith<$Res> {
  __$$DeleteAccountEventImplCopyWithImpl(_$DeleteAccountEventImpl _value,
      $Res Function(_$DeleteAccountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DeleteAccountEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DeleteAccountEventImpl
    with DiagnosticableTreeMixin
    implements _DeleteAccountEvent {
  _$DeleteAccountEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.deleteAccountEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'ProfileEvent.deleteAccountEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeleteAccountEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DeleteAccountEventImplCopyWith<_$DeleteAccountEventImpl> get copyWith =>
      __$$DeleteAccountEventImplCopyWithImpl<_$DeleteAccountEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return deleteAccountEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return deleteAccountEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (deleteAccountEvent != null) {
      return deleteAccountEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return deleteAccountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return deleteAccountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (deleteAccountEvent != null) {
      return deleteAccountEvent(this);
    }
    return orElse();
  }
}

abstract class _DeleteAccountEvent implements ProfileEvent {
  factory _DeleteAccountEvent({required final BuildContext context}) =
      _$DeleteAccountEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DeleteAccountEventImplCopyWith<_$DeleteAccountEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$deleteFileEventImplCopyWith<$Res> {
  factory _$$deleteFileEventImplCopyWith(_$deleteFileEventImpl value,
          $Res Function(_$deleteFileEventImpl) then) =
      __$$deleteFileEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$deleteFileEventImplCopyWithImpl<$Res>
    extends _$ProfileEventCopyWithImpl<$Res, _$deleteFileEventImpl>
    implements _$$deleteFileEventImplCopyWith<$Res> {
  __$$deleteFileEventImplCopyWithImpl(
      _$deleteFileEventImpl _value, $Res Function(_$deleteFileEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$deleteFileEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$deleteFileEventImpl
    with DiagnosticableTreeMixin
    implements _deleteFileEvent {
  _$deleteFileEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileEvent.deleteFileEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'ProfileEvent.deleteFileEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deleteFileEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      __$$deleteFileEventImplCopyWithImpl<_$deleteFileEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() dropDownEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) getBusinessTypeListEvent,
    required TResult Function(BuildContext context)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(
            BuildContext context, bool isUpdate, String mobileNo)
        getProfileDetailsEvent,
    required TResult Function(BuildContext context) updateProfileDetailsEvent,
    required TResult Function(String newBusinessType) changeBusinessTypeEvent,
    required TResult Function(BuildContext context) deleteAccountEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
  }) {
    return deleteFileEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? dropDownEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? getBusinessTypeListEvent,
    TResult? Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult? Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult? Function(BuildContext context)? updateProfileDetailsEvent,
    TResult? Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult? Function(BuildContext context)? deleteAccountEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
  }) {
    return deleteFileEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? dropDownEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? getBusinessTypeListEvent,
    TResult Function(BuildContext context)? navigateToMoreDetailsScreenEvent,
    TResult Function(BuildContext context, bool isUpdate, String mobileNo)?
        getProfileDetailsEvent,
    TResult Function(BuildContext context)? updateProfileDetailsEvent,
    TResult Function(String newBusinessType)? changeBusinessTypeEvent,
    TResult Function(BuildContext context)? deleteAccountEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_dropDownEvent value) dropDownEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_getBusinessTypeListEvent value)
        getBusinessTypeListEvent,
    required TResult Function(_navigateToMoreDetailsScreenEvent value)
        navigateToMoreDetailsScreenEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_updateProfileDetailsEvent value)
        updateProfileDetailsEvent,
    required TResult Function(_ChangeBusinessTypeEventEvent value)
        changeBusinessTypeEvent,
    required TResult Function(_DeleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
  }) {
    return deleteFileEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_dropDownEvent value)? dropDownEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_getBusinessTypeListEvent value)?
        getBusinessTypeListEvent,
    TResult? Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult? Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult? Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
  }) {
    return deleteFileEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_dropDownEvent value)? dropDownEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_getBusinessTypeListEvent value)? getBusinessTypeListEvent,
    TResult Function(_navigateToMoreDetailsScreenEvent value)?
        navigateToMoreDetailsScreenEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_updateProfileDetailsEvent value)?
        updateProfileDetailsEvent,
    TResult Function(_ChangeBusinessTypeEventEvent value)?
        changeBusinessTypeEvent,
    TResult Function(_DeleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(this);
    }
    return orElse();
  }
}

abstract class _deleteFileEvent implements ProfileEvent {
  factory _deleteFileEvent({required final BuildContext context}) =
      _$deleteFileEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProfileState {
  File get image => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;
  String get selectedBusinessType => throw _privateConstructorUsedError;
  BusinessTypeModel get businessTypeList => throw _privateConstructorUsedError;
  TextEditingController get businessNameController =>
      throw _privateConstructorUsedError;
  TextEditingController get businessIdController =>
      throw _privateConstructorUsedError;
  TextEditingController get ownerNameController =>
      throw _privateConstructorUsedError;
  TextEditingController get israelIdController =>
      throw _privateConstructorUsedError;
  TextEditingController get contactController =>
      throw _privateConstructorUsedError;
  String get UserImageUrl => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isUpdating => throw _privateConstructorUsedError;
  bool get isFileSizeExceeds => throw _privateConstructorUsedError;
  bool get isFileUploading => throw _privateConstructorUsedError;
  bool get isUploadingProcess => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  String get userId => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProfileStateCopyWith<ProfileState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileStateCopyWith<$Res> {
  factory $ProfileStateCopyWith(
          ProfileState value, $Res Function(ProfileState) then) =
      _$ProfileStateCopyWithImpl<$Res, ProfileState>;
  @useResult
  $Res call(
      {File image,
      bool isUpdate,
      String selectedBusinessType,
      BusinessTypeModel businessTypeList,
      TextEditingController businessNameController,
      TextEditingController businessIdController,
      TextEditingController ownerNameController,
      TextEditingController israelIdController,
      TextEditingController contactController,
      String UserImageUrl,
      bool isLoading,
      bool isShimmering,
      bool isUpdating,
      bool isFileSizeExceeds,
      bool isFileUploading,
      bool isUploadingProcess,
      String language,
      String userId});

  $BusinessTypeModelCopyWith<$Res> get businessTypeList;
}

/// @nodoc
class _$ProfileStateCopyWithImpl<$Res, $Val extends ProfileState>
    implements $ProfileStateCopyWith<$Res> {
  _$ProfileStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? image = null,
    Object? isUpdate = null,
    Object? selectedBusinessType = null,
    Object? businessTypeList = null,
    Object? businessNameController = null,
    Object? businessIdController = null,
    Object? ownerNameController = null,
    Object? israelIdController = null,
    Object? contactController = null,
    Object? UserImageUrl = null,
    Object? isLoading = null,
    Object? isShimmering = null,
    Object? isUpdating = null,
    Object? isFileSizeExceeds = null,
    Object? isFileUploading = null,
    Object? isUploadingProcess = null,
    Object? language = null,
    Object? userId = null,
  }) {
    return _then(_value.copyWith(
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as File,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedBusinessType: null == selectedBusinessType
          ? _value.selectedBusinessType
          : selectedBusinessType // ignore: cast_nullable_to_non_nullable
              as String,
      businessTypeList: null == businessTypeList
          ? _value.businessTypeList
          : businessTypeList // ignore: cast_nullable_to_non_nullable
              as BusinessTypeModel,
      businessNameController: null == businessNameController
          ? _value.businessNameController
          : businessNameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      businessIdController: null == businessIdController
          ? _value.businessIdController
          : businessIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      ownerNameController: null == ownerNameController
          ? _value.ownerNameController
          : ownerNameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      israelIdController: null == israelIdController
          ? _value.israelIdController
          : israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      contactController: null == contactController
          ? _value.contactController
          : contactController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      UserImageUrl: null == UserImageUrl
          ? _value.UserImageUrl
          : UserImageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdating: null == isUpdating
          ? _value.isUpdating
          : isUpdating // ignore: cast_nullable_to_non_nullable
              as bool,
      isFileSizeExceeds: null == isFileSizeExceeds
          ? _value.isFileSizeExceeds
          : isFileSizeExceeds // ignore: cast_nullable_to_non_nullable
              as bool,
      isFileUploading: null == isFileUploading
          ? _value.isFileUploading
          : isFileUploading // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadingProcess: null == isUploadingProcess
          ? _value.isUploadingProcess
          : isUploadingProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $BusinessTypeModelCopyWith<$Res> get businessTypeList {
    return $BusinessTypeModelCopyWith<$Res>(_value.businessTypeList, (value) {
      return _then(_value.copyWith(businessTypeList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProfileStateImplCopyWith<$Res>
    implements $ProfileStateCopyWith<$Res> {
  factory _$$ProfileStateImplCopyWith(
          _$ProfileStateImpl value, $Res Function(_$ProfileStateImpl) then) =
      __$$ProfileStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {File image,
      bool isUpdate,
      String selectedBusinessType,
      BusinessTypeModel businessTypeList,
      TextEditingController businessNameController,
      TextEditingController businessIdController,
      TextEditingController ownerNameController,
      TextEditingController israelIdController,
      TextEditingController contactController,
      String UserImageUrl,
      bool isLoading,
      bool isShimmering,
      bool isUpdating,
      bool isFileSizeExceeds,
      bool isFileUploading,
      bool isUploadingProcess,
      String language,
      String userId});

  @override
  $BusinessTypeModelCopyWith<$Res> get businessTypeList;
}

/// @nodoc
class __$$ProfileStateImplCopyWithImpl<$Res>
    extends _$ProfileStateCopyWithImpl<$Res, _$ProfileStateImpl>
    implements _$$ProfileStateImplCopyWith<$Res> {
  __$$ProfileStateImplCopyWithImpl(
      _$ProfileStateImpl _value, $Res Function(_$ProfileStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? image = null,
    Object? isUpdate = null,
    Object? selectedBusinessType = null,
    Object? businessTypeList = null,
    Object? businessNameController = null,
    Object? businessIdController = null,
    Object? ownerNameController = null,
    Object? israelIdController = null,
    Object? contactController = null,
    Object? UserImageUrl = null,
    Object? isLoading = null,
    Object? isShimmering = null,
    Object? isUpdating = null,
    Object? isFileSizeExceeds = null,
    Object? isFileUploading = null,
    Object? isUploadingProcess = null,
    Object? language = null,
    Object? userId = null,
  }) {
    return _then(_$ProfileStateImpl(
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as File,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedBusinessType: null == selectedBusinessType
          ? _value.selectedBusinessType
          : selectedBusinessType // ignore: cast_nullable_to_non_nullable
              as String,
      businessTypeList: null == businessTypeList
          ? _value.businessTypeList
          : businessTypeList // ignore: cast_nullable_to_non_nullable
              as BusinessTypeModel,
      businessNameController: null == businessNameController
          ? _value.businessNameController
          : businessNameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      businessIdController: null == businessIdController
          ? _value.businessIdController
          : businessIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      ownerNameController: null == ownerNameController
          ? _value.ownerNameController
          : ownerNameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      israelIdController: null == israelIdController
          ? _value.israelIdController
          : israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      contactController: null == contactController
          ? _value.contactController
          : contactController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      UserImageUrl: null == UserImageUrl
          ? _value.UserImageUrl
          : UserImageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdating: null == isUpdating
          ? _value.isUpdating
          : isUpdating // ignore: cast_nullable_to_non_nullable
              as bool,
      isFileSizeExceeds: null == isFileSizeExceeds
          ? _value.isFileSizeExceeds
          : isFileSizeExceeds // ignore: cast_nullable_to_non_nullable
              as bool,
      isFileUploading: null == isFileUploading
          ? _value.isFileUploading
          : isFileUploading // ignore: cast_nullable_to_non_nullable
              as bool,
      isUploadingProcess: null == isUploadingProcess
          ? _value.isUploadingProcess
          : isUploadingProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ProfileStateImpl with DiagnosticableTreeMixin implements _ProfileState {
  const _$ProfileStateImpl(
      {required this.image,
      required this.isUpdate,
      required this.selectedBusinessType,
      required this.businessTypeList,
      required this.businessNameController,
      required this.businessIdController,
      required this.ownerNameController,
      required this.israelIdController,
      required this.contactController,
      required this.UserImageUrl,
      required this.isLoading,
      required this.isShimmering,
      required this.isUpdating,
      required this.isFileSizeExceeds,
      required this.isFileUploading,
      required this.isUploadingProcess,
      required this.language,
      required this.userId});

  @override
  final File image;
  @override
  final bool isUpdate;
  @override
  final String selectedBusinessType;
  @override
  final BusinessTypeModel businessTypeList;
  @override
  final TextEditingController businessNameController;
  @override
  final TextEditingController businessIdController;
  @override
  final TextEditingController ownerNameController;
  @override
  final TextEditingController israelIdController;
  @override
  final TextEditingController contactController;
  @override
  final String UserImageUrl;
  @override
  final bool isLoading;
  @override
  final bool isShimmering;
  @override
  final bool isUpdating;
  @override
  final bool isFileSizeExceeds;
  @override
  final bool isFileUploading;
  @override
  final bool isUploadingProcess;
  @override
  final String language;
  @override
  final String userId;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'ProfileState(image: $image, isUpdate: $isUpdate, selectedBusinessType: $selectedBusinessType, businessTypeList: $businessTypeList, businessNameController: $businessNameController, businessIdController: $businessIdController, ownerNameController: $ownerNameController, israelIdController: $israelIdController, contactController: $contactController, UserImageUrl: $UserImageUrl, isLoading: $isLoading, isShimmering: $isShimmering, isUpdating: $isUpdating, isFileSizeExceeds: $isFileSizeExceeds, isFileUploading: $isFileUploading, isUploadingProcess: $isUploadingProcess, language: $language, userId: $userId)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'ProfileState'))
      ..add(DiagnosticsProperty('image', image))
      ..add(DiagnosticsProperty('isUpdate', isUpdate))
      ..add(DiagnosticsProperty('selectedBusinessType', selectedBusinessType))
      ..add(DiagnosticsProperty('businessTypeList', businessTypeList))
      ..add(
          DiagnosticsProperty('businessNameController', businessNameController))
      ..add(DiagnosticsProperty('businessIdController', businessIdController))
      ..add(DiagnosticsProperty('ownerNameController', ownerNameController))
      ..add(DiagnosticsProperty('israelIdController', israelIdController))
      ..add(DiagnosticsProperty('contactController', contactController))
      ..add(DiagnosticsProperty('UserImageUrl', UserImageUrl))
      ..add(DiagnosticsProperty('isLoading', isLoading))
      ..add(DiagnosticsProperty('isShimmering', isShimmering))
      ..add(DiagnosticsProperty('isUpdating', isUpdating))
      ..add(DiagnosticsProperty('isFileSizeExceeds', isFileSizeExceeds))
      ..add(DiagnosticsProperty('isFileUploading', isFileUploading))
      ..add(DiagnosticsProperty('isUploadingProcess', isUploadingProcess))
      ..add(DiagnosticsProperty('language', language))
      ..add(DiagnosticsProperty('userId', userId));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileStateImpl &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            (identical(other.selectedBusinessType, selectedBusinessType) ||
                other.selectedBusinessType == selectedBusinessType) &&
            (identical(other.businessTypeList, businessTypeList) ||
                other.businessTypeList == businessTypeList) &&
            (identical(other.businessNameController, businessNameController) ||
                other.businessNameController == businessNameController) &&
            (identical(other.businessIdController, businessIdController) ||
                other.businessIdController == businessIdController) &&
            (identical(other.ownerNameController, ownerNameController) ||
                other.ownerNameController == ownerNameController) &&
            (identical(other.israelIdController, israelIdController) ||
                other.israelIdController == israelIdController) &&
            (identical(other.contactController, contactController) ||
                other.contactController == contactController) &&
            (identical(other.UserImageUrl, UserImageUrl) ||
                other.UserImageUrl == UserImageUrl) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isUpdating, isUpdating) ||
                other.isUpdating == isUpdating) &&
            (identical(other.isFileSizeExceeds, isFileSizeExceeds) ||
                other.isFileSizeExceeds == isFileSizeExceeds) &&
            (identical(other.isFileUploading, isFileUploading) ||
                other.isFileUploading == isFileUploading) &&
            (identical(other.isUploadingProcess, isUploadingProcess) ||
                other.isUploadingProcess == isUploadingProcess) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.userId, userId) || other.userId == userId));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      image,
      isUpdate,
      selectedBusinessType,
      businessTypeList,
      businessNameController,
      businessIdController,
      ownerNameController,
      israelIdController,
      contactController,
      UserImageUrl,
      isLoading,
      isShimmering,
      isUpdating,
      isFileSizeExceeds,
      isFileUploading,
      isUploadingProcess,
      language,
      userId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileStateImplCopyWith<_$ProfileStateImpl> get copyWith =>
      __$$ProfileStateImplCopyWithImpl<_$ProfileStateImpl>(this, _$identity);
}

abstract class _ProfileState implements ProfileState {
  const factory _ProfileState(
      {required final File image,
      required final bool isUpdate,
      required final String selectedBusinessType,
      required final BusinessTypeModel businessTypeList,
      required final TextEditingController businessNameController,
      required final TextEditingController businessIdController,
      required final TextEditingController ownerNameController,
      required final TextEditingController israelIdController,
      required final TextEditingController contactController,
      required final String UserImageUrl,
      required final bool isLoading,
      required final bool isShimmering,
      required final bool isUpdating,
      required final bool isFileSizeExceeds,
      required final bool isFileUploading,
      required final bool isUploadingProcess,
      required final String language,
      required final String userId}) = _$ProfileStateImpl;

  @override
  File get image;
  @override
  bool get isUpdate;
  @override
  String get selectedBusinessType;
  @override
  BusinessTypeModel get businessTypeList;
  @override
  TextEditingController get businessNameController;
  @override
  TextEditingController get businessIdController;
  @override
  TextEditingController get ownerNameController;
  @override
  TextEditingController get israelIdController;
  @override
  TextEditingController get contactController;
  @override
  String get UserImageUrl;
  @override
  bool get isLoading;
  @override
  bool get isShimmering;
  @override
  bool get isUpdating;
  @override
  bool get isFileSizeExceeds;
  @override
  bool get isFileUploading;
  @override
  bool get isUploadingProcess;
  @override
  String get language;
  @override
  String get userId;
  @override
  @JsonKey(ignore: true)
  _$$ProfileStateImplCopyWith<_$ProfileStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
