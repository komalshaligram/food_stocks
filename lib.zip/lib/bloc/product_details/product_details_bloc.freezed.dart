// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_details_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProductDetailsEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductDetailsEventCopyWith<$Res> {
  factory $ProductDetailsEventCopyWith(
          ProductDetailsEvent value, $Res Function(ProductDetailsEvent) then) =
      _$ProductDetailsEventCopyWithImpl<$Res, ProductDetailsEvent>;
}

/// @nodoc
class _$ProductDetailsEventCopyWithImpl<$Res, $Val extends ProductDetailsEvent>
    implements $ProductDetailsEventCopyWith<$Res> {
  _$ProductDetailsEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$productProblemEventImplCopyWith<$Res> {
  factory _$$productProblemEventImplCopyWith(_$productProblemEventImpl value,
          $Res Function(_$productProblemEventImpl) then) =
      __$$productProblemEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isProductProblem, int index});
}

/// @nodoc
class __$$productProblemEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$productProblemEventImpl>
    implements _$$productProblemEventImplCopyWith<$Res> {
  __$$productProblemEventImplCopyWithImpl(_$productProblemEventImpl _value,
      $Res Function(_$productProblemEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isProductProblem = null,
    Object? index = null,
  }) {
    return _then(_$productProblemEventImpl(
      isProductProblem: null == isProductProblem
          ? _value.isProductProblem
          : isProductProblem // ignore: cast_nullable_to_non_nullable
              as bool,
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$productProblemEventImpl implements _productProblemEvent {
  const _$productProblemEventImpl(
      {required this.isProductProblem, required this.index});

  @override
  final bool isProductProblem;
  @override
  final int index;

  @override
  String toString() {
    return 'ProductDetailsEvent.productProblemEvent(isProductProblem: $isProductProblem, index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$productProblemEventImpl &&
            (identical(other.isProductProblem, isProductProblem) ||
                other.isProductProblem == isProductProblem) &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isProductProblem, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$productProblemEventImplCopyWith<_$productProblemEventImpl> get copyWith =>
      __$$productProblemEventImplCopyWithImpl<_$productProblemEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return productProblemEvent(isProductProblem, index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return productProblemEvent?.call(isProductProblem, index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productProblemEvent != null) {
      return productProblemEvent(isProductProblem, index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return productProblemEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return productProblemEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productProblemEvent != null) {
      return productProblemEvent(this);
    }
    return orElse();
  }
}

abstract class _productProblemEvent implements ProductDetailsEvent {
  const factory _productProblemEvent(
      {required final bool isProductProblem,
      required final int index}) = _$productProblemEventImpl;

  bool get isProductProblem;
  int get index;
  @JsonKey(ignore: true)
  _$$productProblemEventImplCopyWith<_$productProblemEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$radioButtonEventImplCopyWith<$Res> {
  factory _$$radioButtonEventImplCopyWith(_$radioButtonEventImpl value,
          $Res Function(_$radioButtonEventImpl) then) =
      __$$radioButtonEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int selectRadioTile});
}

/// @nodoc
class __$$radioButtonEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$radioButtonEventImpl>
    implements _$$radioButtonEventImplCopyWith<$Res> {
  __$$radioButtonEventImplCopyWithImpl(_$radioButtonEventImpl _value,
      $Res Function(_$radioButtonEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? selectRadioTile = null,
  }) {
    return _then(_$radioButtonEventImpl(
      selectRadioTile: null == selectRadioTile
          ? _value.selectRadioTile
          : selectRadioTile // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$radioButtonEventImpl implements _radioButtonEvent {
  const _$radioButtonEventImpl({required this.selectRadioTile});

  @override
  final int selectRadioTile;

  @override
  String toString() {
    return 'ProductDetailsEvent.radioButtonEvent(selectRadioTile: $selectRadioTile)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$radioButtonEventImpl &&
            (identical(other.selectRadioTile, selectRadioTile) ||
                other.selectRadioTile == selectRadioTile));
  }

  @override
  int get hashCode => Object.hash(runtimeType, selectRadioTile);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$radioButtonEventImplCopyWith<_$radioButtonEventImpl> get copyWith =>
      __$$radioButtonEventImplCopyWithImpl<_$radioButtonEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return radioButtonEvent(selectRadioTile);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return radioButtonEvent?.call(selectRadioTile);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (radioButtonEvent != null) {
      return radioButtonEvent(selectRadioTile);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return radioButtonEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return radioButtonEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (radioButtonEvent != null) {
      return radioButtonEvent(this);
    }
    return orElse();
  }
}

abstract class _radioButtonEvent implements ProductDetailsEvent {
  const factory _radioButtonEvent({required final int selectRadioTile}) =
      _$radioButtonEventImpl;

  int get selectRadioTile;
  @JsonKey(ignore: true)
  _$$radioButtonEventImplCopyWith<_$radioButtonEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$productIncrementEventImplCopyWith<$Res> {
  factory _$$productIncrementEventImplCopyWith(
          _$productIncrementEventImpl value,
          $Res Function(_$productIncrementEventImpl) then) =
      __$$productIncrementEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {int productQuantity,
      int listIndex,
      BuildContext context,
      int messingQuantity});
}

/// @nodoc
class __$$productIncrementEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$productIncrementEventImpl>
    implements _$$productIncrementEventImplCopyWith<$Res> {
  __$$productIncrementEventImplCopyWithImpl(_$productIncrementEventImpl _value,
      $Res Function(_$productIncrementEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productQuantity = null,
    Object? listIndex = null,
    Object? context = null,
    Object? messingQuantity = null,
  }) {
    return _then(_$productIncrementEventImpl(
      productQuantity: null == productQuantity
          ? _value.productQuantity
          : productQuantity // ignore: cast_nullable_to_non_nullable
              as int,
      listIndex: null == listIndex
          ? _value.listIndex
          : listIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      messingQuantity: null == messingQuantity
          ? _value.messingQuantity
          : messingQuantity // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$productIncrementEventImpl implements _productIncrementEvent {
  const _$productIncrementEventImpl(
      {required this.productQuantity,
      required this.listIndex,
      required this.context,
      required this.messingQuantity});

  @override
  final int productQuantity;
  @override
  final int listIndex;
  @override
  final BuildContext context;
  @override
  final int messingQuantity;

  @override
  String toString() {
    return 'ProductDetailsEvent.productIncrementEvent(productQuantity: $productQuantity, listIndex: $listIndex, context: $context, messingQuantity: $messingQuantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$productIncrementEventImpl &&
            (identical(other.productQuantity, productQuantity) ||
                other.productQuantity == productQuantity) &&
            (identical(other.listIndex, listIndex) ||
                other.listIndex == listIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.messingQuantity, messingQuantity) ||
                other.messingQuantity == messingQuantity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, productQuantity, listIndex, context, messingQuantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$productIncrementEventImplCopyWith<_$productIncrementEventImpl>
      get copyWith => __$$productIncrementEventImplCopyWithImpl<
          _$productIncrementEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return productIncrementEvent(
        productQuantity, listIndex, context, messingQuantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return productIncrementEvent?.call(
        productQuantity, listIndex, context, messingQuantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productIncrementEvent != null) {
      return productIncrementEvent(
          productQuantity, listIndex, context, messingQuantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return productIncrementEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return productIncrementEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productIncrementEvent != null) {
      return productIncrementEvent(this);
    }
    return orElse();
  }
}

abstract class _productIncrementEvent implements ProductDetailsEvent {
  const factory _productIncrementEvent(
      {required final int productQuantity,
      required final int listIndex,
      required final BuildContext context,
      required final int messingQuantity}) = _$productIncrementEventImpl;

  int get productQuantity;
  int get listIndex;
  BuildContext get context;
  int get messingQuantity;
  @JsonKey(ignore: true)
  _$$productIncrementEventImplCopyWith<_$productIncrementEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$productDecrementEventImplCopyWith<$Res> {
  factory _$$productDecrementEventImplCopyWith(
          _$productDecrementEventImpl value,
          $Res Function(_$productDecrementEventImpl) then) =
      __$$productDecrementEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {int productQuantity,
      int listIndex,
      int messingQuantity,
      BuildContext context});
}

/// @nodoc
class __$$productDecrementEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$productDecrementEventImpl>
    implements _$$productDecrementEventImplCopyWith<$Res> {
  __$$productDecrementEventImplCopyWithImpl(_$productDecrementEventImpl _value,
      $Res Function(_$productDecrementEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productQuantity = null,
    Object? listIndex = null,
    Object? messingQuantity = null,
    Object? context = null,
  }) {
    return _then(_$productDecrementEventImpl(
      productQuantity: null == productQuantity
          ? _value.productQuantity
          : productQuantity // ignore: cast_nullable_to_non_nullable
              as int,
      listIndex: null == listIndex
          ? _value.listIndex
          : listIndex // ignore: cast_nullable_to_non_nullable
              as int,
      messingQuantity: null == messingQuantity
          ? _value.messingQuantity
          : messingQuantity // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$productDecrementEventImpl implements _productDecrementEvent {
  const _$productDecrementEventImpl(
      {required this.productQuantity,
      required this.listIndex,
      required this.messingQuantity,
      required this.context});

  @override
  final int productQuantity;
  @override
  final int listIndex;
  @override
  final int messingQuantity;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductDetailsEvent.productDecrementEvent(productQuantity: $productQuantity, listIndex: $listIndex, messingQuantity: $messingQuantity, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$productDecrementEventImpl &&
            (identical(other.productQuantity, productQuantity) ||
                other.productQuantity == productQuantity) &&
            (identical(other.listIndex, listIndex) ||
                other.listIndex == listIndex) &&
            (identical(other.messingQuantity, messingQuantity) ||
                other.messingQuantity == messingQuantity) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, productQuantity, listIndex, messingQuantity, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$productDecrementEventImplCopyWith<_$productDecrementEventImpl>
      get copyWith => __$$productDecrementEventImplCopyWithImpl<
          _$productDecrementEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return productDecrementEvent(
        productQuantity, listIndex, messingQuantity, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return productDecrementEvent?.call(
        productQuantity, listIndex, messingQuantity, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productDecrementEvent != null) {
      return productDecrementEvent(
          productQuantity, listIndex, messingQuantity, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return productDecrementEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return productDecrementEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (productDecrementEvent != null) {
      return productDecrementEvent(this);
    }
    return orElse();
  }
}

abstract class _productDecrementEvent implements ProductDetailsEvent {
  const factory _productDecrementEvent(
      {required final int productQuantity,
      required final int listIndex,
      required final int messingQuantity,
      required final BuildContext context}) = _$productDecrementEventImpl;

  int get productQuantity;
  int get listIndex;
  int get messingQuantity;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$productDecrementEventImplCopyWith<_$productDecrementEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getProductDataEventImplCopyWith<$Res> {
  factory _$$getProductDataEventImplCopyWith(_$getProductDataEventImpl value,
          $Res Function(_$getProductDataEventImpl) then) =
      __$$getProductDataEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      String orderId,
      OrdersBySupplier orderBySupplierProduct,
      OrderDatum orderData});

  $OrdersBySupplierCopyWith<$Res> get orderBySupplierProduct;
  $OrderDatumCopyWith<$Res> get orderData;
}

/// @nodoc
class __$$getProductDataEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$getProductDataEventImpl>
    implements _$$getProductDataEventImplCopyWith<$Res> {
  __$$getProductDataEventImplCopyWithImpl(_$getProductDataEventImpl _value,
      $Res Function(_$getProductDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? orderId = null,
    Object? orderBySupplierProduct = null,
    Object? orderData = null,
  }) {
    return _then(_$getProductDataEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
      orderBySupplierProduct: null == orderBySupplierProduct
          ? _value.orderBySupplierProduct
          : orderBySupplierProduct // ignore: cast_nullable_to_non_nullable
              as OrdersBySupplier,
      orderData: null == orderData
          ? _value.orderData
          : orderData // ignore: cast_nullable_to_non_nullable
              as OrderDatum,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $OrdersBySupplierCopyWith<$Res> get orderBySupplierProduct {
    return $OrdersBySupplierCopyWith<$Res>(_value.orderBySupplierProduct,
        (value) {
      return _then(_value.copyWith(orderBySupplierProduct: value));
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $OrderDatumCopyWith<$Res> get orderData {
    return $OrderDatumCopyWith<$Res>(_value.orderData, (value) {
      return _then(_value.copyWith(orderData: value));
    });
  }
}

/// @nodoc

class _$getProductDataEventImpl implements _getProductDataEvent {
  const _$getProductDataEventImpl(
      {required this.context,
      required this.orderId,
      required this.orderBySupplierProduct,
      required this.orderData});

  @override
  final BuildContext context;
  @override
  final String orderId;
  @override
  final OrdersBySupplier orderBySupplierProduct;
  @override
  final OrderDatum orderData;

  @override
  String toString() {
    return 'ProductDetailsEvent.getProductDataEvent(context: $context, orderId: $orderId, orderBySupplierProduct: $orderBySupplierProduct, orderData: $orderData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getProductDataEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.orderId, orderId) || other.orderId == orderId) &&
            (identical(other.orderBySupplierProduct, orderBySupplierProduct) ||
                other.orderBySupplierProduct == orderBySupplierProduct) &&
            (identical(other.orderData, orderData) ||
                other.orderData == orderData));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, context, orderId, orderBySupplierProduct, orderData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getProductDataEventImplCopyWith<_$getProductDataEventImpl> get copyWith =>
      __$$getProductDataEventImplCopyWithImpl<_$getProductDataEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductDataEvent(
        context, orderId, orderBySupplierProduct, orderData);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductDataEvent?.call(
        context, orderId, orderBySupplierProduct, orderData);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDataEvent != null) {
      return getProductDataEvent(
          context, orderId, orderBySupplierProduct, orderData);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDataEvent != null) {
      return getProductDataEvent(this);
    }
    return orElse();
  }
}

abstract class _getProductDataEvent implements ProductDetailsEvent {
  const factory _getProductDataEvent(
      {required final BuildContext context,
      required final String orderId,
      required final OrdersBySupplier orderBySupplierProduct,
      required final OrderDatum orderData}) = _$getProductDataEventImpl;

  BuildContext get context;
  String get orderId;
  OrdersBySupplier get orderBySupplierProduct;
  OrderDatum get orderData;
  @JsonKey(ignore: true)
  _$$getProductDataEventImplCopyWith<_$getProductDataEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$createIssueEventImplCopyWith<$Res> {
  factory _$$createIssueEventImplCopyWith(_$createIssueEventImpl value,
          $Res Function(_$createIssueEventImpl) then) =
      __$$createIssueEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext BottomSheetContext,
      BuildContext context,
      String supplierId,
      String productId,
      String issue,
      int missingQuantity,
      String orderId,
      bool isDeliver});
}

/// @nodoc
class __$$createIssueEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$createIssueEventImpl>
    implements _$$createIssueEventImplCopyWith<$Res> {
  __$$createIssueEventImplCopyWithImpl(_$createIssueEventImpl _value,
      $Res Function(_$createIssueEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? BottomSheetContext = null,
    Object? context = null,
    Object? supplierId = null,
    Object? productId = null,
    Object? issue = null,
    Object? missingQuantity = null,
    Object? orderId = null,
    Object? isDeliver = null,
  }) {
    return _then(_$createIssueEventImpl(
      BottomSheetContext: null == BottomSheetContext
          ? _value.BottomSheetContext
          : BottomSheetContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      issue: null == issue
          ? _value.issue
          : issue // ignore: cast_nullable_to_non_nullable
              as String,
      missingQuantity: null == missingQuantity
          ? _value.missingQuantity
          : missingQuantity // ignore: cast_nullable_to_non_nullable
              as int,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
      isDeliver: null == isDeliver
          ? _value.isDeliver
          : isDeliver // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$createIssueEventImpl implements _createIssueEvent {
  const _$createIssueEventImpl(
      {required this.BottomSheetContext,
      required this.context,
      required this.supplierId,
      required this.productId,
      required this.issue,
      required this.missingQuantity,
      required this.orderId,
      required this.isDeliver});

  @override
  final BuildContext BottomSheetContext;
  @override
  final BuildContext context;
  @override
  final String supplierId;
  @override
  final String productId;
  @override
  final String issue;
  @override
  final int missingQuantity;
  @override
  final String orderId;
  @override
  final bool isDeliver;

  @override
  String toString() {
    return 'ProductDetailsEvent.createIssueEvent(BottomSheetContext: $BottomSheetContext, context: $context, supplierId: $supplierId, productId: $productId, issue: $issue, missingQuantity: $missingQuantity, orderId: $orderId, isDeliver: $isDeliver)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$createIssueEventImpl &&
            (identical(other.BottomSheetContext, BottomSheetContext) ||
                other.BottomSheetContext == BottomSheetContext) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.issue, issue) || other.issue == issue) &&
            (identical(other.missingQuantity, missingQuantity) ||
                other.missingQuantity == missingQuantity) &&
            (identical(other.orderId, orderId) || other.orderId == orderId) &&
            (identical(other.isDeliver, isDeliver) ||
                other.isDeliver == isDeliver));
  }

  @override
  int get hashCode => Object.hash(runtimeType, BottomSheetContext, context,
      supplierId, productId, issue, missingQuantity, orderId, isDeliver);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$createIssueEventImplCopyWith<_$createIssueEventImpl> get copyWith =>
      __$$createIssueEventImplCopyWithImpl<_$createIssueEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return createIssueEvent(BottomSheetContext, context, supplierId, productId,
        issue, missingQuantity, orderId, isDeliver);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return createIssueEvent?.call(BottomSheetContext, context, supplierId,
        productId, issue, missingQuantity, orderId, isDeliver);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (createIssueEvent != null) {
      return createIssueEvent(BottomSheetContext, context, supplierId,
          productId, issue, missingQuantity, orderId, isDeliver);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return createIssueEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return createIssueEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (createIssueEvent != null) {
      return createIssueEvent(this);
    }
    return orElse();
  }
}

abstract class _createIssueEvent implements ProductDetailsEvent {
  const factory _createIssueEvent(
      {required final BuildContext BottomSheetContext,
      required final BuildContext context,
      required final String supplierId,
      required final String productId,
      required final String issue,
      required final int missingQuantity,
      required final String orderId,
      required final bool isDeliver}) = _$createIssueEventImpl;

  BuildContext get BottomSheetContext;
  BuildContext get context;
  String get supplierId;
  String get productId;
  String get issue;
  int get missingQuantity;
  String get orderId;
  bool get isDeliver;
  @JsonKey(ignore: true)
  _$$createIssueEventImplCopyWith<_$createIssueEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$checkAllEventImplCopyWith<$Res> {
  factory _$$checkAllEventImplCopyWith(
          _$checkAllEventImpl value, $Res Function(_$checkAllEventImpl) then) =
      __$$checkAllEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$checkAllEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$checkAllEventImpl>
    implements _$$checkAllEventImplCopyWith<$Res> {
  __$$checkAllEventImplCopyWithImpl(
      _$checkAllEventImpl _value, $Res Function(_$checkAllEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$checkAllEventImpl implements _checkAllEvent {
  const _$checkAllEventImpl();

  @override
  String toString() {
    return 'ProductDetailsEvent.checkAllEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$checkAllEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return checkAllEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return checkAllEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (checkAllEvent != null) {
      return checkAllEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return checkAllEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return checkAllEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (checkAllEvent != null) {
      return checkAllEvent(this);
    }
    return orElse();
  }
}

abstract class _checkAllEvent implements ProductDetailsEvent {
  const factory _checkAllEvent() = _$checkAllEventImpl;
}

/// @nodoc
abstract class _$$getOrderByIdEventImplCopyWith<$Res> {
  factory _$$getOrderByIdEventImplCopyWith(_$getOrderByIdEventImpl value,
          $Res Function(_$getOrderByIdEventImpl) then) =
      __$$getOrderByIdEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String orderId});
}

/// @nodoc
class __$$getOrderByIdEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$getOrderByIdEventImpl>
    implements _$$getOrderByIdEventImplCopyWith<$Res> {
  __$$getOrderByIdEventImplCopyWithImpl(_$getOrderByIdEventImpl _value,
      $Res Function(_$getOrderByIdEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? orderId = null,
  }) {
    return _then(_$getOrderByIdEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getOrderByIdEventImpl implements _getOrderByIdEvent {
  const _$getOrderByIdEventImpl({required this.context, required this.orderId});

  @override
  final BuildContext context;
  @override
  final String orderId;

  @override
  String toString() {
    return 'ProductDetailsEvent.getOrderByIdEvent(context: $context, orderId: $orderId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getOrderByIdEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.orderId, orderId) || other.orderId == orderId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, orderId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getOrderByIdEventImplCopyWith<_$getOrderByIdEventImpl> get copyWith =>
      __$$getOrderByIdEventImplCopyWithImpl<_$getOrderByIdEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getOrderByIdEvent(context, orderId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getOrderByIdEvent?.call(context, orderId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getOrderByIdEvent != null) {
      return getOrderByIdEvent(context, orderId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getOrderByIdEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getOrderByIdEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getOrderByIdEvent != null) {
      return getOrderByIdEvent(this);
    }
    return orElse();
  }
}

abstract class _getOrderByIdEvent implements ProductDetailsEvent {
  const factory _getOrderByIdEvent(
      {required final BuildContext context,
      required final String orderId}) = _$getOrderByIdEventImpl;

  BuildContext get context;
  String get orderId;
  @JsonKey(ignore: true)
  _$$getOrderByIdEventImplCopyWith<_$getOrderByIdEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getBottomSheetDataEventImplCopyWith<$Res> {
  factory _$$getBottomSheetDataEventImplCopyWith(
          _$getBottomSheetDataEventImpl value,
          $Res Function(_$getBottomSheetDataEventImpl) then) =
      __$$getBottomSheetDataEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String note});
}

/// @nodoc
class __$$getBottomSheetDataEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res,
        _$getBottomSheetDataEventImpl>
    implements _$$getBottomSheetDataEventImplCopyWith<$Res> {
  __$$getBottomSheetDataEventImplCopyWithImpl(
      _$getBottomSheetDataEventImpl _value,
      $Res Function(_$getBottomSheetDataEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? note = null,
  }) {
    return _then(_$getBottomSheetDataEventImpl(
      note: null == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getBottomSheetDataEventImpl implements _getBottomSheetDataEvent {
  const _$getBottomSheetDataEventImpl({required this.note});

  @override
  final String note;

  @override
  String toString() {
    return 'ProductDetailsEvent.getBottomSheetDataEvent(note: $note)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getBottomSheetDataEventImpl &&
            (identical(other.note, note) || other.note == note));
  }

  @override
  int get hashCode => Object.hash(runtimeType, note);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getBottomSheetDataEventImplCopyWith<_$getBottomSheetDataEventImpl>
      get copyWith => __$$getBottomSheetDataEventImplCopyWithImpl<
          _$getBottomSheetDataEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getBottomSheetDataEvent(note);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getBottomSheetDataEvent?.call(note);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getBottomSheetDataEvent != null) {
      return getBottomSheetDataEvent(note);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getBottomSheetDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getBottomSheetDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getBottomSheetDataEvent != null) {
      return getBottomSheetDataEvent(this);
    }
    return orElse();
  }
}

abstract class _getBottomSheetDataEvent implements ProductDetailsEvent {
  const factory _getBottomSheetDataEvent({required final String note}) =
      _$getBottomSheetDataEventImpl;

  String get note;
  @JsonKey(ignore: true)
  _$$getBottomSheetDataEventImplCopyWith<_$getBottomSheetDataEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$removeIssueEventImplCopyWith<$Res> {
  factory _$$removeIssueEventImplCopyWith(_$removeIssueEventImpl value,
          $Res Function(_$removeIssueEventImpl) then) =
      __$$removeIssueEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      String supplierId,
      String orderId,
      List<String> Product,
      BuildContext BottomSheetContext});
}

/// @nodoc
class __$$removeIssueEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$removeIssueEventImpl>
    implements _$$removeIssueEventImplCopyWith<$Res> {
  __$$removeIssueEventImplCopyWithImpl(_$removeIssueEventImpl _value,
      $Res Function(_$removeIssueEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? supplierId = null,
    Object? orderId = null,
    Object? Product = null,
    Object? BottomSheetContext = null,
  }) {
    return _then(_$removeIssueEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
      Product: null == Product
          ? _value._Product
          : Product // ignore: cast_nullable_to_non_nullable
              as List<String>,
      BottomSheetContext: null == BottomSheetContext
          ? _value.BottomSheetContext
          : BottomSheetContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$removeIssueEventImpl implements _removeIssueEvent {
  const _$removeIssueEventImpl(
      {required this.context,
      required this.supplierId,
      required this.orderId,
      required final List<String> Product,
      required this.BottomSheetContext})
      : _Product = Product;

  @override
  final BuildContext context;
  @override
  final String supplierId;
  @override
  final String orderId;
  final List<String> _Product;
  @override
  List<String> get Product {
    if (_Product is EqualUnmodifiableListView) return _Product;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_Product);
  }

  @override
  final BuildContext BottomSheetContext;

  @override
  String toString() {
    return 'ProductDetailsEvent.removeIssueEvent(context: $context, supplierId: $supplierId, orderId: $orderId, Product: $Product, BottomSheetContext: $BottomSheetContext)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$removeIssueEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.orderId, orderId) || other.orderId == orderId) &&
            const DeepCollectionEquality().equals(other._Product, _Product) &&
            (identical(other.BottomSheetContext, BottomSheetContext) ||
                other.BottomSheetContext == BottomSheetContext));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, supplierId, orderId,
      const DeepCollectionEquality().hash(_Product), BottomSheetContext);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$removeIssueEventImplCopyWith<_$removeIssueEventImpl> get copyWith =>
      __$$removeIssueEventImplCopyWithImpl<_$removeIssueEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return removeIssueEvent(
        context, supplierId, orderId, Product, BottomSheetContext);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return removeIssueEvent?.call(
        context, supplierId, orderId, Product, BottomSheetContext);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (removeIssueEvent != null) {
      return removeIssueEvent(
          context, supplierId, orderId, Product, BottomSheetContext);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return removeIssueEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return removeIssueEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (removeIssueEvent != null) {
      return removeIssueEvent(this);
    }
    return orElse();
  }
}

abstract class _removeIssueEvent implements ProductDetailsEvent {
  const factory _removeIssueEvent(
      {required final BuildContext context,
      required final String supplierId,
      required final String orderId,
      required final List<String> Product,
      required final BuildContext BottomSheetContext}) = _$removeIssueEventImpl;

  BuildContext get context;
  String get supplierId;
  String get orderId;
  List<String> get Product;
  BuildContext get BottomSheetContext;
  @JsonKey(ignore: true)
  _$$removeIssueEventImplCopyWith<_$removeIssueEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$duplicateOrderEventImplCopyWith<$Res> {
  factory _$$duplicateOrderEventImplCopyWith(_$duplicateOrderEventImpl value,
          $Res Function(_$duplicateOrderEventImpl) then) =
      __$$duplicateOrderEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String orderId, BuildContext dialogContext});
}

/// @nodoc
class __$$duplicateOrderEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$duplicateOrderEventImpl>
    implements _$$duplicateOrderEventImplCopyWith<$Res> {
  __$$duplicateOrderEventImplCopyWithImpl(_$duplicateOrderEventImpl _value,
      $Res Function(_$duplicateOrderEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? orderId = null,
    Object? dialogContext = null,
  }) {
    return _then(_$duplicateOrderEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
      dialogContext: null == dialogContext
          ? _value.dialogContext
          : dialogContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$duplicateOrderEventImpl implements _duplicateOrderEvent {
  const _$duplicateOrderEventImpl(
      {required this.context,
      required this.orderId,
      required this.dialogContext});

  @override
  final BuildContext context;
  @override
  final String orderId;
  @override
  final BuildContext dialogContext;

  @override
  String toString() {
    return 'ProductDetailsEvent.duplicateOrderEvent(context: $context, orderId: $orderId, dialogContext: $dialogContext)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$duplicateOrderEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.orderId, orderId) || other.orderId == orderId) &&
            (identical(other.dialogContext, dialogContext) ||
                other.dialogContext == dialogContext));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, orderId, dialogContext);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$duplicateOrderEventImplCopyWith<_$duplicateOrderEventImpl> get copyWith =>
      __$$duplicateOrderEventImplCopyWithImpl<_$duplicateOrderEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return duplicateOrderEvent(context, orderId, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return duplicateOrderEvent?.call(context, orderId, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (duplicateOrderEvent != null) {
      return duplicateOrderEvent(context, orderId, dialogContext);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return duplicateOrderEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return duplicateOrderEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (duplicateOrderEvent != null) {
      return duplicateOrderEvent(this);
    }
    return orElse();
  }
}

abstract class _duplicateOrderEvent implements ProductDetailsEvent {
  const factory _duplicateOrderEvent(
      {required final BuildContext context,
      required final String orderId,
      required final BuildContext dialogContext}) = _$duplicateOrderEventImpl;

  BuildContext get context;
  String get orderId;
  BuildContext get dialogContext;
  @JsonKey(ignore: true)
  _$$duplicateOrderEventImplCopyWith<_$duplicateOrderEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getAllCartEventImplCopyWith<$Res> {
  factory _$$getAllCartEventImplCopyWith(_$getAllCartEventImpl value,
          $Res Function(_$getAllCartEventImpl) then) =
      __$$getAllCartEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getAllCartEventImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$getAllCartEventImpl>
    implements _$$getAllCartEventImplCopyWith<$Res> {
  __$$getAllCartEventImplCopyWithImpl(
      _$getAllCartEventImpl _value, $Res Function(_$getAllCartEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getAllCartEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getAllCartEventImpl implements _getAllCartEvent {
  const _$getAllCartEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductDetailsEvent.getAllCartEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getAllCartEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getAllCartEventImplCopyWith<_$getAllCartEventImpl> get copyWith =>
      __$$getAllCartEventImplCopyWithImpl<_$getAllCartEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getAllCartEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getAllCartEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAllCartEvent != null) {
      return getAllCartEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getAllCartEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getAllCartEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAllCartEvent != null) {
      return getAllCartEvent(this);
    }
    return orElse();
  }
}

abstract class _getAllCartEvent implements ProductDetailsEvent {
  const factory _getAllCartEvent({required final BuildContext context}) =
      _$getAllCartEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getAllCartEventImplCopyWith<_$getAllCartEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$ProductDetailsEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductDetailsEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool isProductProblem, int index)
        productProblemEvent,
    required TResult Function(int selectRadioTile) radioButtonEvent,
    required TResult Function(int productQuantity, int listIndex,
            BuildContext context, int messingQuantity)
        productIncrementEvent,
    required TResult Function(int productQuantity, int listIndex,
            int messingQuantity, BuildContext context)
        productDecrementEvent,
    required TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)
        getProductDataEvent,
    required TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)
        createIssueEvent,
    required TResult Function() checkAllEvent,
    required TResult Function(BuildContext context, String orderId)
        getOrderByIdEvent,
    required TResult Function(String note) getBottomSheetDataEvent,
    required TResult Function(
            BuildContext context,
            String supplierId,
            String orderId,
            List<String> Product,
            BuildContext BottomSheetContext)
        removeIssueEvent,
    required TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)
        duplicateOrderEvent,
    required TResult Function(BuildContext context) getAllCartEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool isProductProblem, int index)? productProblemEvent,
    TResult? Function(int selectRadioTile)? radioButtonEvent,
    TResult? Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult? Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult? Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult? Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult? Function()? checkAllEvent,
    TResult? Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult? Function(String note)? getBottomSheetDataEvent,
    TResult? Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult? Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult? Function(BuildContext context)? getAllCartEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool isProductProblem, int index)? productProblemEvent,
    TResult Function(int selectRadioTile)? radioButtonEvent,
    TResult Function(int productQuantity, int listIndex, BuildContext context,
            int messingQuantity)?
        productIncrementEvent,
    TResult Function(int productQuantity, int listIndex, int messingQuantity,
            BuildContext context)?
        productDecrementEvent,
    TResult Function(BuildContext context, String orderId,
            OrdersBySupplier orderBySupplierProduct, OrderDatum orderData)?
        getProductDataEvent,
    TResult Function(
            BuildContext BottomSheetContext,
            BuildContext context,
            String supplierId,
            String productId,
            String issue,
            int missingQuantity,
            String orderId,
            bool isDeliver)?
        createIssueEvent,
    TResult Function()? checkAllEvent,
    TResult Function(BuildContext context, String orderId)? getOrderByIdEvent,
    TResult Function(String note)? getBottomSheetDataEvent,
    TResult Function(BuildContext context, String supplierId, String orderId,
            List<String> Product, BuildContext BottomSheetContext)?
        removeIssueEvent,
    TResult Function(
            BuildContext context, String orderId, BuildContext dialogContext)?
        duplicateOrderEvent,
    TResult Function(BuildContext context)? getAllCartEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_productProblemEvent value) productProblemEvent,
    required TResult Function(_radioButtonEvent value) radioButtonEvent,
    required TResult Function(_productIncrementEvent value)
        productIncrementEvent,
    required TResult Function(_productDecrementEvent value)
        productDecrementEvent,
    required TResult Function(_getProductDataEvent value) getProductDataEvent,
    required TResult Function(_createIssueEvent value) createIssueEvent,
    required TResult Function(_checkAllEvent value) checkAllEvent,
    required TResult Function(_getOrderByIdEvent value) getOrderByIdEvent,
    required TResult Function(_getBottomSheetDataEvent value)
        getBottomSheetDataEvent,
    required TResult Function(_removeIssueEvent value) removeIssueEvent,
    required TResult Function(_duplicateOrderEvent value) duplicateOrderEvent,
    required TResult Function(_getAllCartEvent value) getAllCartEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_productProblemEvent value)? productProblemEvent,
    TResult? Function(_radioButtonEvent value)? radioButtonEvent,
    TResult? Function(_productIncrementEvent value)? productIncrementEvent,
    TResult? Function(_productDecrementEvent value)? productDecrementEvent,
    TResult? Function(_getProductDataEvent value)? getProductDataEvent,
    TResult? Function(_createIssueEvent value)? createIssueEvent,
    TResult? Function(_checkAllEvent value)? checkAllEvent,
    TResult? Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult? Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult? Function(_removeIssueEvent value)? removeIssueEvent,
    TResult? Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult? Function(_getAllCartEvent value)? getAllCartEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_productProblemEvent value)? productProblemEvent,
    TResult Function(_radioButtonEvent value)? radioButtonEvent,
    TResult Function(_productIncrementEvent value)? productIncrementEvent,
    TResult Function(_productDecrementEvent value)? productDecrementEvent,
    TResult Function(_getProductDataEvent value)? getProductDataEvent,
    TResult Function(_createIssueEvent value)? createIssueEvent,
    TResult Function(_checkAllEvent value)? checkAllEvent,
    TResult Function(_getOrderByIdEvent value)? getOrderByIdEvent,
    TResult Function(_getBottomSheetDataEvent value)? getBottomSheetDataEvent,
    TResult Function(_removeIssueEvent value)? removeIssueEvent,
    TResult Function(_duplicateOrderEvent value)? duplicateOrderEvent,
    TResult Function(_getAllCartEvent value)? getAllCartEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements ProductDetailsEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProductDetailsState {
  bool get isProductProblem => throw _privateConstructorUsedError;
  bool get isRefresh => throw _privateConstructorUsedError;
  int get selectedRadioTile => throw _privateConstructorUsedError;
  List<int> get productListIndex => throw _privateConstructorUsedError;
  int get productWeight => throw _privateConstructorUsedError;
  String get phoneNumber => throw _privateConstructorUsedError;
  OrdersBySupplier get orderBySupplierProduct =>
      throw _privateConstructorUsedError;
  OrderDatum get orderData => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  int get quantity => throw _privateConstructorUsedError;
  bool get isAllCheck => throw _privateConstructorUsedError;
  int get missingQuantity => throw _privateConstructorUsedError;
  String get note => throw _privateConstructorUsedError;
  TextEditingController get addNoteController =>
      throw _privateConstructorUsedError;
  bool get isRemoveProcess => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  List<ProductStockModel> get productStockList =>
      throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  bool get isDuplicateOrderProcess => throw _privateConstructorUsedError;
  bool get isCartCount => throw _privateConstructorUsedError;
  bool get isSubUserCreateDuplicateOrder => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProductDetailsStateCopyWith<ProductDetailsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductDetailsStateCopyWith<$Res> {
  factory $ProductDetailsStateCopyWith(
          ProductDetailsState value, $Res Function(ProductDetailsState) then) =
      _$ProductDetailsStateCopyWithImpl<$Res, ProductDetailsState>;
  @useResult
  $Res call(
      {bool isProductProblem,
      bool isRefresh,
      int selectedRadioTile,
      List<int> productListIndex,
      int productWeight,
      String phoneNumber,
      OrdersBySupplier orderBySupplierProduct,
      OrderDatum orderData,
      bool isShimmering,
      bool isLoading,
      int quantity,
      bool isAllCheck,
      int missingQuantity,
      String note,
      TextEditingController addNoteController,
      bool isRemoveProcess,
      String language,
      List<ProductStockModel> productStockList,
      int productStockUpdateIndex,
      bool isDuplicateOrderProcess,
      bool isCartCount,
      bool isSubUserCreateDuplicateOrder});

  $OrdersBySupplierCopyWith<$Res> get orderBySupplierProduct;
  $OrderDatumCopyWith<$Res> get orderData;
}

/// @nodoc
class _$ProductDetailsStateCopyWithImpl<$Res, $Val extends ProductDetailsState>
    implements $ProductDetailsStateCopyWith<$Res> {
  _$ProductDetailsStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isProductProblem = null,
    Object? isRefresh = null,
    Object? selectedRadioTile = null,
    Object? productListIndex = null,
    Object? productWeight = null,
    Object? phoneNumber = null,
    Object? orderBySupplierProduct = null,
    Object? orderData = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? quantity = null,
    Object? isAllCheck = null,
    Object? missingQuantity = null,
    Object? note = null,
    Object? addNoteController = null,
    Object? isRemoveProcess = null,
    Object? language = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isDuplicateOrderProcess = null,
    Object? isCartCount = null,
    Object? isSubUserCreateDuplicateOrder = null,
  }) {
    return _then(_value.copyWith(
      isProductProblem: null == isProductProblem
          ? _value.isProductProblem
          : isProductProblem // ignore: cast_nullable_to_non_nullable
              as bool,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedRadioTile: null == selectedRadioTile
          ? _value.selectedRadioTile
          : selectedRadioTile // ignore: cast_nullable_to_non_nullable
              as int,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as List<int>,
      productWeight: null == productWeight
          ? _value.productWeight
          : productWeight // ignore: cast_nullable_to_non_nullable
              as int,
      phoneNumber: null == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String,
      orderBySupplierProduct: null == orderBySupplierProduct
          ? _value.orderBySupplierProduct
          : orderBySupplierProduct // ignore: cast_nullable_to_non_nullable
              as OrdersBySupplier,
      orderData: null == orderData
          ? _value.orderData
          : orderData // ignore: cast_nullable_to_non_nullable
              as OrderDatum,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      isAllCheck: null == isAllCheck
          ? _value.isAllCheck
          : isAllCheck // ignore: cast_nullable_to_non_nullable
              as bool,
      missingQuantity: null == missingQuantity
          ? _value.missingQuantity
          : missingQuantity // ignore: cast_nullable_to_non_nullable
              as int,
      note: null == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String,
      addNoteController: null == addNoteController
          ? _value.addNoteController
          : addNoteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<ProductStockModel>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isDuplicateOrderProcess: null == isDuplicateOrderProcess
          ? _value.isDuplicateOrderProcess
          : isDuplicateOrderProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      isCartCount: null == isCartCount
          ? _value.isCartCount
          : isCartCount // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCreateDuplicateOrder: null == isSubUserCreateDuplicateOrder
          ? _value.isSubUserCreateDuplicateOrder
          : isSubUserCreateDuplicateOrder // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $OrdersBySupplierCopyWith<$Res> get orderBySupplierProduct {
    return $OrdersBySupplierCopyWith<$Res>(_value.orderBySupplierProduct,
        (value) {
      return _then(_value.copyWith(orderBySupplierProduct: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $OrderDatumCopyWith<$Res> get orderData {
    return $OrderDatumCopyWith<$Res>(_value.orderData, (value) {
      return _then(_value.copyWith(orderData: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProductDetailsStateImplCopyWith<$Res>
    implements $ProductDetailsStateCopyWith<$Res> {
  factory _$$ProductDetailsStateImplCopyWith(_$ProductDetailsStateImpl value,
          $Res Function(_$ProductDetailsStateImpl) then) =
      __$$ProductDetailsStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isProductProblem,
      bool isRefresh,
      int selectedRadioTile,
      List<int> productListIndex,
      int productWeight,
      String phoneNumber,
      OrdersBySupplier orderBySupplierProduct,
      OrderDatum orderData,
      bool isShimmering,
      bool isLoading,
      int quantity,
      bool isAllCheck,
      int missingQuantity,
      String note,
      TextEditingController addNoteController,
      bool isRemoveProcess,
      String language,
      List<ProductStockModel> productStockList,
      int productStockUpdateIndex,
      bool isDuplicateOrderProcess,
      bool isCartCount,
      bool isSubUserCreateDuplicateOrder});

  @override
  $OrdersBySupplierCopyWith<$Res> get orderBySupplierProduct;
  @override
  $OrderDatumCopyWith<$Res> get orderData;
}

/// @nodoc
class __$$ProductDetailsStateImplCopyWithImpl<$Res>
    extends _$ProductDetailsStateCopyWithImpl<$Res, _$ProductDetailsStateImpl>
    implements _$$ProductDetailsStateImplCopyWith<$Res> {
  __$$ProductDetailsStateImplCopyWithImpl(_$ProductDetailsStateImpl _value,
      $Res Function(_$ProductDetailsStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isProductProblem = null,
    Object? isRefresh = null,
    Object? selectedRadioTile = null,
    Object? productListIndex = null,
    Object? productWeight = null,
    Object? phoneNumber = null,
    Object? orderBySupplierProduct = null,
    Object? orderData = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? quantity = null,
    Object? isAllCheck = null,
    Object? missingQuantity = null,
    Object? note = null,
    Object? addNoteController = null,
    Object? isRemoveProcess = null,
    Object? language = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isDuplicateOrderProcess = null,
    Object? isCartCount = null,
    Object? isSubUserCreateDuplicateOrder = null,
  }) {
    return _then(_$ProductDetailsStateImpl(
      isProductProblem: null == isProductProblem
          ? _value.isProductProblem
          : isProductProblem // ignore: cast_nullable_to_non_nullable
              as bool,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedRadioTile: null == selectedRadioTile
          ? _value.selectedRadioTile
          : selectedRadioTile // ignore: cast_nullable_to_non_nullable
              as int,
      productListIndex: null == productListIndex
          ? _value._productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as List<int>,
      productWeight: null == productWeight
          ? _value.productWeight
          : productWeight // ignore: cast_nullable_to_non_nullable
              as int,
      phoneNumber: null == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String,
      orderBySupplierProduct: null == orderBySupplierProduct
          ? _value.orderBySupplierProduct
          : orderBySupplierProduct // ignore: cast_nullable_to_non_nullable
              as OrdersBySupplier,
      orderData: null == orderData
          ? _value.orderData
          : orderData // ignore: cast_nullable_to_non_nullable
              as OrderDatum,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      isAllCheck: null == isAllCheck
          ? _value.isAllCheck
          : isAllCheck // ignore: cast_nullable_to_non_nullable
              as bool,
      missingQuantity: null == missingQuantity
          ? _value.missingQuantity
          : missingQuantity // ignore: cast_nullable_to_non_nullable
              as int,
      note: null == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String,
      addNoteController: null == addNoteController
          ? _value.addNoteController
          : addNoteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isRemoveProcess: null == isRemoveProcess
          ? _value.isRemoveProcess
          : isRemoveProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<ProductStockModel>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isDuplicateOrderProcess: null == isDuplicateOrderProcess
          ? _value.isDuplicateOrderProcess
          : isDuplicateOrderProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      isCartCount: null == isCartCount
          ? _value.isCartCount
          : isCartCount // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCreateDuplicateOrder: null == isSubUserCreateDuplicateOrder
          ? _value.isSubUserCreateDuplicateOrder
          : isSubUserCreateDuplicateOrder // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ProductDetailsStateImpl implements _ProductDetailsState {
  const _$ProductDetailsStateImpl(
      {required this.isProductProblem,
      required this.isRefresh,
      required this.selectedRadioTile,
      required final List<int> productListIndex,
      required this.productWeight,
      required this.phoneNumber,
      required this.orderBySupplierProduct,
      required this.orderData,
      required this.isShimmering,
      required this.isLoading,
      required this.quantity,
      required this.isAllCheck,
      required this.missingQuantity,
      required this.note,
      required this.addNoteController,
      required this.isRemoveProcess,
      required this.language,
      required final List<ProductStockModel> productStockList,
      required this.productStockUpdateIndex,
      required this.isDuplicateOrderProcess,
      required this.isCartCount,
      required this.isSubUserCreateDuplicateOrder})
      : _productListIndex = productListIndex,
        _productStockList = productStockList;

  @override
  final bool isProductProblem;
  @override
  final bool isRefresh;
  @override
  final int selectedRadioTile;
  final List<int> _productListIndex;
  @override
  List<int> get productListIndex {
    if (_productListIndex is EqualUnmodifiableListView)
      return _productListIndex;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productListIndex);
  }

  @override
  final int productWeight;
  @override
  final String phoneNumber;
  @override
  final OrdersBySupplier orderBySupplierProduct;
  @override
  final OrderDatum orderData;
  @override
  final bool isShimmering;
  @override
  final bool isLoading;
  @override
  final int quantity;
  @override
  final bool isAllCheck;
  @override
  final int missingQuantity;
  @override
  final String note;
  @override
  final TextEditingController addNoteController;
  @override
  final bool isRemoveProcess;
  @override
  final String language;
  final List<ProductStockModel> _productStockList;
  @override
  List<ProductStockModel> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final int productStockUpdateIndex;
  @override
  final bool isDuplicateOrderProcess;
  @override
  final bool isCartCount;
  @override
  final bool isSubUserCreateDuplicateOrder;

  @override
  String toString() {
    return 'ProductDetailsState(isProductProblem: $isProductProblem, isRefresh: $isRefresh, selectedRadioTile: $selectedRadioTile, productListIndex: $productListIndex, productWeight: $productWeight, phoneNumber: $phoneNumber, orderBySupplierProduct: $orderBySupplierProduct, orderData: $orderData, isShimmering: $isShimmering, isLoading: $isLoading, quantity: $quantity, isAllCheck: $isAllCheck, missingQuantity: $missingQuantity, note: $note, addNoteController: $addNoteController, isRemoveProcess: $isRemoveProcess, language: $language, productStockList: $productStockList, productStockUpdateIndex: $productStockUpdateIndex, isDuplicateOrderProcess: $isDuplicateOrderProcess, isCartCount: $isCartCount, isSubUserCreateDuplicateOrder: $isSubUserCreateDuplicateOrder)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductDetailsStateImpl &&
            (identical(other.isProductProblem, isProductProblem) ||
                other.isProductProblem == isProductProblem) &&
            (identical(other.isRefresh, isRefresh) ||
                other.isRefresh == isRefresh) &&
            (identical(other.selectedRadioTile, selectedRadioTile) ||
                other.selectedRadioTile == selectedRadioTile) &&
            const DeepCollectionEquality()
                .equals(other._productListIndex, _productListIndex) &&
            (identical(other.productWeight, productWeight) ||
                other.productWeight == productWeight) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.orderBySupplierProduct, orderBySupplierProduct) ||
                other.orderBySupplierProduct == orderBySupplierProduct) &&
            (identical(other.orderData, orderData) ||
                other.orderData == orderData) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.isAllCheck, isAllCheck) ||
                other.isAllCheck == isAllCheck) &&
            (identical(other.missingQuantity, missingQuantity) ||
                other.missingQuantity == missingQuantity) &&
            (identical(other.note, note) || other.note == note) &&
            (identical(other.addNoteController, addNoteController) ||
                other.addNoteController == addNoteController) &&
            (identical(other.isRemoveProcess, isRemoveProcess) ||
                other.isRemoveProcess == isRemoveProcess) &&
            (identical(other.language, language) ||
                other.language == language) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(
                    other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(
                    other.isDuplicateOrderProcess, isDuplicateOrderProcess) ||
                other.isDuplicateOrderProcess == isDuplicateOrderProcess) &&
            (identical(other.isCartCount, isCartCount) ||
                other.isCartCount == isCartCount) &&
            (identical(other.isSubUserCreateDuplicateOrder,
                    isSubUserCreateDuplicateOrder) ||
                other.isSubUserCreateDuplicateOrder ==
                    isSubUserCreateDuplicateOrder));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        isProductProblem,
        isRefresh,
        selectedRadioTile,
        const DeepCollectionEquality().hash(_productListIndex),
        productWeight,
        phoneNumber,
        orderBySupplierProduct,
        orderData,
        isShimmering,
        isLoading,
        quantity,
        isAllCheck,
        missingQuantity,
        note,
        addNoteController,
        isRemoveProcess,
        language,
        const DeepCollectionEquality().hash(_productStockList),
        productStockUpdateIndex,
        isDuplicateOrderProcess,
        isCartCount,
        isSubUserCreateDuplicateOrder
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductDetailsStateImplCopyWith<_$ProductDetailsStateImpl> get copyWith =>
      __$$ProductDetailsStateImplCopyWithImpl<_$ProductDetailsStateImpl>(
          this, _$identity);
}

abstract class _ProductDetailsState implements ProductDetailsState {
  const factory _ProductDetailsState(
          {required final bool isProductProblem,
          required final bool isRefresh,
          required final int selectedRadioTile,
          required final List<int> productListIndex,
          required final int productWeight,
          required final String phoneNumber,
          required final OrdersBySupplier orderBySupplierProduct,
          required final OrderDatum orderData,
          required final bool isShimmering,
          required final bool isLoading,
          required final int quantity,
          required final bool isAllCheck,
          required final int missingQuantity,
          required final String note,
          required final TextEditingController addNoteController,
          required final bool isRemoveProcess,
          required final String language,
          required final List<ProductStockModel> productStockList,
          required final int productStockUpdateIndex,
          required final bool isDuplicateOrderProcess,
          required final bool isCartCount,
          required final bool isSubUserCreateDuplicateOrder}) =
      _$ProductDetailsStateImpl;

  @override
  bool get isProductProblem;
  @override
  bool get isRefresh;
  @override
  int get selectedRadioTile;
  @override
  List<int> get productListIndex;
  @override
  int get productWeight;
  @override
  String get phoneNumber;
  @override
  OrdersBySupplier get orderBySupplierProduct;
  @override
  OrderDatum get orderData;
  @override
  bool get isShimmering;
  @override
  bool get isLoading;
  @override
  int get quantity;
  @override
  bool get isAllCheck;
  @override
  int get missingQuantity;
  @override
  String get note;
  @override
  TextEditingController get addNoteController;
  @override
  bool get isRemoveProcess;
  @override
  String get language;
  @override
  List<ProductStockModel> get productStockList;
  @override
  int get productStockUpdateIndex;
  @override
  bool get isDuplicateOrderProcess;
  @override
  bool get isCartCount;
  @override
  bool get isSubUserCreateDuplicateOrder;
  @override
  @JsonKey(ignore: true)
  _$$ProductDetailsStateImplCopyWith<_$ProductDetailsStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
