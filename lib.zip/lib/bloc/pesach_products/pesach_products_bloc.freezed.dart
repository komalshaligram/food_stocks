// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'pesach_products_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$PesachProductsEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PesachProductsEventCopyWith<$Res> {
  factory $PesachProductsEventCopyWith(
          PesachProductsEvent value, $Res Function(PesachProductsEvent) then) =
      _$PesachProductsEventCopyWithImpl<$Res, PesachProductsEvent>;
}

/// @nodoc
class _$PesachProductsEventCopyWithImpl<$Res, $Val extends PesachProductsEvent>
    implements $PesachProductsEventCopyWith<$Res> {
  _$PesachProductsEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetSupplierProductsIdEventImplCopyWith<$Res> {
  factory _$$GetSupplierProductsIdEventImplCopyWith(
          _$GetSupplierProductsIdEventImpl value,
          $Res Function(_$GetSupplierProductsIdEventImpl) then) =
      __$$GetSupplierProductsIdEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String supplierId, String search});
}

/// @nodoc
class __$$GetSupplierProductsIdEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$GetSupplierProductsIdEventImpl>
    implements _$$GetSupplierProductsIdEventImplCopyWith<$Res> {
  __$$GetSupplierProductsIdEventImplCopyWithImpl(
      _$GetSupplierProductsIdEventImpl _value,
      $Res Function(_$GetSupplierProductsIdEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierId = null,
    Object? search = null,
  }) {
    return _then(_$GetSupplierProductsIdEventImpl(
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetSupplierProductsIdEventImpl implements _GetSupplierProductsIdEvent {
  const _$GetSupplierProductsIdEventImpl(
      {required this.supplierId, required this.search});

  @override
  final String supplierId;
  @override
  final String search;

  @override
  String toString() {
    return 'PesachProductsEvent.getSupplierProductsIdEvent(supplierId: $supplierId, search: $search)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetSupplierProductsIdEventImpl &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.search, search) || other.search == search));
  }

  @override
  int get hashCode => Object.hash(runtimeType, supplierId, search);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetSupplierProductsIdEventImplCopyWith<_$GetSupplierProductsIdEventImpl>
      get copyWith => __$$GetSupplierProductsIdEventImplCopyWithImpl<
          _$GetSupplierProductsIdEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getSupplierProductsIdEvent(supplierId, search);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getSupplierProductsIdEvent?.call(supplierId, search);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSupplierProductsIdEvent != null) {
      return getSupplierProductsIdEvent(supplierId, search);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getSupplierProductsIdEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getSupplierProductsIdEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSupplierProductsIdEvent != null) {
      return getSupplierProductsIdEvent(this);
    }
    return orElse();
  }
}

abstract class _GetSupplierProductsIdEvent implements PesachProductsEvent {
  const factory _GetSupplierProductsIdEvent(
      {required final String supplierId,
      required final String search}) = _$GetSupplierProductsIdEventImpl;

  String get supplierId;
  String get search;
  @JsonKey(ignore: true)
  _$$GetSupplierProductsIdEventImplCopyWith<_$GetSupplierProductsIdEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetSupplierProductsListEventImplCopyWith<$Res> {
  factory _$$GetSupplierProductsListEventImplCopyWith(
          _$GetSupplierProductsListEventImpl value,
          $Res Function(_$GetSupplierProductsListEventImpl) then) =
      __$$GetSupplierProductsListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String searchType});
}

/// @nodoc
class __$$GetSupplierProductsListEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$GetSupplierProductsListEventImpl>
    implements _$$GetSupplierProductsListEventImplCopyWith<$Res> {
  __$$GetSupplierProductsListEventImplCopyWithImpl(
      _$GetSupplierProductsListEventImpl _value,
      $Res Function(_$GetSupplierProductsListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? searchType = null,
  }) {
    return _then(_$GetSupplierProductsListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      searchType: null == searchType
          ? _value.searchType
          : searchType // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetSupplierProductsListEventImpl
    implements _GetSupplierProductsListEvent {
  const _$GetSupplierProductsListEventImpl(
      {required this.context, required this.searchType});

  @override
  final BuildContext context;
  @override
  final String searchType;

  @override
  String toString() {
    return 'PesachProductsEvent.getSupplierProductsListEvent(context: $context, searchType: $searchType)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetSupplierProductsListEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.searchType, searchType) ||
                other.searchType == searchType));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, searchType);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetSupplierProductsListEventImplCopyWith<
          _$GetSupplierProductsListEventImpl>
      get copyWith => __$$GetSupplierProductsListEventImplCopyWithImpl<
          _$GetSupplierProductsListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getSupplierProductsListEvent(context, searchType);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getSupplierProductsListEvent?.call(context, searchType);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSupplierProductsListEvent != null) {
      return getSupplierProductsListEvent(context, searchType);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getSupplierProductsListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getSupplierProductsListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSupplierProductsListEvent != null) {
      return getSupplierProductsListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetSupplierProductsListEvent implements PesachProductsEvent {
  const factory _GetSupplierProductsListEvent(
      {required final BuildContext context,
      required final String searchType}) = _$GetSupplierProductsListEventImpl;

  BuildContext get context;
  String get searchType;
  @JsonKey(ignore: true)
  _$$GetSupplierProductsListEventImplCopyWith<
          _$GetSupplierProductsListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductDetailsEventImplCopyWith<$Res> {
  factory _$$GetProductDetailsEventImplCopyWith(
          _$GetProductDetailsEventImpl value,
          $Res Function(_$GetProductDetailsEventImpl) then) =
      __$$GetProductDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      String productId,
      bool isBarcode,
      int productListIndex});
}

/// @nodoc
class __$$GetProductDetailsEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$GetProductDetailsEventImpl>
    implements _$$GetProductDetailsEventImplCopyWith<$Res> {
  __$$GetProductDetailsEventImplCopyWithImpl(
      _$GetProductDetailsEventImpl _value,
      $Res Function(_$GetProductDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
    Object? isBarcode = null,
    Object? productListIndex = null,
  }) {
    return _then(_$GetProductDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$GetProductDetailsEventImpl implements _GetProductDetailsEvent {
  const _$GetProductDetailsEventImpl(
      {required this.context,
      required this.productId,
      required this.isBarcode,
      required this.productListIndex});

  @override
  final BuildContext context;
  @override
  final String productId;
  @override
  final bool isBarcode;
  @override
  final int productListIndex;

  @override
  String toString() {
    return 'PesachProductsEvent.getProductDetailsEvent(context: $context, productId: $productId, isBarcode: $isBarcode, productListIndex: $productListIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode) &&
            (identical(other.productListIndex, productListIndex) ||
                other.productListIndex == productListIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, productId, isBarcode, productListIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => __$$GetProductDetailsEventImplCopyWithImpl<
          _$GetProductDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductDetailsEvent(
        context, productId, isBarcode, productListIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(
        context, productId, isBarcode, productListIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(
          context, productId, isBarcode, productListIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductDetailsEvent implements PesachProductsEvent {
  const factory _GetProductDetailsEvent(
      {required final BuildContext context,
      required final String productId,
      required final bool isBarcode,
      required final int productListIndex}) = _$GetProductDetailsEventImpl;

  BuildContext get context;
  String get productId;
  bool get isBarcode;
  int get productListIndex;
  @JsonKey(ignore: true)
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$IncreaseQuantityOfProductImplCopyWith(
          _$IncreaseQuantityOfProductImpl value,
          $Res Function(_$IncreaseQuantityOfProductImpl) then) =
      __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$IncreaseQuantityOfProductImpl>
    implements _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  __$$IncreaseQuantityOfProductImplCopyWithImpl(
      _$IncreaseQuantityOfProductImpl _value,
      $Res Function(_$IncreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$IncreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$IncreaseQuantityOfProductImpl implements _IncreaseQuantityOfProduct {
  const _$IncreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PesachProductsEvent.increaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => __$$IncreaseQuantityOfProductImplCopyWithImpl<
          _$IncreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return increaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return increaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _IncreaseQuantityOfProduct implements PesachProductsEvent {
  const factory _IncreaseQuantityOfProduct(
      {required final BuildContext context}) = _$IncreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$DecreaseQuantityOfProductImplCopyWith(
          _$DecreaseQuantityOfProductImpl value,
          $Res Function(_$DecreaseQuantityOfProductImpl) then) =
      __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$DecreaseQuantityOfProductImpl>
    implements _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  __$$DecreaseQuantityOfProductImplCopyWithImpl(
      _$DecreaseQuantityOfProductImpl _value,
      $Res Function(_$DecreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DecreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DecreaseQuantityOfProductImpl implements _DecreaseQuantityOfProduct {
  const _$DecreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PesachProductsEvent.decreaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DecreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => __$$DecreaseQuantityOfProductImplCopyWithImpl<
          _$DecreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _DecreaseQuantityOfProduct implements PesachProductsEvent {
  const factory _DecreaseQuantityOfProduct(
      {required final BuildContext context}) = _$DecreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  factory _$$UpdateQuantityOfProductImplCopyWith(
          _$UpdateQuantityOfProductImpl value,
          $Res Function(_$UpdateQuantityOfProductImpl) then) =
      __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String quantity});
}

/// @nodoc
class __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$UpdateQuantityOfProductImpl>
    implements _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  __$$UpdateQuantityOfProductImplCopyWithImpl(
      _$UpdateQuantityOfProductImpl _value,
      $Res Function(_$UpdateQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? quantity = null,
  }) {
    return _then(_$UpdateQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UpdateQuantityOfProductImpl implements _UpdateQuantityOfProduct {
  const _$UpdateQuantityOfProductImpl(
      {required this.context, required this.quantity});

  @override
  final BuildContext context;
  @override
  final String quantity;

  @override
  String toString() {
    return 'PesachProductsEvent.updateQuantityOfProduct(context: $context, quantity: $quantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, quantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => __$$UpdateQuantityOfProductImplCopyWithImpl<
          _$UpdateQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateQuantityOfProduct(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(context, quantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _UpdateQuantityOfProduct implements PesachProductsEvent {
  const factory _UpdateQuantityOfProduct(
      {required final BuildContext context,
      required final String quantity}) = _$UpdateQuantityOfProductImpl;

  BuildContext get context;
  String get quantity;
  @JsonKey(ignore: true)
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeNoteOfProductImplCopyWith<$Res> {
  factory _$$ChangeNoteOfProductImplCopyWith(_$ChangeNoteOfProductImpl value,
          $Res Function(_$ChangeNoteOfProductImpl) then) =
      __$$ChangeNoteOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String newNote});
}

/// @nodoc
class __$$ChangeNoteOfProductImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$ChangeNoteOfProductImpl>
    implements _$$ChangeNoteOfProductImplCopyWith<$Res> {
  __$$ChangeNoteOfProductImplCopyWithImpl(_$ChangeNoteOfProductImpl _value,
      $Res Function(_$ChangeNoteOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newNote = null,
  }) {
    return _then(_$ChangeNoteOfProductImpl(
      newNote: null == newNote
          ? _value.newNote
          : newNote // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeNoteOfProductImpl implements _ChangeNoteOfProduct {
  const _$ChangeNoteOfProductImpl({required this.newNote});

  @override
  final String newNote;

  @override
  String toString() {
    return 'PesachProductsEvent.changeNoteOfProduct(newNote: $newNote)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeNoteOfProductImpl &&
            (identical(other.newNote, newNote) || other.newNote == newNote));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newNote);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      __$$ChangeNoteOfProductImplCopyWithImpl<_$ChangeNoteOfProductImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeNoteOfProduct(newNote);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(newNote);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(newNote);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeNoteOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(this);
    }
    return orElse();
  }
}

abstract class _ChangeNoteOfProduct implements PesachProductsEvent {
  const factory _ChangeNoteOfProduct({required final String newNote}) =
      _$ChangeNoteOfProductImpl;

  String get newNote;
  @JsonKey(ignore: true)
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  factory _$$ChangeSupplierSelectionExpansionEventImplCopyWith(
          _$ChangeSupplierSelectionExpansionEventImpl value,
          $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) then) =
      __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isSelectSupplier});
}

/// @nodoc
class __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$ChangeSupplierSelectionExpansionEventImpl>
    implements _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl(
      _$ChangeSupplierSelectionExpansionEventImpl _value,
      $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSelectSupplier = freezed,
  }) {
    return _then(_$ChangeSupplierSelectionExpansionEventImpl(
      isSelectSupplier: freezed == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeSupplierSelectionExpansionEventImpl
    implements _ChangeSupplierSelectionExpansionEvent {
  const _$ChangeSupplierSelectionExpansionEventImpl({this.isSelectSupplier});

  @override
  final bool? isSelectSupplier;

  @override
  String toString() {
    return 'PesachProductsEvent.changeSupplierSelectionExpansionEvent(isSelectSupplier: $isSelectSupplier)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSupplierSelectionExpansionEventImpl &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSelectSupplier);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<
          _$ChangeSupplierSelectionExpansionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(isSelectSupplier);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSupplierSelectionExpansionEvent
    implements PesachProductsEvent {
  const factory _ChangeSupplierSelectionExpansionEvent(
          {final bool? isSelectSupplier}) =
      _$ChangeSupplierSelectionExpansionEventImpl;

  bool? get isSelectSupplier;
  @JsonKey(ignore: true)
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SupplierSelectionEventImplCopyWith<$Res> {
  factory _$$SupplierSelectionEventImplCopyWith(
          _$SupplierSelectionEventImpl value,
          $Res Function(_$SupplierSelectionEventImpl) then) =
      __$$SupplierSelectionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int supplierIndex, BuildContext context, int supplierSaleIndex});
}

/// @nodoc
class __$$SupplierSelectionEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$SupplierSelectionEventImpl>
    implements _$$SupplierSelectionEventImplCopyWith<$Res> {
  __$$SupplierSelectionEventImplCopyWithImpl(
      _$SupplierSelectionEventImpl _value,
      $Res Function(_$SupplierSelectionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierIndex = null,
    Object? context = null,
    Object? supplierSaleIndex = null,
  }) {
    return _then(_$SupplierSelectionEventImpl(
      supplierIndex: null == supplierIndex
          ? _value.supplierIndex
          : supplierIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierSaleIndex: null == supplierSaleIndex
          ? _value.supplierSaleIndex
          : supplierSaleIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SupplierSelectionEventImpl implements _SupplierSelectionEvent {
  const _$SupplierSelectionEventImpl(
      {required this.supplierIndex,
      required this.context,
      required this.supplierSaleIndex});

  @override
  final int supplierIndex;
  @override
  final BuildContext context;
  @override
  final int supplierSaleIndex;

  @override
  String toString() {
    return 'PesachProductsEvent.supplierSelectionEvent(supplierIndex: $supplierIndex, context: $context, supplierSaleIndex: $supplierSaleIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSelectionEventImpl &&
            (identical(other.supplierIndex, supplierIndex) ||
                other.supplierIndex == supplierIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierSaleIndex, supplierSaleIndex) ||
                other.supplierSaleIndex == supplierSaleIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, supplierIndex, context, supplierSaleIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => __$$SupplierSelectionEventImplCopyWithImpl<
          _$SupplierSelectionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(
        supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return supplierSelectionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(this);
    }
    return orElse();
  }
}

abstract class _SupplierSelectionEvent implements PesachProductsEvent {
  const factory _SupplierSelectionEvent(
      {required final int supplierIndex,
      required final BuildContext context,
      required final int supplierSaleIndex}) = _$SupplierSelectionEventImpl;

  int get supplierIndex;
  BuildContext get context;
  int get supplierSaleIndex;
  @JsonKey(ignore: true)
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddToCartProductEventImplCopyWith<$Res> {
  factory _$$AddToCartProductEventImplCopyWith(
          _$AddToCartProductEventImpl value,
          $Res Function(_$AddToCartProductEventImpl) then) =
      __$$AddToCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$AddToCartProductEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$AddToCartProductEventImpl>
    implements _$$AddToCartProductEventImplCopyWith<$Res> {
  __$$AddToCartProductEventImplCopyWithImpl(_$AddToCartProductEventImpl _value,
      $Res Function(_$AddToCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$AddToCartProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AddToCartProductEventImpl implements _AddToCartProductEvent {
  const _$AddToCartProductEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'PesachProductsEvent.addToCartProductEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddToCartProductEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => __$$AddToCartProductEventImplCopyWithImpl<
          _$AddToCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return addToCartProductEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return addToCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _AddToCartProductEvent implements PesachProductsEvent {
  const factory _AddToCartProductEvent(
      {required final BuildContext context,
      required final String productId}) = _$AddToCartProductEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetCartCountEventImplCopyWith<$Res> {
  factory _$$SetCartCountEventImplCopyWith(_$SetCartCountEventImpl value,
          $Res Function(_$SetCartCountEventImpl) then) =
      __$$SetCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SetCartCountEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$SetCartCountEventImpl>
    implements _$$SetCartCountEventImplCopyWith<$Res> {
  __$$SetCartCountEventImplCopyWithImpl(_$SetCartCountEventImpl _value,
      $Res Function(_$SetCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SetCartCountEventImpl implements _SetCartCountEvent {
  const _$SetCartCountEventImpl();

  @override
  String toString() {
    return 'PesachProductsEvent.setCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SetCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return setCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return setCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return setCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return setCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetCartCountEvent implements PesachProductsEvent {
  const factory _SetCartCountEvent() = _$SetCartCountEventImpl;
}

/// @nodoc
abstract class _$$UpdateImageIndexEventImplCopyWith<$Res> {
  factory _$$UpdateImageIndexEventImplCopyWith(
          _$UpdateImageIndexEventImpl value,
          $Res Function(_$UpdateImageIndexEventImpl) then) =
      __$$UpdateImageIndexEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$UpdateImageIndexEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$UpdateImageIndexEventImpl>
    implements _$$UpdateImageIndexEventImplCopyWith<$Res> {
  __$$UpdateImageIndexEventImplCopyWithImpl(_$UpdateImageIndexEventImpl _value,
      $Res Function(_$UpdateImageIndexEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$UpdateImageIndexEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$UpdateImageIndexEventImpl implements _UpdateImageIndexEvent {
  const _$UpdateImageIndexEventImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'PesachProductsEvent.updateImageIndexEvent(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateImageIndexEventImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => __$$UpdateImageIndexEventImplCopyWithImpl<
          _$UpdateImageIndexEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateImageIndexEvent(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateImageIndexEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateImageIndexEvent implements PesachProductsEvent {
  const factory _UpdateImageIndexEvent({required final int index}) =
      _$UpdateImageIndexEventImpl;

  int get index;
  @JsonKey(ignore: true)
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ToggleNoteEventImplCopyWith<$Res> {
  factory _$$ToggleNoteEventImplCopyWith(_$ToggleNoteEventImpl value,
          $Res Function(_$ToggleNoteEventImpl) then) =
      __$$ToggleNoteEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ToggleNoteEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$ToggleNoteEventImpl>
    implements _$$ToggleNoteEventImplCopyWith<$Res> {
  __$$ToggleNoteEventImplCopyWithImpl(
      _$ToggleNoteEventImpl _value, $Res Function(_$ToggleNoteEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ToggleNoteEventImpl implements _ToggleNoteEvent {
  const _$ToggleNoteEventImpl();

  @override
  String toString() {
    return 'PesachProductsEvent.toggleNoteEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ToggleNoteEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return toggleNoteEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return toggleNoteEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return toggleNoteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(this);
    }
    return orElse();
  }
}

abstract class _ToggleNoteEvent implements PesachProductsEvent {
  const factory _ToggleNoteEvent() = _$ToggleNoteEventImpl;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PesachProductsEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements PesachProductsEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetAllProductsEventImplCopyWith<$Res> {
  factory _$$GetAllProductsEventImplCopyWith(_$GetAllProductsEventImpl value,
          $Res Function(_$GetAllProductsEventImpl) then) =
      __$$GetAllProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String search});
}

/// @nodoc
class __$$GetAllProductsEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$GetAllProductsEventImpl>
    implements _$$GetAllProductsEventImplCopyWith<$Res> {
  __$$GetAllProductsEventImplCopyWithImpl(_$GetAllProductsEventImpl _value,
      $Res Function(_$GetAllProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? search = null,
  }) {
    return _then(_$GetAllProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetAllProductsEventImpl implements _GetAllProductsEvent {
  const _$GetAllProductsEventImpl(
      {required this.context, required this.search});

  @override
  final BuildContext context;
  @override
  final String search;

  @override
  String toString() {
    return 'PesachProductsEvent.getAllProducts(context: $context, search: $search)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.search, search) || other.search == search));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, search);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllProductsEventImplCopyWith<_$GetAllProductsEventImpl> get copyWith =>
      __$$GetAllProductsEventImplCopyWithImpl<_$GetAllProductsEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getAllProducts(context, search);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getAllProducts?.call(context, search);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAllProducts != null) {
      return getAllProducts(context, search);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getAllProducts(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getAllProducts?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAllProducts != null) {
      return getAllProducts(this);
    }
    return orElse();
  }
}

abstract class _GetAllProductsEvent implements PesachProductsEvent {
  const factory _GetAllProductsEvent(
      {required final BuildContext context,
      required final String search}) = _$GetAllProductsEventImpl;

  BuildContext get context;
  String get search;
  @JsonKey(ignore: true)
  _$$GetAllProductsEventImplCopyWith<_$GetAllProductsEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getGridListViewImplCopyWith<$Res> {
  factory _$$getGridListViewImplCopyWith(_$getGridListViewImpl value,
          $Res Function(_$getGridListViewImpl) then) =
      __$$getGridListViewImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getGridListViewImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$getGridListViewImpl>
    implements _$$getGridListViewImplCopyWith<$Res> {
  __$$getGridListViewImplCopyWithImpl(
      _$getGridListViewImpl _value, $Res Function(_$getGridListViewImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getGridListViewImpl implements _getGridListView {
  const _$getGridListViewImpl();

  @override
  String toString() {
    return 'PesachProductsEvent.getGridListView()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getGridListViewImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getGridListView();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getGridListView?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getGridListView != null) {
      return getGridListView();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getGridListView(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getGridListView?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getGridListView != null) {
      return getGridListView(this);
    }
    return orElse();
  }
}

abstract class _getGridListView implements PesachProductsEvent {
  const factory _getGridListView() = _$getGridListViewImpl;
}

/// @nodoc
abstract class _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  factory _$$ChangeCategoryExpansionImplCopyWith(
          _$ChangeCategoryExpansionImpl value,
          $Res Function(_$ChangeCategoryExpansionImpl) then) =
      __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isOpened});
}

/// @nodoc
class __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$ChangeCategoryExpansionImpl>
    implements _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  __$$ChangeCategoryExpansionImplCopyWithImpl(
      _$ChangeCategoryExpansionImpl _value,
      $Res Function(_$ChangeCategoryExpansionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isOpened = freezed,
  }) {
    return _then(_$ChangeCategoryExpansionImpl(
      isOpened: freezed == isOpened
          ? _value.isOpened
          : isOpened // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeCategoryExpansionImpl implements _ChangeCategoryExpansion {
  const _$ChangeCategoryExpansionImpl({this.isOpened});

  @override
  final bool? isOpened;

  @override
  String toString() {
    return 'PesachProductsEvent.changeCategoryExpansion(isOpened: $isOpened)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeCategoryExpansionImpl &&
            (identical(other.isOpened, isOpened) ||
                other.isOpened == isOpened));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isOpened);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => __$$ChangeCategoryExpansionImplCopyWithImpl<
          _$ChangeCategoryExpansionImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeCategoryExpansion(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(isOpened);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeCategoryExpansion(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(this);
    }
    return orElse();
  }
}

abstract class _ChangeCategoryExpansion implements PesachProductsEvent {
  const factory _ChangeCategoryExpansion({final bool? isOpened}) =
      _$ChangeCategoryExpansionImpl;

  bool? get isOpened;
  @JsonKey(ignore: true)
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GlobalSearchEventImplCopyWith<$Res> {
  factory _$$GlobalSearchEventImplCopyWith(_$GlobalSearchEventImpl value,
          $Res Function(_$GlobalSearchEventImpl) then) =
      __$$GlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GlobalSearchEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$GlobalSearchEventImpl>
    implements _$$GlobalSearchEventImplCopyWith<$Res> {
  __$$GlobalSearchEventImplCopyWithImpl(_$GlobalSearchEventImpl _value,
      $Res Function(_$GlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GlobalSearchEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GlobalSearchEventImpl implements _GlobalSearchEvent {
  const _$GlobalSearchEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PesachProductsEvent.globalSearchEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalSearchEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      __$$GlobalSearchEventImplCopyWithImpl<_$GlobalSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return globalSearchEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return globalSearchEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return globalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return globalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _GlobalSearchEvent implements PesachProductsEvent {
  const factory _GlobalSearchEvent({required final BuildContext context}) =
      _$GlobalSearchEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  factory _$$UpdateGlobalSearchEventImplCopyWith(
          _$UpdateGlobalSearchEventImpl value,
          $Res Function(_$UpdateGlobalSearchEventImpl) then) =
      __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search, List<SearchModel> searchList});
}

/// @nodoc
class __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$UpdateGlobalSearchEventImpl>
    implements _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  __$$UpdateGlobalSearchEventImplCopyWithImpl(
      _$UpdateGlobalSearchEventImpl _value,
      $Res Function(_$UpdateGlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
    Object? searchList = null,
  }) {
    return _then(_$UpdateGlobalSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
    ));
  }
}

/// @nodoc

class _$UpdateGlobalSearchEventImpl implements _UpdateGlobalSearchEvent {
  const _$UpdateGlobalSearchEventImpl(
      {required this.search, required final List<SearchModel> searchList})
      : _searchList = searchList;

  @override
  final String search;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  String toString() {
    return 'PesachProductsEvent.updateGlobalSearchEvent(search: $search, searchList: $searchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateGlobalSearchEventImpl &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, search, const DeepCollectionEquality().hash(_searchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => __$$UpdateGlobalSearchEventImplCopyWithImpl<
          _$UpdateGlobalSearchEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateGlobalSearchEvent(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(search, searchList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateGlobalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateGlobalSearchEvent implements PesachProductsEvent {
  const factory _UpdateGlobalSearchEvent(
          {required final String search,
          required final List<SearchModel> searchList}) =
      _$UpdateGlobalSearchEventImpl;

  String get search;
  List<SearchModel> get searchList;
  @JsonKey(ignore: true)
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RelatedProductsEventImplCopyWith<$Res> {
  factory _$$RelatedProductsEventImplCopyWith(_$RelatedProductsEventImpl value,
          $Res Function(_$RelatedProductsEventImpl) then) =
      __$$RelatedProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$RelatedProductsEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$RelatedProductsEventImpl>
    implements _$$RelatedProductsEventImplCopyWith<$Res> {
  __$$RelatedProductsEventImplCopyWithImpl(_$RelatedProductsEventImpl _value,
      $Res Function(_$RelatedProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$RelatedProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RelatedProductsEventImpl implements _RelatedProductsEvent {
  const _$RelatedProductsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'PesachProductsEvent.RelatedProductsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith =>
          __$$RelatedProductsEventImplCopyWithImpl<_$RelatedProductsEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RelatedProductsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RelatedProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _RelatedProductsEvent implements PesachProductsEvent {
  const factory _RelatedProductsEvent(
      {required final BuildContext context,
      required final String productId}) = _$RelatedProductsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  factory _$$RemoveRelatedProductEventImplCopyWith(
          _$RemoveRelatedProductEventImpl value,
          $Res Function(_$RemoveRelatedProductEventImpl) then) =
      __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res,
        _$RemoveRelatedProductEventImpl>
    implements _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  __$$RemoveRelatedProductEventImplCopyWithImpl(
      _$RemoveRelatedProductEventImpl _value,
      $Res Function(_$RemoveRelatedProductEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$RemoveRelatedProductEventImpl implements _RemoveRelatedProductEvent {
  const _$RemoveRelatedProductEventImpl();

  @override
  String toString() {
    return 'PesachProductsEvent.RemoveRelatedProductEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveRelatedProductEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RemoveRelatedProductEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RemoveRelatedProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveRelatedProductEvent implements PesachProductsEvent {
  const factory _RemoveRelatedProductEvent() = _$RemoveRelatedProductEventImpl;
}

/// @nodoc
abstract class _$$getCartCountEventImplCopyWith<$Res> {
  factory _$$getCartCountEventImplCopyWith(_$getCartCountEventImpl value,
          $Res Function(_$getCartCountEventImpl) then) =
      __$$getCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getCartCountEventImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$getCartCountEventImpl>
    implements _$$getCartCountEventImplCopyWith<$Res> {
  __$$getCartCountEventImplCopyWithImpl(_$getCartCountEventImpl _value,
      $Res Function(_$getCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getCartCountEventImpl implements _getCartCountEvent {
  const _$getCartCountEventImpl();

  @override
  String toString() {
    return 'PesachProductsEvent.getCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _getCartCountEvent implements PesachProductsEvent {
  const factory _getCartCountEvent() = _$getCartCountEventImpl;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$PesachProductsEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PesachProductsEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String supplierId, String search)
        getSupplierProductsIdEvent,
    required TResult Function(BuildContext context, String searchType)
        getSupplierProductsListEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String search)
        getAllProducts,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult? Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String search)? getAllProducts,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String supplierId, String search)?
        getSupplierProductsIdEvent,
    TResult Function(BuildContext context, String searchType)?
        getSupplierProductsListEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String search)? getAllProducts,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSupplierProductsIdEvent value)
        getSupplierProductsIdEvent,
    required TResult Function(_GetSupplierProductsListEvent value)
        getSupplierProductsListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_GetAllProductsEvent value) getAllProducts,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult? Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_GetAllProductsEvent value)? getAllProducts,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSupplierProductsIdEvent value)?
        getSupplierProductsIdEvent,
    TResult Function(_GetSupplierProductsListEvent value)?
        getSupplierProductsListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_GetAllProductsEvent value)? getAllProducts,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements PesachProductsEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$PesachProductsState {
  String get supplierId => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  List<PesachData> get productList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isProductLoading => throw _privateConstructorUsedError;
  List<Product> get productDetails => throw _privateConstructorUsedError;
  List<List<ProductStockModel>> get productStockList =>
      throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfProducts => throw _privateConstructorUsedError;
  bool get isSelectSupplier => throw _privateConstructorUsedError;
  List<ProductSupplierModel> get productSupplierList =>
      throw _privateConstructorUsedError;
  int get imageIndex => throw _privateConstructorUsedError;
  TextEditingController get noteController =>
      throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  String get searchType => throw _privateConstructorUsedError;
  bool get isGuestUser => throw _privateConstructorUsedError;
  bool get isGridView => throw _privateConstructorUsedError;
  bool get isCategoryExpand => throw _privateConstructorUsedError;
  bool get isSearching => throw _privateConstructorUsedError;
  TextEditingController get searchController =>
      throw _privateConstructorUsedError;
  List<SearchModel> get searchList => throw _privateConstructorUsedError;
  List<Category> get productCategoryList => throw _privateConstructorUsedError;
  bool get isCatVisible => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get relatedProductList =>
      throw _privateConstructorUsedError;
  bool get isRelatedShimmering => throw _privateConstructorUsedError;
  bool get duringCelebration => throw _privateConstructorUsedError;
  int get cartCount => throw _privateConstructorUsedError;
  int get productListIndex => throw _privateConstructorUsedError;
  double get bottleDeposit => throw _privateConstructorUsedError;
  bool get isSubUserAddToBasket => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PesachProductsStateCopyWith<PesachProductsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PesachProductsStateCopyWith<$Res> {
  factory $PesachProductsStateCopyWith(
          PesachProductsState value, $Res Function(PesachProductsState) then) =
      _$PesachProductsStateCopyWithImpl<$Res, PesachProductsState>;
  @useResult
  $Res call(
      {String supplierId,
      String search,
      List<PesachData> productList,
      bool isShimmering,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      int imageIndex,
      TextEditingController noteController,
      RefreshController refreshController,
      String searchType,
      bool isGuestUser,
      bool isGridView,
      bool isCategoryExpand,
      bool isSearching,
      TextEditingController searchController,
      List<SearchModel> searchList,
      List<Category> productCategoryList,
      bool isCatVisible,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      bool duringCelebration,
      int cartCount,
      int productListIndex,
      double bottleDeposit,
      bool isSubUserAddToBasket});
}

/// @nodoc
class _$PesachProductsStateCopyWithImpl<$Res, $Val extends PesachProductsState>
    implements $PesachProductsStateCopyWith<$Res> {
  _$PesachProductsStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierId = null,
    Object? search = null,
    Object? productList = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? imageIndex = null,
    Object? noteController = null,
    Object? refreshController = null,
    Object? searchType = null,
    Object? isGuestUser = null,
    Object? isGridView = null,
    Object? isCategoryExpand = null,
    Object? isSearching = null,
    Object? searchController = null,
    Object? searchList = null,
    Object? productCategoryList = null,
    Object? isCatVisible = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? duringCelebration = null,
    Object? cartCount = null,
    Object? productListIndex = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
  }) {
    return _then(_value.copyWith(
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productList: null == productList
          ? _value.productList
          : productList // ignore: cast_nullable_to_non_nullable
              as List<PesachData>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value.productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      searchType: null == searchType
          ? _value.searchType
          : searchType // ignore: cast_nullable_to_non_nullable
              as String,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      searchList: null == searchList
          ? _value.searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      productCategoryList: null == productCategoryList
          ? _value.productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value.relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PesachProductsStateImplCopyWith<$Res>
    implements $PesachProductsStateCopyWith<$Res> {
  factory _$$PesachProductsStateImplCopyWith(_$PesachProductsStateImpl value,
          $Res Function(_$PesachProductsStateImpl) then) =
      __$$PesachProductsStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String supplierId,
      String search,
      List<PesachData> productList,
      bool isShimmering,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      int imageIndex,
      TextEditingController noteController,
      RefreshController refreshController,
      String searchType,
      bool isGuestUser,
      bool isGridView,
      bool isCategoryExpand,
      bool isSearching,
      TextEditingController searchController,
      List<SearchModel> searchList,
      List<Category> productCategoryList,
      bool isCatVisible,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      bool duringCelebration,
      int cartCount,
      int productListIndex,
      double bottleDeposit,
      bool isSubUserAddToBasket});
}

/// @nodoc
class __$$PesachProductsStateImplCopyWithImpl<$Res>
    extends _$PesachProductsStateCopyWithImpl<$Res, _$PesachProductsStateImpl>
    implements _$$PesachProductsStateImplCopyWith<$Res> {
  __$$PesachProductsStateImplCopyWithImpl(_$PesachProductsStateImpl _value,
      $Res Function(_$PesachProductsStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierId = null,
    Object? search = null,
    Object? productList = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? imageIndex = null,
    Object? noteController = null,
    Object? refreshController = null,
    Object? searchType = null,
    Object? isGuestUser = null,
    Object? isGridView = null,
    Object? isCategoryExpand = null,
    Object? isSearching = null,
    Object? searchController = null,
    Object? searchList = null,
    Object? productCategoryList = null,
    Object? isCatVisible = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? duringCelebration = null,
    Object? cartCount = null,
    Object? productListIndex = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
  }) {
    return _then(_$PesachProductsStateImpl(
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productList: null == productList
          ? _value._productList
          : productList // ignore: cast_nullable_to_non_nullable
              as List<PesachData>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value._productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value._productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      searchType: null == searchType
          ? _value.searchType
          : searchType // ignore: cast_nullable_to_non_nullable
              as String,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      productCategoryList: null == productCategoryList
          ? _value._productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value._relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$PesachProductsStateImpl implements _PesachProductsState {
  const _$PesachProductsStateImpl(
      {required this.supplierId,
      required this.search,
      required final List<PesachData> productList,
      required this.isShimmering,
      required this.isLoading,
      required this.isProductLoading,
      required final List<Product> productDetails,
      required final List<List<ProductStockModel>> productStockList,
      required this.productStockUpdateIndex,
      required this.pageNum,
      required this.isLoadMore,
      required this.isBottomOfProducts,
      required this.isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required this.imageIndex,
      required this.noteController,
      required this.refreshController,
      required this.searchType,
      required this.isGuestUser,
      required this.isGridView,
      required this.isCategoryExpand,
      required this.isSearching,
      required this.searchController,
      required final List<SearchModel> searchList,
      required final List<Category> productCategoryList,
      required this.isCatVisible,
      required final List<RelatedProductDatum> relatedProductList,
      required this.isRelatedShimmering,
      required this.duringCelebration,
      required this.cartCount,
      required this.productListIndex,
      required this.bottleDeposit,
      required this.isSubUserAddToBasket})
      : _productList = productList,
        _productDetails = productDetails,
        _productStockList = productStockList,
        _productSupplierList = productSupplierList,
        _searchList = searchList,
        _productCategoryList = productCategoryList,
        _relatedProductList = relatedProductList;

  @override
  final String supplierId;
  @override
  final String search;
  final List<PesachData> _productList;
  @override
  List<PesachData> get productList {
    if (_productList is EqualUnmodifiableListView) return _productList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productList);
  }

  @override
  final bool isShimmering;
  @override
  final bool isLoading;
  @override
  final bool isProductLoading;
  final List<Product> _productDetails;
  @override
  List<Product> get productDetails {
    if (_productDetails is EqualUnmodifiableListView) return _productDetails;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productDetails);
  }

  final List<List<ProductStockModel>> _productStockList;
  @override
  List<List<ProductStockModel>> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final int productStockUpdateIndex;
  @override
  final int pageNum;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfProducts;
  @override
  final bool isSelectSupplier;
  final List<ProductSupplierModel> _productSupplierList;
  @override
  List<ProductSupplierModel> get productSupplierList {
    if (_productSupplierList is EqualUnmodifiableListView)
      return _productSupplierList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSupplierList);
  }

  @override
  final int imageIndex;
  @override
  final TextEditingController noteController;
  @override
  final RefreshController refreshController;
  @override
  final String searchType;
  @override
  final bool isGuestUser;
  @override
  final bool isGridView;
  @override
  final bool isCategoryExpand;
  @override
  final bool isSearching;
  @override
  final TextEditingController searchController;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  final List<Category> _productCategoryList;
  @override
  List<Category> get productCategoryList {
    if (_productCategoryList is EqualUnmodifiableListView)
      return _productCategoryList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productCategoryList);
  }

  @override
  final bool isCatVisible;
  final List<RelatedProductDatum> _relatedProductList;
  @override
  List<RelatedProductDatum> get relatedProductList {
    if (_relatedProductList is EqualUnmodifiableListView)
      return _relatedProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedProductList);
  }

  @override
  final bool isRelatedShimmering;
  @override
  final bool duringCelebration;
  @override
  final int cartCount;
  @override
  final int productListIndex;
  @override
  final double bottleDeposit;
  @override
  final bool isSubUserAddToBasket;

  @override
  String toString() {
    return 'PesachProductsState(supplierId: $supplierId, search: $search, productList: $productList, isShimmering: $isShimmering, isLoading: $isLoading, isProductLoading: $isProductLoading, productDetails: $productDetails, productStockList: $productStockList, productStockUpdateIndex: $productStockUpdateIndex, pageNum: $pageNum, isLoadMore: $isLoadMore, isBottomOfProducts: $isBottomOfProducts, isSelectSupplier: $isSelectSupplier, productSupplierList: $productSupplierList, imageIndex: $imageIndex, noteController: $noteController, refreshController: $refreshController, searchType: $searchType, isGuestUser: $isGuestUser, isGridView: $isGridView, isCategoryExpand: $isCategoryExpand, isSearching: $isSearching, searchController: $searchController, searchList: $searchList, productCategoryList: $productCategoryList, isCatVisible: $isCatVisible, relatedProductList: $relatedProductList, isRelatedShimmering: $isRelatedShimmering, duringCelebration: $duringCelebration, cartCount: $cartCount, productListIndex: $productListIndex, bottleDeposit: $bottleDeposit, isSubUserAddToBasket: $isSubUserAddToBasket)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PesachProductsStateImpl &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._productList, _productList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isProductLoading, isProductLoading) ||
                other.isProductLoading == isProductLoading) &&
            const DeepCollectionEquality()
                .equals(other._productDetails, _productDetails) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(
                    other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfProducts, isBottomOfProducts) ||
                other.isBottomOfProducts == isBottomOfProducts) &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier) &&
            const DeepCollectionEquality()
                .equals(other._productSupplierList, _productSupplierList) &&
            (identical(other.imageIndex, imageIndex) ||
                other.imageIndex == imageIndex) &&
            (identical(other.noteController, noteController) ||
                other.noteController == noteController) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.searchType, searchType) ||
                other.searchType == searchType) &&
            (identical(other.isGuestUser, isGuestUser) ||
                other.isGuestUser == isGuestUser) &&
            (identical(other.isGridView, isGridView) ||
                other.isGridView == isGridView) &&
            (identical(other.isCategoryExpand, isCategoryExpand) ||
                other.isCategoryExpand == isCategoryExpand) &&
            (identical(other.isSearching, isSearching) ||
                other.isSearching == isSearching) &&
            (identical(other.searchController, searchController) ||
                other.searchController == searchController) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList) &&
            const DeepCollectionEquality()
                .equals(other._productCategoryList, _productCategoryList) &&
            (identical(other.isCatVisible, isCatVisible) ||
                other.isCatVisible == isCatVisible) &&
            const DeepCollectionEquality()
                .equals(other._relatedProductList, _relatedProductList) &&
            (identical(other.isRelatedShimmering, isRelatedShimmering) ||
                other.isRelatedShimmering == isRelatedShimmering) &&
            (identical(other.duringCelebration, duringCelebration) ||
                other.duringCelebration == duringCelebration) &&
            (identical(other.cartCount, cartCount) ||
                other.cartCount == cartCount) &&
            (identical(other.productListIndex, productListIndex) ||
                other.productListIndex == productListIndex) &&
            (identical(other.bottleDeposit, bottleDeposit) ||
                other.bottleDeposit == bottleDeposit) &&
            (identical(other.isSubUserAddToBasket, isSubUserAddToBasket) ||
                other.isSubUserAddToBasket == isSubUserAddToBasket));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        supplierId,
        search,
        const DeepCollectionEquality().hash(_productList),
        isShimmering,
        isLoading,
        isProductLoading,
        const DeepCollectionEquality().hash(_productDetails),
        const DeepCollectionEquality().hash(_productStockList),
        productStockUpdateIndex,
        pageNum,
        isLoadMore,
        isBottomOfProducts,
        isSelectSupplier,
        const DeepCollectionEquality().hash(_productSupplierList),
        imageIndex,
        noteController,
        refreshController,
        searchType,
        isGuestUser,
        isGridView,
        isCategoryExpand,
        isSearching,
        searchController,
        const DeepCollectionEquality().hash(_searchList),
        const DeepCollectionEquality().hash(_productCategoryList),
        isCatVisible,
        const DeepCollectionEquality().hash(_relatedProductList),
        isRelatedShimmering,
        duringCelebration,
        cartCount,
        productListIndex,
        bottleDeposit,
        isSubUserAddToBasket
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PesachProductsStateImplCopyWith<_$PesachProductsStateImpl> get copyWith =>
      __$$PesachProductsStateImplCopyWithImpl<_$PesachProductsStateImpl>(
          this, _$identity);
}

abstract class _PesachProductsState implements PesachProductsState {
  const factory _PesachProductsState(
      {required final String supplierId,
      required final String search,
      required final List<PesachData> productList,
      required final bool isShimmering,
      required final bool isLoading,
      required final bool isProductLoading,
      required final List<Product> productDetails,
      required final List<List<ProductStockModel>> productStockList,
      required final int productStockUpdateIndex,
      required final int pageNum,
      required final bool isLoadMore,
      required final bool isBottomOfProducts,
      required final bool isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required final int imageIndex,
      required final TextEditingController noteController,
      required final RefreshController refreshController,
      required final String searchType,
      required final bool isGuestUser,
      required final bool isGridView,
      required final bool isCategoryExpand,
      required final bool isSearching,
      required final TextEditingController searchController,
      required final List<SearchModel> searchList,
      required final List<Category> productCategoryList,
      required final bool isCatVisible,
      required final List<RelatedProductDatum> relatedProductList,
      required final bool isRelatedShimmering,
      required final bool duringCelebration,
      required final int cartCount,
      required final int productListIndex,
      required final double bottleDeposit,
      required final bool isSubUserAddToBasket}) = _$PesachProductsStateImpl;

  @override
  String get supplierId;
  @override
  String get search;
  @override
  List<PesachData> get productList;
  @override
  bool get isShimmering;
  @override
  bool get isLoading;
  @override
  bool get isProductLoading;
  @override
  List<Product> get productDetails;
  @override
  List<List<ProductStockModel>> get productStockList;
  @override
  int get productStockUpdateIndex;
  @override
  int get pageNum;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfProducts;
  @override
  bool get isSelectSupplier;
  @override
  List<ProductSupplierModel> get productSupplierList;
  @override
  int get imageIndex;
  @override
  TextEditingController get noteController;
  @override
  RefreshController get refreshController;
  @override
  String get searchType;
  @override
  bool get isGuestUser;
  @override
  bool get isGridView;
  @override
  bool get isCategoryExpand;
  @override
  bool get isSearching;
  @override
  TextEditingController get searchController;
  @override
  List<SearchModel> get searchList;
  @override
  List<Category> get productCategoryList;
  @override
  bool get isCatVisible;
  @override
  List<RelatedProductDatum> get relatedProductList;
  @override
  bool get isRelatedShimmering;
  @override
  bool get duringCelebration;
  @override
  int get cartCount;
  @override
  int get productListIndex;
  @override
  double get bottleDeposit;
  @override
  bool get isSubUserAddToBasket;
  @override
  @JsonKey(ignore: true)
  _$$PesachProductsStateImplCopyWith<_$PesachProductsStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
