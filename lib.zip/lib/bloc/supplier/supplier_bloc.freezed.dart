// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'supplier_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SupplierEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierEventCopyWith<$Res> {
  factory $SupplierEventCopyWith(
          SupplierEvent value, $Res Function(SupplierEvent) then) =
      _$SupplierEventCopyWithImpl<$Res, SupplierEvent>;
}

/// @nodoc
class _$SupplierEventCopyWithImpl<$Res, $Val extends SupplierEvent>
    implements $SupplierEventCopyWith<$Res> {
  _$SupplierEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetSuppliersListEventImplCopyWith<$Res> {
  factory _$$GetSuppliersListEventImplCopyWith(
          _$GetSuppliersListEventImpl value,
          $Res Function(_$GetSuppliersListEventImpl) then) =
      __$$GetSuppliersListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetSuppliersListEventImplCopyWithImpl<$Res>
    extends _$SupplierEventCopyWithImpl<$Res, _$GetSuppliersListEventImpl>
    implements _$$GetSuppliersListEventImplCopyWith<$Res> {
  __$$GetSuppliersListEventImplCopyWithImpl(_$GetSuppliersListEventImpl _value,
      $Res Function(_$GetSuppliersListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetSuppliersListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetSuppliersListEventImpl implements _GetSuppliersListEvent {
  const _$GetSuppliersListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SupplierEvent.getSuppliersListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetSuppliersListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetSuppliersListEventImplCopyWith<_$GetSuppliersListEventImpl>
      get copyWith => __$$GetSuppliersListEventImplCopyWithImpl<
          _$GetSuppliersListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return getSuppliersListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return getSuppliersListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getSuppliersListEvent != null) {
      return getSuppliersListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return getSuppliersListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return getSuppliersListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (getSuppliersListEvent != null) {
      return getSuppliersListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetSuppliersListEvent implements SupplierEvent {
  const factory _GetSuppliersListEvent({required final BuildContext context}) =
      _$GetSuppliersListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetSuppliersListEventImplCopyWith<_$GetSuppliersListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetSearchEventImplCopyWith<$Res> {
  factory _$$SetSearchEventImplCopyWith(_$SetSearchEventImpl value,
          $Res Function(_$SetSearchEventImpl) then) =
      __$$SetSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search});
}

/// @nodoc
class __$$SetSearchEventImplCopyWithImpl<$Res>
    extends _$SupplierEventCopyWithImpl<$Res, _$SetSearchEventImpl>
    implements _$$SetSearchEventImplCopyWith<$Res> {
  __$$SetSearchEventImplCopyWithImpl(
      _$SetSearchEventImpl _value, $Res Function(_$SetSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
  }) {
    return _then(_$SetSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SetSearchEventImpl implements _SetSearchEvent {
  const _$SetSearchEventImpl({required this.search});

  @override
  final String search;

  @override
  String toString() {
    return 'SupplierEvent.setSearchEvent(search: $search)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SetSearchEventImpl &&
            (identical(other.search, search) || other.search == search));
  }

  @override
  int get hashCode => Object.hash(runtimeType, search);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SetSearchEventImplCopyWith<_$SetSearchEventImpl> get copyWith =>
      __$$SetSearchEventImplCopyWithImpl<_$SetSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return setSearchEvent(search);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return setSearchEvent?.call(search);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (setSearchEvent != null) {
      return setSearchEvent(search);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return setSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return setSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (setSearchEvent != null) {
      return setSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _SetSearchEvent implements SupplierEvent {
  const factory _SetSearchEvent({required final String search}) =
      _$SetSearchEventImpl;

  String get search;
  @JsonKey(ignore: true)
  _$$SetSearchEventImplCopyWith<_$SetSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$SupplierEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SupplierEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getSuppliersListEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function(BuildContext context) refreshListEvent,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getSuppliersListEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getSuppliersListEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetSuppliersListEvent value)
        getSuppliersListEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetSuppliersListEvent value)? getSuppliersListEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements SupplierEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SupplierState {
  List<Datum> get suppliersList => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfSuppliers => throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SupplierStateCopyWith<SupplierState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierStateCopyWith<$Res> {
  factory $SupplierStateCopyWith(
          SupplierState value, $Res Function(SupplierState) then) =
      _$SupplierStateCopyWithImpl<$Res, SupplierState>;
  @useResult
  $Res call(
      {List<Datum> suppliersList,
      String search,
      bool isShimmering,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfSuppliers,
      RefreshController refreshController});
}

/// @nodoc
class _$SupplierStateCopyWithImpl<$Res, $Val extends SupplierState>
    implements $SupplierStateCopyWith<$Res> {
  _$SupplierStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? suppliersList = null,
    Object? search = null,
    Object? isShimmering = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfSuppliers = null,
    Object? refreshController = null,
  }) {
    return _then(_value.copyWith(
      suppliersList: null == suppliersList
          ? _value.suppliersList
          : suppliersList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfSuppliers: null == isBottomOfSuppliers
          ? _value.isBottomOfSuppliers
          : isBottomOfSuppliers // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierStateImplCopyWith<$Res>
    implements $SupplierStateCopyWith<$Res> {
  factory _$$SupplierStateImplCopyWith(
          _$SupplierStateImpl value, $Res Function(_$SupplierStateImpl) then) =
      __$$SupplierStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Datum> suppliersList,
      String search,
      bool isShimmering,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfSuppliers,
      RefreshController refreshController});
}

/// @nodoc
class __$$SupplierStateImplCopyWithImpl<$Res>
    extends _$SupplierStateCopyWithImpl<$Res, _$SupplierStateImpl>
    implements _$$SupplierStateImplCopyWith<$Res> {
  __$$SupplierStateImplCopyWithImpl(
      _$SupplierStateImpl _value, $Res Function(_$SupplierStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? suppliersList = null,
    Object? search = null,
    Object? isShimmering = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfSuppliers = null,
    Object? refreshController = null,
  }) {
    return _then(_$SupplierStateImpl(
      suppliersList: null == suppliersList
          ? _value._suppliersList
          : suppliersList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfSuppliers: null == isBottomOfSuppliers
          ? _value.isBottomOfSuppliers
          : isBottomOfSuppliers // ignore: cast_nullable_to_non_nullable
              as bool,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
    ));
  }
}

/// @nodoc

class _$SupplierStateImpl implements _SupplierState {
  const _$SupplierStateImpl(
      {required final List<Datum> suppliersList,
      required this.search,
      required this.isShimmering,
      required this.pageNum,
      required this.isLoadMore,
      required this.isBottomOfSuppliers,
      required this.refreshController})
      : _suppliersList = suppliersList;

  final List<Datum> _suppliersList;
  @override
  List<Datum> get suppliersList {
    if (_suppliersList is EqualUnmodifiableListView) return _suppliersList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_suppliersList);
  }

  @override
  final String search;
  @override
  final bool isShimmering;
  @override
  final int pageNum;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfSuppliers;
  @override
  final RefreshController refreshController;

  @override
  String toString() {
    return 'SupplierState(suppliersList: $suppliersList, search: $search, isShimmering: $isShimmering, pageNum: $pageNum, isLoadMore: $isLoadMore, isBottomOfSuppliers: $isBottomOfSuppliers, refreshController: $refreshController)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierStateImpl &&
            const DeepCollectionEquality()
                .equals(other._suppliersList, _suppliersList) &&
            (identical(other.search, search) || other.search == search) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfSuppliers, isBottomOfSuppliers) ||
                other.isBottomOfSuppliers == isBottomOfSuppliers) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_suppliersList),
      search,
      isShimmering,
      pageNum,
      isLoadMore,
      isBottomOfSuppliers,
      refreshController);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierStateImplCopyWith<_$SupplierStateImpl> get copyWith =>
      __$$SupplierStateImplCopyWithImpl<_$SupplierStateImpl>(this, _$identity);
}

abstract class _SupplierState implements SupplierState {
  const factory _SupplierState(
          {required final List<Datum> suppliersList,
          required final String search,
          required final bool isShimmering,
          required final int pageNum,
          required final bool isLoadMore,
          required final bool isBottomOfSuppliers,
          required final RefreshController refreshController}) =
      _$SupplierStateImpl;

  @override
  List<Datum> get suppliersList;
  @override
  String get search;
  @override
  bool get isShimmering;
  @override
  int get pageNum;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfSuppliers;
  @override
  RefreshController get refreshController;
  @override
  @JsonKey(ignore: true)
  _$$SupplierStateImplCopyWith<_$SupplierStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
