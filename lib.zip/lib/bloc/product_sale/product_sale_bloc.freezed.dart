// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'product_sale_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProductSaleEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductSaleEventCopyWith<$Res> {
  factory $ProductSaleEventCopyWith(
          ProductSaleEvent value, $Res Function(ProductSaleEvent) then) =
      _$ProductSaleEventCopyWithImpl<$Res, ProductSaleEvent>;
}

/// @nodoc
class _$ProductSaleEventCopyWithImpl<$Res, $Val extends ProductSaleEvent>
    implements $ProductSaleEventCopyWith<$Res> {
  _$ProductSaleEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetProductSalesListEventImplCopyWith<$Res> {
  factory _$$GetProductSalesListEventImplCopyWith(
          _$GetProductSalesListEventImpl value,
          $Res Function(_$GetProductSalesListEventImpl) then) =
      __$$GetProductSalesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductSalesListEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$GetProductSalesListEventImpl>
    implements _$$GetProductSalesListEventImplCopyWith<$Res> {
  __$$GetProductSalesListEventImplCopyWithImpl(
      _$GetProductSalesListEventImpl _value,
      $Res Function(_$GetProductSalesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductSalesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductSalesListEventImpl implements _GetProductSalesListEvent {
  const _$GetProductSalesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductSaleEvent.getProductSalesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductSalesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductSalesListEventImplCopyWith<_$GetProductSalesListEventImpl>
      get copyWith => __$$GetProductSalesListEventImplCopyWithImpl<
          _$GetProductSalesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return getProductSalesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return getProductSalesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (getProductSalesListEvent != null) {
      return getProductSalesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return getProductSalesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return getProductSalesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (getProductSalesListEvent != null) {
      return getProductSalesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductSalesListEvent implements ProductSaleEvent {
  const factory _GetProductSalesListEvent(
      {required final BuildContext context}) = _$GetProductSalesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductSalesListEventImplCopyWith<_$GetProductSalesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductDetailsEventImplCopyWith<$Res> {
  factory _$$GetProductDetailsEventImplCopyWith(
          _$GetProductDetailsEventImpl value,
          $Res Function(_$GetProductDetailsEventImpl) then) =
      __$$GetProductDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$GetProductDetailsEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$GetProductDetailsEventImpl>
    implements _$$GetProductDetailsEventImplCopyWith<$Res> {
  __$$GetProductDetailsEventImplCopyWithImpl(
      _$GetProductDetailsEventImpl _value,
      $Res Function(_$GetProductDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$GetProductDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetProductDetailsEventImpl implements _GetProductDetailsEvent {
  const _$GetProductDetailsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'ProductSaleEvent.getProductDetailsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => __$$GetProductDetailsEventImplCopyWithImpl<
          _$GetProductDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return getProductDetailsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return getProductDetailsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return getProductDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return getProductDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductDetailsEvent implements ProductSaleEvent {
  const factory _GetProductDetailsEvent(
      {required final BuildContext context,
      required final String productId}) = _$GetProductDetailsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$IncreaseQuantityOfProductImplCopyWith(
          _$IncreaseQuantityOfProductImpl value,
          $Res Function(_$IncreaseQuantityOfProductImpl) then) =
      __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res,
        _$IncreaseQuantityOfProductImpl>
    implements _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  __$$IncreaseQuantityOfProductImplCopyWithImpl(
      _$IncreaseQuantityOfProductImpl _value,
      $Res Function(_$IncreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$IncreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$IncreaseQuantityOfProductImpl implements _IncreaseQuantityOfProduct {
  const _$IncreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductSaleEvent.increaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => __$$IncreaseQuantityOfProductImplCopyWithImpl<
          _$IncreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return increaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return increaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return increaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return increaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _IncreaseQuantityOfProduct implements ProductSaleEvent {
  const factory _IncreaseQuantityOfProduct(
      {required final BuildContext context}) = _$IncreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$DecreaseQuantityOfProductImplCopyWith(
          _$DecreaseQuantityOfProductImpl value,
          $Res Function(_$DecreaseQuantityOfProductImpl) then) =
      __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res,
        _$DecreaseQuantityOfProductImpl>
    implements _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  __$$DecreaseQuantityOfProductImplCopyWithImpl(
      _$DecreaseQuantityOfProductImpl _value,
      $Res Function(_$DecreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DecreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DecreaseQuantityOfProductImpl implements _DecreaseQuantityOfProduct {
  const _$DecreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductSaleEvent.decreaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DecreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => __$$DecreaseQuantityOfProductImplCopyWithImpl<
          _$DecreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return decreaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return decreaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return decreaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return decreaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _DecreaseQuantityOfProduct implements ProductSaleEvent {
  const factory _DecreaseQuantityOfProduct(
      {required final BuildContext context}) = _$DecreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  factory _$$UpdateQuantityOfProductImplCopyWith(
          _$UpdateQuantityOfProductImpl value,
          $Res Function(_$UpdateQuantityOfProductImpl) then) =
      __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String quantity});
}

/// @nodoc
class __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$UpdateQuantityOfProductImpl>
    implements _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  __$$UpdateQuantityOfProductImplCopyWithImpl(
      _$UpdateQuantityOfProductImpl _value,
      $Res Function(_$UpdateQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? quantity = null,
  }) {
    return _then(_$UpdateQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UpdateQuantityOfProductImpl implements _UpdateQuantityOfProduct {
  const _$UpdateQuantityOfProductImpl(
      {required this.context, required this.quantity});

  @override
  final BuildContext context;
  @override
  final String quantity;

  @override
  String toString() {
    return 'ProductSaleEvent.updateQuantityOfProduct(context: $context, quantity: $quantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, quantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => __$$UpdateQuantityOfProductImplCopyWithImpl<
          _$UpdateQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return updateQuantityOfProduct(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return updateQuantityOfProduct?.call(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(context, quantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return updateQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return updateQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _UpdateQuantityOfProduct implements ProductSaleEvent {
  const factory _UpdateQuantityOfProduct(
      {required final BuildContext context,
      required final String quantity}) = _$UpdateQuantityOfProductImpl;

  BuildContext get context;
  String get quantity;
  @JsonKey(ignore: true)
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeNoteOfProductImplCopyWith<$Res> {
  factory _$$ChangeNoteOfProductImplCopyWith(_$ChangeNoteOfProductImpl value,
          $Res Function(_$ChangeNoteOfProductImpl) then) =
      __$$ChangeNoteOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String newNote});
}

/// @nodoc
class __$$ChangeNoteOfProductImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$ChangeNoteOfProductImpl>
    implements _$$ChangeNoteOfProductImplCopyWith<$Res> {
  __$$ChangeNoteOfProductImplCopyWithImpl(_$ChangeNoteOfProductImpl _value,
      $Res Function(_$ChangeNoteOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newNote = null,
  }) {
    return _then(_$ChangeNoteOfProductImpl(
      newNote: null == newNote
          ? _value.newNote
          : newNote // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeNoteOfProductImpl implements _ChangeNoteOfProduct {
  const _$ChangeNoteOfProductImpl({required this.newNote});

  @override
  final String newNote;

  @override
  String toString() {
    return 'ProductSaleEvent.changeNoteOfProduct(newNote: $newNote)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeNoteOfProductImpl &&
            (identical(other.newNote, newNote) || other.newNote == newNote));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newNote);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      __$$ChangeNoteOfProductImplCopyWithImpl<_$ChangeNoteOfProductImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return changeNoteOfProduct(newNote);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return changeNoteOfProduct?.call(newNote);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(newNote);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return changeNoteOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return changeNoteOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(this);
    }
    return orElse();
  }
}

abstract class _ChangeNoteOfProduct implements ProductSaleEvent {
  const factory _ChangeNoteOfProduct({required final String newNote}) =
      _$ChangeNoteOfProductImpl;

  String get newNote;
  @JsonKey(ignore: true)
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  factory _$$ChangeSupplierSelectionExpansionEventImplCopyWith(
          _$ChangeSupplierSelectionExpansionEventImpl value,
          $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) then) =
      __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isSelectSupplier});
}

/// @nodoc
class __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res,
        _$ChangeSupplierSelectionExpansionEventImpl>
    implements _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl(
      _$ChangeSupplierSelectionExpansionEventImpl _value,
      $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSelectSupplier = freezed,
  }) {
    return _then(_$ChangeSupplierSelectionExpansionEventImpl(
      isSelectSupplier: freezed == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeSupplierSelectionExpansionEventImpl
    implements _ChangeSupplierSelectionExpansionEvent {
  const _$ChangeSupplierSelectionExpansionEventImpl({this.isSelectSupplier});

  @override
  final bool? isSelectSupplier;

  @override
  String toString() {
    return 'ProductSaleEvent.changeSupplierSelectionExpansionEvent(isSelectSupplier: $isSelectSupplier)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSupplierSelectionExpansionEventImpl &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSelectSupplier);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<
          _$ChangeSupplierSelectionExpansionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return changeSupplierSelectionExpansionEvent(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(isSelectSupplier);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return changeSupplierSelectionExpansionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSupplierSelectionExpansionEvent
    implements ProductSaleEvent {
  const factory _ChangeSupplierSelectionExpansionEvent(
          {final bool? isSelectSupplier}) =
      _$ChangeSupplierSelectionExpansionEventImpl;

  bool? get isSelectSupplier;
  @JsonKey(ignore: true)
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SupplierSelectionEventImplCopyWith<$Res> {
  factory _$$SupplierSelectionEventImplCopyWith(
          _$SupplierSelectionEventImpl value,
          $Res Function(_$SupplierSelectionEventImpl) then) =
      __$$SupplierSelectionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int supplierIndex, BuildContext context, int supplierSaleIndex});
}

/// @nodoc
class __$$SupplierSelectionEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$SupplierSelectionEventImpl>
    implements _$$SupplierSelectionEventImplCopyWith<$Res> {
  __$$SupplierSelectionEventImplCopyWithImpl(
      _$SupplierSelectionEventImpl _value,
      $Res Function(_$SupplierSelectionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierIndex = null,
    Object? context = null,
    Object? supplierSaleIndex = null,
  }) {
    return _then(_$SupplierSelectionEventImpl(
      supplierIndex: null == supplierIndex
          ? _value.supplierIndex
          : supplierIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierSaleIndex: null == supplierSaleIndex
          ? _value.supplierSaleIndex
          : supplierSaleIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SupplierSelectionEventImpl implements _SupplierSelectionEvent {
  const _$SupplierSelectionEventImpl(
      {required this.supplierIndex,
      required this.context,
      required this.supplierSaleIndex});

  @override
  final int supplierIndex;
  @override
  final BuildContext context;
  @override
  final int supplierSaleIndex;

  @override
  String toString() {
    return 'ProductSaleEvent.supplierSelectionEvent(supplierIndex: $supplierIndex, context: $context, supplierSaleIndex: $supplierSaleIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSelectionEventImpl &&
            (identical(other.supplierIndex, supplierIndex) ||
                other.supplierIndex == supplierIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierSaleIndex, supplierSaleIndex) ||
                other.supplierSaleIndex == supplierSaleIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, supplierIndex, context, supplierSaleIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => __$$SupplierSelectionEventImplCopyWithImpl<
          _$SupplierSelectionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return supplierSelectionEvent?.call(
        supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return supplierSelectionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return supplierSelectionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(this);
    }
    return orElse();
  }
}

abstract class _SupplierSelectionEvent implements ProductSaleEvent {
  const factory _SupplierSelectionEvent(
      {required final int supplierIndex,
      required final BuildContext context,
      required final int supplierSaleIndex}) = _$SupplierSelectionEventImpl;

  int get supplierIndex;
  BuildContext get context;
  int get supplierSaleIndex;
  @JsonKey(ignore: true)
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddToCartProductEventImplCopyWith<$Res> {
  factory _$$AddToCartProductEventImplCopyWith(
          _$AddToCartProductEventImpl value,
          $Res Function(_$AddToCartProductEventImpl) then) =
      __$$AddToCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$AddToCartProductEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$AddToCartProductEventImpl>
    implements _$$AddToCartProductEventImplCopyWith<$Res> {
  __$$AddToCartProductEventImplCopyWithImpl(_$AddToCartProductEventImpl _value,
      $Res Function(_$AddToCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$AddToCartProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$AddToCartProductEventImpl implements _AddToCartProductEvent {
  const _$AddToCartProductEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductSaleEvent.addToCartProductEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddToCartProductEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => __$$AddToCartProductEventImplCopyWithImpl<
          _$AddToCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return addToCartProductEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return addToCartProductEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return addToCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return addToCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _AddToCartProductEvent implements ProductSaleEvent {
  const factory _AddToCartProductEvent({required final BuildContext context}) =
      _$AddToCartProductEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetCartCountEventImplCopyWith<$Res> {
  factory _$$SetCartCountEventImplCopyWith(_$SetCartCountEventImpl value,
          $Res Function(_$SetCartCountEventImpl) then) =
      __$$SetCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SetCartCountEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$SetCartCountEventImpl>
    implements _$$SetCartCountEventImplCopyWith<$Res> {
  __$$SetCartCountEventImplCopyWithImpl(_$SetCartCountEventImpl _value,
      $Res Function(_$SetCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SetCartCountEventImpl implements _SetCartCountEvent {
  const _$SetCartCountEventImpl();

  @override
  String toString() {
    return 'ProductSaleEvent.setCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SetCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return setCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return setCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return setCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return setCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetCartCountEvent implements ProductSaleEvent {
  const factory _SetCartCountEvent() = _$SetCartCountEventImpl;
}

/// @nodoc
abstract class _$$UpdateImageIndexEventImplCopyWith<$Res> {
  factory _$$UpdateImageIndexEventImplCopyWith(
          _$UpdateImageIndexEventImpl value,
          $Res Function(_$UpdateImageIndexEventImpl) then) =
      __$$UpdateImageIndexEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$UpdateImageIndexEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$UpdateImageIndexEventImpl>
    implements _$$UpdateImageIndexEventImplCopyWith<$Res> {
  __$$UpdateImageIndexEventImplCopyWithImpl(_$UpdateImageIndexEventImpl _value,
      $Res Function(_$UpdateImageIndexEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$UpdateImageIndexEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$UpdateImageIndexEventImpl implements _UpdateImageIndexEvent {
  const _$UpdateImageIndexEventImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'ProductSaleEvent.updateImageIndexEvent(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateImageIndexEventImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => __$$UpdateImageIndexEventImplCopyWithImpl<
          _$UpdateImageIndexEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return updateImageIndexEvent(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return updateImageIndexEvent?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return updateImageIndexEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return updateImageIndexEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateImageIndexEvent implements ProductSaleEvent {
  const factory _UpdateImageIndexEvent({required final int index}) =
      _$UpdateImageIndexEventImpl;

  int get index;
  @JsonKey(ignore: true)
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetSearchEventImplCopyWith<$Res> {
  factory _$$SetSearchEventImplCopyWith(_$SetSearchEventImpl value,
          $Res Function(_$SetSearchEventImpl) then) =
      __$$SetSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search});
}

/// @nodoc
class __$$SetSearchEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$SetSearchEventImpl>
    implements _$$SetSearchEventImplCopyWith<$Res> {
  __$$SetSearchEventImplCopyWithImpl(
      _$SetSearchEventImpl _value, $Res Function(_$SetSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
  }) {
    return _then(_$SetSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SetSearchEventImpl implements _SetSearchEvent {
  const _$SetSearchEventImpl({required this.search});

  @override
  final String search;

  @override
  String toString() {
    return 'ProductSaleEvent.setSearchEvent(search: $search)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SetSearchEventImpl &&
            (identical(other.search, search) || other.search == search));
  }

  @override
  int get hashCode => Object.hash(runtimeType, search);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SetSearchEventImplCopyWith<_$SetSearchEventImpl> get copyWith =>
      __$$SetSearchEventImplCopyWithImpl<_$SetSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return setSearchEvent(search);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return setSearchEvent?.call(search);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (setSearchEvent != null) {
      return setSearchEvent(search);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return setSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return setSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (setSearchEvent != null) {
      return setSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _SetSearchEvent implements ProductSaleEvent {
  const factory _SetSearchEvent({required final String search}) =
      _$SetSearchEventImpl;

  String get search;
  @JsonKey(ignore: true)
  _$$SetSearchEventImplCopyWith<_$SetSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ToggleNoteEventImplCopyWith<$Res> {
  factory _$$ToggleNoteEventImplCopyWith(_$ToggleNoteEventImpl value,
          $Res Function(_$ToggleNoteEventImpl) then) =
      __$$ToggleNoteEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ToggleNoteEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$ToggleNoteEventImpl>
    implements _$$ToggleNoteEventImplCopyWith<$Res> {
  __$$ToggleNoteEventImplCopyWithImpl(
      _$ToggleNoteEventImpl _value, $Res Function(_$ToggleNoteEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ToggleNoteEventImpl implements _ToggleNoteEvent {
  const _$ToggleNoteEventImpl();

  @override
  String toString() {
    return 'ProductSaleEvent.toggleNoteEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ToggleNoteEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return toggleNoteEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return toggleNoteEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return toggleNoteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return toggleNoteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(this);
    }
    return orElse();
  }
}

abstract class _ToggleNoteEvent implements ProductSaleEvent {
  const factory _ToggleNoteEvent() = _$ToggleNoteEventImpl;
}

/// @nodoc
abstract class _$$RefreshListEventImplCopyWith<$Res> {
  factory _$$RefreshListEventImplCopyWith(_$RefreshListEventImpl value,
          $Res Function(_$RefreshListEventImpl) then) =
      __$$RefreshListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$RefreshListEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$RefreshListEventImpl>
    implements _$$RefreshListEventImplCopyWith<$Res> {
  __$$RefreshListEventImplCopyWithImpl(_$RefreshListEventImpl _value,
      $Res Function(_$RefreshListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$RefreshListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$RefreshListEventImpl implements _RefreshListEvent {
  const _$RefreshListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProductSaleEvent.refreshListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RefreshListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      __$$RefreshListEventImplCopyWithImpl<_$RefreshListEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return refreshListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return refreshListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return refreshListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return refreshListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (refreshListEvent != null) {
      return refreshListEvent(this);
    }
    return orElse();
  }
}

abstract class _RefreshListEvent implements ProductSaleEvent {
  const factory _RefreshListEvent({required final BuildContext context}) =
      _$RefreshListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$RefreshListEventImplCopyWith<_$RefreshListEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RelatedProductsEventImplCopyWith<$Res> {
  factory _$$RelatedProductsEventImplCopyWith(_$RelatedProductsEventImpl value,
          $Res Function(_$RelatedProductsEventImpl) then) =
      __$$RelatedProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$RelatedProductsEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$RelatedProductsEventImpl>
    implements _$$RelatedProductsEventImplCopyWith<$Res> {
  __$$RelatedProductsEventImplCopyWithImpl(_$RelatedProductsEventImpl _value,
      $Res Function(_$RelatedProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$RelatedProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RelatedProductsEventImpl implements _RelatedProductsEvent {
  const _$RelatedProductsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'ProductSaleEvent.RelatedProductsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith =>
          __$$RelatedProductsEventImplCopyWithImpl<_$RelatedProductsEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return RelatedProductsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return RelatedProductsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return RelatedProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return RelatedProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _RelatedProductsEvent implements ProductSaleEvent {
  const factory _RelatedProductsEvent(
      {required final BuildContext context,
      required final String productId}) = _$RelatedProductsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  factory _$$RemoveRelatedProductEventImplCopyWith(
          _$RemoveRelatedProductEventImpl value,
          $Res Function(_$RemoveRelatedProductEventImpl) then) =
      __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res,
        _$RemoveRelatedProductEventImpl>
    implements _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  __$$RemoveRelatedProductEventImplCopyWithImpl(
      _$RemoveRelatedProductEventImpl _value,
      $Res Function(_$RemoveRelatedProductEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$RemoveRelatedProductEventImpl implements _RemoveRelatedProductEvent {
  const _$RemoveRelatedProductEventImpl();

  @override
  String toString() {
    return 'ProductSaleEvent.RemoveRelatedProductEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveRelatedProductEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return RemoveRelatedProductEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return RemoveRelatedProductEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return RemoveRelatedProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return RemoveRelatedProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveRelatedProductEvent implements ProductSaleEvent {
  const factory _RemoveRelatedProductEvent() = _$RemoveRelatedProductEventImpl;
}

/// @nodoc
abstract class _$$getGridListViewImplCopyWith<$Res> {
  factory _$$getGridListViewImplCopyWith(_$getGridListViewImpl value,
          $Res Function(_$getGridListViewImpl) then) =
      __$$getGridListViewImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getGridListViewImplCopyWithImpl<$Res>
    extends _$ProductSaleEventCopyWithImpl<$Res, _$getGridListViewImpl>
    implements _$$getGridListViewImplCopyWith<$Res> {
  __$$getGridListViewImplCopyWithImpl(
      _$getGridListViewImpl _value, $Res Function(_$getGridListViewImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getGridListViewImpl implements _getGridListView {
  const _$getGridListViewImpl();

  @override
  String toString() {
    return 'ProductSaleEvent.getGridListView()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getGridListViewImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getProductSalesListEvent,
    required TResult Function(BuildContext context, String productId)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context) addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function(String search) setSearchEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(BuildContext context) refreshListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function() getGridListView,
  }) {
    return getGridListView();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getProductSalesListEvent,
    TResult? Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context)? addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function(String search)? setSearchEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(BuildContext context)? refreshListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function()? getGridListView,
  }) {
    return getGridListView?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getProductSalesListEvent,
    TResult Function(BuildContext context, String productId)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context)? addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function(String search)? setSearchEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(BuildContext context)? refreshListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function()? getGridListView,
    required TResult orElse(),
  }) {
    if (getGridListView != null) {
      return getGridListView();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetProductSalesListEvent value)
        getProductSalesListEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_SetSearchEvent value) setSearchEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_RefreshListEvent value) refreshListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getGridListView value) getGridListView,
  }) {
    return getGridListView(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetProductSalesListEvent value)?
        getProductSalesListEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_SetSearchEvent value)? setSearchEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_RefreshListEvent value)? refreshListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getGridListView value)? getGridListView,
  }) {
    return getGridListView?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetProductSalesListEvent value)? getProductSalesListEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_SetSearchEvent value)? setSearchEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_RefreshListEvent value)? refreshListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getGridListView value)? getGridListView,
    required TResult orElse(),
  }) {
    if (getGridListView != null) {
      return getGridListView(this);
    }
    return orElse();
  }
}

abstract class _getGridListView implements ProductSaleEvent {
  const factory _getGridListView() = _$getGridListViewImpl;
}

/// @nodoc
mixin _$ProductSaleState {
  List<ProductSale> get productSalesList => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  List<Product> get productDetails => throw _privateConstructorUsedError;
  List<ProductStockModel> get productStockList =>
      throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isProductLoading => throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfProducts => throw _privateConstructorUsedError;
  bool get isSelectSupplier => throw _privateConstructorUsedError;
  List<ProductSupplierModel> get productSupplierList =>
      throw _privateConstructorUsedError;
  int get imageIndex => throw _privateConstructorUsedError;
  TextEditingController get noteController =>
      throw _privateConstructorUsedError;
  RefreshController get refreshController => throw _privateConstructorUsedError;
  bool get isGuestUser => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get relatedProductList =>
      throw _privateConstructorUsedError;
  bool get isRelatedShimmering => throw _privateConstructorUsedError;
  double get bottleDeposit => throw _privateConstructorUsedError;
  bool get isSubUserAddToBasket => throw _privateConstructorUsedError;
  bool get isGridView => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProductSaleStateCopyWith<ProductSaleState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProductSaleStateCopyWith<$Res> {
  factory $ProductSaleStateCopyWith(
          ProductSaleState value, $Res Function(ProductSaleState) then) =
      _$ProductSaleStateCopyWithImpl<$Res, ProductSaleState>;
  @useResult
  $Res call(
      {List<ProductSale> productSalesList,
      String search,
      List<Product> productDetails,
      List<ProductStockModel> productStockList,
      bool isShimmering,
      bool isLoading,
      bool isProductLoading,
      int productStockUpdateIndex,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      int imageIndex,
      TextEditingController noteController,
      RefreshController refreshController,
      bool isGuestUser,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      double bottleDeposit,
      bool isSubUserAddToBasket,
      bool isGridView});
}

/// @nodoc
class _$ProductSaleStateCopyWithImpl<$Res, $Val extends ProductSaleState>
    implements $ProductSaleStateCopyWith<$Res> {
  _$ProductSaleStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productSalesList = null,
    Object? search = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productStockUpdateIndex = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? imageIndex = null,
    Object? noteController = null,
    Object? refreshController = null,
    Object? isGuestUser = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
    Object? isGridView = null,
  }) {
    return _then(_value.copyWith(
      productSalesList: null == productSalesList
          ? _value.productSalesList
          : productSalesList // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productDetails: null == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<ProductStockModel>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value.productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value.relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProductSaleStateImplCopyWith<$Res>
    implements $ProductSaleStateCopyWith<$Res> {
  factory _$$ProductSaleStateImplCopyWith(_$ProductSaleStateImpl value,
          $Res Function(_$ProductSaleStateImpl) then) =
      __$$ProductSaleStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<ProductSale> productSalesList,
      String search,
      List<Product> productDetails,
      List<ProductStockModel> productStockList,
      bool isShimmering,
      bool isLoading,
      bool isProductLoading,
      int productStockUpdateIndex,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      int imageIndex,
      TextEditingController noteController,
      RefreshController refreshController,
      bool isGuestUser,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      double bottleDeposit,
      bool isSubUserAddToBasket,
      bool isGridView});
}

/// @nodoc
class __$$ProductSaleStateImplCopyWithImpl<$Res>
    extends _$ProductSaleStateCopyWithImpl<$Res, _$ProductSaleStateImpl>
    implements _$$ProductSaleStateImplCopyWith<$Res> {
  __$$ProductSaleStateImplCopyWithImpl(_$ProductSaleStateImpl _value,
      $Res Function(_$ProductSaleStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? productSalesList = null,
    Object? search = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? isShimmering = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productStockUpdateIndex = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? imageIndex = null,
    Object? noteController = null,
    Object? refreshController = null,
    Object? isGuestUser = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
    Object? isGridView = null,
  }) {
    return _then(_$ProductSaleStateImpl(
      productSalesList: null == productSalesList
          ? _value._productSalesList
          : productSalesList // ignore: cast_nullable_to_non_nullable
              as List<ProductSale>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productDetails: null == productDetails
          ? _value._productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<ProductStockModel>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value._productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      refreshController: null == refreshController
          ? _value.refreshController
          : refreshController // ignore: cast_nullable_to_non_nullable
              as RefreshController,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value._relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ProductSaleStateImpl implements _ProductSaleState {
  const _$ProductSaleStateImpl(
      {required final List<ProductSale> productSalesList,
      required this.search,
      required final List<Product> productDetails,
      required final List<ProductStockModel> productStockList,
      required this.isShimmering,
      required this.isLoading,
      required this.isProductLoading,
      required this.productStockUpdateIndex,
      required this.pageNum,
      required this.isLoadMore,
      required this.isBottomOfProducts,
      required this.isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required this.imageIndex,
      required this.noteController,
      required this.refreshController,
      required this.isGuestUser,
      required final List<RelatedProductDatum> relatedProductList,
      required this.isRelatedShimmering,
      required this.bottleDeposit,
      required this.isSubUserAddToBasket,
      required this.isGridView})
      : _productSalesList = productSalesList,
        _productDetails = productDetails,
        _productStockList = productStockList,
        _productSupplierList = productSupplierList,
        _relatedProductList = relatedProductList;

  final List<ProductSale> _productSalesList;
  @override
  List<ProductSale> get productSalesList {
    if (_productSalesList is EqualUnmodifiableListView)
      return _productSalesList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSalesList);
  }

  @override
  final String search;
  final List<Product> _productDetails;
  @override
  List<Product> get productDetails {
    if (_productDetails is EqualUnmodifiableListView) return _productDetails;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productDetails);
  }

  final List<ProductStockModel> _productStockList;
  @override
  List<ProductStockModel> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final bool isShimmering;
  @override
  final bool isLoading;
  @override
  final bool isProductLoading;
  @override
  final int productStockUpdateIndex;
  @override
  final int pageNum;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfProducts;
  @override
  final bool isSelectSupplier;
  final List<ProductSupplierModel> _productSupplierList;
  @override
  List<ProductSupplierModel> get productSupplierList {
    if (_productSupplierList is EqualUnmodifiableListView)
      return _productSupplierList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSupplierList);
  }

  @override
  final int imageIndex;
  @override
  final TextEditingController noteController;
  @override
  final RefreshController refreshController;
  @override
  final bool isGuestUser;
  final List<RelatedProductDatum> _relatedProductList;
  @override
  List<RelatedProductDatum> get relatedProductList {
    if (_relatedProductList is EqualUnmodifiableListView)
      return _relatedProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedProductList);
  }

  @override
  final bool isRelatedShimmering;
  @override
  final double bottleDeposit;
  @override
  final bool isSubUserAddToBasket;
  @override
  final bool isGridView;

  @override
  String toString() {
    return 'ProductSaleState(productSalesList: $productSalesList, search: $search, productDetails: $productDetails, productStockList: $productStockList, isShimmering: $isShimmering, isLoading: $isLoading, isProductLoading: $isProductLoading, productStockUpdateIndex: $productStockUpdateIndex, pageNum: $pageNum, isLoadMore: $isLoadMore, isBottomOfProducts: $isBottomOfProducts, isSelectSupplier: $isSelectSupplier, productSupplierList: $productSupplierList, imageIndex: $imageIndex, noteController: $noteController, refreshController: $refreshController, isGuestUser: $isGuestUser, relatedProductList: $relatedProductList, isRelatedShimmering: $isRelatedShimmering, bottleDeposit: $bottleDeposit, isSubUserAddToBasket: $isSubUserAddToBasket, isGridView: $isGridView)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProductSaleStateImpl &&
            const DeepCollectionEquality()
                .equals(other._productSalesList, _productSalesList) &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._productDetails, _productDetails) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isProductLoading, isProductLoading) ||
                other.isProductLoading == isProductLoading) &&
            (identical(
                    other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfProducts, isBottomOfProducts) ||
                other.isBottomOfProducts == isBottomOfProducts) &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier) &&
            const DeepCollectionEquality()
                .equals(other._productSupplierList, _productSupplierList) &&
            (identical(other.imageIndex, imageIndex) ||
                other.imageIndex == imageIndex) &&
            (identical(other.noteController, noteController) ||
                other.noteController == noteController) &&
            (identical(other.refreshController, refreshController) ||
                other.refreshController == refreshController) &&
            (identical(other.isGuestUser, isGuestUser) ||
                other.isGuestUser == isGuestUser) &&
            const DeepCollectionEquality()
                .equals(other._relatedProductList, _relatedProductList) &&
            (identical(other.isRelatedShimmering, isRelatedShimmering) ||
                other.isRelatedShimmering == isRelatedShimmering) &&
            (identical(other.bottleDeposit, bottleDeposit) ||
                other.bottleDeposit == bottleDeposit) &&
            (identical(other.isSubUserAddToBasket, isSubUserAddToBasket) ||
                other.isSubUserAddToBasket == isSubUserAddToBasket) &&
            (identical(other.isGridView, isGridView) ||
                other.isGridView == isGridView));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        const DeepCollectionEquality().hash(_productSalesList),
        search,
        const DeepCollectionEquality().hash(_productDetails),
        const DeepCollectionEquality().hash(_productStockList),
        isShimmering,
        isLoading,
        isProductLoading,
        productStockUpdateIndex,
        pageNum,
        isLoadMore,
        isBottomOfProducts,
        isSelectSupplier,
        const DeepCollectionEquality().hash(_productSupplierList),
        imageIndex,
        noteController,
        refreshController,
        isGuestUser,
        const DeepCollectionEquality().hash(_relatedProductList),
        isRelatedShimmering,
        bottleDeposit,
        isSubUserAddToBasket,
        isGridView
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProductSaleStateImplCopyWith<_$ProductSaleStateImpl> get copyWith =>
      __$$ProductSaleStateImplCopyWithImpl<_$ProductSaleStateImpl>(
          this, _$identity);
}

abstract class _ProductSaleState implements ProductSaleState {
  const factory _ProductSaleState(
      {required final List<ProductSale> productSalesList,
      required final String search,
      required final List<Product> productDetails,
      required final List<ProductStockModel> productStockList,
      required final bool isShimmering,
      required final bool isLoading,
      required final bool isProductLoading,
      required final int productStockUpdateIndex,
      required final int pageNum,
      required final bool isLoadMore,
      required final bool isBottomOfProducts,
      required final bool isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required final int imageIndex,
      required final TextEditingController noteController,
      required final RefreshController refreshController,
      required final bool isGuestUser,
      required final List<RelatedProductDatum> relatedProductList,
      required final bool isRelatedShimmering,
      required final double bottleDeposit,
      required final bool isSubUserAddToBasket,
      required final bool isGridView}) = _$ProductSaleStateImpl;

  @override
  List<ProductSale> get productSalesList;
  @override
  String get search;
  @override
  List<Product> get productDetails;
  @override
  List<ProductStockModel> get productStockList;
  @override
  bool get isShimmering;
  @override
  bool get isLoading;
  @override
  bool get isProductLoading;
  @override
  int get productStockUpdateIndex;
  @override
  int get pageNum;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfProducts;
  @override
  bool get isSelectSupplier;
  @override
  List<ProductSupplierModel> get productSupplierList;
  @override
  int get imageIndex;
  @override
  TextEditingController get noteController;
  @override
  RefreshController get refreshController;
  @override
  bool get isGuestUser;
  @override
  List<RelatedProductDatum> get relatedProductList;
  @override
  bool get isRelatedShimmering;
  @override
  double get bottleDeposit;
  @override
  bool get isSubUserAddToBasket;
  @override
  bool get isGridView;
  @override
  @JsonKey(ignore: true)
  _$$ProductSaleStateImplCopyWith<_$ProductSaleStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
