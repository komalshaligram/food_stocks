// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$WalletEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletEventCopyWith<$Res> {
  factory $WalletEventCopyWith(
          WalletEvent value, $Res Function(WalletEvent) then) =
      _$WalletEventCopyWithImpl<$Res, WalletEvent>;
}

/// @nodoc
class _$WalletEventCopyWithImpl<$Res, $Val extends WalletEvent>
    implements $WalletEventCopyWith<$Res> {
  _$WalletEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getTotalExpenseEventImplCopyWith<$Res> {
  factory _$$getTotalExpenseEventImplCopyWith(_$getTotalExpenseEventImpl value,
          $Res Function(_$getTotalExpenseEventImpl) then) =
      __$$getTotalExpenseEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int year, BuildContext context});
}

/// @nodoc
class __$$getTotalExpenseEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$getTotalExpenseEventImpl>
    implements _$$getTotalExpenseEventImplCopyWith<$Res> {
  __$$getTotalExpenseEventImplCopyWithImpl(_$getTotalExpenseEventImpl _value,
      $Res Function(_$getTotalExpenseEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = null,
    Object? context = null,
  }) {
    return _then(_$getTotalExpenseEventImpl(
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getTotalExpenseEventImpl
    with DiagnosticableTreeMixin
    implements _getTotalExpenseEvent {
  const _$getTotalExpenseEventImpl({required this.year, required this.context});

  @override
  final int year;
  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.getTotalExpenseEvent(year: $year, context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'WalletEvent.getTotalExpenseEvent'))
      ..add(DiagnosticsProperty('year', year))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getTotalExpenseEventImpl &&
            (identical(other.year, year) || other.year == year) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, year, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getTotalExpenseEventImplCopyWith<_$getTotalExpenseEventImpl>
      get copyWith =>
          __$$getTotalExpenseEventImplCopyWithImpl<_$getTotalExpenseEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return getTotalExpenseEvent(year, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return getTotalExpenseEvent?.call(year, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getTotalExpenseEvent != null) {
      return getTotalExpenseEvent(year, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return getTotalExpenseEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return getTotalExpenseEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getTotalExpenseEvent != null) {
      return getTotalExpenseEvent(this);
    }
    return orElse();
  }
}

abstract class _getTotalExpenseEvent implements WalletEvent {
  const factory _getTotalExpenseEvent(
      {required final int year,
      required final BuildContext context}) = _$getTotalExpenseEventImpl;

  int get year;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getTotalExpenseEventImplCopyWith<_$getTotalExpenseEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$checkLanguageImplCopyWith<$Res> {
  factory _$$checkLanguageImplCopyWith(
          _$checkLanguageImpl value, $Res Function(_$checkLanguageImpl) then) =
      __$$checkLanguageImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$checkLanguageImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$checkLanguageImpl>
    implements _$$checkLanguageImplCopyWith<$Res> {
  __$$checkLanguageImplCopyWithImpl(
      _$checkLanguageImpl _value, $Res Function(_$checkLanguageImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$checkLanguageImpl
    with DiagnosticableTreeMixin
    implements _checkLanguage {
  const _$checkLanguageImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.checkLanguage()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'WalletEvent.checkLanguage'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$checkLanguageImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return checkLanguage();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return checkLanguage?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (checkLanguage != null) {
      return checkLanguage();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return checkLanguage(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return checkLanguage?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (checkLanguage != null) {
      return checkLanguage(this);
    }
    return orElse();
  }
}

abstract class _checkLanguage implements WalletEvent {
  const factory _checkLanguage() = _$checkLanguageImpl;
}

/// @nodoc
abstract class _$$getYearListEventImplCopyWith<$Res> {
  factory _$$getYearListEventImplCopyWith(_$getYearListEventImpl value,
          $Res Function(_$getYearListEventImpl) then) =
      __$$getYearListEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getYearListEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$getYearListEventImpl>
    implements _$$getYearListEventImplCopyWith<$Res> {
  __$$getYearListEventImplCopyWithImpl(_$getYearListEventImpl _value,
      $Res Function(_$getYearListEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getYearListEventImpl
    with DiagnosticableTreeMixin
    implements _getYearListEvent {
  const _$getYearListEventImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.getYearListEvent()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'WalletEvent.getYearListEvent'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getYearListEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return getYearListEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return getYearListEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getYearListEvent != null) {
      return getYearListEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return getYearListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return getYearListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getYearListEvent != null) {
      return getYearListEvent(this);
    }
    return orElse();
  }
}

abstract class _getYearListEvent implements WalletEvent {
  const factory _getYearListEvent() = _$getYearListEventImpl;
}

/// @nodoc
abstract class _$$getWalletRecordEventImplCopyWith<$Res> {
  factory _$$getWalletRecordEventImplCopyWith(_$getWalletRecordEventImpl value,
          $Res Function(_$getWalletRecordEventImpl) then) =
      __$$getWalletRecordEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getWalletRecordEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$getWalletRecordEventImpl>
    implements _$$getWalletRecordEventImplCopyWith<$Res> {
  __$$getWalletRecordEventImplCopyWithImpl(_$getWalletRecordEventImpl _value,
      $Res Function(_$getWalletRecordEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getWalletRecordEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getWalletRecordEventImpl
    with DiagnosticableTreeMixin
    implements _getWalletRecordEvent {
  const _$getWalletRecordEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.getWalletRecordEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'WalletEvent.getWalletRecordEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getWalletRecordEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getWalletRecordEventImplCopyWith<_$getWalletRecordEventImpl>
      get copyWith =>
          __$$getWalletRecordEventImplCopyWithImpl<_$getWalletRecordEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return getWalletRecordEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return getWalletRecordEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getWalletRecordEvent != null) {
      return getWalletRecordEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return getWalletRecordEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return getWalletRecordEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getWalletRecordEvent != null) {
      return getWalletRecordEvent(this);
    }
    return orElse();
  }
}

abstract class _getWalletRecordEvent implements WalletEvent {
  const factory _getWalletRecordEvent({required final BuildContext context}) =
      _$getWalletRecordEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getWalletRecordEventImplCopyWith<_$getWalletRecordEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getAllWalletTransactionEventImplCopyWith<$Res> {
  factory _$$getAllWalletTransactionEventImplCopyWith(
          _$getAllWalletTransactionEventImpl value,
          $Res Function(_$getAllWalletTransactionEventImpl) then) =
      __$$getAllWalletTransactionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, DateTime? startDate, DateTime? endDate});
}

/// @nodoc
class __$$getAllWalletTransactionEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$getAllWalletTransactionEventImpl>
    implements _$$getAllWalletTransactionEventImplCopyWith<$Res> {
  __$$getAllWalletTransactionEventImplCopyWithImpl(
      _$getAllWalletTransactionEventImpl _value,
      $Res Function(_$getAllWalletTransactionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$getAllWalletTransactionEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$getAllWalletTransactionEventImpl
    with DiagnosticableTreeMixin
    implements _getAllWalletTransactionEvent {
  const _$getAllWalletTransactionEventImpl(
      {required this.context, required this.startDate, required this.endDate});

  @override
  final BuildContext context;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.getAllWalletTransactionEvent(context: $context, startDate: $startDate, endDate: $endDate)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty(
          'type', 'WalletEvent.getAllWalletTransactionEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('startDate', startDate))
      ..add(DiagnosticsProperty('endDate', endDate));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getAllWalletTransactionEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, startDate, endDate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getAllWalletTransactionEventImplCopyWith<
          _$getAllWalletTransactionEventImpl>
      get copyWith => __$$getAllWalletTransactionEventImplCopyWithImpl<
          _$getAllWalletTransactionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return getAllWalletTransactionEvent(context, startDate, endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return getAllWalletTransactionEvent?.call(context, startDate, endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getAllWalletTransactionEvent != null) {
      return getAllWalletTransactionEvent(context, startDate, endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return getAllWalletTransactionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return getAllWalletTransactionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getAllWalletTransactionEvent != null) {
      return getAllWalletTransactionEvent(this);
    }
    return orElse();
  }
}

abstract class _getAllWalletTransactionEvent implements WalletEvent {
  const factory _getAllWalletTransactionEvent(
      {required final BuildContext context,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$getAllWalletTransactionEventImpl;

  BuildContext get context;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$getAllWalletTransactionEventImplCopyWith<
          _$getAllWalletTransactionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getDateRangeEventImplCopyWith<$Res> {
  factory _$$getDateRangeEventImplCopyWith(_$getDateRangeEventImpl value,
          $Res Function(_$getDateRangeEventImpl) then) =
      __$$getDateRangeEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, DateRange? range});
}

/// @nodoc
class __$$getDateRangeEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$getDateRangeEventImpl>
    implements _$$getDateRangeEventImplCopyWith<$Res> {
  __$$getDateRangeEventImplCopyWithImpl(_$getDateRangeEventImpl _value,
      $Res Function(_$getDateRangeEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? range = freezed,
  }) {
    return _then(_$getDateRangeEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      range: freezed == range
          ? _value.range
          : range // ignore: cast_nullable_to_non_nullable
              as DateRange?,
    ));
  }
}

/// @nodoc

class _$getDateRangeEventImpl
    with DiagnosticableTreeMixin
    implements _getDateRangeEvent {
  const _$getDateRangeEventImpl({required this.context, required this.range});

  @override
  final BuildContext context;
  @override
  final DateRange? range;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.getDateRangeEvent(context: $context, range: $range)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'WalletEvent.getDateRangeEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('range', range));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getDateRangeEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.range, range) || other.range == range));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, range);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getDateRangeEventImplCopyWith<_$getDateRangeEventImpl> get copyWith =>
      __$$getDateRangeEventImplCopyWithImpl<_$getDateRangeEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return getDateRangeEvent(context, range);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return getDateRangeEvent?.call(context, range);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getDateRangeEvent != null) {
      return getDateRangeEvent(context, range);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return getDateRangeEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return getDateRangeEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getDateRangeEvent != null) {
      return getDateRangeEvent(this);
    }
    return orElse();
  }
}

abstract class _getDateRangeEvent implements WalletEvent {
  const factory _getDateRangeEvent(
      {required final BuildContext context,
      required final DateRange? range}) = _$getDateRangeEventImpl;

  BuildContext get context;
  DateRange? get range;
  @JsonKey(ignore: true)
  _$$getDateRangeEventImplCopyWith<_$getDateRangeEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getDropDownElementEventImplCopyWith<$Res> {
  factory _$$getDropDownElementEventImplCopyWith(
          _$getDropDownElementEventImpl value,
          $Res Function(_$getDropDownElementEventImpl) then) =
      __$$getDropDownElementEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int year});
}

/// @nodoc
class __$$getDropDownElementEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$getDropDownElementEventImpl>
    implements _$$getDropDownElementEventImplCopyWith<$Res> {
  __$$getDropDownElementEventImplCopyWithImpl(
      _$getDropDownElementEventImpl _value,
      $Res Function(_$getDropDownElementEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = null,
  }) {
    return _then(_$getDropDownElementEventImpl(
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$getDropDownElementEventImpl
    with DiagnosticableTreeMixin
    implements _getDropDownElementEvent {
  const _$getDropDownElementEventImpl({required this.year});

  @override
  final int year;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.getDropDownElementEvent(year: $year)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'WalletEvent.getDropDownElementEvent'))
      ..add(DiagnosticsProperty('year', year));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getDropDownElementEventImpl &&
            (identical(other.year, year) || other.year == year));
  }

  @override
  int get hashCode => Object.hash(runtimeType, year);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getDropDownElementEventImplCopyWith<_$getDropDownElementEventImpl>
      get copyWith => __$$getDropDownElementEventImplCopyWithImpl<
          _$getDropDownElementEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return getDropDownElementEvent(year);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return getDropDownElementEvent?.call(year);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getDropDownElementEvent != null) {
      return getDropDownElementEvent(year);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return getDropDownElementEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return getDropDownElementEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getDropDownElementEvent != null) {
      return getDropDownElementEvent(this);
    }
    return orElse();
  }
}

abstract class _getDropDownElementEvent implements WalletEvent {
  const factory _getDropDownElementEvent({required final int year}) =
      _$getDropDownElementEventImpl;

  int get year;
  @JsonKey(ignore: true)
  _$$getDropDownElementEventImplCopyWith<_$getDropDownElementEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$exportWalletTransactionEventImplCopyWith<$Res> {
  factory _$$exportWalletTransactionEventImplCopyWith(
          _$exportWalletTransactionEventImpl value,
          $Res Function(_$exportWalletTransactionEventImpl) then) =
      __$$exportWalletTransactionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, DateTime? startDate, DateTime? endDate});
}

/// @nodoc
class __$$exportWalletTransactionEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$exportWalletTransactionEventImpl>
    implements _$$exportWalletTransactionEventImplCopyWith<$Res> {
  __$$exportWalletTransactionEventImplCopyWithImpl(
      _$exportWalletTransactionEventImpl _value,
      $Res Function(_$exportWalletTransactionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$exportWalletTransactionEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$exportWalletTransactionEventImpl
    with DiagnosticableTreeMixin
    implements _exportWalletTransactionEvent {
  const _$exportWalletTransactionEventImpl(
      {required this.context, required this.startDate, required this.endDate});

  @override
  final BuildContext context;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.exportWalletTransactionEvent(context: $context, startDate: $startDate, endDate: $endDate)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty(
          'type', 'WalletEvent.exportWalletTransactionEvent'))
      ..add(DiagnosticsProperty('context', context))
      ..add(DiagnosticsProperty('startDate', startDate))
      ..add(DiagnosticsProperty('endDate', endDate));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$exportWalletTransactionEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, startDate, endDate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$exportWalletTransactionEventImplCopyWith<
          _$exportWalletTransactionEventImpl>
      get copyWith => __$$exportWalletTransactionEventImplCopyWithImpl<
          _$exportWalletTransactionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return exportWalletTransactionEvent(context, startDate, endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return exportWalletTransactionEvent?.call(context, startDate, endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (exportWalletTransactionEvent != null) {
      return exportWalletTransactionEvent(context, startDate, endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return exportWalletTransactionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return exportWalletTransactionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (exportWalletTransactionEvent != null) {
      return exportWalletTransactionEvent(this);
    }
    return orElse();
  }
}

abstract class _exportWalletTransactionEvent implements WalletEvent {
  const factory _exportWalletTransactionEvent(
      {required final BuildContext context,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$exportWalletTransactionEventImpl;

  BuildContext get context;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$exportWalletTransactionEventImplCopyWith<
          _$exportWalletTransactionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getOrderCountEventImplCopyWith<$Res> {
  factory _$$getOrderCountEventImplCopyWith(_$getOrderCountEventImpl value,
          $Res Function(_$getOrderCountEventImpl) then) =
      __$$getOrderCountEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getOrderCountEventImplCopyWithImpl<$Res>
    extends _$WalletEventCopyWithImpl<$Res, _$getOrderCountEventImpl>
    implements _$$getOrderCountEventImplCopyWith<$Res> {
  __$$getOrderCountEventImplCopyWithImpl(_$getOrderCountEventImpl _value,
      $Res Function(_$getOrderCountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getOrderCountEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getOrderCountEventImpl
    with DiagnosticableTreeMixin
    implements _getOrderCountEvent {
  const _$getOrderCountEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletEvent.getOrderCountEvent(context: $context)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'WalletEvent.getOrderCountEvent'))
      ..add(DiagnosticsProperty('context', context));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getOrderCountEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getOrderCountEventImplCopyWith<_$getOrderCountEventImpl> get copyWith =>
      __$$getOrderCountEventImplCopyWithImpl<_$getOrderCountEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int year, BuildContext context)
        getTotalExpenseEvent,
    required TResult Function() checkLanguage,
    required TResult Function() getYearListEvent,
    required TResult Function(BuildContext context) getWalletRecordEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        getAllWalletTransactionEvent,
    required TResult Function(BuildContext context, DateRange? range)
        getDateRangeEvent,
    required TResult Function(int year) getDropDownElementEvent,
    required TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)
        exportWalletTransactionEvent,
    required TResult Function(BuildContext context) getOrderCountEvent,
  }) {
    return getOrderCountEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult? Function()? checkLanguage,
    TResult? Function()? getYearListEvent,
    TResult? Function(BuildContext context)? getWalletRecordEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult? Function(BuildContext context, DateRange? range)?
        getDateRangeEvent,
    TResult? Function(int year)? getDropDownElementEvent,
    TResult? Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult? Function(BuildContext context)? getOrderCountEvent,
  }) {
    return getOrderCountEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int year, BuildContext context)? getTotalExpenseEvent,
    TResult Function()? checkLanguage,
    TResult Function()? getYearListEvent,
    TResult Function(BuildContext context)? getWalletRecordEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        getAllWalletTransactionEvent,
    TResult Function(BuildContext context, DateRange? range)? getDateRangeEvent,
    TResult Function(int year)? getDropDownElementEvent,
    TResult Function(
            BuildContext context, DateTime? startDate, DateTime? endDate)?
        exportWalletTransactionEvent,
    TResult Function(BuildContext context)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getOrderCountEvent != null) {
      return getOrderCountEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getTotalExpenseEvent value) getTotalExpenseEvent,
    required TResult Function(_checkLanguage value) checkLanguage,
    required TResult Function(_getYearListEvent value) getYearListEvent,
    required TResult Function(_getWalletRecordEvent value) getWalletRecordEvent,
    required TResult Function(_getAllWalletTransactionEvent value)
        getAllWalletTransactionEvent,
    required TResult Function(_getDateRangeEvent value) getDateRangeEvent,
    required TResult Function(_getDropDownElementEvent value)
        getDropDownElementEvent,
    required TResult Function(_exportWalletTransactionEvent value)
        exportWalletTransactionEvent,
    required TResult Function(_getOrderCountEvent value) getOrderCountEvent,
  }) {
    return getOrderCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult? Function(_checkLanguage value)? checkLanguage,
    TResult? Function(_getYearListEvent value)? getYearListEvent,
    TResult? Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult? Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult? Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult? Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult? Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult? Function(_getOrderCountEvent value)? getOrderCountEvent,
  }) {
    return getOrderCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getTotalExpenseEvent value)? getTotalExpenseEvent,
    TResult Function(_checkLanguage value)? checkLanguage,
    TResult Function(_getYearListEvent value)? getYearListEvent,
    TResult Function(_getWalletRecordEvent value)? getWalletRecordEvent,
    TResult Function(_getAllWalletTransactionEvent value)?
        getAllWalletTransactionEvent,
    TResult Function(_getDateRangeEvent value)? getDateRangeEvent,
    TResult Function(_getDropDownElementEvent value)? getDropDownElementEvent,
    TResult Function(_exportWalletTransactionEvent value)?
        exportWalletTransactionEvent,
    TResult Function(_getOrderCountEvent value)? getOrderCountEvent,
    required TResult orElse(),
  }) {
    if (getOrderCountEvent != null) {
      return getOrderCountEvent(this);
    }
    return orElse();
  }
}

abstract class _getOrderCountEvent implements WalletEvent {
  const factory _getOrderCountEvent({required final BuildContext context}) =
      _$getOrderCountEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getOrderCountEventImplCopyWith<_$getOrderCountEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$WalletState {
  int get year => throw _privateConstructorUsedError;
  List<int> get yearList => throw _privateConstructorUsedError;
  AllWalletTransactionResModel get balanceSheetList =>
      throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  double get totalCredit => throw _privateConstructorUsedError;
  double get thisMonthExpense => throw _privateConstructorUsedError;
  double get lastMonthExpense => throw _privateConstructorUsedError;
  int get orderThisMonth => throw _privateConstructorUsedError;
  double get balance => throw _privateConstructorUsedError;
  List<FlSpot> get monthlyExpenseList => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  String get currentDate => throw _privateConstructorUsedError;
  DateRange? get selectedDateRange => throw _privateConstructorUsedError;
  List<Datum> get walletTransactionsList => throw _privateConstructorUsedError;
  int get pageNum => throw _privateConstructorUsedError;
  bool get isLoadMore => throw _privateConstructorUsedError;
  bool get isBottomOfProducts => throw _privateConstructorUsedError;
  bool get isExportShimmering => throw _privateConstructorUsedError;
  double get expensePercentage => throw _privateConstructorUsedError;
  bool get isProcess => throw _privateConstructorUsedError;
  List<String> get graphDataList => throw _privateConstructorUsedError;
  bool get isGraphProcess => throw _privateConstructorUsedError;
  bool get isExportComplete => throw _privateConstructorUsedError;
  String get userEmail => throw _privateConstructorUsedError;
  DateTime get firstDateOfMonth => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $WalletStateCopyWith<WalletState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletStateCopyWith<$Res> {
  factory $WalletStateCopyWith(
          WalletState value, $Res Function(WalletState) then) =
      _$WalletStateCopyWithImpl<$Res, WalletState>;
  @useResult
  $Res call(
      {int year,
      List<int> yearList,
      AllWalletTransactionResModel balanceSheetList,
      String language,
      double totalCredit,
      double thisMonthExpense,
      double lastMonthExpense,
      int orderThisMonth,
      double balance,
      List<FlSpot> monthlyExpenseList,
      bool isShimmering,
      String currentDate,
      DateRange? selectedDateRange,
      List<Datum> walletTransactionsList,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      bool isExportShimmering,
      double expensePercentage,
      bool isProcess,
      List<String> graphDataList,
      bool isGraphProcess,
      bool isExportComplete,
      String userEmail,
      DateTime firstDateOfMonth});

  $AllWalletTransactionResModelCopyWith<$Res> get balanceSheetList;
}

/// @nodoc
class _$WalletStateCopyWithImpl<$Res, $Val extends WalletState>
    implements $WalletStateCopyWith<$Res> {
  _$WalletStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = null,
    Object? yearList = null,
    Object? balanceSheetList = null,
    Object? language = null,
    Object? totalCredit = null,
    Object? thisMonthExpense = null,
    Object? lastMonthExpense = null,
    Object? orderThisMonth = null,
    Object? balance = null,
    Object? monthlyExpenseList = null,
    Object? isShimmering = null,
    Object? currentDate = null,
    Object? selectedDateRange = freezed,
    Object? walletTransactionsList = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? isExportShimmering = null,
    Object? expensePercentage = null,
    Object? isProcess = null,
    Object? graphDataList = null,
    Object? isGraphProcess = null,
    Object? isExportComplete = null,
    Object? userEmail = null,
    Object? firstDateOfMonth = null,
  }) {
    return _then(_value.copyWith(
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
      yearList: null == yearList
          ? _value.yearList
          : yearList // ignore: cast_nullable_to_non_nullable
              as List<int>,
      balanceSheetList: null == balanceSheetList
          ? _value.balanceSheetList
          : balanceSheetList // ignore: cast_nullable_to_non_nullable
              as AllWalletTransactionResModel,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      thisMonthExpense: null == thisMonthExpense
          ? _value.thisMonthExpense
          : thisMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      lastMonthExpense: null == lastMonthExpense
          ? _value.lastMonthExpense
          : lastMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      orderThisMonth: null == orderThisMonth
          ? _value.orderThisMonth
          : orderThisMonth // ignore: cast_nullable_to_non_nullable
              as int,
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as double,
      monthlyExpenseList: null == monthlyExpenseList
          ? _value.monthlyExpenseList
          : monthlyExpenseList // ignore: cast_nullable_to_non_nullable
              as List<FlSpot>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      currentDate: null == currentDate
          ? _value.currentDate
          : currentDate // ignore: cast_nullable_to_non_nullable
              as String,
      selectedDateRange: freezed == selectedDateRange
          ? _value.selectedDateRange
          : selectedDateRange // ignore: cast_nullable_to_non_nullable
              as DateRange?,
      walletTransactionsList: null == walletTransactionsList
          ? _value.walletTransactionsList
          : walletTransactionsList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isExportShimmering: null == isExportShimmering
          ? _value.isExportShimmering
          : isExportShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      expensePercentage: null == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      isProcess: null == isProcess
          ? _value.isProcess
          : isProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      graphDataList: null == graphDataList
          ? _value.graphDataList
          : graphDataList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      isGraphProcess: null == isGraphProcess
          ? _value.isGraphProcess
          : isGraphProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      isExportComplete: null == isExportComplete
          ? _value.isExportComplete
          : isExportComplete // ignore: cast_nullable_to_non_nullable
              as bool,
      userEmail: null == userEmail
          ? _value.userEmail
          : userEmail // ignore: cast_nullable_to_non_nullable
              as String,
      firstDateOfMonth: null == firstDateOfMonth
          ? _value.firstDateOfMonth
          : firstDateOfMonth // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $AllWalletTransactionResModelCopyWith<$Res> get balanceSheetList {
    return $AllWalletTransactionResModelCopyWith<$Res>(_value.balanceSheetList,
        (value) {
      return _then(_value.copyWith(balanceSheetList: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$WalletStateImplCopyWith<$Res>
    implements $WalletStateCopyWith<$Res> {
  factory _$$WalletStateImplCopyWith(
          _$WalletStateImpl value, $Res Function(_$WalletStateImpl) then) =
      __$$WalletStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int year,
      List<int> yearList,
      AllWalletTransactionResModel balanceSheetList,
      String language,
      double totalCredit,
      double thisMonthExpense,
      double lastMonthExpense,
      int orderThisMonth,
      double balance,
      List<FlSpot> monthlyExpenseList,
      bool isShimmering,
      String currentDate,
      DateRange? selectedDateRange,
      List<Datum> walletTransactionsList,
      int pageNum,
      bool isLoadMore,
      bool isBottomOfProducts,
      bool isExportShimmering,
      double expensePercentage,
      bool isProcess,
      List<String> graphDataList,
      bool isGraphProcess,
      bool isExportComplete,
      String userEmail,
      DateTime firstDateOfMonth});

  @override
  $AllWalletTransactionResModelCopyWith<$Res> get balanceSheetList;
}

/// @nodoc
class __$$WalletStateImplCopyWithImpl<$Res>
    extends _$WalletStateCopyWithImpl<$Res, _$WalletStateImpl>
    implements _$$WalletStateImplCopyWith<$Res> {
  __$$WalletStateImplCopyWithImpl(
      _$WalletStateImpl _value, $Res Function(_$WalletStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? year = null,
    Object? yearList = null,
    Object? balanceSheetList = null,
    Object? language = null,
    Object? totalCredit = null,
    Object? thisMonthExpense = null,
    Object? lastMonthExpense = null,
    Object? orderThisMonth = null,
    Object? balance = null,
    Object? monthlyExpenseList = null,
    Object? isShimmering = null,
    Object? currentDate = null,
    Object? selectedDateRange = freezed,
    Object? walletTransactionsList = null,
    Object? pageNum = null,
    Object? isLoadMore = null,
    Object? isBottomOfProducts = null,
    Object? isExportShimmering = null,
    Object? expensePercentage = null,
    Object? isProcess = null,
    Object? graphDataList = null,
    Object? isGraphProcess = null,
    Object? isExportComplete = null,
    Object? userEmail = null,
    Object? firstDateOfMonth = null,
  }) {
    return _then(_$WalletStateImpl(
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
      yearList: null == yearList
          ? _value._yearList
          : yearList // ignore: cast_nullable_to_non_nullable
              as List<int>,
      balanceSheetList: null == balanceSheetList
          ? _value.balanceSheetList
          : balanceSheetList // ignore: cast_nullable_to_non_nullable
              as AllWalletTransactionResModel,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      thisMonthExpense: null == thisMonthExpense
          ? _value.thisMonthExpense
          : thisMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      lastMonthExpense: null == lastMonthExpense
          ? _value.lastMonthExpense
          : lastMonthExpense // ignore: cast_nullable_to_non_nullable
              as double,
      orderThisMonth: null == orderThisMonth
          ? _value.orderThisMonth
          : orderThisMonth // ignore: cast_nullable_to_non_nullable
              as int,
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as double,
      monthlyExpenseList: null == monthlyExpenseList
          ? _value._monthlyExpenseList
          : monthlyExpenseList // ignore: cast_nullable_to_non_nullable
              as List<FlSpot>,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      currentDate: null == currentDate
          ? _value.currentDate
          : currentDate // ignore: cast_nullable_to_non_nullable
              as String,
      selectedDateRange: freezed == selectedDateRange
          ? _value.selectedDateRange
          : selectedDateRange // ignore: cast_nullable_to_non_nullable
              as DateRange?,
      walletTransactionsList: null == walletTransactionsList
          ? _value._walletTransactionsList
          : walletTransactionsList // ignore: cast_nullable_to_non_nullable
              as List<Datum>,
      pageNum: null == pageNum
          ? _value.pageNum
          : pageNum // ignore: cast_nullable_to_non_nullable
              as int,
      isLoadMore: null == isLoadMore
          ? _value.isLoadMore
          : isLoadMore // ignore: cast_nullable_to_non_nullable
              as bool,
      isBottomOfProducts: null == isBottomOfProducts
          ? _value.isBottomOfProducts
          : isBottomOfProducts // ignore: cast_nullable_to_non_nullable
              as bool,
      isExportShimmering: null == isExportShimmering
          ? _value.isExportShimmering
          : isExportShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      expensePercentage: null == expensePercentage
          ? _value.expensePercentage
          : expensePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      isProcess: null == isProcess
          ? _value.isProcess
          : isProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      graphDataList: null == graphDataList
          ? _value._graphDataList
          : graphDataList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      isGraphProcess: null == isGraphProcess
          ? _value.isGraphProcess
          : isGraphProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      isExportComplete: null == isExportComplete
          ? _value.isExportComplete
          : isExportComplete // ignore: cast_nullable_to_non_nullable
              as bool,
      userEmail: null == userEmail
          ? _value.userEmail
          : userEmail // ignore: cast_nullable_to_non_nullable
              as String,
      firstDateOfMonth: null == firstDateOfMonth
          ? _value.firstDateOfMonth
          : firstDateOfMonth // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc

class _$WalletStateImpl with DiagnosticableTreeMixin implements _WalletState {
  const _$WalletStateImpl(
      {required this.year,
      required final List<int> yearList,
      required this.balanceSheetList,
      required this.language,
      required this.totalCredit,
      required this.thisMonthExpense,
      required this.lastMonthExpense,
      required this.orderThisMonth,
      required this.balance,
      required final List<FlSpot> monthlyExpenseList,
      required this.isShimmering,
      required this.currentDate,
      required this.selectedDateRange,
      required final List<Datum> walletTransactionsList,
      required this.pageNum,
      required this.isLoadMore,
      required this.isBottomOfProducts,
      required this.isExportShimmering,
      required this.expensePercentage,
      required this.isProcess,
      required final List<String> graphDataList,
      required this.isGraphProcess,
      required this.isExportComplete,
      required this.userEmail,
      required this.firstDateOfMonth})
      : _yearList = yearList,
        _monthlyExpenseList = monthlyExpenseList,
        _walletTransactionsList = walletTransactionsList,
        _graphDataList = graphDataList;

  @override
  final int year;
  final List<int> _yearList;
  @override
  List<int> get yearList {
    if (_yearList is EqualUnmodifiableListView) return _yearList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_yearList);
  }

  @override
  final AllWalletTransactionResModel balanceSheetList;
  @override
  final String language;
  @override
  final double totalCredit;
  @override
  final double thisMonthExpense;
  @override
  final double lastMonthExpense;
  @override
  final int orderThisMonth;
  @override
  final double balance;
  final List<FlSpot> _monthlyExpenseList;
  @override
  List<FlSpot> get monthlyExpenseList {
    if (_monthlyExpenseList is EqualUnmodifiableListView)
      return _monthlyExpenseList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_monthlyExpenseList);
  }

  @override
  final bool isShimmering;
  @override
  final String currentDate;
  @override
  final DateRange? selectedDateRange;
  final List<Datum> _walletTransactionsList;
  @override
  List<Datum> get walletTransactionsList {
    if (_walletTransactionsList is EqualUnmodifiableListView)
      return _walletTransactionsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_walletTransactionsList);
  }

  @override
  final int pageNum;
  @override
  final bool isLoadMore;
  @override
  final bool isBottomOfProducts;
  @override
  final bool isExportShimmering;
  @override
  final double expensePercentage;
  @override
  final bool isProcess;
  final List<String> _graphDataList;
  @override
  List<String> get graphDataList {
    if (_graphDataList is EqualUnmodifiableListView) return _graphDataList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_graphDataList);
  }

  @override
  final bool isGraphProcess;
  @override
  final bool isExportComplete;
  @override
  final String userEmail;
  @override
  final DateTime firstDateOfMonth;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'WalletState(year: $year, yearList: $yearList, balanceSheetList: $balanceSheetList, language: $language, totalCredit: $totalCredit, thisMonthExpense: $thisMonthExpense, lastMonthExpense: $lastMonthExpense, orderThisMonth: $orderThisMonth, balance: $balance, monthlyExpenseList: $monthlyExpenseList, isShimmering: $isShimmering, currentDate: $currentDate, selectedDateRange: $selectedDateRange, walletTransactionsList: $walletTransactionsList, pageNum: $pageNum, isLoadMore: $isLoadMore, isBottomOfProducts: $isBottomOfProducts, isExportShimmering: $isExportShimmering, expensePercentage: $expensePercentage, isProcess: $isProcess, graphDataList: $graphDataList, isGraphProcess: $isGraphProcess, isExportComplete: $isExportComplete, userEmail: $userEmail, firstDateOfMonth: $firstDateOfMonth)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'WalletState'))
      ..add(DiagnosticsProperty('year', year))
      ..add(DiagnosticsProperty('yearList', yearList))
      ..add(DiagnosticsProperty('balanceSheetList', balanceSheetList))
      ..add(DiagnosticsProperty('language', language))
      ..add(DiagnosticsProperty('totalCredit', totalCredit))
      ..add(DiagnosticsProperty('thisMonthExpense', thisMonthExpense))
      ..add(DiagnosticsProperty('lastMonthExpense', lastMonthExpense))
      ..add(DiagnosticsProperty('orderThisMonth', orderThisMonth))
      ..add(DiagnosticsProperty('balance', balance))
      ..add(DiagnosticsProperty('monthlyExpenseList', monthlyExpenseList))
      ..add(DiagnosticsProperty('isShimmering', isShimmering))
      ..add(DiagnosticsProperty('currentDate', currentDate))
      ..add(DiagnosticsProperty('selectedDateRange', selectedDateRange))
      ..add(
          DiagnosticsProperty('walletTransactionsList', walletTransactionsList))
      ..add(DiagnosticsProperty('pageNum', pageNum))
      ..add(DiagnosticsProperty('isLoadMore', isLoadMore))
      ..add(DiagnosticsProperty('isBottomOfProducts', isBottomOfProducts))
      ..add(DiagnosticsProperty('isExportShimmering', isExportShimmering))
      ..add(DiagnosticsProperty('expensePercentage', expensePercentage))
      ..add(DiagnosticsProperty('isProcess', isProcess))
      ..add(DiagnosticsProperty('graphDataList', graphDataList))
      ..add(DiagnosticsProperty('isGraphProcess', isGraphProcess))
      ..add(DiagnosticsProperty('isExportComplete', isExportComplete))
      ..add(DiagnosticsProperty('userEmail', userEmail))
      ..add(DiagnosticsProperty('firstDateOfMonth', firstDateOfMonth));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$WalletStateImpl &&
            (identical(other.year, year) || other.year == year) &&
            const DeepCollectionEquality().equals(other._yearList, _yearList) &&
            (identical(other.balanceSheetList, balanceSheetList) ||
                other.balanceSheetList == balanceSheetList) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.totalCredit, totalCredit) ||
                other.totalCredit == totalCredit) &&
            (identical(other.thisMonthExpense, thisMonthExpense) ||
                other.thisMonthExpense == thisMonthExpense) &&
            (identical(other.lastMonthExpense, lastMonthExpense) ||
                other.lastMonthExpense == lastMonthExpense) &&
            (identical(other.orderThisMonth, orderThisMonth) ||
                other.orderThisMonth == orderThisMonth) &&
            (identical(other.balance, balance) || other.balance == balance) &&
            const DeepCollectionEquality()
                .equals(other._monthlyExpenseList, _monthlyExpenseList) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.currentDate, currentDate) ||
                other.currentDate == currentDate) &&
            (identical(other.selectedDateRange, selectedDateRange) ||
                other.selectedDateRange == selectedDateRange) &&
            const DeepCollectionEquality().equals(
                other._walletTransactionsList, _walletTransactionsList) &&
            (identical(other.pageNum, pageNum) || other.pageNum == pageNum) &&
            (identical(other.isLoadMore, isLoadMore) ||
                other.isLoadMore == isLoadMore) &&
            (identical(other.isBottomOfProducts, isBottomOfProducts) ||
                other.isBottomOfProducts == isBottomOfProducts) &&
            (identical(other.isExportShimmering, isExportShimmering) ||
                other.isExportShimmering == isExportShimmering) &&
            (identical(other.expensePercentage, expensePercentage) ||
                other.expensePercentage == expensePercentage) &&
            (identical(other.isProcess, isProcess) ||
                other.isProcess == isProcess) &&
            const DeepCollectionEquality()
                .equals(other._graphDataList, _graphDataList) &&
            (identical(other.isGraphProcess, isGraphProcess) ||
                other.isGraphProcess == isGraphProcess) &&
            (identical(other.isExportComplete, isExportComplete) ||
                other.isExportComplete == isExportComplete) &&
            (identical(other.userEmail, userEmail) ||
                other.userEmail == userEmail) &&
            (identical(other.firstDateOfMonth, firstDateOfMonth) ||
                other.firstDateOfMonth == firstDateOfMonth));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        year,
        const DeepCollectionEquality().hash(_yearList),
        balanceSheetList,
        language,
        totalCredit,
        thisMonthExpense,
        lastMonthExpense,
        orderThisMonth,
        balance,
        const DeepCollectionEquality().hash(_monthlyExpenseList),
        isShimmering,
        currentDate,
        selectedDateRange,
        const DeepCollectionEquality().hash(_walletTransactionsList),
        pageNum,
        isLoadMore,
        isBottomOfProducts,
        isExportShimmering,
        expensePercentage,
        isProcess,
        const DeepCollectionEquality().hash(_graphDataList),
        isGraphProcess,
        isExportComplete,
        userEmail,
        firstDateOfMonth
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$WalletStateImplCopyWith<_$WalletStateImpl> get copyWith =>
      __$$WalletStateImplCopyWithImpl<_$WalletStateImpl>(this, _$identity);
}

abstract class _WalletState implements WalletState {
  const factory _WalletState(
      {required final int year,
      required final List<int> yearList,
      required final AllWalletTransactionResModel balanceSheetList,
      required final String language,
      required final double totalCredit,
      required final double thisMonthExpense,
      required final double lastMonthExpense,
      required final int orderThisMonth,
      required final double balance,
      required final List<FlSpot> monthlyExpenseList,
      required final bool isShimmering,
      required final String currentDate,
      required final DateRange? selectedDateRange,
      required final List<Datum> walletTransactionsList,
      required final int pageNum,
      required final bool isLoadMore,
      required final bool isBottomOfProducts,
      required final bool isExportShimmering,
      required final double expensePercentage,
      required final bool isProcess,
      required final List<String> graphDataList,
      required final bool isGraphProcess,
      required final bool isExportComplete,
      required final String userEmail,
      required final DateTime firstDateOfMonth}) = _$WalletStateImpl;

  @override
  int get year;
  @override
  List<int> get yearList;
  @override
  AllWalletTransactionResModel get balanceSheetList;
  @override
  String get language;
  @override
  double get totalCredit;
  @override
  double get thisMonthExpense;
  @override
  double get lastMonthExpense;
  @override
  int get orderThisMonth;
  @override
  double get balance;
  @override
  List<FlSpot> get monthlyExpenseList;
  @override
  bool get isShimmering;
  @override
  String get currentDate;
  @override
  DateRange? get selectedDateRange;
  @override
  List<Datum> get walletTransactionsList;
  @override
  int get pageNum;
  @override
  bool get isLoadMore;
  @override
  bool get isBottomOfProducts;
  @override
  bool get isExportShimmering;
  @override
  double get expensePercentage;
  @override
  bool get isProcess;
  @override
  List<String> get graphDataList;
  @override
  bool get isGraphProcess;
  @override
  bool get isExportComplete;
  @override
  String get userEmail;
  @override
  DateTime get firstDateOfMonth;
  @override
  @JsonKey(ignore: true)
  _$$WalletStateImplCopyWith<_$WalletStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
