// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sub_users_profile_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SubUsersProfileEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SubUsersProfileEventCopyWith<SubUsersProfileEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubUsersProfileEventCopyWith<$Res> {
  factory $SubUsersProfileEventCopyWith(SubUsersProfileEvent value,
          $Res Function(SubUsersProfileEvent) then) =
      _$SubUsersProfileEventCopyWithImpl<$Res, SubUsersProfileEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$SubUsersProfileEventCopyWithImpl<$Res,
        $Val extends SubUsersProfileEvent>
    implements $SubUsersProfileEventCopyWith<$Res> {
  _$SubUsersProfileEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$getAppLanguageEventImplCopyWith<$Res>
    implements $SubUsersProfileEventCopyWith<$Res> {
  factory _$$getAppLanguageEventImplCopyWith(_$getAppLanguageEventImpl value,
          $Res Function(_$getAppLanguageEventImpl) then) =
      __$$getAppLanguageEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getAppLanguageEventImplCopyWithImpl<$Res>
    extends _$SubUsersProfileEventCopyWithImpl<$Res, _$getAppLanguageEventImpl>
    implements _$$getAppLanguageEventImplCopyWith<$Res> {
  __$$getAppLanguageEventImplCopyWithImpl(_$getAppLanguageEventImpl _value,
      $Res Function(_$getAppLanguageEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getAppLanguageEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getAppLanguageEventImpl implements _getAppLanguageEvent {
  const _$getAppLanguageEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SubUsersProfileEvent.getAppLanguageEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getAppLanguageEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getAppLanguageEventImplCopyWith<_$getAppLanguageEventImpl> get copyWith =>
      __$$getAppLanguageEventImplCopyWithImpl<_$getAppLanguageEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) {
    return getAppLanguageEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) {
    return getAppLanguageEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (getAppLanguageEvent != null) {
      return getAppLanguageEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) {
    return getAppLanguageEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) {
    return getAppLanguageEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (getAppLanguageEvent != null) {
      return getAppLanguageEvent(this);
    }
    return orElse();
  }
}

abstract class _getAppLanguageEvent implements SubUsersProfileEvent {
  const factory _getAppLanguageEvent({required final BuildContext context}) =
      _$getAppLanguageEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$getAppLanguageEventImplCopyWith<_$getAppLanguageEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$pickProfileImageEventImplCopyWith<$Res>
    implements $SubUsersProfileEventCopyWith<$Res> {
  factory _$$pickProfileImageEventImplCopyWith(
          _$pickProfileImageEventImpl value,
          $Res Function(_$pickProfileImageEventImpl) then) =
      __$$pickProfileImageEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, bool isFromCamera});
}

/// @nodoc
class __$$pickProfileImageEventImplCopyWithImpl<$Res>
    extends _$SubUsersProfileEventCopyWithImpl<$Res,
        _$pickProfileImageEventImpl>
    implements _$$pickProfileImageEventImplCopyWith<$Res> {
  __$$pickProfileImageEventImplCopyWithImpl(_$pickProfileImageEventImpl _value,
      $Res Function(_$pickProfileImageEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? isFromCamera = null,
  }) {
    return _then(_$pickProfileImageEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      isFromCamera: null == isFromCamera
          ? _value.isFromCamera
          : isFromCamera // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$pickProfileImageEventImpl implements _pickProfileImageEvent {
  _$pickProfileImageEventImpl(
      {required this.context, required this.isFromCamera});

  @override
  final BuildContext context;
  @override
  final bool isFromCamera;

  @override
  String toString() {
    return 'SubUsersProfileEvent.pickProfileImageEvent(context: $context, isFromCamera: $isFromCamera)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$pickProfileImageEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.isFromCamera, isFromCamera) ||
                other.isFromCamera == isFromCamera));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, isFromCamera);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$pickProfileImageEventImplCopyWith<_$pickProfileImageEventImpl>
      get copyWith => __$$pickProfileImageEventImplCopyWithImpl<
          _$pickProfileImageEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) {
    return pickProfileImageEvent(context, isFromCamera);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) {
    return pickProfileImageEvent?.call(context, isFromCamera);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (pickProfileImageEvent != null) {
      return pickProfileImageEvent(context, isFromCamera);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) {
    return pickProfileImageEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) {
    return pickProfileImageEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (pickProfileImageEvent != null) {
      return pickProfileImageEvent(this);
    }
    return orElse();
  }
}

abstract class _pickProfileImageEvent implements SubUsersProfileEvent {
  factory _pickProfileImageEvent(
      {required final BuildContext context,
      required final bool isFromCamera}) = _$pickProfileImageEventImpl;

  @override
  BuildContext get context;
  bool get isFromCamera;
  @override
  @JsonKey(ignore: true)
  _$$pickProfileImageEventImplCopyWith<_$pickProfileImageEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$createSubUserEventImplCopyWith<$Res>
    implements $SubUsersProfileEventCopyWith<$Res> {
  factory _$$createSubUserEventImplCopyWith(_$createSubUserEventImpl value,
          $Res Function(_$createSubUserEventImpl) then) =
      __$$createSubUserEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$createSubUserEventImplCopyWithImpl<$Res>
    extends _$SubUsersProfileEventCopyWithImpl<$Res, _$createSubUserEventImpl>
    implements _$$createSubUserEventImplCopyWith<$Res> {
  __$$createSubUserEventImplCopyWithImpl(_$createSubUserEventImpl _value,
      $Res Function(_$createSubUserEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$createSubUserEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$createSubUserEventImpl implements _createSubUserEvent {
  const _$createSubUserEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SubUsersProfileEvent.createSubUserEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$createSubUserEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$createSubUserEventImplCopyWith<_$createSubUserEventImpl> get copyWith =>
      __$$createSubUserEventImplCopyWithImpl<_$createSubUserEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) {
    return createSubUserEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) {
    return createSubUserEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (createSubUserEvent != null) {
      return createSubUserEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) {
    return createSubUserEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) {
    return createSubUserEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (createSubUserEvent != null) {
      return createSubUserEvent(this);
    }
    return orElse();
  }
}

abstract class _createSubUserEvent implements SubUsersProfileEvent {
  const factory _createSubUserEvent({required final BuildContext context}) =
      _$createSubUserEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$createSubUserEventImplCopyWith<_$createSubUserEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$deleteFileEventImplCopyWith<$Res>
    implements $SubUsersProfileEventCopyWith<$Res> {
  factory _$$deleteFileEventImplCopyWith(_$deleteFileEventImpl value,
          $Res Function(_$deleteFileEventImpl) then) =
      __$$deleteFileEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$deleteFileEventImplCopyWithImpl<$Res>
    extends _$SubUsersProfileEventCopyWithImpl<$Res, _$deleteFileEventImpl>
    implements _$$deleteFileEventImplCopyWith<$Res> {
  __$$deleteFileEventImplCopyWithImpl(
      _$deleteFileEventImpl _value, $Res Function(_$deleteFileEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$deleteFileEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$deleteFileEventImpl implements _deleteFileEvent {
  const _$deleteFileEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SubUsersProfileEvent.deleteFileEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deleteFileEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      __$$deleteFileEventImplCopyWithImpl<_$deleteFileEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) {
    return deleteFileEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) {
    return deleteFileEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) {
    return deleteFileEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) {
    return deleteFileEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (deleteFileEvent != null) {
      return deleteFileEvent(this);
    }
    return orElse();
  }
}

abstract class _deleteFileEvent implements SubUsersProfileEvent {
  const factory _deleteFileEvent({required final BuildContext context}) =
      _$deleteFileEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$deleteFileEventImplCopyWith<_$deleteFileEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$deleteAccountEventImplCopyWith<$Res>
    implements $SubUsersProfileEventCopyWith<$Res> {
  factory _$$deleteAccountEventImplCopyWith(_$deleteAccountEventImpl value,
          $Res Function(_$deleteAccountEventImpl) then) =
      __$$deleteAccountEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, BuildContext dialogContext});
}

/// @nodoc
class __$$deleteAccountEventImplCopyWithImpl<$Res>
    extends _$SubUsersProfileEventCopyWithImpl<$Res, _$deleteAccountEventImpl>
    implements _$$deleteAccountEventImplCopyWith<$Res> {
  __$$deleteAccountEventImplCopyWithImpl(_$deleteAccountEventImpl _value,
      $Res Function(_$deleteAccountEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? dialogContext = null,
  }) {
    return _then(_$deleteAccountEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      dialogContext: null == dialogContext
          ? _value.dialogContext
          : dialogContext // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$deleteAccountEventImpl implements _deleteAccountEvent {
  const _$deleteAccountEventImpl(
      {required this.context, required this.dialogContext});

  @override
  final BuildContext context;
  @override
  final BuildContext dialogContext;

  @override
  String toString() {
    return 'SubUsersProfileEvent.deleteAccountEvent(context: $context, dialogContext: $dialogContext)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deleteAccountEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.dialogContext, dialogContext) ||
                other.dialogContext == dialogContext));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, dialogContext);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deleteAccountEventImplCopyWith<_$deleteAccountEventImpl> get copyWith =>
      __$$deleteAccountEventImplCopyWithImpl<_$deleteAccountEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) {
    return deleteAccountEvent(context, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) {
    return deleteAccountEvent?.call(context, dialogContext);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (deleteAccountEvent != null) {
      return deleteAccountEvent(context, dialogContext);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) {
    return deleteAccountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) {
    return deleteAccountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (deleteAccountEvent != null) {
      return deleteAccountEvent(this);
    }
    return orElse();
  }
}

abstract class _deleteAccountEvent implements SubUsersProfileEvent {
  const factory _deleteAccountEvent(
      {required final BuildContext context,
      required final BuildContext dialogContext}) = _$deleteAccountEventImpl;

  @override
  BuildContext get context;
  BuildContext get dialogContext;
  @override
  @JsonKey(ignore: true)
  _$$deleteAccountEventImplCopyWith<_$deleteAccountEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$updateSubUserEventImplCopyWith<$Res>
    implements $SubUsersProfileEventCopyWith<$Res> {
  factory _$$updateSubUserEventImplCopyWith(_$updateSubUserEventImpl value,
          $Res Function(_$updateSubUserEventImpl) then) =
      __$$updateSubUserEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$updateSubUserEventImplCopyWithImpl<$Res>
    extends _$SubUsersProfileEventCopyWithImpl<$Res, _$updateSubUserEventImpl>
    implements _$$updateSubUserEventImplCopyWith<$Res> {
  __$$updateSubUserEventImplCopyWithImpl(_$updateSubUserEventImpl _value,
      $Res Function(_$updateSubUserEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$updateSubUserEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$updateSubUserEventImpl implements _updateSubUserEvent {
  const _$updateSubUserEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SubUsersProfileEvent.updateSubUserEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateSubUserEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateSubUserEventImplCopyWith<_$updateSubUserEventImpl> get copyWith =>
      __$$updateSubUserEventImplCopyWithImpl<_$updateSubUserEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) {
    return updateSubUserEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) {
    return updateSubUserEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (updateSubUserEvent != null) {
      return updateSubUserEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) {
    return updateSubUserEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) {
    return updateSubUserEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (updateSubUserEvent != null) {
      return updateSubUserEvent(this);
    }
    return orElse();
  }
}

abstract class _updateSubUserEvent implements SubUsersProfileEvent {
  const factory _updateSubUserEvent({required final BuildContext context}) =
      _$updateSubUserEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$updateSubUserEventImplCopyWith<_$updateSubUserEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getSubUserByIdEventImplCopyWith<$Res>
    implements $SubUsersProfileEventCopyWith<$Res> {
  factory _$$getSubUserByIdEventImplCopyWith(_$getSubUserByIdEventImpl value,
          $Res Function(_$getSubUserByIdEventImpl) then) =
      __$$getSubUserByIdEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, String subUserId, bool isUpdate});
}

/// @nodoc
class __$$getSubUserByIdEventImplCopyWithImpl<$Res>
    extends _$SubUsersProfileEventCopyWithImpl<$Res, _$getSubUserByIdEventImpl>
    implements _$$getSubUserByIdEventImplCopyWith<$Res> {
  __$$getSubUserByIdEventImplCopyWithImpl(_$getSubUserByIdEventImpl _value,
      $Res Function(_$getSubUserByIdEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? subUserId = null,
    Object? isUpdate = null,
  }) {
    return _then(_$getSubUserByIdEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$getSubUserByIdEventImpl implements _getSubUserByIdEvent {
  const _$getSubUserByIdEventImpl(
      {required this.context, required this.subUserId, required this.isUpdate});

  @override
  final BuildContext context;
  @override
  final String subUserId;
  @override
  final bool isUpdate;

  @override
  String toString() {
    return 'SubUsersProfileEvent.getSubUserByIdEvent(context: $context, subUserId: $subUserId, isUpdate: $isUpdate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getSubUserByIdEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, subUserId, isUpdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getSubUserByIdEventImplCopyWith<_$getSubUserByIdEventImpl> get copyWith =>
      __$$getSubUserByIdEventImplCopyWithImpl<_$getSubUserByIdEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context) getAppLanguageEvent,
    required TResult Function(BuildContext context, bool isFromCamera)
        pickProfileImageEvent,
    required TResult Function(BuildContext context) createSubUserEvent,
    required TResult Function(BuildContext context) deleteFileEvent,
    required TResult Function(BuildContext context, BuildContext dialogContext)
        deleteAccountEvent,
    required TResult Function(BuildContext context) updateSubUserEvent,
    required TResult Function(
            BuildContext context, String subUserId, bool isUpdate)
        getSubUserByIdEvent,
  }) {
    return getSubUserByIdEvent(context, subUserId, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context)? getAppLanguageEvent,
    TResult? Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult? Function(BuildContext context)? createSubUserEvent,
    TResult? Function(BuildContext context)? deleteFileEvent,
    TResult? Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult? Function(BuildContext context)? updateSubUserEvent,
    TResult? Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
  }) {
    return getSubUserByIdEvent?.call(context, subUserId, isUpdate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context)? getAppLanguageEvent,
    TResult Function(BuildContext context, bool isFromCamera)?
        pickProfileImageEvent,
    TResult Function(BuildContext context)? createSubUserEvent,
    TResult Function(BuildContext context)? deleteFileEvent,
    TResult Function(BuildContext context, BuildContext dialogContext)?
        deleteAccountEvent,
    TResult Function(BuildContext context)? updateSubUserEvent,
    TResult Function(BuildContext context, String subUserId, bool isUpdate)?
        getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (getSubUserByIdEvent != null) {
      return getSubUserByIdEvent(context, subUserId, isUpdate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getAppLanguageEvent value) getAppLanguageEvent,
    required TResult Function(_pickProfileImageEvent value)
        pickProfileImageEvent,
    required TResult Function(_createSubUserEvent value) createSubUserEvent,
    required TResult Function(_deleteFileEvent value) deleteFileEvent,
    required TResult Function(_deleteAccountEvent value) deleteAccountEvent,
    required TResult Function(_updateSubUserEvent value) updateSubUserEvent,
    required TResult Function(_getSubUserByIdEvent value) getSubUserByIdEvent,
  }) {
    return getSubUserByIdEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult? Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult? Function(_createSubUserEvent value)? createSubUserEvent,
    TResult? Function(_deleteFileEvent value)? deleteFileEvent,
    TResult? Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult? Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult? Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
  }) {
    return getSubUserByIdEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getAppLanguageEvent value)? getAppLanguageEvent,
    TResult Function(_pickProfileImageEvent value)? pickProfileImageEvent,
    TResult Function(_createSubUserEvent value)? createSubUserEvent,
    TResult Function(_deleteFileEvent value)? deleteFileEvent,
    TResult Function(_deleteAccountEvent value)? deleteAccountEvent,
    TResult Function(_updateSubUserEvent value)? updateSubUserEvent,
    TResult Function(_getSubUserByIdEvent value)? getSubUserByIdEvent,
    required TResult orElse(),
  }) {
    if (getSubUserByIdEvent != null) {
      return getSubUserByIdEvent(this);
    }
    return orElse();
  }
}

abstract class _getSubUserByIdEvent implements SubUsersProfileEvent {
  const factory _getSubUserByIdEvent(
      {required final BuildContext context,
      required final String subUserId,
      required final bool isUpdate}) = _$getSubUserByIdEventImpl;

  @override
  BuildContext get context;
  String get subUserId;
  bool get isUpdate;
  @override
  @JsonKey(ignore: true)
  _$$getSubUserByIdEventImplCopyWith<_$getSubUserByIdEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SubUsersProfileState {
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;
  String get subUserProfileImage => throw _privateConstructorUsedError;
  bool get isUploadingProcess => throw _privateConstructorUsedError;
  bool get isFileUploading => throw _privateConstructorUsedError;
  File get image => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  TextEditingController get israelIdController =>
      throw _privateConstructorUsedError;
  TextEditingController get nameController =>
      throw _privateConstructorUsedError;
  TextEditingController get phoneNumberController =>
      throw _privateConstructorUsedError;
  TextEditingController get emailController =>
      throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isEnable => throw _privateConstructorUsedError;
  String get subUserId => throw _privateConstructorUsedError;
  bool get isDeleteProcess => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SubUsersProfileStateCopyWith<SubUsersProfileState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubUsersProfileStateCopyWith<$Res> {
  factory $SubUsersProfileStateCopyWith(SubUsersProfileState value,
          $Res Function(SubUsersProfileState) then) =
      _$SubUsersProfileStateCopyWithImpl<$Res, SubUsersProfileState>;
  @useResult
  $Res call(
      {bool isShimmering,
      bool isUpdate,
      String subUserProfileImage,
      bool isUploadingProcess,
      bool isFileUploading,
      File image,
      String language,
      TextEditingController israelIdController,
      TextEditingController nameController,
      TextEditingController phoneNumberController,
      TextEditingController emailController,
      bool isLoading,
      bool isEnable,
      String subUserId,
      bool isDeleteProcess});
}

/// @nodoc
class _$SubUsersProfileStateCopyWithImpl<$Res,
        $Val extends SubUsersProfileState>
    implements $SubUsersProfileStateCopyWith<$Res> {
  _$SubUsersProfileStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? isUpdate = null,
    Object? subUserProfileImage = null,
    Object? isUploadingProcess = null,
    Object? isFileUploading = null,
    Object? image = null,
    Object? language = null,
    Object? israelIdController = null,
    Object? nameController = null,
    Object? phoneNumberController = null,
    Object? emailController = null,
    Object? isLoading = null,
    Object? isEnable = null,
    Object? subUserId = null,
    Object? isDeleteProcess = null,
  }) {
    return _then(_value.copyWith(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserProfileImage: null == subUserProfileImage
          ? _value.subUserProfileImage
          : subUserProfileImage // ignore: cast_nullable_to_non_nullable
              as String,
      isUploadingProcess: null == isUploadingProcess
          ? _value.isUploadingProcess
          : isUploadingProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      isFileUploading: null == isFileUploading
          ? _value.isFileUploading
          : isFileUploading // ignore: cast_nullable_to_non_nullable
              as bool,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as File,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      israelIdController: null == israelIdController
          ? _value.israelIdController
          : israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      nameController: null == nameController
          ? _value.nameController
          : nameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      phoneNumberController: null == phoneNumberController
          ? _value.phoneNumberController
          : phoneNumberController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      emailController: null == emailController
          ? _value.emailController
          : emailController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isEnable: null == isEnable
          ? _value.isEnable
          : isEnable // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
      isDeleteProcess: null == isDeleteProcess
          ? _value.isDeleteProcess
          : isDeleteProcess // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubUsersProfileStateImplCopyWith<$Res>
    implements $SubUsersProfileStateCopyWith<$Res> {
  factory _$$SubUsersProfileStateImplCopyWith(_$SubUsersProfileStateImpl value,
          $Res Function(_$SubUsersProfileStateImpl) then) =
      __$$SubUsersProfileStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isShimmering,
      bool isUpdate,
      String subUserProfileImage,
      bool isUploadingProcess,
      bool isFileUploading,
      File image,
      String language,
      TextEditingController israelIdController,
      TextEditingController nameController,
      TextEditingController phoneNumberController,
      TextEditingController emailController,
      bool isLoading,
      bool isEnable,
      String subUserId,
      bool isDeleteProcess});
}

/// @nodoc
class __$$SubUsersProfileStateImplCopyWithImpl<$Res>
    extends _$SubUsersProfileStateCopyWithImpl<$Res, _$SubUsersProfileStateImpl>
    implements _$$SubUsersProfileStateImplCopyWith<$Res> {
  __$$SubUsersProfileStateImplCopyWithImpl(_$SubUsersProfileStateImpl _value,
      $Res Function(_$SubUsersProfileStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? isUpdate = null,
    Object? subUserProfileImage = null,
    Object? isUploadingProcess = null,
    Object? isFileUploading = null,
    Object? image = null,
    Object? language = null,
    Object? israelIdController = null,
    Object? nameController = null,
    Object? phoneNumberController = null,
    Object? emailController = null,
    Object? isLoading = null,
    Object? isEnable = null,
    Object? subUserId = null,
    Object? isDeleteProcess = null,
  }) {
    return _then(_$SubUsersProfileStateImpl(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserProfileImage: null == subUserProfileImage
          ? _value.subUserProfileImage
          : subUserProfileImage // ignore: cast_nullable_to_non_nullable
              as String,
      isUploadingProcess: null == isUploadingProcess
          ? _value.isUploadingProcess
          : isUploadingProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      isFileUploading: null == isFileUploading
          ? _value.isFileUploading
          : isFileUploading // ignore: cast_nullable_to_non_nullable
              as bool,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as File,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      israelIdController: null == israelIdController
          ? _value.israelIdController
          : israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      nameController: null == nameController
          ? _value.nameController
          : nameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      phoneNumberController: null == phoneNumberController
          ? _value.phoneNumberController
          : phoneNumberController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      emailController: null == emailController
          ? _value.emailController
          : emailController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isEnable: null == isEnable
          ? _value.isEnable
          : isEnable // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
      isDeleteProcess: null == isDeleteProcess
          ? _value.isDeleteProcess
          : isDeleteProcess // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$SubUsersProfileStateImpl implements _SubUsersProfileState {
  const _$SubUsersProfileStateImpl(
      {required this.isShimmering,
      required this.isUpdate,
      required this.subUserProfileImage,
      required this.isUploadingProcess,
      required this.isFileUploading,
      required this.image,
      required this.language,
      required this.israelIdController,
      required this.nameController,
      required this.phoneNumberController,
      required this.emailController,
      required this.isLoading,
      required this.isEnable,
      required this.subUserId,
      required this.isDeleteProcess});

  @override
  final bool isShimmering;
  @override
  final bool isUpdate;
  @override
  final String subUserProfileImage;
  @override
  final bool isUploadingProcess;
  @override
  final bool isFileUploading;
  @override
  final File image;
  @override
  final String language;
  @override
  final TextEditingController israelIdController;
  @override
  final TextEditingController nameController;
  @override
  final TextEditingController phoneNumberController;
  @override
  final TextEditingController emailController;
  @override
  final bool isLoading;
  @override
  final bool isEnable;
  @override
  final String subUserId;
  @override
  final bool isDeleteProcess;

  @override
  String toString() {
    return 'SubUsersProfileState(isShimmering: $isShimmering, isUpdate: $isUpdate, subUserProfileImage: $subUserProfileImage, isUploadingProcess: $isUploadingProcess, isFileUploading: $isFileUploading, image: $image, language: $language, israelIdController: $israelIdController, nameController: $nameController, phoneNumberController: $phoneNumberController, emailController: $emailController, isLoading: $isLoading, isEnable: $isEnable, subUserId: $subUserId, isDeleteProcess: $isDeleteProcess)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubUsersProfileStateImpl &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            (identical(other.subUserProfileImage, subUserProfileImage) ||
                other.subUserProfileImage == subUserProfileImage) &&
            (identical(other.isUploadingProcess, isUploadingProcess) ||
                other.isUploadingProcess == isUploadingProcess) &&
            (identical(other.isFileUploading, isFileUploading) ||
                other.isFileUploading == isFileUploading) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.israelIdController, israelIdController) ||
                other.israelIdController == israelIdController) &&
            (identical(other.nameController, nameController) ||
                other.nameController == nameController) &&
            (identical(other.phoneNumberController, phoneNumberController) ||
                other.phoneNumberController == phoneNumberController) &&
            (identical(other.emailController, emailController) ||
                other.emailController == emailController) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isEnable, isEnable) ||
                other.isEnable == isEnable) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId) &&
            (identical(other.isDeleteProcess, isDeleteProcess) ||
                other.isDeleteProcess == isDeleteProcess));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isShimmering,
      isUpdate,
      subUserProfileImage,
      isUploadingProcess,
      isFileUploading,
      image,
      language,
      israelIdController,
      nameController,
      phoneNumberController,
      emailController,
      isLoading,
      isEnable,
      subUserId,
      isDeleteProcess);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubUsersProfileStateImplCopyWith<_$SubUsersProfileStateImpl>
      get copyWith =>
          __$$SubUsersProfileStateImplCopyWithImpl<_$SubUsersProfileStateImpl>(
              this, _$identity);
}

abstract class _SubUsersProfileState implements SubUsersProfileState {
  const factory _SubUsersProfileState(
      {required final bool isShimmering,
      required final bool isUpdate,
      required final String subUserProfileImage,
      required final bool isUploadingProcess,
      required final bool isFileUploading,
      required final File image,
      required final String language,
      required final TextEditingController israelIdController,
      required final TextEditingController nameController,
      required final TextEditingController phoneNumberController,
      required final TextEditingController emailController,
      required final bool isLoading,
      required final bool isEnable,
      required final String subUserId,
      required final bool isDeleteProcess}) = _$SubUsersProfileStateImpl;

  @override
  bool get isShimmering;
  @override
  bool get isUpdate;
  @override
  String get subUserProfileImage;
  @override
  bool get isUploadingProcess;
  @override
  bool get isFileUploading;
  @override
  File get image;
  @override
  String get language;
  @override
  TextEditingController get israelIdController;
  @override
  TextEditingController get nameController;
  @override
  TextEditingController get phoneNumberController;
  @override
  TextEditingController get emailController;
  @override
  bool get isLoading;
  @override
  bool get isEnable;
  @override
  String get subUserId;
  @override
  bool get isDeleteProcess;
  @override
  @JsonKey(ignore: true)
  _$$SubUsersProfileStateImplCopyWith<_$SubUsersProfileStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
