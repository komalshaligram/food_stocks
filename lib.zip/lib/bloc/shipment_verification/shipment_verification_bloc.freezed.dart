// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'shipment_verification_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ShipmentVerificationEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() signatureEvent,
    required TResult Function(BuildContext context, String supplierId,
            String signPath, String orderId)
        deliveryConfirmEvent,
    required TResult Function() signDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? signatureEvent,
    TResult? Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult? Function()? signDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? signatureEvent,
    TResult Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult Function()? signDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_signatureEvent value) signatureEvent,
    required TResult Function(_deliveryConfirmEvent value) deliveryConfirmEvent,
    required TResult Function(_signDeleteEvent value) signDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_signatureEvent value)? signatureEvent,
    TResult? Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult? Function(_signDeleteEvent value)? signDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_signatureEvent value)? signatureEvent,
    TResult Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult Function(_signDeleteEvent value)? signDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShipmentVerificationEventCopyWith<$Res> {
  factory $ShipmentVerificationEventCopyWith(ShipmentVerificationEvent value,
          $Res Function(ShipmentVerificationEvent) then) =
      _$ShipmentVerificationEventCopyWithImpl<$Res, ShipmentVerificationEvent>;
}

/// @nodoc
class _$ShipmentVerificationEventCopyWithImpl<$Res,
        $Val extends ShipmentVerificationEvent>
    implements $ShipmentVerificationEventCopyWith<$Res> {
  _$ShipmentVerificationEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$signatureEventImplCopyWith<$Res> {
  factory _$$signatureEventImplCopyWith(_$signatureEventImpl value,
          $Res Function(_$signatureEventImpl) then) =
      __$$signatureEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$signatureEventImplCopyWithImpl<$Res>
    extends _$ShipmentVerificationEventCopyWithImpl<$Res, _$signatureEventImpl>
    implements _$$signatureEventImplCopyWith<$Res> {
  __$$signatureEventImplCopyWithImpl(
      _$signatureEventImpl _value, $Res Function(_$signatureEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$signatureEventImpl implements _signatureEvent {
  _$signatureEventImpl();

  @override
  String toString() {
    return 'ShipmentVerificationEvent.signatureEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$signatureEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() signatureEvent,
    required TResult Function(BuildContext context, String supplierId,
            String signPath, String orderId)
        deliveryConfirmEvent,
    required TResult Function() signDeleteEvent,
  }) {
    return signatureEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? signatureEvent,
    TResult? Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult? Function()? signDeleteEvent,
  }) {
    return signatureEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? signatureEvent,
    TResult Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult Function()? signDeleteEvent,
    required TResult orElse(),
  }) {
    if (signatureEvent != null) {
      return signatureEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_signatureEvent value) signatureEvent,
    required TResult Function(_deliveryConfirmEvent value) deliveryConfirmEvent,
    required TResult Function(_signDeleteEvent value) signDeleteEvent,
  }) {
    return signatureEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_signatureEvent value)? signatureEvent,
    TResult? Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult? Function(_signDeleteEvent value)? signDeleteEvent,
  }) {
    return signatureEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_signatureEvent value)? signatureEvent,
    TResult Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult Function(_signDeleteEvent value)? signDeleteEvent,
    required TResult orElse(),
  }) {
    if (signatureEvent != null) {
      return signatureEvent(this);
    }
    return orElse();
  }
}

abstract class _signatureEvent implements ShipmentVerificationEvent {
  factory _signatureEvent() = _$signatureEventImpl;
}

/// @nodoc
abstract class _$$deliveryConfirmEventImplCopyWith<$Res> {
  factory _$$deliveryConfirmEventImplCopyWith(_$deliveryConfirmEventImpl value,
          $Res Function(_$deliveryConfirmEventImpl) then) =
      __$$deliveryConfirmEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      String supplierId,
      String signPath,
      String orderId});
}

/// @nodoc
class __$$deliveryConfirmEventImplCopyWithImpl<$Res>
    extends _$ShipmentVerificationEventCopyWithImpl<$Res,
        _$deliveryConfirmEventImpl>
    implements _$$deliveryConfirmEventImplCopyWith<$Res> {
  __$$deliveryConfirmEventImplCopyWithImpl(_$deliveryConfirmEventImpl _value,
      $Res Function(_$deliveryConfirmEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? supplierId = null,
    Object? signPath = null,
    Object? orderId = null,
  }) {
    return _then(_$deliveryConfirmEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierId: null == supplierId
          ? _value.supplierId
          : supplierId // ignore: cast_nullable_to_non_nullable
              as String,
      signPath: null == signPath
          ? _value.signPath
          : signPath // ignore: cast_nullable_to_non_nullable
              as String,
      orderId: null == orderId
          ? _value.orderId
          : orderId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$deliveryConfirmEventImpl implements _deliveryConfirmEvent {
  _$deliveryConfirmEventImpl(
      {required this.context,
      required this.supplierId,
      required this.signPath,
      required this.orderId});

  @override
  final BuildContext context;
  @override
  final String supplierId;
  @override
  final String signPath;
  @override
  final String orderId;

  @override
  String toString() {
    return 'ShipmentVerificationEvent.deliveryConfirmEvent(context: $context, supplierId: $supplierId, signPath: $signPath, orderId: $orderId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deliveryConfirmEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierId, supplierId) ||
                other.supplierId == supplierId) &&
            (identical(other.signPath, signPath) ||
                other.signPath == signPath) &&
            (identical(other.orderId, orderId) || other.orderId == orderId));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, supplierId, signPath, orderId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deliveryConfirmEventImplCopyWith<_$deliveryConfirmEventImpl>
      get copyWith =>
          __$$deliveryConfirmEventImplCopyWithImpl<_$deliveryConfirmEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() signatureEvent,
    required TResult Function(BuildContext context, String supplierId,
            String signPath, String orderId)
        deliveryConfirmEvent,
    required TResult Function() signDeleteEvent,
  }) {
    return deliveryConfirmEvent(context, supplierId, signPath, orderId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? signatureEvent,
    TResult? Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult? Function()? signDeleteEvent,
  }) {
    return deliveryConfirmEvent?.call(context, supplierId, signPath, orderId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? signatureEvent,
    TResult Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult Function()? signDeleteEvent,
    required TResult orElse(),
  }) {
    if (deliveryConfirmEvent != null) {
      return deliveryConfirmEvent(context, supplierId, signPath, orderId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_signatureEvent value) signatureEvent,
    required TResult Function(_deliveryConfirmEvent value) deliveryConfirmEvent,
    required TResult Function(_signDeleteEvent value) signDeleteEvent,
  }) {
    return deliveryConfirmEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_signatureEvent value)? signatureEvent,
    TResult? Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult? Function(_signDeleteEvent value)? signDeleteEvent,
  }) {
    return deliveryConfirmEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_signatureEvent value)? signatureEvent,
    TResult Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult Function(_signDeleteEvent value)? signDeleteEvent,
    required TResult orElse(),
  }) {
    if (deliveryConfirmEvent != null) {
      return deliveryConfirmEvent(this);
    }
    return orElse();
  }
}

abstract class _deliveryConfirmEvent implements ShipmentVerificationEvent {
  factory _deliveryConfirmEvent(
      {required final BuildContext context,
      required final String supplierId,
      required final String signPath,
      required final String orderId}) = _$deliveryConfirmEventImpl;

  BuildContext get context;
  String get supplierId;
  String get signPath;
  String get orderId;
  @JsonKey(ignore: true)
  _$$deliveryConfirmEventImplCopyWith<_$deliveryConfirmEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$signDeleteEventImplCopyWith<$Res> {
  factory _$$signDeleteEventImplCopyWith(_$signDeleteEventImpl value,
          $Res Function(_$signDeleteEventImpl) then) =
      __$$signDeleteEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$signDeleteEventImplCopyWithImpl<$Res>
    extends _$ShipmentVerificationEventCopyWithImpl<$Res, _$signDeleteEventImpl>
    implements _$$signDeleteEventImplCopyWith<$Res> {
  __$$signDeleteEventImplCopyWithImpl(
      _$signDeleteEventImpl _value, $Res Function(_$signDeleteEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$signDeleteEventImpl implements _signDeleteEvent {
  _$signDeleteEventImpl();

  @override
  String toString() {
    return 'ShipmentVerificationEvent.signDeleteEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$signDeleteEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() signatureEvent,
    required TResult Function(BuildContext context, String supplierId,
            String signPath, String orderId)
        deliveryConfirmEvent,
    required TResult Function() signDeleteEvent,
  }) {
    return signDeleteEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? signatureEvent,
    TResult? Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult? Function()? signDeleteEvent,
  }) {
    return signDeleteEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? signatureEvent,
    TResult Function(BuildContext context, String supplierId, String signPath,
            String orderId)?
        deliveryConfirmEvent,
    TResult Function()? signDeleteEvent,
    required TResult orElse(),
  }) {
    if (signDeleteEvent != null) {
      return signDeleteEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_signatureEvent value) signatureEvent,
    required TResult Function(_deliveryConfirmEvent value) deliveryConfirmEvent,
    required TResult Function(_signDeleteEvent value) signDeleteEvent,
  }) {
    return signDeleteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_signatureEvent value)? signatureEvent,
    TResult? Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult? Function(_signDeleteEvent value)? signDeleteEvent,
  }) {
    return signDeleteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_signatureEvent value)? signatureEvent,
    TResult Function(_deliveryConfirmEvent value)? deliveryConfirmEvent,
    TResult Function(_signDeleteEvent value)? signDeleteEvent,
    required TResult orElse(),
  }) {
    if (signDeleteEvent != null) {
      return signDeleteEvent(this);
    }
    return orElse();
  }
}

abstract class _signDeleteEvent implements ShipmentVerificationEvent {
  factory _signDeleteEvent() = _$signDeleteEventImpl;
}

/// @nodoc
mixin _$ShipmentVerificationState {
  bool get isSignaturePadActive => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isDelete => throw _privateConstructorUsedError;
  TextEditingController get surfacesController =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ShipmentVerificationStateCopyWith<ShipmentVerificationState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShipmentVerificationStateCopyWith<$Res> {
  factory $ShipmentVerificationStateCopyWith(ShipmentVerificationState value,
          $Res Function(ShipmentVerificationState) then) =
      _$ShipmentVerificationStateCopyWithImpl<$Res, ShipmentVerificationState>;
  @useResult
  $Res call(
      {bool isSignaturePadActive,
      bool isLoading,
      bool isDelete,
      TextEditingController surfacesController});
}

/// @nodoc
class _$ShipmentVerificationStateCopyWithImpl<$Res,
        $Val extends ShipmentVerificationState>
    implements $ShipmentVerificationStateCopyWith<$Res> {
  _$ShipmentVerificationStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSignaturePadActive = null,
    Object? isLoading = null,
    Object? isDelete = null,
    Object? surfacesController = null,
  }) {
    return _then(_value.copyWith(
      isSignaturePadActive: null == isSignaturePadActive
          ? _value.isSignaturePadActive
          : isSignaturePadActive // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isDelete: null == isDelete
          ? _value.isDelete
          : isDelete // ignore: cast_nullable_to_non_nullable
              as bool,
      surfacesController: null == surfacesController
          ? _value.surfacesController
          : surfacesController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ShipmentVerificationStateImplCopyWith<$Res>
    implements $ShipmentVerificationStateCopyWith<$Res> {
  factory _$$ShipmentVerificationStateImplCopyWith(
          _$ShipmentVerificationStateImpl value,
          $Res Function(_$ShipmentVerificationStateImpl) then) =
      __$$ShipmentVerificationStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isSignaturePadActive,
      bool isLoading,
      bool isDelete,
      TextEditingController surfacesController});
}

/// @nodoc
class __$$ShipmentVerificationStateImplCopyWithImpl<$Res>
    extends _$ShipmentVerificationStateCopyWithImpl<$Res,
        _$ShipmentVerificationStateImpl>
    implements _$$ShipmentVerificationStateImplCopyWith<$Res> {
  __$$ShipmentVerificationStateImplCopyWithImpl(
      _$ShipmentVerificationStateImpl _value,
      $Res Function(_$ShipmentVerificationStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSignaturePadActive = null,
    Object? isLoading = null,
    Object? isDelete = null,
    Object? surfacesController = null,
  }) {
    return _then(_$ShipmentVerificationStateImpl(
      isSignaturePadActive: null == isSignaturePadActive
          ? _value.isSignaturePadActive
          : isSignaturePadActive // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isDelete: null == isDelete
          ? _value.isDelete
          : isDelete // ignore: cast_nullable_to_non_nullable
              as bool,
      surfacesController: null == surfacesController
          ? _value.surfacesController
          : surfacesController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
    ));
  }
}

/// @nodoc

class _$ShipmentVerificationStateImpl implements _ShipmentVerificationState {
  _$ShipmentVerificationStateImpl(
      {required this.isSignaturePadActive,
      required this.isLoading,
      required this.isDelete,
      required this.surfacesController});

  @override
  final bool isSignaturePadActive;
  @override
  final bool isLoading;
  @override
  final bool isDelete;
  @override
  final TextEditingController surfacesController;

  @override
  String toString() {
    return 'ShipmentVerificationState(isSignaturePadActive: $isSignaturePadActive, isLoading: $isLoading, isDelete: $isDelete, surfacesController: $surfacesController)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ShipmentVerificationStateImpl &&
            (identical(other.isSignaturePadActive, isSignaturePadActive) ||
                other.isSignaturePadActive == isSignaturePadActive) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isDelete, isDelete) ||
                other.isDelete == isDelete) &&
            (identical(other.surfacesController, surfacesController) ||
                other.surfacesController == surfacesController));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSignaturePadActive, isLoading,
      isDelete, surfacesController);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ShipmentVerificationStateImplCopyWith<_$ShipmentVerificationStateImpl>
      get copyWith => __$$ShipmentVerificationStateImplCopyWithImpl<
          _$ShipmentVerificationStateImpl>(this, _$identity);
}

abstract class _ShipmentVerificationState implements ShipmentVerificationState {
  factory _ShipmentVerificationState(
          {required final bool isSignaturePadActive,
          required final bool isLoading,
          required final bool isDelete,
          required final TextEditingController surfacesController}) =
      _$ShipmentVerificationStateImpl;

  @override
  bool get isSignaturePadActive;
  @override
  bool get isLoading;
  @override
  bool get isDelete;
  @override
  TextEditingController get surfacesController;
  @override
  @JsonKey(ignore: true)
  _$$ShipmentVerificationStateImplCopyWith<_$ShipmentVerificationStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
