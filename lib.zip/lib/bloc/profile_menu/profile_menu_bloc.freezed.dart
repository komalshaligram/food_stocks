// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_menu_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProfileMenuEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferenceDataEvent,
    required TResult Function() getAppLanguage,
    required TResult Function(BuildContext context) logOutEvent,
    required TResult Function(BuildContext context) changeAppLanguageEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferenceDataEvent,
    TResult? Function()? getAppLanguage,
    TResult? Function(BuildContext context)? logOutEvent,
    TResult? Function(BuildContext context)? changeAppLanguageEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferenceDataEvent,
    TResult Function()? getAppLanguage,
    TResult Function(BuildContext context)? logOutEvent,
    TResult Function(BuildContext context)? changeAppLanguageEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferenceDataEvent value)
        getPreferenceDataEvent,
    required TResult Function(_GetAppLanguage value) getAppLanguage,
    required TResult Function(_logOutEvent value) logOutEvent,
    required TResult Function(_ChangeAppLanguageEvent value)
        changeAppLanguageEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult? Function(_GetAppLanguage value)? getAppLanguage,
    TResult? Function(_logOutEvent value)? logOutEvent,
    TResult? Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult Function(_GetAppLanguage value)? getAppLanguage,
    TResult Function(_logOutEvent value)? logOutEvent,
    TResult Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileMenuEventCopyWith<$Res> {
  factory $ProfileMenuEventCopyWith(
          ProfileMenuEvent value, $Res Function(ProfileMenuEvent) then) =
      _$ProfileMenuEventCopyWithImpl<$Res, ProfileMenuEvent>;
}

/// @nodoc
class _$ProfileMenuEventCopyWithImpl<$Res, $Val extends ProfileMenuEvent>
    implements $ProfileMenuEventCopyWith<$Res> {
  _$ProfileMenuEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getPreferenceDataEventImplCopyWith<$Res> {
  factory _$$getPreferenceDataEventImplCopyWith(
          _$getPreferenceDataEventImpl value,
          $Res Function(_$getPreferenceDataEventImpl) then) =
      __$$getPreferenceDataEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getPreferenceDataEventImplCopyWithImpl<$Res>
    extends _$ProfileMenuEventCopyWithImpl<$Res, _$getPreferenceDataEventImpl>
    implements _$$getPreferenceDataEventImplCopyWith<$Res> {
  __$$getPreferenceDataEventImplCopyWithImpl(
      _$getPreferenceDataEventImpl _value,
      $Res Function(_$getPreferenceDataEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getPreferenceDataEventImpl implements _getPreferenceDataEvent {
  const _$getPreferenceDataEventImpl();

  @override
  String toString() {
    return 'ProfileMenuEvent.getPreferenceDataEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPreferenceDataEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferenceDataEvent,
    required TResult Function() getAppLanguage,
    required TResult Function(BuildContext context) logOutEvent,
    required TResult Function(BuildContext context) changeAppLanguageEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPreferenceDataEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferenceDataEvent,
    TResult? Function()? getAppLanguage,
    TResult? Function(BuildContext context)? logOutEvent,
    TResult? Function(BuildContext context)? changeAppLanguageEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPreferenceDataEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferenceDataEvent,
    TResult Function()? getAppLanguage,
    TResult Function(BuildContext context)? logOutEvent,
    TResult Function(BuildContext context)? changeAppLanguageEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPreferenceDataEvent != null) {
      return getPreferenceDataEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferenceDataEvent value)
        getPreferenceDataEvent,
    required TResult Function(_GetAppLanguage value) getAppLanguage,
    required TResult Function(_logOutEvent value) logOutEvent,
    required TResult Function(_ChangeAppLanguageEvent value)
        changeAppLanguageEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPreferenceDataEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult? Function(_GetAppLanguage value)? getAppLanguage,
    TResult? Function(_logOutEvent value)? logOutEvent,
    TResult? Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPreferenceDataEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult Function(_GetAppLanguage value)? getAppLanguage,
    TResult Function(_logOutEvent value)? logOutEvent,
    TResult Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPreferenceDataEvent != null) {
      return getPreferenceDataEvent(this);
    }
    return orElse();
  }
}

abstract class _getPreferenceDataEvent implements ProfileMenuEvent {
  const factory _getPreferenceDataEvent() = _$getPreferenceDataEventImpl;
}

/// @nodoc
abstract class _$$GetAppLanguageImplCopyWith<$Res> {
  factory _$$GetAppLanguageImplCopyWith(_$GetAppLanguageImpl value,
          $Res Function(_$GetAppLanguageImpl) then) =
      __$$GetAppLanguageImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetAppLanguageImplCopyWithImpl<$Res>
    extends _$ProfileMenuEventCopyWithImpl<$Res, _$GetAppLanguageImpl>
    implements _$$GetAppLanguageImplCopyWith<$Res> {
  __$$GetAppLanguageImplCopyWithImpl(
      _$GetAppLanguageImpl _value, $Res Function(_$GetAppLanguageImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetAppLanguageImpl implements _GetAppLanguage {
  const _$GetAppLanguageImpl();

  @override
  String toString() {
    return 'ProfileMenuEvent.getAppLanguage()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetAppLanguageImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferenceDataEvent,
    required TResult Function() getAppLanguage,
    required TResult Function(BuildContext context) logOutEvent,
    required TResult Function(BuildContext context) changeAppLanguageEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getAppLanguage();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferenceDataEvent,
    TResult? Function()? getAppLanguage,
    TResult? Function(BuildContext context)? logOutEvent,
    TResult? Function(BuildContext context)? changeAppLanguageEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getAppLanguage?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferenceDataEvent,
    TResult Function()? getAppLanguage,
    TResult Function(BuildContext context)? logOutEvent,
    TResult Function(BuildContext context)? changeAppLanguageEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAppLanguage != null) {
      return getAppLanguage();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferenceDataEvent value)
        getPreferenceDataEvent,
    required TResult Function(_GetAppLanguage value) getAppLanguage,
    required TResult Function(_logOutEvent value) logOutEvent,
    required TResult Function(_ChangeAppLanguageEvent value)
        changeAppLanguageEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getAppLanguage(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult? Function(_GetAppLanguage value)? getAppLanguage,
    TResult? Function(_logOutEvent value)? logOutEvent,
    TResult? Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getAppLanguage?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult Function(_GetAppLanguage value)? getAppLanguage,
    TResult Function(_logOutEvent value)? logOutEvent,
    TResult Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getAppLanguage != null) {
      return getAppLanguage(this);
    }
    return orElse();
  }
}

abstract class _GetAppLanguage implements ProfileMenuEvent {
  const factory _GetAppLanguage() = _$GetAppLanguageImpl;
}

/// @nodoc
abstract class _$$logOutEventImplCopyWith<$Res> {
  factory _$$logOutEventImplCopyWith(
          _$logOutEventImpl value, $Res Function(_$logOutEventImpl) then) =
      __$$logOutEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$logOutEventImplCopyWithImpl<$Res>
    extends _$ProfileMenuEventCopyWithImpl<$Res, _$logOutEventImpl>
    implements _$$logOutEventImplCopyWith<$Res> {
  __$$logOutEventImplCopyWithImpl(
      _$logOutEventImpl _value, $Res Function(_$logOutEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$logOutEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$logOutEventImpl implements _logOutEvent {
  const _$logOutEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProfileMenuEvent.logOutEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$logOutEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$logOutEventImplCopyWith<_$logOutEventImpl> get copyWith =>
      __$$logOutEventImplCopyWithImpl<_$logOutEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferenceDataEvent,
    required TResult Function() getAppLanguage,
    required TResult Function(BuildContext context) logOutEvent,
    required TResult Function(BuildContext context) changeAppLanguageEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return logOutEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferenceDataEvent,
    TResult? Function()? getAppLanguage,
    TResult? Function(BuildContext context)? logOutEvent,
    TResult? Function(BuildContext context)? changeAppLanguageEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return logOutEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferenceDataEvent,
    TResult Function()? getAppLanguage,
    TResult Function(BuildContext context)? logOutEvent,
    TResult Function(BuildContext context)? changeAppLanguageEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (logOutEvent != null) {
      return logOutEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferenceDataEvent value)
        getPreferenceDataEvent,
    required TResult Function(_GetAppLanguage value) getAppLanguage,
    required TResult Function(_logOutEvent value) logOutEvent,
    required TResult Function(_ChangeAppLanguageEvent value)
        changeAppLanguageEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return logOutEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult? Function(_GetAppLanguage value)? getAppLanguage,
    TResult? Function(_logOutEvent value)? logOutEvent,
    TResult? Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return logOutEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult Function(_GetAppLanguage value)? getAppLanguage,
    TResult Function(_logOutEvent value)? logOutEvent,
    TResult Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (logOutEvent != null) {
      return logOutEvent(this);
    }
    return orElse();
  }
}

abstract class _logOutEvent implements ProfileMenuEvent {
  const factory _logOutEvent({required final BuildContext context}) =
      _$logOutEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$logOutEventImplCopyWith<_$logOutEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeAppLanguageEventImplCopyWith<$Res> {
  factory _$$ChangeAppLanguageEventImplCopyWith(
          _$ChangeAppLanguageEventImpl value,
          $Res Function(_$ChangeAppLanguageEventImpl) then) =
      __$$ChangeAppLanguageEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$ChangeAppLanguageEventImplCopyWithImpl<$Res>
    extends _$ProfileMenuEventCopyWithImpl<$Res, _$ChangeAppLanguageEventImpl>
    implements _$$ChangeAppLanguageEventImplCopyWith<$Res> {
  __$$ChangeAppLanguageEventImplCopyWithImpl(
      _$ChangeAppLanguageEventImpl _value,
      $Res Function(_$ChangeAppLanguageEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$ChangeAppLanguageEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$ChangeAppLanguageEventImpl implements _ChangeAppLanguageEvent {
  const _$ChangeAppLanguageEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProfileMenuEvent.changeAppLanguageEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeAppLanguageEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeAppLanguageEventImplCopyWith<_$ChangeAppLanguageEventImpl>
      get copyWith => __$$ChangeAppLanguageEventImplCopyWithImpl<
          _$ChangeAppLanguageEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferenceDataEvent,
    required TResult Function() getAppLanguage,
    required TResult Function(BuildContext context) logOutEvent,
    required TResult Function(BuildContext context) changeAppLanguageEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeAppLanguageEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferenceDataEvent,
    TResult? Function()? getAppLanguage,
    TResult? Function(BuildContext context)? logOutEvent,
    TResult? Function(BuildContext context)? changeAppLanguageEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeAppLanguageEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferenceDataEvent,
    TResult Function()? getAppLanguage,
    TResult Function(BuildContext context)? logOutEvent,
    TResult Function(BuildContext context)? changeAppLanguageEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeAppLanguageEvent != null) {
      return changeAppLanguageEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferenceDataEvent value)
        getPreferenceDataEvent,
    required TResult Function(_GetAppLanguage value) getAppLanguage,
    required TResult Function(_logOutEvent value) logOutEvent,
    required TResult Function(_ChangeAppLanguageEvent value)
        changeAppLanguageEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeAppLanguageEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult? Function(_GetAppLanguage value)? getAppLanguage,
    TResult? Function(_logOutEvent value)? logOutEvent,
    TResult? Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeAppLanguageEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult Function(_GetAppLanguage value)? getAppLanguage,
    TResult Function(_logOutEvent value)? logOutEvent,
    TResult Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeAppLanguageEvent != null) {
      return changeAppLanguageEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeAppLanguageEvent implements ProfileMenuEvent {
  const factory _ChangeAppLanguageEvent({required final BuildContext context}) =
      _$ChangeAppLanguageEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$ChangeAppLanguageEventImplCopyWith<_$ChangeAppLanguageEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getProfileDetailsEventImplCopyWith<$Res> {
  factory _$$getProfileDetailsEventImplCopyWith(
          _$getProfileDetailsEventImpl value,
          $Res Function(_$getProfileDetailsEventImpl) then) =
      __$$getProfileDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getProfileDetailsEventImplCopyWithImpl<$Res>
    extends _$ProfileMenuEventCopyWithImpl<$Res, _$getProfileDetailsEventImpl>
    implements _$$getProfileDetailsEventImplCopyWith<$Res> {
  __$$getProfileDetailsEventImplCopyWithImpl(
      _$getProfileDetailsEventImpl _value,
      $Res Function(_$getProfileDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getProfileDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getProfileDetailsEventImpl implements _getProfileDetailsEvent {
  const _$getProfileDetailsEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProfileMenuEvent.getProfileDetailsEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getProfileDetailsEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getProfileDetailsEventImplCopyWith<_$getProfileDetailsEventImpl>
      get copyWith => __$$getProfileDetailsEventImplCopyWithImpl<
          _$getProfileDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferenceDataEvent,
    required TResult Function() getAppLanguage,
    required TResult Function(BuildContext context) logOutEvent,
    required TResult Function(BuildContext context) changeAppLanguageEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProfileDetailsEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferenceDataEvent,
    TResult? Function()? getAppLanguage,
    TResult? Function(BuildContext context)? logOutEvent,
    TResult? Function(BuildContext context)? changeAppLanguageEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProfileDetailsEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferenceDataEvent,
    TResult Function()? getAppLanguage,
    TResult Function(BuildContext context)? logOutEvent,
    TResult Function(BuildContext context)? changeAppLanguageEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProfileDetailsEvent != null) {
      return getProfileDetailsEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferenceDataEvent value)
        getPreferenceDataEvent,
    required TResult Function(_GetAppLanguage value) getAppLanguage,
    required TResult Function(_logOutEvent value) logOutEvent,
    required TResult Function(_ChangeAppLanguageEvent value)
        changeAppLanguageEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProfileDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult? Function(_GetAppLanguage value)? getAppLanguage,
    TResult? Function(_logOutEvent value)? logOutEvent,
    TResult? Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProfileDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult Function(_GetAppLanguage value)? getAppLanguage,
    TResult Function(_logOutEvent value)? logOutEvent,
    TResult Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProfileDetailsEvent != null) {
      return getProfileDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _getProfileDetailsEvent implements ProfileMenuEvent {
  const factory _getProfileDetailsEvent({required final BuildContext context}) =
      _$getProfileDetailsEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getProfileDetailsEventImplCopyWith<_$getProfileDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$ProfileMenuEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'ProfileMenuEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getPreferenceDataEvent,
    required TResult Function() getAppLanguage,
    required TResult Function(BuildContext context) logOutEvent,
    required TResult Function(BuildContext context) changeAppLanguageEvent,
    required TResult Function(BuildContext context) getProfileDetailsEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getPreferenceDataEvent,
    TResult? Function()? getAppLanguage,
    TResult? Function(BuildContext context)? logOutEvent,
    TResult? Function(BuildContext context)? changeAppLanguageEvent,
    TResult? Function(BuildContext context)? getProfileDetailsEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getPreferenceDataEvent,
    TResult Function()? getAppLanguage,
    TResult Function(BuildContext context)? logOutEvent,
    TResult Function(BuildContext context)? changeAppLanguageEvent,
    TResult Function(BuildContext context)? getProfileDetailsEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getPreferenceDataEvent value)
        getPreferenceDataEvent,
    required TResult Function(_GetAppLanguage value) getAppLanguage,
    required TResult Function(_logOutEvent value) logOutEvent,
    required TResult Function(_ChangeAppLanguageEvent value)
        changeAppLanguageEvent,
    required TResult Function(_getProfileDetailsEvent value)
        getProfileDetailsEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult? Function(_GetAppLanguage value)? getAppLanguage,
    TResult? Function(_logOutEvent value)? logOutEvent,
    TResult? Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult? Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getPreferenceDataEvent value)? getPreferenceDataEvent,
    TResult Function(_GetAppLanguage value)? getAppLanguage,
    TResult Function(_logOutEvent value)? logOutEvent,
    TResult Function(_ChangeAppLanguageEvent value)? changeAppLanguageEvent,
    TResult Function(_getProfileDetailsEvent value)? getProfileDetailsEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements ProfileMenuEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProfileMenuState {
  String get UserImageUrl => throw _privateConstructorUsedError;
  String get UserCompanyLogoUrl => throw _privateConstructorUsedError;
  String get userName => throw _privateConstructorUsedError;
  bool get isHebrewLanguage => throw _privateConstructorUsedError;
  bool get isLogOut => throw _privateConstructorUsedError;
  bool get isLogOutProcess => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;
  String get applicationVersion => throw _privateConstructorUsedError;
  String get buildNumber => throw _privateConstructorUsedError;
  bool get isSubUserUpdateBusinessInfo => throw _privateConstructorUsedError;
  bool get isSubUserUpdateAdditionalInfo => throw _privateConstructorUsedError;
  bool get isSubUserUpdateTimeInfo => throw _privateConstructorUsedError;
  bool get isSubUserSeeFormsFiles => throw _privateConstructorUsedError;
  bool get isSubUserCanManageSubUser => throw _privateConstructorUsedError;
  bool get isSubUserSeeOrder => throw _privateConstructorUsedError;
  bool get isAccountPermissionShimmering => throw _privateConstructorUsedError;
  bool get isCanSeeInvoices => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProfileMenuStateCopyWith<ProfileMenuState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileMenuStateCopyWith<$Res> {
  factory $ProfileMenuStateCopyWith(
          ProfileMenuState value, $Res Function(ProfileMenuState) then) =
      _$ProfileMenuStateCopyWithImpl<$Res, ProfileMenuState>;
  @useResult
  $Res call(
      {String UserImageUrl,
      String UserCompanyLogoUrl,
      String userName,
      bool isHebrewLanguage,
      bool isLogOut,
      bool isLogOutProcess,
      String language,
      String applicationVersion,
      String buildNumber,
      bool isSubUserUpdateBusinessInfo,
      bool isSubUserUpdateAdditionalInfo,
      bool isSubUserUpdateTimeInfo,
      bool isSubUserSeeFormsFiles,
      bool isSubUserCanManageSubUser,
      bool isSubUserSeeOrder,
      bool isAccountPermissionShimmering,
      bool isCanSeeInvoices});
}

/// @nodoc
class _$ProfileMenuStateCopyWithImpl<$Res, $Val extends ProfileMenuState>
    implements $ProfileMenuStateCopyWith<$Res> {
  _$ProfileMenuStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? UserImageUrl = null,
    Object? UserCompanyLogoUrl = null,
    Object? userName = null,
    Object? isHebrewLanguage = null,
    Object? isLogOut = null,
    Object? isLogOutProcess = null,
    Object? language = null,
    Object? applicationVersion = null,
    Object? buildNumber = null,
    Object? isSubUserUpdateBusinessInfo = null,
    Object? isSubUserUpdateAdditionalInfo = null,
    Object? isSubUserUpdateTimeInfo = null,
    Object? isSubUserSeeFormsFiles = null,
    Object? isSubUserCanManageSubUser = null,
    Object? isSubUserSeeOrder = null,
    Object? isAccountPermissionShimmering = null,
    Object? isCanSeeInvoices = null,
  }) {
    return _then(_value.copyWith(
      UserImageUrl: null == UserImageUrl
          ? _value.UserImageUrl
          : UserImageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      UserCompanyLogoUrl: null == UserCompanyLogoUrl
          ? _value.UserCompanyLogoUrl
          : UserCompanyLogoUrl // ignore: cast_nullable_to_non_nullable
              as String,
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
      isHebrewLanguage: null == isHebrewLanguage
          ? _value.isHebrewLanguage
          : isHebrewLanguage // ignore: cast_nullable_to_non_nullable
              as bool,
      isLogOut: null == isLogOut
          ? _value.isLogOut
          : isLogOut // ignore: cast_nullable_to_non_nullable
              as bool,
      isLogOutProcess: null == isLogOutProcess
          ? _value.isLogOutProcess
          : isLogOutProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      applicationVersion: null == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String,
      buildNumber: null == buildNumber
          ? _value.buildNumber
          : buildNumber // ignore: cast_nullable_to_non_nullable
              as String,
      isSubUserUpdateBusinessInfo: null == isSubUserUpdateBusinessInfo
          ? _value.isSubUserUpdateBusinessInfo
          : isSubUserUpdateBusinessInfo // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserUpdateAdditionalInfo: null == isSubUserUpdateAdditionalInfo
          ? _value.isSubUserUpdateAdditionalInfo
          : isSubUserUpdateAdditionalInfo // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserUpdateTimeInfo: null == isSubUserUpdateTimeInfo
          ? _value.isSubUserUpdateTimeInfo
          : isSubUserUpdateTimeInfo // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserSeeFormsFiles: null == isSubUserSeeFormsFiles
          ? _value.isSubUserSeeFormsFiles
          : isSubUserSeeFormsFiles // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCanManageSubUser: null == isSubUserCanManageSubUser
          ? _value.isSubUserCanManageSubUser
          : isSubUserCanManageSubUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserSeeOrder: null == isSubUserSeeOrder
          ? _value.isSubUserSeeOrder
          : isSubUserSeeOrder // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isCanSeeInvoices: null == isCanSeeInvoices
          ? _value.isCanSeeInvoices
          : isCanSeeInvoices // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProfileMenuStateImplCopyWith<$Res>
    implements $ProfileMenuStateCopyWith<$Res> {
  factory _$$ProfileMenuStateImplCopyWith(_$ProfileMenuStateImpl value,
          $Res Function(_$ProfileMenuStateImpl) then) =
      __$$ProfileMenuStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String UserImageUrl,
      String UserCompanyLogoUrl,
      String userName,
      bool isHebrewLanguage,
      bool isLogOut,
      bool isLogOutProcess,
      String language,
      String applicationVersion,
      String buildNumber,
      bool isSubUserUpdateBusinessInfo,
      bool isSubUserUpdateAdditionalInfo,
      bool isSubUserUpdateTimeInfo,
      bool isSubUserSeeFormsFiles,
      bool isSubUserCanManageSubUser,
      bool isSubUserSeeOrder,
      bool isAccountPermissionShimmering,
      bool isCanSeeInvoices});
}

/// @nodoc
class __$$ProfileMenuStateImplCopyWithImpl<$Res>
    extends _$ProfileMenuStateCopyWithImpl<$Res, _$ProfileMenuStateImpl>
    implements _$$ProfileMenuStateImplCopyWith<$Res> {
  __$$ProfileMenuStateImplCopyWithImpl(_$ProfileMenuStateImpl _value,
      $Res Function(_$ProfileMenuStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? UserImageUrl = null,
    Object? UserCompanyLogoUrl = null,
    Object? userName = null,
    Object? isHebrewLanguage = null,
    Object? isLogOut = null,
    Object? isLogOutProcess = null,
    Object? language = null,
    Object? applicationVersion = null,
    Object? buildNumber = null,
    Object? isSubUserUpdateBusinessInfo = null,
    Object? isSubUserUpdateAdditionalInfo = null,
    Object? isSubUserUpdateTimeInfo = null,
    Object? isSubUserSeeFormsFiles = null,
    Object? isSubUserCanManageSubUser = null,
    Object? isSubUserSeeOrder = null,
    Object? isAccountPermissionShimmering = null,
    Object? isCanSeeInvoices = null,
  }) {
    return _then(_$ProfileMenuStateImpl(
      UserImageUrl: null == UserImageUrl
          ? _value.UserImageUrl
          : UserImageUrl // ignore: cast_nullable_to_non_nullable
              as String,
      UserCompanyLogoUrl: null == UserCompanyLogoUrl
          ? _value.UserCompanyLogoUrl
          : UserCompanyLogoUrl // ignore: cast_nullable_to_non_nullable
              as String,
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
      isHebrewLanguage: null == isHebrewLanguage
          ? _value.isHebrewLanguage
          : isHebrewLanguage // ignore: cast_nullable_to_non_nullable
              as bool,
      isLogOut: null == isLogOut
          ? _value.isLogOut
          : isLogOut // ignore: cast_nullable_to_non_nullable
              as bool,
      isLogOutProcess: null == isLogOutProcess
          ? _value.isLogOutProcess
          : isLogOutProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
      applicationVersion: null == applicationVersion
          ? _value.applicationVersion
          : applicationVersion // ignore: cast_nullable_to_non_nullable
              as String,
      buildNumber: null == buildNumber
          ? _value.buildNumber
          : buildNumber // ignore: cast_nullable_to_non_nullable
              as String,
      isSubUserUpdateBusinessInfo: null == isSubUserUpdateBusinessInfo
          ? _value.isSubUserUpdateBusinessInfo
          : isSubUserUpdateBusinessInfo // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserUpdateAdditionalInfo: null == isSubUserUpdateAdditionalInfo
          ? _value.isSubUserUpdateAdditionalInfo
          : isSubUserUpdateAdditionalInfo // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserUpdateTimeInfo: null == isSubUserUpdateTimeInfo
          ? _value.isSubUserUpdateTimeInfo
          : isSubUserUpdateTimeInfo // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserSeeFormsFiles: null == isSubUserSeeFormsFiles
          ? _value.isSubUserSeeFormsFiles
          : isSubUserSeeFormsFiles // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserCanManageSubUser: null == isSubUserCanManageSubUser
          ? _value.isSubUserCanManageSubUser
          : isSubUserCanManageSubUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isSubUserSeeOrder: null == isSubUserSeeOrder
          ? _value.isSubUserSeeOrder
          : isSubUserSeeOrder // ignore: cast_nullable_to_non_nullable
              as bool,
      isAccountPermissionShimmering: null == isAccountPermissionShimmering
          ? _value.isAccountPermissionShimmering
          : isAccountPermissionShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isCanSeeInvoices: null == isCanSeeInvoices
          ? _value.isCanSeeInvoices
          : isCanSeeInvoices // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ProfileMenuStateImpl implements _ProfileMenuState {
  const _$ProfileMenuStateImpl(
      {required this.UserImageUrl,
      required this.UserCompanyLogoUrl,
      required this.userName,
      required this.isHebrewLanguage,
      required this.isLogOut,
      required this.isLogOutProcess,
      required this.language,
      required this.applicationVersion,
      required this.buildNumber,
      required this.isSubUserUpdateBusinessInfo,
      required this.isSubUserUpdateAdditionalInfo,
      required this.isSubUserUpdateTimeInfo,
      required this.isSubUserSeeFormsFiles,
      required this.isSubUserCanManageSubUser,
      required this.isSubUserSeeOrder,
      required this.isAccountPermissionShimmering,
      required this.isCanSeeInvoices});

  @override
  final String UserImageUrl;
  @override
  final String UserCompanyLogoUrl;
  @override
  final String userName;
  @override
  final bool isHebrewLanguage;
  @override
  final bool isLogOut;
  @override
  final bool isLogOutProcess;
  @override
  final String language;
  @override
  final String applicationVersion;
  @override
  final String buildNumber;
  @override
  final bool isSubUserUpdateBusinessInfo;
  @override
  final bool isSubUserUpdateAdditionalInfo;
  @override
  final bool isSubUserUpdateTimeInfo;
  @override
  final bool isSubUserSeeFormsFiles;
  @override
  final bool isSubUserCanManageSubUser;
  @override
  final bool isSubUserSeeOrder;
  @override
  final bool isAccountPermissionShimmering;
  @override
  final bool isCanSeeInvoices;

  @override
  String toString() {
    return 'ProfileMenuState(UserImageUrl: $UserImageUrl, UserCompanyLogoUrl: $UserCompanyLogoUrl, userName: $userName, isHebrewLanguage: $isHebrewLanguage, isLogOut: $isLogOut, isLogOutProcess: $isLogOutProcess, language: $language, applicationVersion: $applicationVersion, buildNumber: $buildNumber, isSubUserUpdateBusinessInfo: $isSubUserUpdateBusinessInfo, isSubUserUpdateAdditionalInfo: $isSubUserUpdateAdditionalInfo, isSubUserUpdateTimeInfo: $isSubUserUpdateTimeInfo, isSubUserSeeFormsFiles: $isSubUserSeeFormsFiles, isSubUserCanManageSubUser: $isSubUserCanManageSubUser, isSubUserSeeOrder: $isSubUserSeeOrder, isAccountPermissionShimmering: $isAccountPermissionShimmering, isCanSeeInvoices: $isCanSeeInvoices)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileMenuStateImpl &&
            (identical(other.UserImageUrl, UserImageUrl) ||
                other.UserImageUrl == UserImageUrl) &&
            (identical(other.UserCompanyLogoUrl, UserCompanyLogoUrl) ||
                other.UserCompanyLogoUrl == UserCompanyLogoUrl) &&
            (identical(other.userName, userName) ||
                other.userName == userName) &&
            (identical(other.isHebrewLanguage, isHebrewLanguage) ||
                other.isHebrewLanguage == isHebrewLanguage) &&
            (identical(other.isLogOut, isLogOut) ||
                other.isLogOut == isLogOut) &&
            (identical(other.isLogOutProcess, isLogOutProcess) ||
                other.isLogOutProcess == isLogOutProcess) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.applicationVersion, applicationVersion) ||
                other.applicationVersion == applicationVersion) &&
            (identical(other.buildNumber, buildNumber) ||
                other.buildNumber == buildNumber) &&
            (identical(other.isSubUserUpdateBusinessInfo,
                    isSubUserUpdateBusinessInfo) ||
                other.isSubUserUpdateBusinessInfo ==
                    isSubUserUpdateBusinessInfo) &&
            (identical(other.isSubUserUpdateAdditionalInfo,
                    isSubUserUpdateAdditionalInfo) ||
                other.isSubUserUpdateAdditionalInfo ==
                    isSubUserUpdateAdditionalInfo) &&
            (identical(
                    other.isSubUserUpdateTimeInfo, isSubUserUpdateTimeInfo) ||
                other.isSubUserUpdateTimeInfo == isSubUserUpdateTimeInfo) &&
            (identical(other.isSubUserSeeFormsFiles, isSubUserSeeFormsFiles) ||
                other.isSubUserSeeFormsFiles == isSubUserSeeFormsFiles) &&
            (identical(other.isSubUserCanManageSubUser, isSubUserCanManageSubUser) ||
                other.isSubUserCanManageSubUser == isSubUserCanManageSubUser) &&
            (identical(other.isSubUserSeeOrder, isSubUserSeeOrder) ||
                other.isSubUserSeeOrder == isSubUserSeeOrder) &&
            (identical(other.isAccountPermissionShimmering,
                    isAccountPermissionShimmering) ||
                other.isAccountPermissionShimmering ==
                    isAccountPermissionShimmering) &&
            (identical(other.isCanSeeInvoices, isCanSeeInvoices) ||
                other.isCanSeeInvoices == isCanSeeInvoices));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      UserImageUrl,
      UserCompanyLogoUrl,
      userName,
      isHebrewLanguage,
      isLogOut,
      isLogOutProcess,
      language,
      applicationVersion,
      buildNumber,
      isSubUserUpdateBusinessInfo,
      isSubUserUpdateAdditionalInfo,
      isSubUserUpdateTimeInfo,
      isSubUserSeeFormsFiles,
      isSubUserCanManageSubUser,
      isSubUserSeeOrder,
      isAccountPermissionShimmering,
      isCanSeeInvoices);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileMenuStateImplCopyWith<_$ProfileMenuStateImpl> get copyWith =>
      __$$ProfileMenuStateImplCopyWithImpl<_$ProfileMenuStateImpl>(
          this, _$identity);
}

abstract class _ProfileMenuState implements ProfileMenuState {
  const factory _ProfileMenuState(
      {required final String UserImageUrl,
      required final String UserCompanyLogoUrl,
      required final String userName,
      required final bool isHebrewLanguage,
      required final bool isLogOut,
      required final bool isLogOutProcess,
      required final String language,
      required final String applicationVersion,
      required final String buildNumber,
      required final bool isSubUserUpdateBusinessInfo,
      required final bool isSubUserUpdateAdditionalInfo,
      required final bool isSubUserUpdateTimeInfo,
      required final bool isSubUserSeeFormsFiles,
      required final bool isSubUserCanManageSubUser,
      required final bool isSubUserSeeOrder,
      required final bool isAccountPermissionShimmering,
      required final bool isCanSeeInvoices}) = _$ProfileMenuStateImpl;

  @override
  String get UserImageUrl;
  @override
  String get UserCompanyLogoUrl;
  @override
  String get userName;
  @override
  bool get isHebrewLanguage;
  @override
  bool get isLogOut;
  @override
  bool get isLogOutProcess;
  @override
  String get language;
  @override
  String get applicationVersion;
  @override
  String get buildNumber;
  @override
  bool get isSubUserUpdateBusinessInfo;
  @override
  bool get isSubUserUpdateAdditionalInfo;
  @override
  bool get isSubUserUpdateTimeInfo;
  @override
  bool get isSubUserSeeFormsFiles;
  @override
  bool get isSubUserCanManageSubUser;
  @override
  bool get isSubUserSeeOrder;
  @override
  bool get isAccountPermissionShimmering;
  @override
  bool get isCanSeeInvoices;
  @override
  @JsonKey(ignore: true)
  _$$ProfileMenuStateImplCopyWith<_$ProfileMenuStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
