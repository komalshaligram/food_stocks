// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'categories_permission_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$CategoriesPermissionEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateCategoriesPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateCategoriesPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateCategoriesPermissionEvent value)
        updateCategoriesPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CategoriesPermissionEventCopyWith<CategoriesPermissionEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CategoriesPermissionEventCopyWith<$Res> {
  factory $CategoriesPermissionEventCopyWith(CategoriesPermissionEvent value,
          $Res Function(CategoriesPermissionEvent) then) =
      _$CategoriesPermissionEventCopyWithImpl<$Res, CategoriesPermissionEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$CategoriesPermissionEventCopyWithImpl<$Res,
        $Val extends CategoriesPermissionEvent>
    implements $CategoriesPermissionEventCopyWith<$Res> {
  _$CategoriesPermissionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$switchButtonEventImplCopyWith<$Res>
    implements $CategoriesPermissionEventCopyWith<$Res> {
  factory _$$switchButtonEventImplCopyWith(_$switchButtonEventImpl value,
          $Res Function(_$switchButtonEventImpl) then) =
      __$$switchButtonEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {BuildContext context, int categoriesIndex, int subCategoriesIndex});
}

/// @nodoc
class __$$switchButtonEventImplCopyWithImpl<$Res>
    extends _$CategoriesPermissionEventCopyWithImpl<$Res,
        _$switchButtonEventImpl>
    implements _$$switchButtonEventImplCopyWith<$Res> {
  __$$switchButtonEventImplCopyWithImpl(_$switchButtonEventImpl _value,
      $Res Function(_$switchButtonEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? categoriesIndex = null,
    Object? subCategoriesIndex = null,
  }) {
    return _then(_$switchButtonEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      categoriesIndex: null == categoriesIndex
          ? _value.categoriesIndex
          : categoriesIndex // ignore: cast_nullable_to_non_nullable
              as int,
      subCategoriesIndex: null == subCategoriesIndex
          ? _value.subCategoriesIndex
          : subCategoriesIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$switchButtonEventImpl implements _switchButtonEvent {
  const _$switchButtonEventImpl(
      {required this.context,
      required this.categoriesIndex,
      required this.subCategoriesIndex});

  @override
  final BuildContext context;
  @override
  final int categoriesIndex;
  @override
  final int subCategoriesIndex;

  @override
  String toString() {
    return 'CategoriesPermissionEvent.switchButtonEvent(context: $context, categoriesIndex: $categoriesIndex, subCategoriesIndex: $subCategoriesIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$switchButtonEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.categoriesIndex, categoriesIndex) ||
                other.categoriesIndex == categoriesIndex) &&
            (identical(other.subCategoriesIndex, subCategoriesIndex) ||
                other.subCategoriesIndex == subCategoriesIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, categoriesIndex, subCategoriesIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$switchButtonEventImplCopyWith<_$switchButtonEventImpl> get copyWith =>
      __$$switchButtonEventImplCopyWithImpl<_$switchButtonEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateCategoriesPermissionEvent,
  }) {
    return switchButtonEvent(context, categoriesIndex, subCategoriesIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateCategoriesPermissionEvent,
  }) {
    return switchButtonEvent?.call(
        context, categoriesIndex, subCategoriesIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) {
    if (switchButtonEvent != null) {
      return switchButtonEvent(context, categoriesIndex, subCategoriesIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateCategoriesPermissionEvent value)
        updateCategoriesPermissionEvent,
  }) {
    return switchButtonEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
  }) {
    return switchButtonEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) {
    if (switchButtonEvent != null) {
      return switchButtonEvent(this);
    }
    return orElse();
  }
}

abstract class _switchButtonEvent implements CategoriesPermissionEvent {
  const factory _switchButtonEvent(
      {required final BuildContext context,
      required final int categoriesIndex,
      required final int subCategoriesIndex}) = _$switchButtonEventImpl;

  @override
  BuildContext get context;
  int get categoriesIndex;
  int get subCategoriesIndex;
  @override
  @JsonKey(ignore: true)
  _$$switchButtonEventImplCopyWith<_$switchButtonEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res>
    implements $CategoriesPermissionEventCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, String subUserId});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$CategoriesPermissionEventCopyWithImpl<$Res,
        _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? subUserId = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl(
      {required this.context, required this.subUserId});

  @override
  final BuildContext context;
  @override
  final String subUserId;

  @override
  String toString() {
    return 'CategoriesPermissionEvent.getPermissionList(context: $context, subUserId: $subUserId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, subUserId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateCategoriesPermissionEvent,
  }) {
    return getPermissionList(context, subUserId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateCategoriesPermissionEvent,
  }) {
    return getPermissionList?.call(context, subUserId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context, subUserId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateCategoriesPermissionEvent value)
        updateCategoriesPermissionEvent,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements CategoriesPermissionEvent {
  const factory _getPermissionList(
      {required final BuildContext context,
      required final String subUserId}) = _$getPermissionListImpl;

  @override
  BuildContext get context;
  String get subUserId;
  @override
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$updateCategoriesPermissionEventImplCopyWith<$Res>
    implements $CategoriesPermissionEventCopyWith<$Res> {
  factory _$$updateCategoriesPermissionEventImplCopyWith(
          _$updateCategoriesPermissionEventImpl value,
          $Res Function(_$updateCategoriesPermissionEventImpl) then) =
      __$$updateCategoriesPermissionEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$updateCategoriesPermissionEventImplCopyWithImpl<$Res>
    extends _$CategoriesPermissionEventCopyWithImpl<$Res,
        _$updateCategoriesPermissionEventImpl>
    implements _$$updateCategoriesPermissionEventImplCopyWith<$Res> {
  __$$updateCategoriesPermissionEventImplCopyWithImpl(
      _$updateCategoriesPermissionEventImpl _value,
      $Res Function(_$updateCategoriesPermissionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$updateCategoriesPermissionEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$updateCategoriesPermissionEventImpl
    implements _updateCategoriesPermissionEvent {
  const _$updateCategoriesPermissionEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'CategoriesPermissionEvent.updateCategoriesPermissionEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateCategoriesPermissionEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateCategoriesPermissionEventImplCopyWith<
          _$updateCategoriesPermissionEventImpl>
      get copyWith => __$$updateCategoriesPermissionEventImplCopyWithImpl<
          _$updateCategoriesPermissionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateCategoriesPermissionEvent,
  }) {
    return updateCategoriesPermissionEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateCategoriesPermissionEvent,
  }) {
    return updateCategoriesPermissionEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            BuildContext context, int categoriesIndex, int subCategoriesIndex)?
        switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) {
    if (updateCategoriesPermissionEvent != null) {
      return updateCategoriesPermissionEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateCategoriesPermissionEvent value)
        updateCategoriesPermissionEvent,
  }) {
    return updateCategoriesPermissionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
  }) {
    return updateCategoriesPermissionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateCategoriesPermissionEvent value)?
        updateCategoriesPermissionEvent,
    required TResult orElse(),
  }) {
    if (updateCategoriesPermissionEvent != null) {
      return updateCategoriesPermissionEvent(this);
    }
    return orElse();
  }
}

abstract class _updateCategoriesPermissionEvent
    implements CategoriesPermissionEvent {
  const factory _updateCategoriesPermissionEvent(
          {required final BuildContext context}) =
      _$updateCategoriesPermissionEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$updateCategoriesPermissionEventImplCopyWith<
          _$updateCategoriesPermissionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$CategoriesPermissionState {
  bool get isShimmering => throw _privateConstructorUsedError;
  List<categoriesPermission> get categoriesPermissionList =>
      throw _privateConstructorUsedError;
  bool get isRefresh => throw _privateConstructorUsedError;
  bool get isSelectAll => throw _privateConstructorUsedError;
  bool get isUpdateProcess => throw _privateConstructorUsedError;
  String get subUserId => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CategoriesPermissionStateCopyWith<CategoriesPermissionState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CategoriesPermissionStateCopyWith<$Res> {
  factory $CategoriesPermissionStateCopyWith(CategoriesPermissionState value,
          $Res Function(CategoriesPermissionState) then) =
      _$CategoriesPermissionStateCopyWithImpl<$Res, CategoriesPermissionState>;
  @useResult
  $Res call(
      {bool isShimmering,
      List<categoriesPermission> categoriesPermissionList,
      bool isRefresh,
      bool isSelectAll,
      bool isUpdateProcess,
      String subUserId});
}

/// @nodoc
class _$CategoriesPermissionStateCopyWithImpl<$Res,
        $Val extends CategoriesPermissionState>
    implements $CategoriesPermissionStateCopyWith<$Res> {
  _$CategoriesPermissionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? categoriesPermissionList = null,
    Object? isRefresh = null,
    Object? isSelectAll = null,
    Object? isUpdateProcess = null,
    Object? subUserId = null,
  }) {
    return _then(_value.copyWith(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      categoriesPermissionList: null == categoriesPermissionList
          ? _value.categoriesPermissionList
          : categoriesPermissionList // ignore: cast_nullable_to_non_nullable
              as List<categoriesPermission>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectAll: null == isSelectAll
          ? _value.isSelectAll
          : isSelectAll // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdateProcess: null == isUpdateProcess
          ? _value.isUpdateProcess
          : isUpdateProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CategoriesPermissionStateImplCopyWith<$Res>
    implements $CategoriesPermissionStateCopyWith<$Res> {
  factory _$$CategoriesPermissionStateImplCopyWith(
          _$CategoriesPermissionStateImpl value,
          $Res Function(_$CategoriesPermissionStateImpl) then) =
      __$$CategoriesPermissionStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isShimmering,
      List<categoriesPermission> categoriesPermissionList,
      bool isRefresh,
      bool isSelectAll,
      bool isUpdateProcess,
      String subUserId});
}

/// @nodoc
class __$$CategoriesPermissionStateImplCopyWithImpl<$Res>
    extends _$CategoriesPermissionStateCopyWithImpl<$Res,
        _$CategoriesPermissionStateImpl>
    implements _$$CategoriesPermissionStateImplCopyWith<$Res> {
  __$$CategoriesPermissionStateImplCopyWithImpl(
      _$CategoriesPermissionStateImpl _value,
      $Res Function(_$CategoriesPermissionStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? categoriesPermissionList = null,
    Object? isRefresh = null,
    Object? isSelectAll = null,
    Object? isUpdateProcess = null,
    Object? subUserId = null,
  }) {
    return _then(_$CategoriesPermissionStateImpl(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      categoriesPermissionList: null == categoriesPermissionList
          ? _value._categoriesPermissionList
          : categoriesPermissionList // ignore: cast_nullable_to_non_nullable
              as List<categoriesPermission>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectAll: null == isSelectAll
          ? _value.isSelectAll
          : isSelectAll // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdateProcess: null == isUpdateProcess
          ? _value.isUpdateProcess
          : isUpdateProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$CategoriesPermissionStateImpl implements _CategoriesPermissionState {
  const _$CategoriesPermissionStateImpl(
      {required this.isShimmering,
      required final List<categoriesPermission> categoriesPermissionList,
      required this.isRefresh,
      required this.isSelectAll,
      required this.isUpdateProcess,
      required this.subUserId})
      : _categoriesPermissionList = categoriesPermissionList;

  @override
  final bool isShimmering;
  final List<categoriesPermission> _categoriesPermissionList;
  @override
  List<categoriesPermission> get categoriesPermissionList {
    if (_categoriesPermissionList is EqualUnmodifiableListView)
      return _categoriesPermissionList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_categoriesPermissionList);
  }

  @override
  final bool isRefresh;
  @override
  final bool isSelectAll;
  @override
  final bool isUpdateProcess;
  @override
  final String subUserId;

  @override
  String toString() {
    return 'CategoriesPermissionState(isShimmering: $isShimmering, categoriesPermissionList: $categoriesPermissionList, isRefresh: $isRefresh, isSelectAll: $isSelectAll, isUpdateProcess: $isUpdateProcess, subUserId: $subUserId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CategoriesPermissionStateImpl &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            const DeepCollectionEquality().equals(
                other._categoriesPermissionList, _categoriesPermissionList) &&
            (identical(other.isRefresh, isRefresh) ||
                other.isRefresh == isRefresh) &&
            (identical(other.isSelectAll, isSelectAll) ||
                other.isSelectAll == isSelectAll) &&
            (identical(other.isUpdateProcess, isUpdateProcess) ||
                other.isUpdateProcess == isUpdateProcess) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isShimmering,
      const DeepCollectionEquality().hash(_categoriesPermissionList),
      isRefresh,
      isSelectAll,
      isUpdateProcess,
      subUserId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CategoriesPermissionStateImplCopyWith<_$CategoriesPermissionStateImpl>
      get copyWith => __$$CategoriesPermissionStateImplCopyWithImpl<
          _$CategoriesPermissionStateImpl>(this, _$identity);
}

abstract class _CategoriesPermissionState implements CategoriesPermissionState {
  const factory _CategoriesPermissionState(
      {required final bool isShimmering,
      required final List<categoriesPermission> categoriesPermissionList,
      required final bool isRefresh,
      required final bool isSelectAll,
      required final bool isUpdateProcess,
      required final String subUserId}) = _$CategoriesPermissionStateImpl;

  @override
  bool get isShimmering;
  @override
  List<categoriesPermission> get categoriesPermissionList;
  @override
  bool get isRefresh;
  @override
  bool get isSelectAll;
  @override
  bool get isUpdateProcess;
  @override
  String get subUserId;
  @override
  @JsonKey(ignore: true)
  _$$CategoriesPermissionStateImplCopyWith<_$CategoriesPermissionStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
