// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'planogram_product_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$PlanogramProductEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramProductEventCopyWith<$Res> {
  factory $PlanogramProductEventCopyWith(PlanogramProductEvent value,
          $Res Function(PlanogramProductEvent) then) =
      _$PlanogramProductEventCopyWithImpl<$Res, PlanogramProductEvent>;
}

/// @nodoc
class _$PlanogramProductEventCopyWithImpl<$Res,
        $Val extends PlanogramProductEvent>
    implements $PlanogramProductEventCopyWith<$Res> {
  _$PlanogramProductEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetPlanogramProductsEventImplCopyWith<$Res> {
  factory _$$GetPlanogramProductsEventImplCopyWith(
          _$GetPlanogramProductsEventImpl value,
          $Res Function(_$GetPlanogramProductsEventImpl) then) =
      __$$GetPlanogramProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({PlanogramDatum planogram, BuildContext context});

  $PlanogramDatumCopyWith<$Res> get planogram;
}

/// @nodoc
class __$$GetPlanogramProductsEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$GetPlanogramProductsEventImpl>
    implements _$$GetPlanogramProductsEventImplCopyWith<$Res> {
  __$$GetPlanogramProductsEventImplCopyWithImpl(
      _$GetPlanogramProductsEventImpl _value,
      $Res Function(_$GetPlanogramProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? planogram = null,
    Object? context = null,
  }) {
    return _then(_$GetPlanogramProductsEventImpl(
      planogram: null == planogram
          ? _value.planogram
          : planogram // ignore: cast_nullable_to_non_nullable
              as PlanogramDatum,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $PlanogramDatumCopyWith<$Res> get planogram {
    return $PlanogramDatumCopyWith<$Res>(_value.planogram, (value) {
      return _then(_value.copyWith(planogram: value));
    });
  }
}

/// @nodoc

class _$GetPlanogramProductsEventImpl implements _GetPlanogramProductsEvent {
  const _$GetPlanogramProductsEventImpl(
      {required this.planogram, required this.context});

  @override
  final PlanogramDatum planogram;
  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.getPlanogramProductsEvent(planogram: $planogram, context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetPlanogramProductsEventImpl &&
            (identical(other.planogram, planogram) ||
                other.planogram == planogram) &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, planogram, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetPlanogramProductsEventImplCopyWith<_$GetPlanogramProductsEventImpl>
      get copyWith => __$$GetPlanogramProductsEventImplCopyWithImpl<
          _$GetPlanogramProductsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPlanogramProductsEvent(planogram, context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPlanogramProductsEvent?.call(planogram, context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramProductsEvent != null) {
      return getPlanogramProductsEvent(planogram, context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPlanogramProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPlanogramProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramProductsEvent != null) {
      return getPlanogramProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetPlanogramProductsEvent implements PlanogramProductEvent {
  const factory _GetPlanogramProductsEvent(
      {required final PlanogramDatum planogram,
      required final BuildContext context}) = _$GetPlanogramProductsEventImpl;

  PlanogramDatum get planogram;
  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetPlanogramProductsEventImplCopyWith<_$GetPlanogramProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductDetailsEventImplCopyWith<$Res> {
  factory _$$GetProductDetailsEventImplCopyWith(
          _$GetProductDetailsEventImpl value,
          $Res Function(_$GetProductDetailsEventImpl) then) =
      __$$GetProductDetailsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {BuildContext context,
      String productId,
      bool isBarcode,
      int productListIndex});
}

/// @nodoc
class __$$GetProductDetailsEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$GetProductDetailsEventImpl>
    implements _$$GetProductDetailsEventImplCopyWith<$Res> {
  __$$GetProductDetailsEventImplCopyWithImpl(
      _$GetProductDetailsEventImpl _value,
      $Res Function(_$GetProductDetailsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
    Object? isBarcode = null,
    Object? productListIndex = null,
  }) {
    return _then(_$GetProductDetailsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
      isBarcode: null == isBarcode
          ? _value.isBarcode
          : isBarcode // ignore: cast_nullable_to_non_nullable
              as bool,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$GetProductDetailsEventImpl implements _GetProductDetailsEvent {
  const _$GetProductDetailsEventImpl(
      {required this.context,
      required this.productId,
      required this.isBarcode,
      required this.productListIndex});

  @override
  final BuildContext context;
  @override
  final String productId;
  @override
  final bool isBarcode;
  @override
  final int productListIndex;

  @override
  String toString() {
    return 'PlanogramProductEvent.getProductDetailsEvent(context: $context, productId: $productId, isBarcode: $isBarcode, productListIndex: $productListIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductDetailsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId) &&
            (identical(other.isBarcode, isBarcode) ||
                other.isBarcode == isBarcode) &&
            (identical(other.productListIndex, productListIndex) ||
                other.productListIndex == productListIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, context, productId, isBarcode, productListIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => __$$GetProductDetailsEventImplCopyWithImpl<
          _$GetProductDetailsEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductDetailsEvent(
        context, productId, isBarcode, productListIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(
        context, productId, isBarcode, productListIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(
          context, productId, isBarcode, productListIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductDetailsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductDetailsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductDetailsEvent != null) {
      return getProductDetailsEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductDetailsEvent implements PlanogramProductEvent {
  const factory _GetProductDetailsEvent(
      {required final BuildContext context,
      required final String productId,
      required final bool isBarcode,
      required final int productListIndex}) = _$GetProductDetailsEventImpl;

  BuildContext get context;
  String get productId;
  bool get isBarcode;
  int get productListIndex;
  @JsonKey(ignore: true)
  _$$GetProductDetailsEventImplCopyWith<_$GetProductDetailsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$IncreaseQuantityOfProductImplCopyWith(
          _$IncreaseQuantityOfProductImpl value,
          $Res Function(_$IncreaseQuantityOfProductImpl) then) =
      __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$IncreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$IncreaseQuantityOfProductImpl>
    implements _$$IncreaseQuantityOfProductImplCopyWith<$Res> {
  __$$IncreaseQuantityOfProductImplCopyWithImpl(
      _$IncreaseQuantityOfProductImpl _value,
      $Res Function(_$IncreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$IncreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$IncreaseQuantityOfProductImpl implements _IncreaseQuantityOfProduct {
  const _$IncreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.increaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => __$$IncreaseQuantityOfProductImplCopyWithImpl<
          _$IncreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return increaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return increaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return increaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (increaseQuantityOfProduct != null) {
      return increaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _IncreaseQuantityOfProduct implements PlanogramProductEvent {
  const factory _IncreaseQuantityOfProduct(
      {required final BuildContext context}) = _$IncreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$IncreaseQuantityOfProductImplCopyWith<_$IncreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  factory _$$DecreaseQuantityOfProductImplCopyWith(
          _$DecreaseQuantityOfProductImpl value,
          $Res Function(_$DecreaseQuantityOfProductImpl) then) =
      __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$DecreaseQuantityOfProductImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$DecreaseQuantityOfProductImpl>
    implements _$$DecreaseQuantityOfProductImplCopyWith<$Res> {
  __$$DecreaseQuantityOfProductImplCopyWithImpl(
      _$DecreaseQuantityOfProductImpl _value,
      $Res Function(_$DecreaseQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$DecreaseQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$DecreaseQuantityOfProductImpl implements _DecreaseQuantityOfProduct {
  const _$DecreaseQuantityOfProductImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.decreaseQuantityOfProduct(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DecreaseQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => __$$DecreaseQuantityOfProductImplCopyWithImpl<
          _$DecreaseQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return decreaseQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return decreaseQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (decreaseQuantityOfProduct != null) {
      return decreaseQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _DecreaseQuantityOfProduct implements PlanogramProductEvent {
  const factory _DecreaseQuantityOfProduct(
      {required final BuildContext context}) = _$DecreaseQuantityOfProductImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$DecreaseQuantityOfProductImplCopyWith<_$DecreaseQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  factory _$$UpdateQuantityOfProductImplCopyWith(
          _$UpdateQuantityOfProductImpl value,
          $Res Function(_$UpdateQuantityOfProductImpl) then) =
      __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String quantity});
}

/// @nodoc
class __$$UpdateQuantityOfProductImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$UpdateQuantityOfProductImpl>
    implements _$$UpdateQuantityOfProductImplCopyWith<$Res> {
  __$$UpdateQuantityOfProductImplCopyWithImpl(
      _$UpdateQuantityOfProductImpl _value,
      $Res Function(_$UpdateQuantityOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? quantity = null,
  }) {
    return _then(_$UpdateQuantityOfProductImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UpdateQuantityOfProductImpl implements _UpdateQuantityOfProduct {
  const _$UpdateQuantityOfProductImpl(
      {required this.context, required this.quantity});

  @override
  final BuildContext context;
  @override
  final String quantity;

  @override
  String toString() {
    return 'PlanogramProductEvent.updateQuantityOfProduct(context: $context, quantity: $quantity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateQuantityOfProductImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, quantity);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => __$$UpdateQuantityOfProductImplCopyWithImpl<
          _$UpdateQuantityOfProductImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateQuantityOfProduct(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(context, quantity);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(context, quantity);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateQuantityOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateQuantityOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateQuantityOfProduct != null) {
      return updateQuantityOfProduct(this);
    }
    return orElse();
  }
}

abstract class _UpdateQuantityOfProduct implements PlanogramProductEvent {
  const factory _UpdateQuantityOfProduct(
      {required final BuildContext context,
      required final String quantity}) = _$UpdateQuantityOfProductImpl;

  BuildContext get context;
  String get quantity;
  @JsonKey(ignore: true)
  _$$UpdateQuantityOfProductImplCopyWith<_$UpdateQuantityOfProductImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeNoteOfProductImplCopyWith<$Res> {
  factory _$$ChangeNoteOfProductImplCopyWith(_$ChangeNoteOfProductImpl value,
          $Res Function(_$ChangeNoteOfProductImpl) then) =
      __$$ChangeNoteOfProductImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String newNote});
}

/// @nodoc
class __$$ChangeNoteOfProductImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$ChangeNoteOfProductImpl>
    implements _$$ChangeNoteOfProductImplCopyWith<$Res> {
  __$$ChangeNoteOfProductImplCopyWithImpl(_$ChangeNoteOfProductImpl _value,
      $Res Function(_$ChangeNoteOfProductImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newNote = null,
  }) {
    return _then(_$ChangeNoteOfProductImpl(
      newNote: null == newNote
          ? _value.newNote
          : newNote // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ChangeNoteOfProductImpl implements _ChangeNoteOfProduct {
  const _$ChangeNoteOfProductImpl({required this.newNote});

  @override
  final String newNote;

  @override
  String toString() {
    return 'PlanogramProductEvent.changeNoteOfProduct(newNote: $newNote)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeNoteOfProductImpl &&
            (identical(other.newNote, newNote) || other.newNote == newNote));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newNote);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      __$$ChangeNoteOfProductImplCopyWithImpl<_$ChangeNoteOfProductImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeNoteOfProduct(newNote);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(newNote);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(newNote);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeNoteOfProduct(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeNoteOfProduct?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeNoteOfProduct != null) {
      return changeNoteOfProduct(this);
    }
    return orElse();
  }
}

abstract class _ChangeNoteOfProduct implements PlanogramProductEvent {
  const factory _ChangeNoteOfProduct({required final String newNote}) =
      _$ChangeNoteOfProductImpl;

  String get newNote;
  @JsonKey(ignore: true)
  _$$ChangeNoteOfProductImplCopyWith<_$ChangeNoteOfProductImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  factory _$$ChangeSupplierSelectionExpansionEventImplCopyWith(
          _$ChangeSupplierSelectionExpansionEventImpl value,
          $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) then) =
      __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isSelectSupplier});
}

/// @nodoc
class __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$ChangeSupplierSelectionExpansionEventImpl>
    implements _$$ChangeSupplierSelectionExpansionEventImplCopyWith<$Res> {
  __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl(
      _$ChangeSupplierSelectionExpansionEventImpl _value,
      $Res Function(_$ChangeSupplierSelectionExpansionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSelectSupplier = freezed,
  }) {
    return _then(_$ChangeSupplierSelectionExpansionEventImpl(
      isSelectSupplier: freezed == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeSupplierSelectionExpansionEventImpl
    implements _ChangeSupplierSelectionExpansionEvent {
  const _$ChangeSupplierSelectionExpansionEventImpl({this.isSelectSupplier});

  @override
  final bool? isSelectSupplier;

  @override
  String toString() {
    return 'PlanogramProductEvent.changeSupplierSelectionExpansionEvent(isSelectSupplier: $isSelectSupplier)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeSupplierSelectionExpansionEventImpl &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSelectSupplier);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => __$$ChangeSupplierSelectionExpansionEventImplCopyWithImpl<
          _$ChangeSupplierSelectionExpansionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(isSelectSupplier);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(isSelectSupplier);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeSupplierSelectionExpansionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeSupplierSelectionExpansionEvent != null) {
      return changeSupplierSelectionExpansionEvent(this);
    }
    return orElse();
  }
}

abstract class _ChangeSupplierSelectionExpansionEvent
    implements PlanogramProductEvent {
  const factory _ChangeSupplierSelectionExpansionEvent(
          {final bool? isSelectSupplier}) =
      _$ChangeSupplierSelectionExpansionEventImpl;

  bool? get isSelectSupplier;
  @JsonKey(ignore: true)
  _$$ChangeSupplierSelectionExpansionEventImplCopyWith<
          _$ChangeSupplierSelectionExpansionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SupplierSelectionEventImplCopyWith<$Res> {
  factory _$$SupplierSelectionEventImplCopyWith(
          _$SupplierSelectionEventImpl value,
          $Res Function(_$SupplierSelectionEventImpl) then) =
      __$$SupplierSelectionEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int supplierIndex, BuildContext context, int supplierSaleIndex});
}

/// @nodoc
class __$$SupplierSelectionEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$SupplierSelectionEventImpl>
    implements _$$SupplierSelectionEventImplCopyWith<$Res> {
  __$$SupplierSelectionEventImplCopyWithImpl(
      _$SupplierSelectionEventImpl _value,
      $Res Function(_$SupplierSelectionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? supplierIndex = null,
    Object? context = null,
    Object? supplierSaleIndex = null,
  }) {
    return _then(_$SupplierSelectionEventImpl(
      supplierIndex: null == supplierIndex
          ? _value.supplierIndex
          : supplierIndex // ignore: cast_nullable_to_non_nullable
              as int,
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      supplierSaleIndex: null == supplierSaleIndex
          ? _value.supplierSaleIndex
          : supplierSaleIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SupplierSelectionEventImpl implements _SupplierSelectionEvent {
  const _$SupplierSelectionEventImpl(
      {required this.supplierIndex,
      required this.context,
      required this.supplierSaleIndex});

  @override
  final int supplierIndex;
  @override
  final BuildContext context;
  @override
  final int supplierSaleIndex;

  @override
  String toString() {
    return 'PlanogramProductEvent.supplierSelectionEvent(supplierIndex: $supplierIndex, context: $context, supplierSaleIndex: $supplierSaleIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierSelectionEventImpl &&
            (identical(other.supplierIndex, supplierIndex) ||
                other.supplierIndex == supplierIndex) &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.supplierSaleIndex, supplierSaleIndex) ||
                other.supplierSaleIndex == supplierSaleIndex));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, supplierIndex, context, supplierSaleIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => __$$SupplierSelectionEventImplCopyWithImpl<
          _$SupplierSelectionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(
        supplierIndex, context, supplierSaleIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(supplierIndex, context, supplierSaleIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return supplierSelectionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return supplierSelectionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (supplierSelectionEvent != null) {
      return supplierSelectionEvent(this);
    }
    return orElse();
  }
}

abstract class _SupplierSelectionEvent implements PlanogramProductEvent {
  const factory _SupplierSelectionEvent(
      {required final int supplierIndex,
      required final BuildContext context,
      required final int supplierSaleIndex}) = _$SupplierSelectionEventImpl;

  int get supplierIndex;
  BuildContext get context;
  int get supplierSaleIndex;
  @JsonKey(ignore: true)
  _$$SupplierSelectionEventImplCopyWith<_$SupplierSelectionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddToCartProductEventImplCopyWith<$Res> {
  factory _$$AddToCartProductEventImplCopyWith(
          _$AddToCartProductEventImpl value,
          $Res Function(_$AddToCartProductEventImpl) then) =
      __$$AddToCartProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$AddToCartProductEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$AddToCartProductEventImpl>
    implements _$$AddToCartProductEventImplCopyWith<$Res> {
  __$$AddToCartProductEventImplCopyWithImpl(_$AddToCartProductEventImpl _value,
      $Res Function(_$AddToCartProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$AddToCartProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$AddToCartProductEventImpl implements _AddToCartProductEvent {
  const _$AddToCartProductEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'PlanogramProductEvent.addToCartProductEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddToCartProductEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => __$$AddToCartProductEventImplCopyWithImpl<
          _$AddToCartProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return addToCartProductEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return addToCartProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return addToCartProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (addToCartProductEvent != null) {
      return addToCartProductEvent(this);
    }
    return orElse();
  }
}

abstract class _AddToCartProductEvent implements PlanogramProductEvent {
  const factory _AddToCartProductEvent(
      {required final BuildContext context,
      required final String productId}) = _$AddToCartProductEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$AddToCartProductEventImplCopyWith<_$AddToCartProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SetCartCountEventImplCopyWith<$Res> {
  factory _$$SetCartCountEventImplCopyWith(_$SetCartCountEventImpl value,
          $Res Function(_$SetCartCountEventImpl) then) =
      __$$SetCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SetCartCountEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$SetCartCountEventImpl>
    implements _$$SetCartCountEventImplCopyWith<$Res> {
  __$$SetCartCountEventImplCopyWithImpl(_$SetCartCountEventImpl _value,
      $Res Function(_$SetCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SetCartCountEventImpl implements _SetCartCountEvent {
  const _$SetCartCountEventImpl();

  @override
  String toString() {
    return 'PlanogramProductEvent.setCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SetCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return setCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return setCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return setCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return setCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (setCartCountEvent != null) {
      return setCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _SetCartCountEvent implements PlanogramProductEvent {
  const factory _SetCartCountEvent() = _$SetCartCountEventImpl;
}

/// @nodoc
abstract class _$$UpdateImageIndexEventImplCopyWith<$Res> {
  factory _$$UpdateImageIndexEventImplCopyWith(
          _$UpdateImageIndexEventImpl value,
          $Res Function(_$UpdateImageIndexEventImpl) then) =
      __$$UpdateImageIndexEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$UpdateImageIndexEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$UpdateImageIndexEventImpl>
    implements _$$UpdateImageIndexEventImplCopyWith<$Res> {
  __$$UpdateImageIndexEventImplCopyWithImpl(_$UpdateImageIndexEventImpl _value,
      $Res Function(_$UpdateImageIndexEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$UpdateImageIndexEventImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$UpdateImageIndexEventImpl implements _UpdateImageIndexEvent {
  const _$UpdateImageIndexEventImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'PlanogramProductEvent.updateImageIndexEvent(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateImageIndexEventImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => __$$UpdateImageIndexEventImplCopyWithImpl<
          _$UpdateImageIndexEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateImageIndexEvent(index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateImageIndexEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateImageIndexEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateImageIndexEvent != null) {
      return updateImageIndexEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateImageIndexEvent implements PlanogramProductEvent {
  const factory _UpdateImageIndexEvent({required final int index}) =
      _$UpdateImageIndexEventImpl;

  int get index;
  @JsonKey(ignore: true)
  _$$UpdateImageIndexEventImplCopyWith<_$UpdateImageIndexEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ToggleNoteEventImplCopyWith<$Res> {
  factory _$$ToggleNoteEventImplCopyWith(_$ToggleNoteEventImpl value,
          $Res Function(_$ToggleNoteEventImpl) then) =
      __$$ToggleNoteEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ToggleNoteEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$ToggleNoteEventImpl>
    implements _$$ToggleNoteEventImplCopyWith<$Res> {
  __$$ToggleNoteEventImplCopyWithImpl(
      _$ToggleNoteEventImpl _value, $Res Function(_$ToggleNoteEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ToggleNoteEventImpl implements _ToggleNoteEvent {
  const _$ToggleNoteEventImpl();

  @override
  String toString() {
    return 'PlanogramProductEvent.toggleNoteEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ToggleNoteEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return toggleNoteEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return toggleNoteEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return toggleNoteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return toggleNoteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (toggleNoteEvent != null) {
      return toggleNoteEvent(this);
    }
    return orElse();
  }
}

abstract class _ToggleNoteEvent implements PlanogramProductEvent {
  const factory _ToggleNoteEvent() = _$ToggleNoteEventImpl;
}

/// @nodoc
abstract class _$$isCategoryEventImplCopyWith<$Res> {
  factory _$$isCategoryEventImplCopyWith(_$isCategoryEventImpl value,
          $Res Function(_$isCategoryEventImpl) then) =
      __$$isCategoryEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool isSubCategory});
}

/// @nodoc
class __$$isCategoryEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$isCategoryEventImpl>
    implements _$$isCategoryEventImplCopyWith<$Res> {
  __$$isCategoryEventImplCopyWithImpl(
      _$isCategoryEventImpl _value, $Res Function(_$isCategoryEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isSubCategory = null,
  }) {
    return _then(_$isCategoryEventImpl(
      isSubCategory: null == isSubCategory
          ? _value.isSubCategory
          : isSubCategory // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$isCategoryEventImpl implements _isCategoryEvent {
  const _$isCategoryEventImpl({required this.isSubCategory});

  @override
  final bool isSubCategory;

  @override
  String toString() {
    return 'PlanogramProductEvent.isCategoryEvent(isSubCategory: $isSubCategory)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$isCategoryEventImpl &&
            (identical(other.isSubCategory, isSubCategory) ||
                other.isSubCategory == isSubCategory));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isSubCategory);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$isCategoryEventImplCopyWith<_$isCategoryEventImpl> get copyWith =>
      __$$isCategoryEventImplCopyWithImpl<_$isCategoryEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return isCategoryEvent(isSubCategory);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return isCategoryEvent?.call(isSubCategory);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (isCategoryEvent != null) {
      return isCategoryEvent(isSubCategory);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return isCategoryEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return isCategoryEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (isCategoryEvent != null) {
      return isCategoryEvent(this);
    }
    return orElse();
  }
}

abstract class _isCategoryEvent implements PlanogramProductEvent {
  const factory _isCategoryEvent({required final bool isSubCategory}) =
      _$isCategoryEventImpl;

  bool get isSubCategory;
  @JsonKey(ignore: true)
  _$$isCategoryEventImplCopyWith<_$isCategoryEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPlanogramByIdEventImplCopyWith<$Res> {
  factory _$$getPlanogramByIdEventImplCopyWith(
          _$getPlanogramByIdEventImpl value,
          $Res Function(_$getPlanogramByIdEventImpl) then) =
      __$$getPlanogramByIdEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPlanogramByIdEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$getPlanogramByIdEventImpl>
    implements _$$getPlanogramByIdEventImplCopyWith<$Res> {
  __$$getPlanogramByIdEventImplCopyWithImpl(_$getPlanogramByIdEventImpl _value,
      $Res Function(_$getPlanogramByIdEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPlanogramByIdEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPlanogramByIdEventImpl implements _getPlanogramByIdEvent {
  const _$getPlanogramByIdEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.getPlanogramByIdEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPlanogramByIdEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPlanogramByIdEventImplCopyWith<_$getPlanogramByIdEventImpl>
      get copyWith => __$$getPlanogramByIdEventImplCopyWithImpl<
          _$getPlanogramByIdEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPlanogramByIdEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPlanogramByIdEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramByIdEvent != null) {
      return getPlanogramByIdEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPlanogramByIdEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPlanogramByIdEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramByIdEvent != null) {
      return getPlanogramByIdEvent(this);
    }
    return orElse();
  }
}

abstract class _getPlanogramByIdEvent implements PlanogramProductEvent {
  const factory _getPlanogramByIdEvent({required final BuildContext context}) =
      _$getPlanogramByIdEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPlanogramByIdEventImplCopyWith<_$getPlanogramByIdEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPlanogramAllProductEventImplCopyWith<$Res> {
  factory _$$getPlanogramAllProductEventImplCopyWith(
          _$getPlanogramAllProductEventImpl value,
          $Res Function(_$getPlanogramAllProductEventImpl) then) =
      __$$getPlanogramAllProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPlanogramAllProductEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$getPlanogramAllProductEventImpl>
    implements _$$getPlanogramAllProductEventImplCopyWith<$Res> {
  __$$getPlanogramAllProductEventImplCopyWithImpl(
      _$getPlanogramAllProductEventImpl _value,
      $Res Function(_$getPlanogramAllProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPlanogramAllProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPlanogramAllProductEventImpl
    implements _getPlanogramAllProductEvent {
  const _$getPlanogramAllProductEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.getPlanogramAllProductEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPlanogramAllProductEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPlanogramAllProductEventImplCopyWith<_$getPlanogramAllProductEventImpl>
      get copyWith => __$$getPlanogramAllProductEventImplCopyWithImpl<
          _$getPlanogramAllProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPlanogramAllProductEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPlanogramAllProductEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramAllProductEvent != null) {
      return getPlanogramAllProductEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPlanogramAllProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPlanogramAllProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPlanogramAllProductEvent != null) {
      return getPlanogramAllProductEvent(this);
    }
    return orElse();
  }
}

abstract class _getPlanogramAllProductEvent implements PlanogramProductEvent {
  const factory _getPlanogramAllProductEvent(
          {required final BuildContext context}) =
      _$getPlanogramAllProductEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPlanogramAllProductEventImplCopyWith<_$getPlanogramAllProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getSubCategoryProductEventImplCopyWith<$Res> {
  factory _$$getSubCategoryProductEventImplCopyWith(
          _$getSubCategoryProductEventImpl value,
          $Res Function(_$getSubCategoryProductEventImpl) then) =
      __$$getSubCategoryProductEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getSubCategoryProductEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$getSubCategoryProductEventImpl>
    implements _$$getSubCategoryProductEventImplCopyWith<$Res> {
  __$$getSubCategoryProductEventImplCopyWithImpl(
      _$getSubCategoryProductEventImpl _value,
      $Res Function(_$getSubCategoryProductEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getSubCategoryProductEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getSubCategoryProductEventImpl implements _getSubCategoryProductEvent {
  const _$getSubCategoryProductEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.getSubCategoryProductEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getSubCategoryProductEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getSubCategoryProductEventImplCopyWith<_$getSubCategoryProductEventImpl>
      get copyWith => __$$getSubCategoryProductEventImplCopyWithImpl<
          _$getSubCategoryProductEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getSubCategoryProductEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getSubCategoryProductEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSubCategoryProductEvent != null) {
      return getSubCategoryProductEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getSubCategoryProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getSubCategoryProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getSubCategoryProductEvent != null) {
      return getSubCategoryProductEvent(this);
    }
    return orElse();
  }
}

abstract class _getSubCategoryProductEvent implements PlanogramProductEvent {
  const factory _getSubCategoryProductEvent(
      {required final BuildContext context}) = _$getSubCategoryProductEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getSubCategoryProductEventImplCopyWith<_$getSubCategoryProductEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getCartCountEventImplCopyWith<$Res> {
  factory _$$getCartCountEventImplCopyWith(_$getCartCountEventImpl value,
          $Res Function(_$getCartCountEventImpl) then) =
      __$$getCartCountEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getCartCountEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$getCartCountEventImpl>
    implements _$$getCartCountEventImplCopyWith<$Res> {
  __$$getCartCountEventImplCopyWithImpl(_$getCartCountEventImpl _value,
      $Res Function(_$getCartCountEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getCartCountEventImpl implements _getCartCountEvent {
  const _$getCartCountEventImpl();

  @override
  String toString() {
    return 'PlanogramProductEvent.getCartCountEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getCartCountEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getCartCountEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getCartCountEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getCartCountEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getCartCountEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getCartCountEvent != null) {
      return getCartCountEvent(this);
    }
    return orElse();
  }
}

abstract class _getCartCountEvent implements PlanogramProductEvent {
  const factory _getCartCountEvent() = _$getCartCountEventImpl;
}

/// @nodoc
abstract class _$$getGridListViewImplCopyWith<$Res> {
  factory _$$getGridListViewImplCopyWith(_$getGridListViewImpl value,
          $Res Function(_$getGridListViewImpl) then) =
      __$$getGridListViewImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getGridListViewImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$getGridListViewImpl>
    implements _$$getGridListViewImplCopyWith<$Res> {
  __$$getGridListViewImplCopyWithImpl(
      _$getGridListViewImpl _value, $Res Function(_$getGridListViewImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getGridListViewImpl implements _getGridListView {
  const _$getGridListViewImpl();

  @override
  String toString() {
    return 'PlanogramProductEvent.getGridListView()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getGridListViewImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getGridListView();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getGridListView?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getGridListView != null) {
      return getGridListView();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getGridListView(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getGridListView?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getGridListView != null) {
      return getGridListView(this);
    }
    return orElse();
  }
}

abstract class _getGridListView implements PlanogramProductEvent {
  const factory _getGridListView() = _$getGridListViewImpl;
}

/// @nodoc
abstract class _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  factory _$$ChangeCategoryExpansionImplCopyWith(
          _$ChangeCategoryExpansionImpl value,
          $Res Function(_$ChangeCategoryExpansionImpl) then) =
      __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool? isOpened});
}

/// @nodoc
class __$$ChangeCategoryExpansionImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$ChangeCategoryExpansionImpl>
    implements _$$ChangeCategoryExpansionImplCopyWith<$Res> {
  __$$ChangeCategoryExpansionImplCopyWithImpl(
      _$ChangeCategoryExpansionImpl _value,
      $Res Function(_$ChangeCategoryExpansionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isOpened = freezed,
  }) {
    return _then(_$ChangeCategoryExpansionImpl(
      isOpened: freezed == isOpened
          ? _value.isOpened
          : isOpened // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ChangeCategoryExpansionImpl implements _ChangeCategoryExpansion {
  const _$ChangeCategoryExpansionImpl({this.isOpened});

  @override
  final bool? isOpened;

  @override
  String toString() {
    return 'PlanogramProductEvent.changeCategoryExpansion(isOpened: $isOpened)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ChangeCategoryExpansionImpl &&
            (identical(other.isOpened, isOpened) ||
                other.isOpened == isOpened));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isOpened);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => __$$ChangeCategoryExpansionImplCopyWithImpl<
          _$ChangeCategoryExpansionImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return changeCategoryExpansion(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(isOpened);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(isOpened);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return changeCategoryExpansion(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return changeCategoryExpansion?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (changeCategoryExpansion != null) {
      return changeCategoryExpansion(this);
    }
    return orElse();
  }
}

abstract class _ChangeCategoryExpansion implements PlanogramProductEvent {
  const factory _ChangeCategoryExpansion({final bool? isOpened}) =
      _$ChangeCategoryExpansionImpl;

  bool? get isOpened;
  @JsonKey(ignore: true)
  _$$ChangeCategoryExpansionImplCopyWith<_$ChangeCategoryExpansionImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GlobalSearchEventImplCopyWith<$Res> {
  factory _$$GlobalSearchEventImplCopyWith(_$GlobalSearchEventImpl value,
          $Res Function(_$GlobalSearchEventImpl) then) =
      __$$GlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GlobalSearchEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$GlobalSearchEventImpl>
    implements _$$GlobalSearchEventImplCopyWith<$Res> {
  __$$GlobalSearchEventImplCopyWithImpl(_$GlobalSearchEventImpl _value,
      $Res Function(_$GlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GlobalSearchEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GlobalSearchEventImpl implements _GlobalSearchEvent {
  const _$GlobalSearchEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.globalSearchEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalSearchEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      __$$GlobalSearchEventImplCopyWithImpl<_$GlobalSearchEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return globalSearchEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return globalSearchEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return globalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return globalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (globalSearchEvent != null) {
      return globalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _GlobalSearchEvent implements PlanogramProductEvent {
  const factory _GlobalSearchEvent({required final BuildContext context}) =
      _$GlobalSearchEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GlobalSearchEventImplCopyWith<_$GlobalSearchEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  factory _$$UpdateGlobalSearchEventImplCopyWith(
          _$UpdateGlobalSearchEventImpl value,
          $Res Function(_$UpdateGlobalSearchEventImpl) then) =
      __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String search, List<SearchModel> searchList});
}

/// @nodoc
class __$$UpdateGlobalSearchEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$UpdateGlobalSearchEventImpl>
    implements _$$UpdateGlobalSearchEventImplCopyWith<$Res> {
  __$$UpdateGlobalSearchEventImplCopyWithImpl(
      _$UpdateGlobalSearchEventImpl _value,
      $Res Function(_$UpdateGlobalSearchEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? search = null,
    Object? searchList = null,
  }) {
    return _then(_$UpdateGlobalSearchEventImpl(
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
    ));
  }
}

/// @nodoc

class _$UpdateGlobalSearchEventImpl implements _UpdateGlobalSearchEvent {
  const _$UpdateGlobalSearchEventImpl(
      {required this.search, required final List<SearchModel> searchList})
      : _searchList = searchList;

  @override
  final String search;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  String toString() {
    return 'PlanogramProductEvent.updateGlobalSearchEvent(search: $search, searchList: $searchList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateGlobalSearchEventImpl &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, search, const DeepCollectionEquality().hash(_searchList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => __$$UpdateGlobalSearchEventImplCopyWithImpl<
          _$UpdateGlobalSearchEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return updateGlobalSearchEvent(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(search, searchList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(search, searchList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return updateGlobalSearchEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return updateGlobalSearchEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (updateGlobalSearchEvent != null) {
      return updateGlobalSearchEvent(this);
    }
    return orElse();
  }
}

abstract class _UpdateGlobalSearchEvent implements PlanogramProductEvent {
  const factory _UpdateGlobalSearchEvent(
          {required final String search,
          required final List<SearchModel> searchList}) =
      _$UpdateGlobalSearchEventImpl;

  String get search;
  List<SearchModel> get searchList;
  @JsonKey(ignore: true)
  _$$UpdateGlobalSearchEventImplCopyWith<_$UpdateGlobalSearchEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  factory _$$GetProductCategoriesListEventImplCopyWith(
          _$GetProductCategoriesListEventImpl value,
          $Res Function(_$GetProductCategoriesListEventImpl) then) =
      __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$GetProductCategoriesListEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$GetProductCategoriesListEventImpl>
    implements _$$GetProductCategoriesListEventImplCopyWith<$Res> {
  __$$GetProductCategoriesListEventImplCopyWithImpl(
      _$GetProductCategoriesListEventImpl _value,
      $Res Function(_$GetProductCategoriesListEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$GetProductCategoriesListEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$GetProductCategoriesListEventImpl
    implements _GetProductCategoriesListEvent {
  const _$GetProductCategoriesListEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.getProductCategoriesListEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetProductCategoriesListEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => __$$GetProductCategoriesListEventImplCopyWithImpl<
          _$GetProductCategoriesListEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getProductCategoriesListEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getProductCategoriesListEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getProductCategoriesListEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getProductCategoriesListEvent != null) {
      return getProductCategoriesListEvent(this);
    }
    return orElse();
  }
}

abstract class _GetProductCategoriesListEvent implements PlanogramProductEvent {
  const factory _GetProductCategoriesListEvent(
          {required final BuildContext context}) =
      _$GetProductCategoriesListEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$GetProductCategoriesListEventImplCopyWith<
          _$GetProductCategoriesListEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RelatedProductsEventImplCopyWith<$Res> {
  factory _$$RelatedProductsEventImplCopyWith(_$RelatedProductsEventImpl value,
          $Res Function(_$RelatedProductsEventImpl) then) =
      __$$RelatedProductsEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context, String productId});
}

/// @nodoc
class __$$RelatedProductsEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$RelatedProductsEventImpl>
    implements _$$RelatedProductsEventImplCopyWith<$Res> {
  __$$RelatedProductsEventImplCopyWithImpl(_$RelatedProductsEventImpl _value,
      $Res Function(_$RelatedProductsEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? productId = null,
  }) {
    return _then(_$RelatedProductsEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RelatedProductsEventImpl implements _RelatedProductsEvent {
  const _$RelatedProductsEventImpl(
      {required this.context, required this.productId});

  @override
  final BuildContext context;
  @override
  final String productId;

  @override
  String toString() {
    return 'PlanogramProductEvent.RelatedProductsEvent(context: $context, productId: $productId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RelatedProductsEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith =>
          __$$RelatedProductsEventImplCopyWithImpl<_$RelatedProductsEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RelatedProductsEvent(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(context, productId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(context, productId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RelatedProductsEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RelatedProductsEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RelatedProductsEvent != null) {
      return RelatedProductsEvent(this);
    }
    return orElse();
  }
}

abstract class _RelatedProductsEvent implements PlanogramProductEvent {
  const factory _RelatedProductsEvent(
      {required final BuildContext context,
      required final String productId}) = _$RelatedProductsEventImpl;

  BuildContext get context;
  String get productId;
  @JsonKey(ignore: true)
  _$$RelatedProductsEventImplCopyWith<_$RelatedProductsEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  factory _$$RemoveRelatedProductEventImplCopyWith(
          _$RemoveRelatedProductEventImpl value,
          $Res Function(_$RemoveRelatedProductEventImpl) then) =
      __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$RemoveRelatedProductEventImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res,
        _$RemoveRelatedProductEventImpl>
    implements _$$RemoveRelatedProductEventImplCopyWith<$Res> {
  __$$RemoveRelatedProductEventImplCopyWithImpl(
      _$RemoveRelatedProductEventImpl _value,
      $Res Function(_$RemoveRelatedProductEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$RemoveRelatedProductEventImpl implements _RemoveRelatedProductEvent {
  const _$RemoveRelatedProductEventImpl();

  @override
  String toString() {
    return 'PlanogramProductEvent.RemoveRelatedProductEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RemoveRelatedProductEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return RemoveRelatedProductEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return RemoveRelatedProductEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return RemoveRelatedProductEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (RemoveRelatedProductEvent != null) {
      return RemoveRelatedProductEvent(this);
    }
    return orElse();
  }
}

abstract class _RemoveRelatedProductEvent implements PlanogramProductEvent {
  const factory _RemoveRelatedProductEvent() = _$RemoveRelatedProductEventImpl;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$PlanogramProductEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'PlanogramProductEvent.getPermissionList(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(PlanogramDatum planogram, BuildContext context)
        getPlanogramProductsEvent,
    required TResult Function(BuildContext context, String productId,
            bool isBarcode, int productListIndex)
        getProductDetailsEvent,
    required TResult Function(BuildContext context) increaseQuantityOfProduct,
    required TResult Function(BuildContext context) decreaseQuantityOfProduct,
    required TResult Function(BuildContext context, String quantity)
        updateQuantityOfProduct,
    required TResult Function(String newNote) changeNoteOfProduct,
    required TResult Function(bool? isSelectSupplier)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)
        supplierSelectionEvent,
    required TResult Function(BuildContext context, String productId)
        addToCartProductEvent,
    required TResult Function() setCartCountEvent,
    required TResult Function(int index) updateImageIndexEvent,
    required TResult Function() toggleNoteEvent,
    required TResult Function(bool isSubCategory) isCategoryEvent,
    required TResult Function(BuildContext context) getPlanogramByIdEvent,
    required TResult Function(BuildContext context) getPlanogramAllProductEvent,
    required TResult Function(BuildContext context) getSubCategoryProductEvent,
    required TResult Function() getCartCountEvent,
    required TResult Function() getGridListView,
    required TResult Function(bool? isOpened) changeCategoryExpansion,
    required TResult Function(BuildContext context) globalSearchEvent,
    required TResult Function(String search, List<SearchModel> searchList)
        updateGlobalSearchEvent,
    required TResult Function(BuildContext context)
        getProductCategoriesListEvent,
    required TResult Function(BuildContext context, String productId)
        RelatedProductsEvent,
    required TResult Function() RemoveRelatedProductEvent,
    required TResult Function(BuildContext context) getPermissionList,
  }) {
    return getPermissionList(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult? Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult? Function(BuildContext context)? increaseQuantityOfProduct,
    TResult? Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult? Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult? Function(String newNote)? changeNoteOfProduct,
    TResult? Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult? Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult? Function()? setCartCountEvent,
    TResult? Function(int index)? updateImageIndexEvent,
    TResult? Function()? toggleNoteEvent,
    TResult? Function(bool isSubCategory)? isCategoryEvent,
    TResult? Function(BuildContext context)? getPlanogramByIdEvent,
    TResult? Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult? Function(BuildContext context)? getSubCategoryProductEvent,
    TResult? Function()? getCartCountEvent,
    TResult? Function()? getGridListView,
    TResult? Function(bool? isOpened)? changeCategoryExpansion,
    TResult? Function(BuildContext context)? globalSearchEvent,
    TResult? Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult? Function(BuildContext context)? getProductCategoriesListEvent,
    TResult? Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult? Function()? RemoveRelatedProductEvent,
    TResult? Function(BuildContext context)? getPermissionList,
  }) {
    return getPermissionList?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(PlanogramDatum planogram, BuildContext context)?
        getPlanogramProductsEvent,
    TResult Function(BuildContext context, String productId, bool isBarcode,
            int productListIndex)?
        getProductDetailsEvent,
    TResult Function(BuildContext context)? increaseQuantityOfProduct,
    TResult Function(BuildContext context)? decreaseQuantityOfProduct,
    TResult Function(BuildContext context, String quantity)?
        updateQuantityOfProduct,
    TResult Function(String newNote)? changeNoteOfProduct,
    TResult Function(bool? isSelectSupplier)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(
            int supplierIndex, BuildContext context, int supplierSaleIndex)?
        supplierSelectionEvent,
    TResult Function(BuildContext context, String productId)?
        addToCartProductEvent,
    TResult Function()? setCartCountEvent,
    TResult Function(int index)? updateImageIndexEvent,
    TResult Function()? toggleNoteEvent,
    TResult Function(bool isSubCategory)? isCategoryEvent,
    TResult Function(BuildContext context)? getPlanogramByIdEvent,
    TResult Function(BuildContext context)? getPlanogramAllProductEvent,
    TResult Function(BuildContext context)? getSubCategoryProductEvent,
    TResult Function()? getCartCountEvent,
    TResult Function()? getGridListView,
    TResult Function(bool? isOpened)? changeCategoryExpansion,
    TResult Function(BuildContext context)? globalSearchEvent,
    TResult Function(String search, List<SearchModel> searchList)?
        updateGlobalSearchEvent,
    TResult Function(BuildContext context)? getProductCategoriesListEvent,
    TResult Function(BuildContext context, String productId)?
        RelatedProductsEvent,
    TResult Function()? RemoveRelatedProductEvent,
    TResult Function(BuildContext context)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetPlanogramProductsEvent value)
        getPlanogramProductsEvent,
    required TResult Function(_GetProductDetailsEvent value)
        getProductDetailsEvent,
    required TResult Function(_IncreaseQuantityOfProduct value)
        increaseQuantityOfProduct,
    required TResult Function(_DecreaseQuantityOfProduct value)
        decreaseQuantityOfProduct,
    required TResult Function(_UpdateQuantityOfProduct value)
        updateQuantityOfProduct,
    required TResult Function(_ChangeNoteOfProduct value) changeNoteOfProduct,
    required TResult Function(_ChangeSupplierSelectionExpansionEvent value)
        changeSupplierSelectionExpansionEvent,
    required TResult Function(_SupplierSelectionEvent value)
        supplierSelectionEvent,
    required TResult Function(_AddToCartProductEvent value)
        addToCartProductEvent,
    required TResult Function(_SetCartCountEvent value) setCartCountEvent,
    required TResult Function(_UpdateImageIndexEvent value)
        updateImageIndexEvent,
    required TResult Function(_ToggleNoteEvent value) toggleNoteEvent,
    required TResult Function(_isCategoryEvent value) isCategoryEvent,
    required TResult Function(_getPlanogramByIdEvent value)
        getPlanogramByIdEvent,
    required TResult Function(_getPlanogramAllProductEvent value)
        getPlanogramAllProductEvent,
    required TResult Function(_getSubCategoryProductEvent value)
        getSubCategoryProductEvent,
    required TResult Function(_getCartCountEvent value) getCartCountEvent,
    required TResult Function(_getGridListView value) getGridListView,
    required TResult Function(_ChangeCategoryExpansion value)
        changeCategoryExpansion,
    required TResult Function(_GlobalSearchEvent value) globalSearchEvent,
    required TResult Function(_UpdateGlobalSearchEvent value)
        updateGlobalSearchEvent,
    required TResult Function(_GetProductCategoriesListEvent value)
        getProductCategoriesListEvent,
    required TResult Function(_RelatedProductsEvent value) RelatedProductsEvent,
    required TResult Function(_RemoveRelatedProductEvent value)
        RemoveRelatedProductEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult? Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult? Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult? Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult? Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult? Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult? Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult? Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult? Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult? Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult? Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult? Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult? Function(_isCategoryEvent value)? isCategoryEvent,
    TResult? Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult? Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult? Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult? Function(_getCartCountEvent value)? getCartCountEvent,
    TResult? Function(_getGridListView value)? getGridListView,
    TResult? Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult? Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult? Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult? Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult? Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult? Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetPlanogramProductsEvent value)?
        getPlanogramProductsEvent,
    TResult Function(_GetProductDetailsEvent value)? getProductDetailsEvent,
    TResult Function(_IncreaseQuantityOfProduct value)?
        increaseQuantityOfProduct,
    TResult Function(_DecreaseQuantityOfProduct value)?
        decreaseQuantityOfProduct,
    TResult Function(_UpdateQuantityOfProduct value)? updateQuantityOfProduct,
    TResult Function(_ChangeNoteOfProduct value)? changeNoteOfProduct,
    TResult Function(_ChangeSupplierSelectionExpansionEvent value)?
        changeSupplierSelectionExpansionEvent,
    TResult Function(_SupplierSelectionEvent value)? supplierSelectionEvent,
    TResult Function(_AddToCartProductEvent value)? addToCartProductEvent,
    TResult Function(_SetCartCountEvent value)? setCartCountEvent,
    TResult Function(_UpdateImageIndexEvent value)? updateImageIndexEvent,
    TResult Function(_ToggleNoteEvent value)? toggleNoteEvent,
    TResult Function(_isCategoryEvent value)? isCategoryEvent,
    TResult Function(_getPlanogramByIdEvent value)? getPlanogramByIdEvent,
    TResult Function(_getPlanogramAllProductEvent value)?
        getPlanogramAllProductEvent,
    TResult Function(_getSubCategoryProductEvent value)?
        getSubCategoryProductEvent,
    TResult Function(_getCartCountEvent value)? getCartCountEvent,
    TResult Function(_getGridListView value)? getGridListView,
    TResult Function(_ChangeCategoryExpansion value)? changeCategoryExpansion,
    TResult Function(_GlobalSearchEvent value)? globalSearchEvent,
    TResult Function(_UpdateGlobalSearchEvent value)? updateGlobalSearchEvent,
    TResult Function(_GetProductCategoriesListEvent value)?
        getProductCategoriesListEvent,
    TResult Function(_RelatedProductsEvent value)? RelatedProductsEvent,
    TResult Function(_RemoveRelatedProductEvent value)?
        RemoveRelatedProductEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements PlanogramProductEvent {
  const factory _getPermissionList({required final BuildContext context}) =
      _$getPermissionListImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$PlanogramProductState {
  String get planogramName => throw _privateConstructorUsedError;
  List<Planogramproduct> get planogramProductList =>
      throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isProductLoading => throw _privateConstructorUsedError;
  List<Product> get productDetails => throw _privateConstructorUsedError;
  List<List<ProductStockModel>> get productStockList =>
      throw _privateConstructorUsedError;
  int get productStockUpdateIndex => throw _privateConstructorUsedError;
  bool get isSelectSupplier => throw _privateConstructorUsedError;
  List<ProductSupplierModel> get productSupplierList =>
      throw _privateConstructorUsedError;
  bool get isCartCountChange => throw _privateConstructorUsedError;
  int get imageIndex => throw _privateConstructorUsedError;
  TextEditingController get noteController =>
      throw _privateConstructorUsedError;
  bool get duringCelebration => throw _privateConstructorUsedError;
  int get cartCount => throw _privateConstructorUsedError;
  bool get isCategoryExpand => throw _privateConstructorUsedError;
  bool get isSearching => throw _privateConstructorUsedError;
  TextEditingController get searchController =>
      throw _privateConstructorUsedError;
  List<SearchModel> get searchList => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  List<Category> get productCategoryList => throw _privateConstructorUsedError;
  bool get isCatVisible => throw _privateConstructorUsedError;
  bool get isGridView => throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  List<RelatedProductDatum> get relatedProductList =>
      throw _privateConstructorUsedError;
  bool get isRelatedShimmering => throw _privateConstructorUsedError;
  bool get isGuestUser => throw _privateConstructorUsedError;
  int get productListIndex => throw _privateConstructorUsedError;
  double get bottleDeposit => throw _privateConstructorUsedError;
  bool get isSubUserAddToBasket => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PlanogramProductStateCopyWith<PlanogramProductState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlanogramProductStateCopyWith<$Res> {
  factory $PlanogramProductStateCopyWith(PlanogramProductState value,
          $Res Function(PlanogramProductState) then) =
      _$PlanogramProductStateCopyWithImpl<$Res, PlanogramProductState>;
  @useResult
  $Res call(
      {String planogramName,
      List<Planogramproduct> planogramProductList,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      bool isCartCountChange,
      int imageIndex,
      TextEditingController noteController,
      bool duringCelebration,
      int cartCount,
      bool isCategoryExpand,
      bool isSearching,
      TextEditingController searchController,
      List<SearchModel> searchList,
      String search,
      List<Category> productCategoryList,
      bool isCatVisible,
      bool isGridView,
      bool isShimmering,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      bool isGuestUser,
      int productListIndex,
      double bottleDeposit,
      bool isSubUserAddToBasket});
}

/// @nodoc
class _$PlanogramProductStateCopyWithImpl<$Res,
        $Val extends PlanogramProductState>
    implements $PlanogramProductStateCopyWith<$Res> {
  _$PlanogramProductStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? planogramName = null,
    Object? planogramProductList = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? isCartCountChange = null,
    Object? imageIndex = null,
    Object? noteController = null,
    Object? duringCelebration = null,
    Object? cartCount = null,
    Object? isCategoryExpand = null,
    Object? isSearching = null,
    Object? searchController = null,
    Object? searchList = null,
    Object? search = null,
    Object? productCategoryList = null,
    Object? isCatVisible = null,
    Object? isGridView = null,
    Object? isShimmering = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? isGuestUser = null,
    Object? productListIndex = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
  }) {
    return _then(_value.copyWith(
      planogramName: null == planogramName
          ? _value.planogramName
          : planogramName // ignore: cast_nullable_to_non_nullable
              as String,
      planogramProductList: null == planogramProductList
          ? _value.planogramProductList
          : planogramProductList // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value.productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value.productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value.productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      searchList: null == searchList
          ? _value.searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productCategoryList: null == productCategoryList
          ? _value.productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value.relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PlanogramProductStateImplCopyWith<$Res>
    implements $PlanogramProductStateCopyWith<$Res> {
  factory _$$PlanogramProductStateImplCopyWith(
          _$PlanogramProductStateImpl value,
          $Res Function(_$PlanogramProductStateImpl) then) =
      __$$PlanogramProductStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String planogramName,
      List<Planogramproduct> planogramProductList,
      bool isLoading,
      bool isProductLoading,
      List<Product> productDetails,
      List<List<ProductStockModel>> productStockList,
      int productStockUpdateIndex,
      bool isSelectSupplier,
      List<ProductSupplierModel> productSupplierList,
      bool isCartCountChange,
      int imageIndex,
      TextEditingController noteController,
      bool duringCelebration,
      int cartCount,
      bool isCategoryExpand,
      bool isSearching,
      TextEditingController searchController,
      List<SearchModel> searchList,
      String search,
      List<Category> productCategoryList,
      bool isCatVisible,
      bool isGridView,
      bool isShimmering,
      List<RelatedProductDatum> relatedProductList,
      bool isRelatedShimmering,
      bool isGuestUser,
      int productListIndex,
      double bottleDeposit,
      bool isSubUserAddToBasket});
}

/// @nodoc
class __$$PlanogramProductStateImplCopyWithImpl<$Res>
    extends _$PlanogramProductStateCopyWithImpl<$Res,
        _$PlanogramProductStateImpl>
    implements _$$PlanogramProductStateImplCopyWith<$Res> {
  __$$PlanogramProductStateImplCopyWithImpl(_$PlanogramProductStateImpl _value,
      $Res Function(_$PlanogramProductStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? planogramName = null,
    Object? planogramProductList = null,
    Object? isLoading = null,
    Object? isProductLoading = null,
    Object? productDetails = null,
    Object? productStockList = null,
    Object? productStockUpdateIndex = null,
    Object? isSelectSupplier = null,
    Object? productSupplierList = null,
    Object? isCartCountChange = null,
    Object? imageIndex = null,
    Object? noteController = null,
    Object? duringCelebration = null,
    Object? cartCount = null,
    Object? isCategoryExpand = null,
    Object? isSearching = null,
    Object? searchController = null,
    Object? searchList = null,
    Object? search = null,
    Object? productCategoryList = null,
    Object? isCatVisible = null,
    Object? isGridView = null,
    Object? isShimmering = null,
    Object? relatedProductList = null,
    Object? isRelatedShimmering = null,
    Object? isGuestUser = null,
    Object? productListIndex = null,
    Object? bottleDeposit = null,
    Object? isSubUserAddToBasket = null,
  }) {
    return _then(_$PlanogramProductStateImpl(
      planogramName: null == planogramName
          ? _value.planogramName
          : planogramName // ignore: cast_nullable_to_non_nullable
              as String,
      planogramProductList: null == planogramProductList
          ? _value._planogramProductList
          : planogramProductList // ignore: cast_nullable_to_non_nullable
              as List<Planogramproduct>,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isProductLoading: null == isProductLoading
          ? _value.isProductLoading
          : isProductLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      productDetails: null == productDetails
          ? _value._productDetails
          : productDetails // ignore: cast_nullable_to_non_nullable
              as List<Product>,
      productStockList: null == productStockList
          ? _value._productStockList
          : productStockList // ignore: cast_nullable_to_non_nullable
              as List<List<ProductStockModel>>,
      productStockUpdateIndex: null == productStockUpdateIndex
          ? _value.productStockUpdateIndex
          : productStockUpdateIndex // ignore: cast_nullable_to_non_nullable
              as int,
      isSelectSupplier: null == isSelectSupplier
          ? _value.isSelectSupplier
          : isSelectSupplier // ignore: cast_nullable_to_non_nullable
              as bool,
      productSupplierList: null == productSupplierList
          ? _value._productSupplierList
          : productSupplierList // ignore: cast_nullable_to_non_nullable
              as List<ProductSupplierModel>,
      isCartCountChange: null == isCartCountChange
          ? _value.isCartCountChange
          : isCartCountChange // ignore: cast_nullable_to_non_nullable
              as bool,
      imageIndex: null == imageIndex
          ? _value.imageIndex
          : imageIndex // ignore: cast_nullable_to_non_nullable
              as int,
      noteController: null == noteController
          ? _value.noteController
          : noteController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      duringCelebration: null == duringCelebration
          ? _value.duringCelebration
          : duringCelebration // ignore: cast_nullable_to_non_nullable
              as bool,
      cartCount: null == cartCount
          ? _value.cartCount
          : cartCount // ignore: cast_nullable_to_non_nullable
              as int,
      isCategoryExpand: null == isCategoryExpand
          ? _value.isCategoryExpand
          : isCategoryExpand // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearching: null == isSearching
          ? _value.isSearching
          : isSearching // ignore: cast_nullable_to_non_nullable
              as bool,
      searchController: null == searchController
          ? _value.searchController
          : searchController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      searchList: null == searchList
          ? _value._searchList
          : searchList // ignore: cast_nullable_to_non_nullable
              as List<SearchModel>,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      productCategoryList: null == productCategoryList
          ? _value._productCategoryList
          : productCategoryList // ignore: cast_nullable_to_non_nullable
              as List<Category>,
      isCatVisible: null == isCatVisible
          ? _value.isCatVisible
          : isCatVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isGridView: null == isGridView
          ? _value.isGridView
          : isGridView // ignore: cast_nullable_to_non_nullable
              as bool,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      relatedProductList: null == relatedProductList
          ? _value._relatedProductList
          : relatedProductList // ignore: cast_nullable_to_non_nullable
              as List<RelatedProductDatum>,
      isRelatedShimmering: null == isRelatedShimmering
          ? _value.isRelatedShimmering
          : isRelatedShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isGuestUser: null == isGuestUser
          ? _value.isGuestUser
          : isGuestUser // ignore: cast_nullable_to_non_nullable
              as bool,
      productListIndex: null == productListIndex
          ? _value.productListIndex
          : productListIndex // ignore: cast_nullable_to_non_nullable
              as int,
      bottleDeposit: null == bottleDeposit
          ? _value.bottleDeposit
          : bottleDeposit // ignore: cast_nullable_to_non_nullable
              as double,
      isSubUserAddToBasket: null == isSubUserAddToBasket
          ? _value.isSubUserAddToBasket
          : isSubUserAddToBasket // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$PlanogramProductStateImpl implements _PlanogramProductState {
  const _$PlanogramProductStateImpl(
      {required this.planogramName,
      required final List<Planogramproduct> planogramProductList,
      required this.isLoading,
      required this.isProductLoading,
      required final List<Product> productDetails,
      required final List<List<ProductStockModel>> productStockList,
      required this.productStockUpdateIndex,
      required this.isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required this.isCartCountChange,
      required this.imageIndex,
      required this.noteController,
      required this.duringCelebration,
      required this.cartCount,
      required this.isCategoryExpand,
      required this.isSearching,
      required this.searchController,
      required final List<SearchModel> searchList,
      required this.search,
      required final List<Category> productCategoryList,
      required this.isCatVisible,
      required this.isGridView,
      required this.isShimmering,
      required final List<RelatedProductDatum> relatedProductList,
      required this.isRelatedShimmering,
      required this.isGuestUser,
      required this.productListIndex,
      required this.bottleDeposit,
      required this.isSubUserAddToBasket})
      : _planogramProductList = planogramProductList,
        _productDetails = productDetails,
        _productStockList = productStockList,
        _productSupplierList = productSupplierList,
        _searchList = searchList,
        _productCategoryList = productCategoryList,
        _relatedProductList = relatedProductList;

  @override
  final String planogramName;
  final List<Planogramproduct> _planogramProductList;
  @override
  List<Planogramproduct> get planogramProductList {
    if (_planogramProductList is EqualUnmodifiableListView)
      return _planogramProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_planogramProductList);
  }

  @override
  final bool isLoading;
  @override
  final bool isProductLoading;
  final List<Product> _productDetails;
  @override
  List<Product> get productDetails {
    if (_productDetails is EqualUnmodifiableListView) return _productDetails;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productDetails);
  }

  final List<List<ProductStockModel>> _productStockList;
  @override
  List<List<ProductStockModel>> get productStockList {
    if (_productStockList is EqualUnmodifiableListView)
      return _productStockList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productStockList);
  }

  @override
  final int productStockUpdateIndex;
  @override
  final bool isSelectSupplier;
  final List<ProductSupplierModel> _productSupplierList;
  @override
  List<ProductSupplierModel> get productSupplierList {
    if (_productSupplierList is EqualUnmodifiableListView)
      return _productSupplierList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productSupplierList);
  }

  @override
  final bool isCartCountChange;
  @override
  final int imageIndex;
  @override
  final TextEditingController noteController;
  @override
  final bool duringCelebration;
  @override
  final int cartCount;
  @override
  final bool isCategoryExpand;
  @override
  final bool isSearching;
  @override
  final TextEditingController searchController;
  final List<SearchModel> _searchList;
  @override
  List<SearchModel> get searchList {
    if (_searchList is EqualUnmodifiableListView) return _searchList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_searchList);
  }

  @override
  final String search;
  final List<Category> _productCategoryList;
  @override
  List<Category> get productCategoryList {
    if (_productCategoryList is EqualUnmodifiableListView)
      return _productCategoryList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_productCategoryList);
  }

  @override
  final bool isCatVisible;
  @override
  final bool isGridView;
  @override
  final bool isShimmering;
  final List<RelatedProductDatum> _relatedProductList;
  @override
  List<RelatedProductDatum> get relatedProductList {
    if (_relatedProductList is EqualUnmodifiableListView)
      return _relatedProductList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedProductList);
  }

  @override
  final bool isRelatedShimmering;
  @override
  final bool isGuestUser;
  @override
  final int productListIndex;
  @override
  final double bottleDeposit;
  @override
  final bool isSubUserAddToBasket;

  @override
  String toString() {
    return 'PlanogramProductState(planogramName: $planogramName, planogramProductList: $planogramProductList, isLoading: $isLoading, isProductLoading: $isProductLoading, productDetails: $productDetails, productStockList: $productStockList, productStockUpdateIndex: $productStockUpdateIndex, isSelectSupplier: $isSelectSupplier, productSupplierList: $productSupplierList, isCartCountChange: $isCartCountChange, imageIndex: $imageIndex, noteController: $noteController, duringCelebration: $duringCelebration, cartCount: $cartCount, isCategoryExpand: $isCategoryExpand, isSearching: $isSearching, searchController: $searchController, searchList: $searchList, search: $search, productCategoryList: $productCategoryList, isCatVisible: $isCatVisible, isGridView: $isGridView, isShimmering: $isShimmering, relatedProductList: $relatedProductList, isRelatedShimmering: $isRelatedShimmering, isGuestUser: $isGuestUser, productListIndex: $productListIndex, bottleDeposit: $bottleDeposit, isSubUserAddToBasket: $isSubUserAddToBasket)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlanogramProductStateImpl &&
            (identical(other.planogramName, planogramName) ||
                other.planogramName == planogramName) &&
            const DeepCollectionEquality()
                .equals(other._planogramProductList, _planogramProductList) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isProductLoading, isProductLoading) ||
                other.isProductLoading == isProductLoading) &&
            const DeepCollectionEquality()
                .equals(other._productDetails, _productDetails) &&
            const DeepCollectionEquality()
                .equals(other._productStockList, _productStockList) &&
            (identical(
                    other.productStockUpdateIndex, productStockUpdateIndex) ||
                other.productStockUpdateIndex == productStockUpdateIndex) &&
            (identical(other.isSelectSupplier, isSelectSupplier) ||
                other.isSelectSupplier == isSelectSupplier) &&
            const DeepCollectionEquality()
                .equals(other._productSupplierList, _productSupplierList) &&
            (identical(other.isCartCountChange, isCartCountChange) ||
                other.isCartCountChange == isCartCountChange) &&
            (identical(other.imageIndex, imageIndex) ||
                other.imageIndex == imageIndex) &&
            (identical(other.noteController, noteController) ||
                other.noteController == noteController) &&
            (identical(other.duringCelebration, duringCelebration) ||
                other.duringCelebration == duringCelebration) &&
            (identical(other.cartCount, cartCount) ||
                other.cartCount == cartCount) &&
            (identical(other.isCategoryExpand, isCategoryExpand) ||
                other.isCategoryExpand == isCategoryExpand) &&
            (identical(other.isSearching, isSearching) ||
                other.isSearching == isSearching) &&
            (identical(other.searchController, searchController) ||
                other.searchController == searchController) &&
            const DeepCollectionEquality()
                .equals(other._searchList, _searchList) &&
            (identical(other.search, search) || other.search == search) &&
            const DeepCollectionEquality()
                .equals(other._productCategoryList, _productCategoryList) &&
            (identical(other.isCatVisible, isCatVisible) ||
                other.isCatVisible == isCatVisible) &&
            (identical(other.isGridView, isGridView) ||
                other.isGridView == isGridView) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            const DeepCollectionEquality()
                .equals(other._relatedProductList, _relatedProductList) &&
            (identical(other.isRelatedShimmering, isRelatedShimmering) ||
                other.isRelatedShimmering == isRelatedShimmering) &&
            (identical(other.isGuestUser, isGuestUser) ||
                other.isGuestUser == isGuestUser) &&
            (identical(other.productListIndex, productListIndex) ||
                other.productListIndex == productListIndex) &&
            (identical(other.bottleDeposit, bottleDeposit) ||
                other.bottleDeposit == bottleDeposit) &&
            (identical(other.isSubUserAddToBasket, isSubUserAddToBasket) ||
                other.isSubUserAddToBasket == isSubUserAddToBasket));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        planogramName,
        const DeepCollectionEquality().hash(_planogramProductList),
        isLoading,
        isProductLoading,
        const DeepCollectionEquality().hash(_productDetails),
        const DeepCollectionEquality().hash(_productStockList),
        productStockUpdateIndex,
        isSelectSupplier,
        const DeepCollectionEquality().hash(_productSupplierList),
        isCartCountChange,
        imageIndex,
        noteController,
        duringCelebration,
        cartCount,
        isCategoryExpand,
        isSearching,
        searchController,
        const DeepCollectionEquality().hash(_searchList),
        search,
        const DeepCollectionEquality().hash(_productCategoryList),
        isCatVisible,
        isGridView,
        isShimmering,
        const DeepCollectionEquality().hash(_relatedProductList),
        isRelatedShimmering,
        isGuestUser,
        productListIndex,
        bottleDeposit,
        isSubUserAddToBasket
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PlanogramProductStateImplCopyWith<_$PlanogramProductStateImpl>
      get copyWith => __$$PlanogramProductStateImplCopyWithImpl<
          _$PlanogramProductStateImpl>(this, _$identity);
}

abstract class _PlanogramProductState implements PlanogramProductState {
  const factory _PlanogramProductState(
      {required final String planogramName,
      required final List<Planogramproduct> planogramProductList,
      required final bool isLoading,
      required final bool isProductLoading,
      required final List<Product> productDetails,
      required final List<List<ProductStockModel>> productStockList,
      required final int productStockUpdateIndex,
      required final bool isSelectSupplier,
      required final List<ProductSupplierModel> productSupplierList,
      required final bool isCartCountChange,
      required final int imageIndex,
      required final TextEditingController noteController,
      required final bool duringCelebration,
      required final int cartCount,
      required final bool isCategoryExpand,
      required final bool isSearching,
      required final TextEditingController searchController,
      required final List<SearchModel> searchList,
      required final String search,
      required final List<Category> productCategoryList,
      required final bool isCatVisible,
      required final bool isGridView,
      required final bool isShimmering,
      required final List<RelatedProductDatum> relatedProductList,
      required final bool isRelatedShimmering,
      required final bool isGuestUser,
      required final int productListIndex,
      required final double bottleDeposit,
      required final bool isSubUserAddToBasket}) = _$PlanogramProductStateImpl;

  @override
  String get planogramName;
  @override
  List<Planogramproduct> get planogramProductList;
  @override
  bool get isLoading;
  @override
  bool get isProductLoading;
  @override
  List<Product> get productDetails;
  @override
  List<List<ProductStockModel>> get productStockList;
  @override
  int get productStockUpdateIndex;
  @override
  bool get isSelectSupplier;
  @override
  List<ProductSupplierModel> get productSupplierList;
  @override
  bool get isCartCountChange;
  @override
  int get imageIndex;
  @override
  TextEditingController get noteController;
  @override
  bool get duringCelebration;
  @override
  int get cartCount;
  @override
  bool get isCategoryExpand;
  @override
  bool get isSearching;
  @override
  TextEditingController get searchController;
  @override
  List<SearchModel> get searchList;
  @override
  String get search;
  @override
  List<Category> get productCategoryList;
  @override
  bool get isCatVisible;
  @override
  bool get isGridView;
  @override
  bool get isShimmering;
  @override
  List<RelatedProductDatum> get relatedProductList;
  @override
  bool get isRelatedShimmering;
  @override
  bool get isGuestUser;
  @override
  int get productListIndex;
  @override
  double get bottleDeposit;
  @override
  bool get isSubUserAddToBasket;
  @override
  @JsonKey(ignore: true)
  _$$PlanogramProductStateImplCopyWith<_$PlanogramProductStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
