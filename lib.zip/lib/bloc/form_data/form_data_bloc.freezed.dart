// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'form_data_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$FormDataEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String agent) selectAgentEvent,
    required TResult Function(String business, bool haveMultiple)
        selectBusinessTypeEvent,
    required TResult Function(BuildContext context) getAgentEvent,
    required TResult Function(BuildContext context) getBusinessTypeEvent,
    required TResult Function(BuildContext context) navigateToNextScreenEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String agent)? selectAgentEvent,
    TResult? Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult? Function(BuildContext context)? getAgentEvent,
    TResult? Function(BuildContext context)? getBusinessTypeEvent,
    TResult? Function(BuildContext context)? navigateToNextScreenEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String agent)? selectAgentEvent,
    TResult Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult Function(BuildContext context)? getAgentEvent,
    TResult Function(BuildContext context)? getBusinessTypeEvent,
    TResult Function(BuildContext context)? navigateToNextScreenEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectAgentEvent value) selectAgentEvent,
    required TResult Function(_selectBusinessTypeEvent value)
        selectBusinessTypeEvent,
    required TResult Function(_getAgentEvent value) getAgentEvent,
    required TResult Function(_getBusinessTypeEvent value) getBusinessTypeEvent,
    required TResult Function(_navigateToNextScreenEvent value)
        navigateToNextScreenEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectAgentEvent value)? selectAgentEvent,
    TResult? Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult? Function(_getAgentEvent value)? getAgentEvent,
    TResult? Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult? Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectAgentEvent value)? selectAgentEvent,
    TResult Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult Function(_getAgentEvent value)? getAgentEvent,
    TResult Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FormDataEventCopyWith<$Res> {
  factory $FormDataEventCopyWith(
          FormDataEvent value, $Res Function(FormDataEvent) then) =
      _$FormDataEventCopyWithImpl<$Res, FormDataEvent>;
}

/// @nodoc
class _$FormDataEventCopyWithImpl<$Res, $Val extends FormDataEvent>
    implements $FormDataEventCopyWith<$Res> {
  _$FormDataEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$selectAgentEventImplCopyWith<$Res> {
  factory _$$selectAgentEventImplCopyWith(_$selectAgentEventImpl value,
          $Res Function(_$selectAgentEventImpl) then) =
      __$$selectAgentEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String agent});
}

/// @nodoc
class __$$selectAgentEventImplCopyWithImpl<$Res>
    extends _$FormDataEventCopyWithImpl<$Res, _$selectAgentEventImpl>
    implements _$$selectAgentEventImplCopyWith<$Res> {
  __$$selectAgentEventImplCopyWithImpl(_$selectAgentEventImpl _value,
      $Res Function(_$selectAgentEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? agent = null,
  }) {
    return _then(_$selectAgentEventImpl(
      agent: null == agent
          ? _value.agent
          : agent // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$selectAgentEventImpl implements _selectAgentEvent {
  _$selectAgentEventImpl({required this.agent});

  @override
  final String agent;

  @override
  String toString() {
    return 'FormDataEvent.selectAgentEvent(agent: $agent)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$selectAgentEventImpl &&
            (identical(other.agent, agent) || other.agent == agent));
  }

  @override
  int get hashCode => Object.hash(runtimeType, agent);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$selectAgentEventImplCopyWith<_$selectAgentEventImpl> get copyWith =>
      __$$selectAgentEventImplCopyWithImpl<_$selectAgentEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String agent) selectAgentEvent,
    required TResult Function(String business, bool haveMultiple)
        selectBusinessTypeEvent,
    required TResult Function(BuildContext context) getAgentEvent,
    required TResult Function(BuildContext context) getBusinessTypeEvent,
    required TResult Function(BuildContext context) navigateToNextScreenEvent,
  }) {
    return selectAgentEvent(agent);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String agent)? selectAgentEvent,
    TResult? Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult? Function(BuildContext context)? getAgentEvent,
    TResult? Function(BuildContext context)? getBusinessTypeEvent,
    TResult? Function(BuildContext context)? navigateToNextScreenEvent,
  }) {
    return selectAgentEvent?.call(agent);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String agent)? selectAgentEvent,
    TResult Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult Function(BuildContext context)? getAgentEvent,
    TResult Function(BuildContext context)? getBusinessTypeEvent,
    TResult Function(BuildContext context)? navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (selectAgentEvent != null) {
      return selectAgentEvent(agent);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectAgentEvent value) selectAgentEvent,
    required TResult Function(_selectBusinessTypeEvent value)
        selectBusinessTypeEvent,
    required TResult Function(_getAgentEvent value) getAgentEvent,
    required TResult Function(_getBusinessTypeEvent value) getBusinessTypeEvent,
    required TResult Function(_navigateToNextScreenEvent value)
        navigateToNextScreenEvent,
  }) {
    return selectAgentEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectAgentEvent value)? selectAgentEvent,
    TResult? Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult? Function(_getAgentEvent value)? getAgentEvent,
    TResult? Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult? Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
  }) {
    return selectAgentEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectAgentEvent value)? selectAgentEvent,
    TResult Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult Function(_getAgentEvent value)? getAgentEvent,
    TResult Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (selectAgentEvent != null) {
      return selectAgentEvent(this);
    }
    return orElse();
  }
}

abstract class _selectAgentEvent implements FormDataEvent {
  factory _selectAgentEvent({required final String agent}) =
      _$selectAgentEventImpl;

  String get agent;
  @JsonKey(ignore: true)
  _$$selectAgentEventImplCopyWith<_$selectAgentEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$selectBusinessTypeEventImplCopyWith<$Res> {
  factory _$$selectBusinessTypeEventImplCopyWith(
          _$selectBusinessTypeEventImpl value,
          $Res Function(_$selectBusinessTypeEventImpl) then) =
      __$$selectBusinessTypeEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String business, bool haveMultiple});
}

/// @nodoc
class __$$selectBusinessTypeEventImplCopyWithImpl<$Res>
    extends _$FormDataEventCopyWithImpl<$Res, _$selectBusinessTypeEventImpl>
    implements _$$selectBusinessTypeEventImplCopyWith<$Res> {
  __$$selectBusinessTypeEventImplCopyWithImpl(
      _$selectBusinessTypeEventImpl _value,
      $Res Function(_$selectBusinessTypeEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? business = null,
    Object? haveMultiple = null,
  }) {
    return _then(_$selectBusinessTypeEventImpl(
      business: null == business
          ? _value.business
          : business // ignore: cast_nullable_to_non_nullable
              as String,
      haveMultiple: null == haveMultiple
          ? _value.haveMultiple
          : haveMultiple // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$selectBusinessTypeEventImpl implements _selectBusinessTypeEvent {
  _$selectBusinessTypeEventImpl(
      {required this.business, required this.haveMultiple});

  @override
  final String business;
  @override
  final bool haveMultiple;

  @override
  String toString() {
    return 'FormDataEvent.selectBusinessTypeEvent(business: $business, haveMultiple: $haveMultiple)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$selectBusinessTypeEventImpl &&
            (identical(other.business, business) ||
                other.business == business) &&
            (identical(other.haveMultiple, haveMultiple) ||
                other.haveMultiple == haveMultiple));
  }

  @override
  int get hashCode => Object.hash(runtimeType, business, haveMultiple);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$selectBusinessTypeEventImplCopyWith<_$selectBusinessTypeEventImpl>
      get copyWith => __$$selectBusinessTypeEventImplCopyWithImpl<
          _$selectBusinessTypeEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String agent) selectAgentEvent,
    required TResult Function(String business, bool haveMultiple)
        selectBusinessTypeEvent,
    required TResult Function(BuildContext context) getAgentEvent,
    required TResult Function(BuildContext context) getBusinessTypeEvent,
    required TResult Function(BuildContext context) navigateToNextScreenEvent,
  }) {
    return selectBusinessTypeEvent(business, haveMultiple);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String agent)? selectAgentEvent,
    TResult? Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult? Function(BuildContext context)? getAgentEvent,
    TResult? Function(BuildContext context)? getBusinessTypeEvent,
    TResult? Function(BuildContext context)? navigateToNextScreenEvent,
  }) {
    return selectBusinessTypeEvent?.call(business, haveMultiple);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String agent)? selectAgentEvent,
    TResult Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult Function(BuildContext context)? getAgentEvent,
    TResult Function(BuildContext context)? getBusinessTypeEvent,
    TResult Function(BuildContext context)? navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (selectBusinessTypeEvent != null) {
      return selectBusinessTypeEvent(business, haveMultiple);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectAgentEvent value) selectAgentEvent,
    required TResult Function(_selectBusinessTypeEvent value)
        selectBusinessTypeEvent,
    required TResult Function(_getAgentEvent value) getAgentEvent,
    required TResult Function(_getBusinessTypeEvent value) getBusinessTypeEvent,
    required TResult Function(_navigateToNextScreenEvent value)
        navigateToNextScreenEvent,
  }) {
    return selectBusinessTypeEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectAgentEvent value)? selectAgentEvent,
    TResult? Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult? Function(_getAgentEvent value)? getAgentEvent,
    TResult? Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult? Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
  }) {
    return selectBusinessTypeEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectAgentEvent value)? selectAgentEvent,
    TResult Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult Function(_getAgentEvent value)? getAgentEvent,
    TResult Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (selectBusinessTypeEvent != null) {
      return selectBusinessTypeEvent(this);
    }
    return orElse();
  }
}

abstract class _selectBusinessTypeEvent implements FormDataEvent {
  factory _selectBusinessTypeEvent(
      {required final String business,
      required final bool haveMultiple}) = _$selectBusinessTypeEventImpl;

  String get business;
  bool get haveMultiple;
  @JsonKey(ignore: true)
  _$$selectBusinessTypeEventImplCopyWith<_$selectBusinessTypeEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getAgentEventImplCopyWith<$Res> {
  factory _$$getAgentEventImplCopyWith(
          _$getAgentEventImpl value, $Res Function(_$getAgentEventImpl) then) =
      __$$getAgentEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getAgentEventImplCopyWithImpl<$Res>
    extends _$FormDataEventCopyWithImpl<$Res, _$getAgentEventImpl>
    implements _$$getAgentEventImplCopyWith<$Res> {
  __$$getAgentEventImplCopyWithImpl(
      _$getAgentEventImpl _value, $Res Function(_$getAgentEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getAgentEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getAgentEventImpl implements _getAgentEvent {
  _$getAgentEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'FormDataEvent.getAgentEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getAgentEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getAgentEventImplCopyWith<_$getAgentEventImpl> get copyWith =>
      __$$getAgentEventImplCopyWithImpl<_$getAgentEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String agent) selectAgentEvent,
    required TResult Function(String business, bool haveMultiple)
        selectBusinessTypeEvent,
    required TResult Function(BuildContext context) getAgentEvent,
    required TResult Function(BuildContext context) getBusinessTypeEvent,
    required TResult Function(BuildContext context) navigateToNextScreenEvent,
  }) {
    return getAgentEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String agent)? selectAgentEvent,
    TResult? Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult? Function(BuildContext context)? getAgentEvent,
    TResult? Function(BuildContext context)? getBusinessTypeEvent,
    TResult? Function(BuildContext context)? navigateToNextScreenEvent,
  }) {
    return getAgentEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String agent)? selectAgentEvent,
    TResult Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult Function(BuildContext context)? getAgentEvent,
    TResult Function(BuildContext context)? getBusinessTypeEvent,
    TResult Function(BuildContext context)? navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (getAgentEvent != null) {
      return getAgentEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectAgentEvent value) selectAgentEvent,
    required TResult Function(_selectBusinessTypeEvent value)
        selectBusinessTypeEvent,
    required TResult Function(_getAgentEvent value) getAgentEvent,
    required TResult Function(_getBusinessTypeEvent value) getBusinessTypeEvent,
    required TResult Function(_navigateToNextScreenEvent value)
        navigateToNextScreenEvent,
  }) {
    return getAgentEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectAgentEvent value)? selectAgentEvent,
    TResult? Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult? Function(_getAgentEvent value)? getAgentEvent,
    TResult? Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult? Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
  }) {
    return getAgentEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectAgentEvent value)? selectAgentEvent,
    TResult Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult Function(_getAgentEvent value)? getAgentEvent,
    TResult Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (getAgentEvent != null) {
      return getAgentEvent(this);
    }
    return orElse();
  }
}

abstract class _getAgentEvent implements FormDataEvent {
  factory _getAgentEvent({required final BuildContext context}) =
      _$getAgentEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getAgentEventImplCopyWith<_$getAgentEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getBusinessTypeEventImplCopyWith<$Res> {
  factory _$$getBusinessTypeEventImplCopyWith(_$getBusinessTypeEventImpl value,
          $Res Function(_$getBusinessTypeEventImpl) then) =
      __$$getBusinessTypeEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$getBusinessTypeEventImplCopyWithImpl<$Res>
    extends _$FormDataEventCopyWithImpl<$Res, _$getBusinessTypeEventImpl>
    implements _$$getBusinessTypeEventImplCopyWith<$Res> {
  __$$getBusinessTypeEventImplCopyWithImpl(_$getBusinessTypeEventImpl _value,
      $Res Function(_$getBusinessTypeEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$getBusinessTypeEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$getBusinessTypeEventImpl implements _getBusinessTypeEvent {
  _$getBusinessTypeEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'FormDataEvent.getBusinessTypeEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getBusinessTypeEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getBusinessTypeEventImplCopyWith<_$getBusinessTypeEventImpl>
      get copyWith =>
          __$$getBusinessTypeEventImplCopyWithImpl<_$getBusinessTypeEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String agent) selectAgentEvent,
    required TResult Function(String business, bool haveMultiple)
        selectBusinessTypeEvent,
    required TResult Function(BuildContext context) getAgentEvent,
    required TResult Function(BuildContext context) getBusinessTypeEvent,
    required TResult Function(BuildContext context) navigateToNextScreenEvent,
  }) {
    return getBusinessTypeEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String agent)? selectAgentEvent,
    TResult? Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult? Function(BuildContext context)? getAgentEvent,
    TResult? Function(BuildContext context)? getBusinessTypeEvent,
    TResult? Function(BuildContext context)? navigateToNextScreenEvent,
  }) {
    return getBusinessTypeEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String agent)? selectAgentEvent,
    TResult Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult Function(BuildContext context)? getAgentEvent,
    TResult Function(BuildContext context)? getBusinessTypeEvent,
    TResult Function(BuildContext context)? navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (getBusinessTypeEvent != null) {
      return getBusinessTypeEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectAgentEvent value) selectAgentEvent,
    required TResult Function(_selectBusinessTypeEvent value)
        selectBusinessTypeEvent,
    required TResult Function(_getAgentEvent value) getAgentEvent,
    required TResult Function(_getBusinessTypeEvent value) getBusinessTypeEvent,
    required TResult Function(_navigateToNextScreenEvent value)
        navigateToNextScreenEvent,
  }) {
    return getBusinessTypeEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectAgentEvent value)? selectAgentEvent,
    TResult? Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult? Function(_getAgentEvent value)? getAgentEvent,
    TResult? Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult? Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
  }) {
    return getBusinessTypeEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectAgentEvent value)? selectAgentEvent,
    TResult Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult Function(_getAgentEvent value)? getAgentEvent,
    TResult Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (getBusinessTypeEvent != null) {
      return getBusinessTypeEvent(this);
    }
    return orElse();
  }
}

abstract class _getBusinessTypeEvent implements FormDataEvent {
  factory _getBusinessTypeEvent({required final BuildContext context}) =
      _$getBusinessTypeEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$getBusinessTypeEventImplCopyWith<_$getBusinessTypeEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$navigateToNextScreenEventImplCopyWith<$Res> {
  factory _$$navigateToNextScreenEventImplCopyWith(
          _$navigateToNextScreenEventImpl value,
          $Res Function(_$navigateToNextScreenEventImpl) then) =
      __$$navigateToNextScreenEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$navigateToNextScreenEventImplCopyWithImpl<$Res>
    extends _$FormDataEventCopyWithImpl<$Res, _$navigateToNextScreenEventImpl>
    implements _$$navigateToNextScreenEventImplCopyWith<$Res> {
  __$$navigateToNextScreenEventImplCopyWithImpl(
      _$navigateToNextScreenEventImpl _value,
      $Res Function(_$navigateToNextScreenEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$navigateToNextScreenEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$navigateToNextScreenEventImpl implements _navigateToNextScreenEvent {
  _$navigateToNextScreenEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'FormDataEvent.navigateToNextScreenEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$navigateToNextScreenEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$navigateToNextScreenEventImplCopyWith<_$navigateToNextScreenEventImpl>
      get copyWith => __$$navigateToNextScreenEventImplCopyWithImpl<
          _$navigateToNextScreenEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String agent) selectAgentEvent,
    required TResult Function(String business, bool haveMultiple)
        selectBusinessTypeEvent,
    required TResult Function(BuildContext context) getAgentEvent,
    required TResult Function(BuildContext context) getBusinessTypeEvent,
    required TResult Function(BuildContext context) navigateToNextScreenEvent,
  }) {
    return navigateToNextScreenEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String agent)? selectAgentEvent,
    TResult? Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult? Function(BuildContext context)? getAgentEvent,
    TResult? Function(BuildContext context)? getBusinessTypeEvent,
    TResult? Function(BuildContext context)? navigateToNextScreenEvent,
  }) {
    return navigateToNextScreenEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String agent)? selectAgentEvent,
    TResult Function(String business, bool haveMultiple)?
        selectBusinessTypeEvent,
    TResult Function(BuildContext context)? getAgentEvent,
    TResult Function(BuildContext context)? getBusinessTypeEvent,
    TResult Function(BuildContext context)? navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (navigateToNextScreenEvent != null) {
      return navigateToNextScreenEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_selectAgentEvent value) selectAgentEvent,
    required TResult Function(_selectBusinessTypeEvent value)
        selectBusinessTypeEvent,
    required TResult Function(_getAgentEvent value) getAgentEvent,
    required TResult Function(_getBusinessTypeEvent value) getBusinessTypeEvent,
    required TResult Function(_navigateToNextScreenEvent value)
        navigateToNextScreenEvent,
  }) {
    return navigateToNextScreenEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_selectAgentEvent value)? selectAgentEvent,
    TResult? Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult? Function(_getAgentEvent value)? getAgentEvent,
    TResult? Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult? Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
  }) {
    return navigateToNextScreenEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_selectAgentEvent value)? selectAgentEvent,
    TResult Function(_selectBusinessTypeEvent value)? selectBusinessTypeEvent,
    TResult Function(_getAgentEvent value)? getAgentEvent,
    TResult Function(_getBusinessTypeEvent value)? getBusinessTypeEvent,
    TResult Function(_navigateToNextScreenEvent value)?
        navigateToNextScreenEvent,
    required TResult orElse(),
  }) {
    if (navigateToNextScreenEvent != null) {
      return navigateToNextScreenEvent(this);
    }
    return orElse();
  }
}

abstract class _navigateToNextScreenEvent implements FormDataEvent {
  factory _navigateToNextScreenEvent({required final BuildContext context}) =
      _$navigateToNextScreenEventImpl;

  BuildContext get context;
  @JsonKey(ignore: true)
  _$$navigateToNextScreenEventImplCopyWith<_$navigateToNextScreenEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$FormDataState {
  List<Agent> get agentList => throw _privateConstructorUsedError;
  String get agent => throw _privateConstructorUsedError;
  List<BusinessType> get businessTypeList => throw _privateConstructorUsedError;
  String get business => throw _privateConstructorUsedError;
  TextEditingController get owner1NameController =>
      throw _privateConstructorUsedError;
  TextEditingController get owner2NameController =>
      throw _privateConstructorUsedError;
  TextEditingController get owner1israelIdController =>
      throw _privateConstructorUsedError;
  TextEditingController get owner2israelIdController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee1NameController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee2NameController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee1idController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee2idController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee1addressController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee2addressController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee1PhoneController =>
      throw _privateConstructorUsedError;
  TextEditingController get guarantee2PhoneController =>
      throw _privateConstructorUsedError;
  bool get isShimmering => throw _privateConstructorUsedError;
  bool get isAgentListShimmering => throw _privateConstructorUsedError;
  bool get haveMultiple => throw _privateConstructorUsedError;
  bool get isUpdate => throw _privateConstructorUsedError;
  String get language => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $FormDataStateCopyWith<FormDataState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $FormDataStateCopyWith<$Res> {
  factory $FormDataStateCopyWith(
          FormDataState value, $Res Function(FormDataState) then) =
      _$FormDataStateCopyWithImpl<$Res, FormDataState>;
  @useResult
  $Res call(
      {List<Agent> agentList,
      String agent,
      List<BusinessType> businessTypeList,
      String business,
      TextEditingController owner1NameController,
      TextEditingController owner2NameController,
      TextEditingController owner1israelIdController,
      TextEditingController owner2israelIdController,
      TextEditingController guarantee1NameController,
      TextEditingController guarantee2NameController,
      TextEditingController guarantee1idController,
      TextEditingController guarantee2idController,
      TextEditingController guarantee1addressController,
      TextEditingController guarantee2addressController,
      TextEditingController guarantee1PhoneController,
      TextEditingController guarantee2PhoneController,
      bool isShimmering,
      bool isAgentListShimmering,
      bool haveMultiple,
      bool isUpdate,
      String language});
}

/// @nodoc
class _$FormDataStateCopyWithImpl<$Res, $Val extends FormDataState>
    implements $FormDataStateCopyWith<$Res> {
  _$FormDataStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? agentList = null,
    Object? agent = null,
    Object? businessTypeList = null,
    Object? business = null,
    Object? owner1NameController = null,
    Object? owner2NameController = null,
    Object? owner1israelIdController = null,
    Object? owner2israelIdController = null,
    Object? guarantee1NameController = null,
    Object? guarantee2NameController = null,
    Object? guarantee1idController = null,
    Object? guarantee2idController = null,
    Object? guarantee1addressController = null,
    Object? guarantee2addressController = null,
    Object? guarantee1PhoneController = null,
    Object? guarantee2PhoneController = null,
    Object? isShimmering = null,
    Object? isAgentListShimmering = null,
    Object? haveMultiple = null,
    Object? isUpdate = null,
    Object? language = null,
  }) {
    return _then(_value.copyWith(
      agentList: null == agentList
          ? _value.agentList
          : agentList // ignore: cast_nullable_to_non_nullable
              as List<Agent>,
      agent: null == agent
          ? _value.agent
          : agent // ignore: cast_nullable_to_non_nullable
              as String,
      businessTypeList: null == businessTypeList
          ? _value.businessTypeList
          : businessTypeList // ignore: cast_nullable_to_non_nullable
              as List<BusinessType>,
      business: null == business
          ? _value.business
          : business // ignore: cast_nullable_to_non_nullable
              as String,
      owner1NameController: null == owner1NameController
          ? _value.owner1NameController
          : owner1NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      owner2NameController: null == owner2NameController
          ? _value.owner2NameController
          : owner2NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      owner1israelIdController: null == owner1israelIdController
          ? _value.owner1israelIdController
          : owner1israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      owner2israelIdController: null == owner2israelIdController
          ? _value.owner2israelIdController
          : owner2israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1NameController: null == guarantee1NameController
          ? _value.guarantee1NameController
          : guarantee1NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2NameController: null == guarantee2NameController
          ? _value.guarantee2NameController
          : guarantee2NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1idController: null == guarantee1idController
          ? _value.guarantee1idController
          : guarantee1idController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2idController: null == guarantee2idController
          ? _value.guarantee2idController
          : guarantee2idController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1addressController: null == guarantee1addressController
          ? _value.guarantee1addressController
          : guarantee1addressController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2addressController: null == guarantee2addressController
          ? _value.guarantee2addressController
          : guarantee2addressController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1PhoneController: null == guarantee1PhoneController
          ? _value.guarantee1PhoneController
          : guarantee1PhoneController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2PhoneController: null == guarantee2PhoneController
          ? _value.guarantee2PhoneController
          : guarantee2PhoneController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isAgentListShimmering: null == isAgentListShimmering
          ? _value.isAgentListShimmering
          : isAgentListShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      haveMultiple: null == haveMultiple
          ? _value.haveMultiple
          : haveMultiple // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$FormDataStateImplCopyWith<$Res>
    implements $FormDataStateCopyWith<$Res> {
  factory _$$FormDataStateImplCopyWith(
          _$FormDataStateImpl value, $Res Function(_$FormDataStateImpl) then) =
      __$$FormDataStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Agent> agentList,
      String agent,
      List<BusinessType> businessTypeList,
      String business,
      TextEditingController owner1NameController,
      TextEditingController owner2NameController,
      TextEditingController owner1israelIdController,
      TextEditingController owner2israelIdController,
      TextEditingController guarantee1NameController,
      TextEditingController guarantee2NameController,
      TextEditingController guarantee1idController,
      TextEditingController guarantee2idController,
      TextEditingController guarantee1addressController,
      TextEditingController guarantee2addressController,
      TextEditingController guarantee1PhoneController,
      TextEditingController guarantee2PhoneController,
      bool isShimmering,
      bool isAgentListShimmering,
      bool haveMultiple,
      bool isUpdate,
      String language});
}

/// @nodoc
class __$$FormDataStateImplCopyWithImpl<$Res>
    extends _$FormDataStateCopyWithImpl<$Res, _$FormDataStateImpl>
    implements _$$FormDataStateImplCopyWith<$Res> {
  __$$FormDataStateImplCopyWithImpl(
      _$FormDataStateImpl _value, $Res Function(_$FormDataStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? agentList = null,
    Object? agent = null,
    Object? businessTypeList = null,
    Object? business = null,
    Object? owner1NameController = null,
    Object? owner2NameController = null,
    Object? owner1israelIdController = null,
    Object? owner2israelIdController = null,
    Object? guarantee1NameController = null,
    Object? guarantee2NameController = null,
    Object? guarantee1idController = null,
    Object? guarantee2idController = null,
    Object? guarantee1addressController = null,
    Object? guarantee2addressController = null,
    Object? guarantee1PhoneController = null,
    Object? guarantee2PhoneController = null,
    Object? isShimmering = null,
    Object? isAgentListShimmering = null,
    Object? haveMultiple = null,
    Object? isUpdate = null,
    Object? language = null,
  }) {
    return _then(_$FormDataStateImpl(
      agentList: null == agentList
          ? _value._agentList
          : agentList // ignore: cast_nullable_to_non_nullable
              as List<Agent>,
      agent: null == agent
          ? _value.agent
          : agent // ignore: cast_nullable_to_non_nullable
              as String,
      businessTypeList: null == businessTypeList
          ? _value._businessTypeList
          : businessTypeList // ignore: cast_nullable_to_non_nullable
              as List<BusinessType>,
      business: null == business
          ? _value.business
          : business // ignore: cast_nullable_to_non_nullable
              as String,
      owner1NameController: null == owner1NameController
          ? _value.owner1NameController
          : owner1NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      owner2NameController: null == owner2NameController
          ? _value.owner2NameController
          : owner2NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      owner1israelIdController: null == owner1israelIdController
          ? _value.owner1israelIdController
          : owner1israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      owner2israelIdController: null == owner2israelIdController
          ? _value.owner2israelIdController
          : owner2israelIdController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1NameController: null == guarantee1NameController
          ? _value.guarantee1NameController
          : guarantee1NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2NameController: null == guarantee2NameController
          ? _value.guarantee2NameController
          : guarantee2NameController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1idController: null == guarantee1idController
          ? _value.guarantee1idController
          : guarantee1idController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2idController: null == guarantee2idController
          ? _value.guarantee2idController
          : guarantee2idController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1addressController: null == guarantee1addressController
          ? _value.guarantee1addressController
          : guarantee1addressController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2addressController: null == guarantee2addressController
          ? _value.guarantee2addressController
          : guarantee2addressController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee1PhoneController: null == guarantee1PhoneController
          ? _value.guarantee1PhoneController
          : guarantee1PhoneController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      guarantee2PhoneController: null == guarantee2PhoneController
          ? _value.guarantee2PhoneController
          : guarantee2PhoneController // ignore: cast_nullable_to_non_nullable
              as TextEditingController,
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      isAgentListShimmering: null == isAgentListShimmering
          ? _value.isAgentListShimmering
          : isAgentListShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      haveMultiple: null == haveMultiple
          ? _value.haveMultiple
          : haveMultiple // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdate: null == isUpdate
          ? _value.isUpdate
          : isUpdate // ignore: cast_nullable_to_non_nullable
              as bool,
      language: null == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$FormDataStateImpl implements _FormDataState {
  const _$FormDataStateImpl(
      {required final List<Agent> agentList,
      required this.agent,
      required final List<BusinessType> businessTypeList,
      required this.business,
      required this.owner1NameController,
      required this.owner2NameController,
      required this.owner1israelIdController,
      required this.owner2israelIdController,
      required this.guarantee1NameController,
      required this.guarantee2NameController,
      required this.guarantee1idController,
      required this.guarantee2idController,
      required this.guarantee1addressController,
      required this.guarantee2addressController,
      required this.guarantee1PhoneController,
      required this.guarantee2PhoneController,
      required this.isShimmering,
      required this.isAgentListShimmering,
      required this.haveMultiple,
      required this.isUpdate,
      required this.language})
      : _agentList = agentList,
        _businessTypeList = businessTypeList;

  final List<Agent> _agentList;
  @override
  List<Agent> get agentList {
    if (_agentList is EqualUnmodifiableListView) return _agentList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_agentList);
  }

  @override
  final String agent;
  final List<BusinessType> _businessTypeList;
  @override
  List<BusinessType> get businessTypeList {
    if (_businessTypeList is EqualUnmodifiableListView)
      return _businessTypeList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_businessTypeList);
  }

  @override
  final String business;
  @override
  final TextEditingController owner1NameController;
  @override
  final TextEditingController owner2NameController;
  @override
  final TextEditingController owner1israelIdController;
  @override
  final TextEditingController owner2israelIdController;
  @override
  final TextEditingController guarantee1NameController;
  @override
  final TextEditingController guarantee2NameController;
  @override
  final TextEditingController guarantee1idController;
  @override
  final TextEditingController guarantee2idController;
  @override
  final TextEditingController guarantee1addressController;
  @override
  final TextEditingController guarantee2addressController;
  @override
  final TextEditingController guarantee1PhoneController;
  @override
  final TextEditingController guarantee2PhoneController;
  @override
  final bool isShimmering;
  @override
  final bool isAgentListShimmering;
  @override
  final bool haveMultiple;
  @override
  final bool isUpdate;
  @override
  final String language;

  @override
  String toString() {
    return 'FormDataState(agentList: $agentList, agent: $agent, businessTypeList: $businessTypeList, business: $business, owner1NameController: $owner1NameController, owner2NameController: $owner2NameController, owner1israelIdController: $owner1israelIdController, owner2israelIdController: $owner2israelIdController, guarantee1NameController: $guarantee1NameController, guarantee2NameController: $guarantee2NameController, guarantee1idController: $guarantee1idController, guarantee2idController: $guarantee2idController, guarantee1addressController: $guarantee1addressController, guarantee2addressController: $guarantee2addressController, guarantee1PhoneController: $guarantee1PhoneController, guarantee2PhoneController: $guarantee2PhoneController, isShimmering: $isShimmering, isAgentListShimmering: $isAgentListShimmering, haveMultiple: $haveMultiple, isUpdate: $isUpdate, language: $language)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FormDataStateImpl &&
            const DeepCollectionEquality()
                .equals(other._agentList, _agentList) &&
            (identical(other.agent, agent) || other.agent == agent) &&
            const DeepCollectionEquality()
                .equals(other._businessTypeList, _businessTypeList) &&
            (identical(other.business, business) ||
                other.business == business) &&
            (identical(other.owner1NameController, owner1NameController) ||
                other.owner1NameController == owner1NameController) &&
            (identical(other.owner2NameController, owner2NameController) ||
                other.owner2NameController == owner2NameController) &&
            (identical(other.owner1israelIdController, owner1israelIdController) ||
                other.owner1israelIdController == owner1israelIdController) &&
            (identical(other.owner2israelIdController, owner2israelIdController) ||
                other.owner2israelIdController == owner2israelIdController) &&
            (identical(other.guarantee1NameController, guarantee1NameController) ||
                other.guarantee1NameController == guarantee1NameController) &&
            (identical(other.guarantee2NameController, guarantee2NameController) ||
                other.guarantee2NameController == guarantee2NameController) &&
            (identical(other.guarantee1idController, guarantee1idController) ||
                other.guarantee1idController == guarantee1idController) &&
            (identical(other.guarantee2idController, guarantee2idController) ||
                other.guarantee2idController == guarantee2idController) &&
            (identical(other.guarantee1addressController,
                    guarantee1addressController) ||
                other.guarantee1addressController ==
                    guarantee1addressController) &&
            (identical(other.guarantee2addressController,
                    guarantee2addressController) ||
                other.guarantee2addressController ==
                    guarantee2addressController) &&
            (identical(other.guarantee1PhoneController, guarantee1PhoneController) ||
                other.guarantee1PhoneController == guarantee1PhoneController) &&
            (identical(other.guarantee2PhoneController, guarantee2PhoneController) ||
                other.guarantee2PhoneController == guarantee2PhoneController) &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            (identical(other.isAgentListShimmering, isAgentListShimmering) ||
                other.isAgentListShimmering == isAgentListShimmering) &&
            (identical(other.haveMultiple, haveMultiple) ||
                other.haveMultiple == haveMultiple) &&
            (identical(other.isUpdate, isUpdate) ||
                other.isUpdate == isUpdate) &&
            (identical(other.language, language) || other.language == language));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        const DeepCollectionEquality().hash(_agentList),
        agent,
        const DeepCollectionEquality().hash(_businessTypeList),
        business,
        owner1NameController,
        owner2NameController,
        owner1israelIdController,
        owner2israelIdController,
        guarantee1NameController,
        guarantee2NameController,
        guarantee1idController,
        guarantee2idController,
        guarantee1addressController,
        guarantee2addressController,
        guarantee1PhoneController,
        guarantee2PhoneController,
        isShimmering,
        isAgentListShimmering,
        haveMultiple,
        isUpdate,
        language
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FormDataStateImplCopyWith<_$FormDataStateImpl> get copyWith =>
      __$$FormDataStateImplCopyWithImpl<_$FormDataStateImpl>(this, _$identity);
}

abstract class _FormDataState implements FormDataState {
  const factory _FormDataState(
      {required final List<Agent> agentList,
      required final String agent,
      required final List<BusinessType> businessTypeList,
      required final String business,
      required final TextEditingController owner1NameController,
      required final TextEditingController owner2NameController,
      required final TextEditingController owner1israelIdController,
      required final TextEditingController owner2israelIdController,
      required final TextEditingController guarantee1NameController,
      required final TextEditingController guarantee2NameController,
      required final TextEditingController guarantee1idController,
      required final TextEditingController guarantee2idController,
      required final TextEditingController guarantee1addressController,
      required final TextEditingController guarantee2addressController,
      required final TextEditingController guarantee1PhoneController,
      required final TextEditingController guarantee2PhoneController,
      required final bool isShimmering,
      required final bool isAgentListShimmering,
      required final bool haveMultiple,
      required final bool isUpdate,
      required final String language}) = _$FormDataStateImpl;

  @override
  List<Agent> get agentList;
  @override
  String get agent;
  @override
  List<BusinessType> get businessTypeList;
  @override
  String get business;
  @override
  TextEditingController get owner1NameController;
  @override
  TextEditingController get owner2NameController;
  @override
  TextEditingController get owner1israelIdController;
  @override
  TextEditingController get owner2israelIdController;
  @override
  TextEditingController get guarantee1NameController;
  @override
  TextEditingController get guarantee2NameController;
  @override
  TextEditingController get guarantee1idController;
  @override
  TextEditingController get guarantee2idController;
  @override
  TextEditingController get guarantee1addressController;
  @override
  TextEditingController get guarantee2addressController;
  @override
  TextEditingController get guarantee1PhoneController;
  @override
  TextEditingController get guarantee2PhoneController;
  @override
  bool get isShimmering;
  @override
  bool get isAgentListShimmering;
  @override
  bool get haveMultiple;
  @override
  bool get isUpdate;
  @override
  String get language;
  @override
  @JsonKey(ignore: true)
  _$$FormDataStateImplCopyWith<_$FormDataStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
