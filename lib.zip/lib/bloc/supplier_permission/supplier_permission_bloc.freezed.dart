// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'supplier_permission_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SupplierPermissionEvent {
  BuildContext get context => throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateSupplierPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateSupplierPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateSupplierPermissionEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateSupplierPermissionEvent value)
        updateSupplierPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SupplierPermissionEventCopyWith<SupplierPermissionEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierPermissionEventCopyWith<$Res> {
  factory $SupplierPermissionEventCopyWith(SupplierPermissionEvent value,
          $Res Function(SupplierPermissionEvent) then) =
      _$SupplierPermissionEventCopyWithImpl<$Res, SupplierPermissionEvent>;
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class _$SupplierPermissionEventCopyWithImpl<$Res,
        $Val extends SupplierPermissionEvent>
    implements $SupplierPermissionEventCopyWith<$Res> {
  _$SupplierPermissionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_value.copyWith(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$switchButtonEventImplCopyWith<$Res>
    implements $SupplierPermissionEventCopyWith<$Res> {
  factory _$$switchButtonEventImplCopyWith(_$switchButtonEventImpl value,
          $Res Function(_$switchButtonEventImpl) then) =
      __$$switchButtonEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, int index});
}

/// @nodoc
class __$$switchButtonEventImplCopyWithImpl<$Res>
    extends _$SupplierPermissionEventCopyWithImpl<$Res, _$switchButtonEventImpl>
    implements _$$switchButtonEventImplCopyWith<$Res> {
  __$$switchButtonEventImplCopyWithImpl(_$switchButtonEventImpl _value,
      $Res Function(_$switchButtonEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? index = null,
  }) {
    return _then(_$switchButtonEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$switchButtonEventImpl implements _switchButtonEvent {
  const _$switchButtonEventImpl({required this.context, required this.index});

  @override
  final BuildContext context;
  @override
  final int index;

  @override
  String toString() {
    return 'SupplierPermissionEvent.switchButtonEvent(context: $context, index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$switchButtonEventImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$switchButtonEventImplCopyWith<_$switchButtonEventImpl> get copyWith =>
      __$$switchButtonEventImplCopyWithImpl<_$switchButtonEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateSupplierPermissionEvent,
  }) {
    return switchButtonEvent(context, index);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateSupplierPermissionEvent,
  }) {
    return switchButtonEvent?.call(context, index);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateSupplierPermissionEvent,
    required TResult orElse(),
  }) {
    if (switchButtonEvent != null) {
      return switchButtonEvent(context, index);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateSupplierPermissionEvent value)
        updateSupplierPermissionEvent,
  }) {
    return switchButtonEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
  }) {
    return switchButtonEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
    required TResult orElse(),
  }) {
    if (switchButtonEvent != null) {
      return switchButtonEvent(this);
    }
    return orElse();
  }
}

abstract class _switchButtonEvent implements SupplierPermissionEvent {
  const factory _switchButtonEvent(
      {required final BuildContext context,
      required final int index}) = _$switchButtonEventImpl;

  @override
  BuildContext get context;
  int get index;
  @override
  @JsonKey(ignore: true)
  _$$switchButtonEventImplCopyWith<_$switchButtonEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$getPermissionListImplCopyWith<$Res>
    implements $SupplierPermissionEventCopyWith<$Res> {
  factory _$$getPermissionListImplCopyWith(_$getPermissionListImpl value,
          $Res Function(_$getPermissionListImpl) then) =
      __$$getPermissionListImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context, String subUserId});
}

/// @nodoc
class __$$getPermissionListImplCopyWithImpl<$Res>
    extends _$SupplierPermissionEventCopyWithImpl<$Res, _$getPermissionListImpl>
    implements _$$getPermissionListImplCopyWith<$Res> {
  __$$getPermissionListImplCopyWithImpl(_$getPermissionListImpl _value,
      $Res Function(_$getPermissionListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
    Object? subUserId = null,
  }) {
    return _then(_$getPermissionListImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getPermissionListImpl implements _getPermissionList {
  const _$getPermissionListImpl(
      {required this.context, required this.subUserId});

  @override
  final BuildContext context;
  @override
  final String subUserId;

  @override
  String toString() {
    return 'SupplierPermissionEvent.getPermissionList(context: $context, subUserId: $subUserId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getPermissionListImpl &&
            (identical(other.context, context) || other.context == context) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context, subUserId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      __$$getPermissionListImplCopyWithImpl<_$getPermissionListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateSupplierPermissionEvent,
  }) {
    return getPermissionList(context, subUserId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateSupplierPermissionEvent,
  }) {
    return getPermissionList?.call(context, subUserId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateSupplierPermissionEvent,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(context, subUserId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateSupplierPermissionEvent value)
        updateSupplierPermissionEvent,
  }) {
    return getPermissionList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
  }) {
    return getPermissionList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
    required TResult orElse(),
  }) {
    if (getPermissionList != null) {
      return getPermissionList(this);
    }
    return orElse();
  }
}

abstract class _getPermissionList implements SupplierPermissionEvent {
  const factory _getPermissionList(
      {required final BuildContext context,
      required final String subUserId}) = _$getPermissionListImpl;

  @override
  BuildContext get context;
  String get subUserId;
  @override
  @JsonKey(ignore: true)
  _$$getPermissionListImplCopyWith<_$getPermissionListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$updateSupplierPermissionEventImplCopyWith<$Res>
    implements $SupplierPermissionEventCopyWith<$Res> {
  factory _$$updateSupplierPermissionEventImplCopyWith(
          _$updateSupplierPermissionEventImpl value,
          $Res Function(_$updateSupplierPermissionEventImpl) then) =
      __$$updateSupplierPermissionEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({BuildContext context});
}

/// @nodoc
class __$$updateSupplierPermissionEventImplCopyWithImpl<$Res>
    extends _$SupplierPermissionEventCopyWithImpl<$Res,
        _$updateSupplierPermissionEventImpl>
    implements _$$updateSupplierPermissionEventImplCopyWith<$Res> {
  __$$updateSupplierPermissionEventImplCopyWithImpl(
      _$updateSupplierPermissionEventImpl _value,
      $Res Function(_$updateSupplierPermissionEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? context = null,
  }) {
    return _then(_$updateSupplierPermissionEventImpl(
      context: null == context
          ? _value.context
          : context // ignore: cast_nullable_to_non_nullable
              as BuildContext,
    ));
  }
}

/// @nodoc

class _$updateSupplierPermissionEventImpl
    implements _updateSupplierPermissionEvent {
  const _$updateSupplierPermissionEventImpl({required this.context});

  @override
  final BuildContext context;

  @override
  String toString() {
    return 'SupplierPermissionEvent.updateSupplierPermissionEvent(context: $context)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateSupplierPermissionEventImpl &&
            (identical(other.context, context) || other.context == context));
  }

  @override
  int get hashCode => Object.hash(runtimeType, context);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateSupplierPermissionEventImplCopyWith<
          _$updateSupplierPermissionEventImpl>
      get copyWith => __$$updateSupplierPermissionEventImplCopyWithImpl<
          _$updateSupplierPermissionEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(BuildContext context, int index)
        switchButtonEvent,
    required TResult Function(BuildContext context, String subUserId)
        getPermissionList,
    required TResult Function(BuildContext context)
        updateSupplierPermissionEvent,
  }) {
    return updateSupplierPermissionEvent(context);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(BuildContext context, int index)? switchButtonEvent,
    TResult? Function(BuildContext context, String subUserId)?
        getPermissionList,
    TResult? Function(BuildContext context)? updateSupplierPermissionEvent,
  }) {
    return updateSupplierPermissionEvent?.call(context);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(BuildContext context, int index)? switchButtonEvent,
    TResult Function(BuildContext context, String subUserId)? getPermissionList,
    TResult Function(BuildContext context)? updateSupplierPermissionEvent,
    required TResult orElse(),
  }) {
    if (updateSupplierPermissionEvent != null) {
      return updateSupplierPermissionEvent(context);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_switchButtonEvent value) switchButtonEvent,
    required TResult Function(_getPermissionList value) getPermissionList,
    required TResult Function(_updateSupplierPermissionEvent value)
        updateSupplierPermissionEvent,
  }) {
    return updateSupplierPermissionEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_switchButtonEvent value)? switchButtonEvent,
    TResult? Function(_getPermissionList value)? getPermissionList,
    TResult? Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
  }) {
    return updateSupplierPermissionEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_switchButtonEvent value)? switchButtonEvent,
    TResult Function(_getPermissionList value)? getPermissionList,
    TResult Function(_updateSupplierPermissionEvent value)?
        updateSupplierPermissionEvent,
    required TResult orElse(),
  }) {
    if (updateSupplierPermissionEvent != null) {
      return updateSupplierPermissionEvent(this);
    }
    return orElse();
  }
}

abstract class _updateSupplierPermissionEvent
    implements SupplierPermissionEvent {
  const factory _updateSupplierPermissionEvent(
          {required final BuildContext context}) =
      _$updateSupplierPermissionEventImpl;

  @override
  BuildContext get context;
  @override
  @JsonKey(ignore: true)
  _$$updateSupplierPermissionEventImplCopyWith<
          _$updateSupplierPermissionEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SupplierPermissionState {
  bool get isShimmering => throw _privateConstructorUsedError;
  List<permissionModel> get supplierPermissionList =>
      throw _privateConstructorUsedError;
  bool get isRefresh => throw _privateConstructorUsedError;
  bool get isSelectAll => throw _privateConstructorUsedError;
  bool get isUpdateProcess => throw _privateConstructorUsedError;
  String get subUserId => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SupplierPermissionStateCopyWith<SupplierPermissionState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierPermissionStateCopyWith<$Res> {
  factory $SupplierPermissionStateCopyWith(SupplierPermissionState value,
          $Res Function(SupplierPermissionState) then) =
      _$SupplierPermissionStateCopyWithImpl<$Res, SupplierPermissionState>;
  @useResult
  $Res call(
      {bool isShimmering,
      List<permissionModel> supplierPermissionList,
      bool isRefresh,
      bool isSelectAll,
      bool isUpdateProcess,
      String subUserId});
}

/// @nodoc
class _$SupplierPermissionStateCopyWithImpl<$Res,
        $Val extends SupplierPermissionState>
    implements $SupplierPermissionStateCopyWith<$Res> {
  _$SupplierPermissionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? supplierPermissionList = null,
    Object? isRefresh = null,
    Object? isSelectAll = null,
    Object? isUpdateProcess = null,
    Object? subUserId = null,
  }) {
    return _then(_value.copyWith(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      supplierPermissionList: null == supplierPermissionList
          ? _value.supplierPermissionList
          : supplierPermissionList // ignore: cast_nullable_to_non_nullable
              as List<permissionModel>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectAll: null == isSelectAll
          ? _value.isSelectAll
          : isSelectAll // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdateProcess: null == isUpdateProcess
          ? _value.isUpdateProcess
          : isUpdateProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SupplierPermissionStateImplCopyWith<$Res>
    implements $SupplierPermissionStateCopyWith<$Res> {
  factory _$$SupplierPermissionStateImplCopyWith(
          _$SupplierPermissionStateImpl value,
          $Res Function(_$SupplierPermissionStateImpl) then) =
      __$$SupplierPermissionStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isShimmering,
      List<permissionModel> supplierPermissionList,
      bool isRefresh,
      bool isSelectAll,
      bool isUpdateProcess,
      String subUserId});
}

/// @nodoc
class __$$SupplierPermissionStateImplCopyWithImpl<$Res>
    extends _$SupplierPermissionStateCopyWithImpl<$Res,
        _$SupplierPermissionStateImpl>
    implements _$$SupplierPermissionStateImplCopyWith<$Res> {
  __$$SupplierPermissionStateImplCopyWithImpl(
      _$SupplierPermissionStateImpl _value,
      $Res Function(_$SupplierPermissionStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isShimmering = null,
    Object? supplierPermissionList = null,
    Object? isRefresh = null,
    Object? isSelectAll = null,
    Object? isUpdateProcess = null,
    Object? subUserId = null,
  }) {
    return _then(_$SupplierPermissionStateImpl(
      isShimmering: null == isShimmering
          ? _value.isShimmering
          : isShimmering // ignore: cast_nullable_to_non_nullable
              as bool,
      supplierPermissionList: null == supplierPermissionList
          ? _value._supplierPermissionList
          : supplierPermissionList // ignore: cast_nullable_to_non_nullable
              as List<permissionModel>,
      isRefresh: null == isRefresh
          ? _value.isRefresh
          : isRefresh // ignore: cast_nullable_to_non_nullable
              as bool,
      isSelectAll: null == isSelectAll
          ? _value.isSelectAll
          : isSelectAll // ignore: cast_nullable_to_non_nullable
              as bool,
      isUpdateProcess: null == isUpdateProcess
          ? _value.isUpdateProcess
          : isUpdateProcess // ignore: cast_nullable_to_non_nullable
              as bool,
      subUserId: null == subUserId
          ? _value.subUserId
          : subUserId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SupplierPermissionStateImpl implements _SupplierPermissionState {
  const _$SupplierPermissionStateImpl(
      {required this.isShimmering,
      required final List<permissionModel> supplierPermissionList,
      required this.isRefresh,
      required this.isSelectAll,
      required this.isUpdateProcess,
      required this.subUserId})
      : _supplierPermissionList = supplierPermissionList;

  @override
  final bool isShimmering;
  final List<permissionModel> _supplierPermissionList;
  @override
  List<permissionModel> get supplierPermissionList {
    if (_supplierPermissionList is EqualUnmodifiableListView)
      return _supplierPermissionList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_supplierPermissionList);
  }

  @override
  final bool isRefresh;
  @override
  final bool isSelectAll;
  @override
  final bool isUpdateProcess;
  @override
  final String subUserId;

  @override
  String toString() {
    return 'SupplierPermissionState(isShimmering: $isShimmering, supplierPermissionList: $supplierPermissionList, isRefresh: $isRefresh, isSelectAll: $isSelectAll, isUpdateProcess: $isUpdateProcess, subUserId: $subUserId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SupplierPermissionStateImpl &&
            (identical(other.isShimmering, isShimmering) ||
                other.isShimmering == isShimmering) &&
            const DeepCollectionEquality().equals(
                other._supplierPermissionList, _supplierPermissionList) &&
            (identical(other.isRefresh, isRefresh) ||
                other.isRefresh == isRefresh) &&
            (identical(other.isSelectAll, isSelectAll) ||
                other.isSelectAll == isSelectAll) &&
            (identical(other.isUpdateProcess, isUpdateProcess) ||
                other.isUpdateProcess == isUpdateProcess) &&
            (identical(other.subUserId, subUserId) ||
                other.subUserId == subUserId));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isShimmering,
      const DeepCollectionEquality().hash(_supplierPermissionList),
      isRefresh,
      isSelectAll,
      isUpdateProcess,
      subUserId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SupplierPermissionStateImplCopyWith<_$SupplierPermissionStateImpl>
      get copyWith => __$$SupplierPermissionStateImplCopyWithImpl<
          _$SupplierPermissionStateImpl>(this, _$identity);
}

abstract class _SupplierPermissionState implements SupplierPermissionState {
  const factory _SupplierPermissionState(
      {required final bool isShimmering,
      required final List<permissionModel> supplierPermissionList,
      required final bool isRefresh,
      required final bool isSelectAll,
      required final bool isUpdateProcess,
      required final String subUserId}) = _$SupplierPermissionStateImpl;

  @override
  bool get isShimmering;
  @override
  List<permissionModel> get supplierPermissionList;
  @override
  bool get isRefresh;
  @override
  bool get isSelectAll;
  @override
  bool get isUpdateProcess;
  @override
  String get subUserId;
  @override
  @JsonKey(ignore: true)
  _$$SupplierPermissionStateImplCopyWith<_$SupplierPermissionStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
