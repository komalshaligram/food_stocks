import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AppStrings {
  static const appName = 'Tavili';
  static const cropImageString = 'Crop Image';
  static const androidString = 'Android';
  static const iosString = 'IOS';
  static const timeString = '';
  static const hr24String = '24:00';
  static const tempString = 'temp';
  static const cancelString = 'Cancel';
  static const doneString = 'Done';
  static const failedToLoadString = 'Failed to load';
  static const outOfStockString = 'Out of Stock';
  static const clearString = 'Clear';
  static const deleteString = 'Delete';
  static const deliverString = 'deliver';
  static const onTheWayString = 'onTheWay';
  static const statusString = 'status';
  static const updateString = 'Updating';
  static const pendingString = 'pending';
  static const navigateToStore = 'true';
  static const orderStatusNo = 'orderStatusNo';
  static const subuserString = 'subuser';


  //language Strings
  static const englishString = 'en';
  static const hebrewString = 'he';
  static const englishLocal = 'en-US';
  static const hebrewLocal = 'he-IL';

  //api req param strings
  static const profileImageString = 'profileImg';
  static const profileUpdateString =  'profileImage';
  static const promissoryNoteString = 'promissoryNote';
  static const personalGuaranteeString = 'personalGuarantee';
  static const israelIdImageString = 'israelIdImage';
  static const businessCertificateString = 'businessCertificate';
  static const messageString = 'message';
  static const fileString = 'file';
  static const filesString = 'files';
  static const formString = 'form';
  static const formsString = 'forms';
  static const idParamString = '_id';
  static const clientDetailString = 'clientDetail';
  static const logoString = 'logo';
  static const supplierIdString = 'supplierId';
  static const companyIdString = 'companyId';
  static const companyName = 'companyName';
  static const companyLogo = 'companyLogo';
  static const ascendingString = 'asc';
  static const descendingString = 'desc';
  static const planogramSortFieldString = 'planogramName';
  static const orderNumberString = 'orderNumber';
  static const signatureString = 'signature';
  static const cartProductIdString = 'cartProductId';
  static const categoryIdString = 'catregoryId';
  static const categoryNameString = 'catregoryName';
  static const pdfString = 'PDF';
  static const jsonString = 'JSON';
  static const orderBySupplierId = 'orderSupplierId';
  static const getCartListString = 'getCartListString';
  static const isSubCategory = 'false';
  static const issueString = 'issue';
  static const isBasketScreenString = 'basketScreen';
  static const isCartCountString = 'true';
  static const homeScreenString = 'homeScreen';
  static const sortFieldString = 'productStock';
  static const sortOrderString = 'desc';
  static const userIdString = 'id';
  static const agentIdString = 'agentId';
  static const businessTypeIdString = 'businessTypeId';
  static const bankIdString = 'bankId';
  static const owner1FullNameString = 'owner1FullName';
  static const owner1IsraelIdString = 'owner1IsraelId';
  static const owner2FullNameString = 'owner2FullName';
  static const owner2IsraelIdString = 'owner2IsraelId';
  static const guarantee1FullNameString = 'guarantee1FullName';
  static const guarantee1IsraelIdString = 'guarantee1IsraelId';
  static const guarantee1AddressString = 'guarantee1Address';
  static const guarantee1PhoneNumberString = 'guarantee1PhoneNumber';
  static const guarantee2FullNameString = 'guarantee2FullName';
  static const guarantee2IsraelIdString = 'guarantee2IsraelId';
  static const guarantee2AddressString = 'guarantee2Address';
  static const guarantee2PhoneNumberString = 'guarantee2PhoneNumber';
  static const branchNumberString = 'branchNumber';
  static const accountNumberString = 'accountNumber';
  static const owner1SignatureString = 'owner1Signature';
  static const owner2SignatureString = 'owner2Signature';
  static const guarantee1SignatureString = 'guarantee1Signature';
  static const guarantee2SignatureString = 'guarantee2Signature';
  static const guaranteeNameString = 'guaranteeNameString';




  //validation strings
  static const businessNameValString = 'businessNameVal';
  static const hpValString = 'hpVal';
  static const ownerNameValString = 'ownerNameVal';
  static const idValString = 'idVal';
  static const contactNameValString = 'contactNameVal';
  static const addressValString = 'addressVal';
  static const zipValString = 'zipVal';
  static const streetNameValString = 'streetNameVal';
  static const streetNumberValString = 'streetNumberVal';
  static const emailValString = 'emailVal';
  static const faxValString = 'faxVal';
  static const generalValString = 'generalVal';
  static const mobileValString = 'mobileVal';
  static const cityValString = 'cityVal';
  static const branchValString = 'branchVal';
  static const accountValString = 'accountVal';
  static const surfaceValString = 'surfacesVal';
  static const subUserValString = 'subUserNameVal';
  static const isNavigateToProductDetailString = 'isNavigateToProductDetail';

  //page parameters strings
  static const mobileParamString = 'mobileParam';
  static const profileParamString = 'profileParam';
  static const isUpdateParamString = 'isUpdateParam';
  static const planogramProductsParamString = 'planogramProductsParam';
  static const messageDataString = 'messageDataParam';
  static const appContentIdString = 'appContentIdParam';
  static const appContentNameString = 'appContentNameParam';
  static const messageReadString = 'messageReadSParam';
  static const messageDeleteString = 'messageDeleteParam';
  static const searchString = 'searchParam';
  static const reqSearchString = 'reqSearchParam';
  static const searchResultString = 'searchResultParam';
  static const fromStoreCategoryString = 'fromStoreCategoryParam';
  static const pushNavigationString = 'pushNavigationParam';
  static const monthlyCreditString = 'Monthly Credits';
  static const orderString = 'Order';
  static const companiesString = 'companies';
  static const searchType = 'searchType';
  static const termsConditionParamString = 'termsConditionParam';
  static const privacyPolicyPdfString = 'pdf';
  static const clientFormString = 'clientForm';
  static const subUserIdString = 'id';
  static const subUserNameString = 'subUserName';
  static const subUserPhoneNumberString = 'subUserPhoneNumber';
  static const subUserEmailString = 'subUserEmail';
  static const subUserIsraelIdString = 'subUserIsraelId';
  static const isPopString = 'isPop';

  //hint strings
  static const hintNumberString = '1234567890';

  //argument strings
  static const isRegisterString = 'isRegister';
  static const contactString = 'contact';
  static const idString = 'id';
  static const orderIdString = 'orderId';
  static const productDataString = 'productData';
  static const supplierNameString = 'supplierName';
  static const deliveryStatusString = 'deliveryStatus';
  static const totalOrderString = 'totalOrder';
  static const deliveryDateString = 'deliveryDate';
  static const quantityString = 'quantity';
  static const supplierOrderNumberString = 'supplierOrderNumber';
  static const totalAmountString = 'totalAmount';
  static const cartIdString = 'cartId';
  static const messageIdString = 'messageId';
  static const messageIdListString = 'messageIdList';
  static const isReadMoreString = 'isReadMore';
  static const invoiceListString = 'invoiceListString';



  static String getLocalizedStrings(String key,BuildContext context){
    switch(key){
      case 'errmessage':
        return AppLocalizations.of(context)!.errmessage;
      case 'successmessage':
        return AppLocalizations.of(context)!.successmessage;
      case 'invalidoperation':
        return AppLocalizations.of(context)!.invalidoperation;
      case 'documentcreatedmessage':
        return AppLocalizations.of(context)!.documentcreatedmessage;
      case 'loginsuccessmessage':
        return AppLocalizations.of(context)!.loginsuccessmessage;
      case 'usercreatedmessage':
        return AppLocalizations.of(context)!.usercreatedmessage;
      case 'validationerror':
        return AppLocalizations.of(context)!.validationerror;
      case 'servererrormessage':
        return AppLocalizations.of(context)!.servererrormessage;
      case 'invalidcredentials':
        return AppLocalizations.of(context)!.invalidcredentials;
      case 'verificationemailsent':
        return AppLocalizations.of(context)!.verificationemailsent;
      case 'invalidcode':
        return AppLocalizations.of(context)!.invalidcode;
      case 'alreadyverified':
        return AppLocalizations.of(context)!.alreadyverified;
      case 'expiredcode':
        return AppLocalizations.of(context)!.expiredcode;
      case 'verificationsuccess':
        return AppLocalizations.of(context)!.verificationsuccess;
      case 'invalidverificationcode':
        return AppLocalizations.of(context)!.invalidverificationcode;
      case 'expiredverificationcode':
        return AppLocalizations.of(context)!.expiredverificationcode;
      case 'unverifiedverificationcode':
        return AppLocalizations.of(context)!.unverifiedverificationcode;
      case 'usernotfound':
        return AppLocalizations.of(context)!.usernotfound;
      case 'newpasswordsameasold':
        return AppLocalizations.of(context)!.newpasswordsameasold;
      case 'resetsuccessful':
        return AppLocalizations.of(context)!.resetsuccessful;
      case 'setsuccessful':
        return AppLocalizations.of(context)!.setsuccessful;
      case 'currentpasswordwrong':
        return AppLocalizations.of(context)!.currentpasswordwrong;
      case 'changesuccessful':
        return AppLocalizations.of(context)!.changesuccessful;
      case 'formcreatesuccessful':
        return AppLocalizations.of(context)!.formcreatesuccessful;
      case 'formupdatesuccessful':
        return AppLocalizations.of(context)!.formupdatesuccessful;
      case 'formnotfound':
        return AppLocalizations.of(context)!.formnotfound;
      case 'formexistswiththisname':
        return AppLocalizations.of(context)!.formexistswiththisname;
      case 'badrequest':
        return AppLocalizations.of(context)!.badrequest;
      case 'internalservererror':
        return AppLocalizations.of(context)!.internalservererror;
      case 'recordalreadyexist':
        return AppLocalizations.of(context)!.recordalreadyexist;
      case 'phonenumberalreadyexist':
        return AppLocalizations.of(context)!.phonenumberalreadyexist;
      case 'emailalreadyexist':
        return AppLocalizations.of(context)!.emailalreadyexist;
      case 'recordnotcreated':
        return AppLocalizations.of(context)!.recordnotcreated;
      case 'tokenerror':
        return AppLocalizations.of(context)!.tokenerror;
      case 'datanotfound':
        return AppLocalizations.of(context)!.datanotfound;
      case 'invalidcontact':
        return AppLocalizations.of(context)!.invalidcontact;
      case 'foundcontact':
        return AppLocalizations.of(context)!.foundcontact;
      case 'invalidemail':
        return AppLocalizations.of(context)!.invalidemail;
      case 'recorddoesnotexist':
        return AppLocalizations.of(context)!.recorddoesnotexist;
      case 'skuarerequired':
        return AppLocalizations.of(context)!.skuarerequired;
      case 'productidarerequired':
        return AppLocalizations.of(context)!.productidarerequired;
      case 'skusarenotregistered':
        return AppLocalizations.of(context)!.skusarenotregistered;
      case 'productarenoregistered':
        return AppLocalizations.of(context)!.productarenoregistered;
      case 'supplierproductisnotregistered':
        return AppLocalizations.of(context)!.supplierproductisnotregistered;
      case 'productssuppliermismatch':
        return AppLocalizations.of(context)!.productssuppliermismatch;
      case 'productremovalsalesuccess':
        return AppLocalizations.of(context)!.productremovalsalesuccess;
      case 'productremovalsalefailure':
        return AppLocalizations.of(context)!.productremovalsalefailure;
      case 'insufficientdataforproductremovalfromsale':
        return AppLocalizations.of(context)!
            .insufficientdataforproductremovalfromsale;
      case 'productnotfound':
        return AppLocalizations.of(context)!.productnotfound;
      case 'failedtoauthenticate':
        return AppLocalizations.of(context)!.failedtoauthenticate;
      case 'recordupdatedsuccessfully':
        return AppLocalizations.of(context)!.recordupdatedsuccessfully;
      case 'recorddeletedsuccessfully':
        return AppLocalizations.of(context)!.recorddeletedsuccessfully;
      case 'recordcreatedsuccessfully':
        return AppLocalizations.of(context)!.recordcreatedsuccessfully;
      case 'invalidids':
        return AppLocalizations.of(context)!.invalidids;
      case 'importedsuccessfully':
        return AppLocalizations.of(context)!.importedsuccessfully;
      case 'cartproductsbadrequest':
        return AppLocalizations.of(context)!.cartproductsbadrequest;
      case 'cartdoesnotexist':
        return AppLocalizations.of(context)!.cartdoesnotexist;
      case 'cartproductdoesnotexist':
        return AppLocalizations.of(context)!.cartproductdoesnotexist;
      case 'productdoesnotexistincart':
        return AppLocalizations.of(context)!.productdoesnotexistincart;
      case 'supplierdoesnothavequantity':
        return AppLocalizations.of(context)!.supplierdoesnothavequantity;
      case 'orderproductsbadrequest':
        return AppLocalizations.of(context)!.orderproductsbadrequest;
      case 'ordercreatedsuccessfully':
        return AppLocalizations.of(context)!.ordercreatedsuccessfully;
      case 'orderupdatedsuccessfully':
        return AppLocalizations.of(context)!.orderupdatedsuccessfully;
      case 'ordernotfound':
        return AppLocalizations.of(context)!.ordernotfound;
      case 'lowquantity':
        return AppLocalizations.of(context)!.lowquantity;
      case 'cartcleared':
        return AppLocalizations.of(context)!.cartcleared;
      case 'nullpassword':
        return AppLocalizations.of(context)!.nullpassword;
      case 'logout':
        return AppLocalizations.of(context)!.logout;
      case 'messagecreated':
        return AppLocalizations.of(context)!.messagecreated;
      case 'messageupdated':
        return AppLocalizations.of(context)!.messageupdated;
      case 'quantityfulfilled':
        return AppLocalizations.of(context)!.quantityfulfilled;
      case 'ordersaleexist':
        return AppLocalizations.of(context)!.ordersaleexist;
      case 'supplierproductexist':
        return AppLocalizations.of(context)!.supplierproductexist;
      case 'questioniddoesnotexist':
        return AppLocalizations.of(context)!.questioniddoesnotexist;
      case 'uniquequestionandanswer':
        return AppLocalizations.of(context)!.uniquequestionandanswer;
      case 'questioncreatedsuccessfully':
        return AppLocalizations.of(context)!.questioncreatedsuccessfully;
      case 'questionrecorddoesnotexist':
        return AppLocalizations.of(context)!.questionrecorddoesnotexist;
      case 'questiondeletedsuccessfully':
        return AppLocalizations.of(context)!.questiondeletedsuccessfully;
      case 'productalreadyincart':
        return AppLocalizations.of(context)!.productalreadyincart;
      case 'productorsuppliernotexits':
        return AppLocalizations.of(context)!.productorsuppliernotexits;
      case 'productaddedincart':
        return AppLocalizations.of(context)!.productaddedincart;
      case 'orderissuecreatednotificationtitle':
        return AppLocalizations.of(context)!.orderissuecreatednotificationtitle;
      case 'filenotfound':
        return AppLocalizations.of(context)!.filenotfound;
      case 'youcannotupdateorder':
        return AppLocalizations.of(context)!.youcannotupdateorder;
      case 'youcannotcreateissue':
        return AppLocalizations.of(context)!.youcannotcreateissue;
      case 'youcannotplaceorder':
        return AppLocalizations.of(context)!.youcannotplaceorder;
      case 'youcannotconfirmdelivery':
        return AppLocalizations.of(context)!.youcannotconfirmdelivery;
      case 'signaturerequired':
        return AppLocalizations.of(context)!.signaturerequired;
      case 'providevalidcsv':
        return AppLocalizations.of(context)!.providevalidcsv;
      case 'invalidsupplierid':
        return AppLocalizations.of(context)!.invalidsupplierid;
      case 'downlodedsuccessfully':
        return AppLocalizations.of(context)!.downlodedsuccessfully;
      case 'admintypealreadyexist':
        return AppLocalizations.of(context)!.admintypealreadyexist;
      case 'alredylinkedwithuser':
        return AppLocalizations.of(context)!.alredylinkedwithuser;
      case 'youcannotplaceorderqtymustabovezero':
        return AppLocalizations.of(context)!.youcannotplaceorderqtymustabovezero;
      case 'youcannotplaceordernotenoughqty':
        return AppLocalizations.of(context)!.youcannotplaceordernotenoughqty;
      case 'contentalreadyexist':
        return AppLocalizations.of(context)!.contentalreadyexist;
      case 'modulealreadyexist':
        return AppLocalizations.of(context)!.modulealreadyexist;
      case 'productorsuppliernotexist':
        return AppLocalizations.of(context)!.productorsuppliernotexist;
      case 'issuegenrated':
        return AppLocalizations.of(context)!.issuegenrated;
      case 'deliveryconfirmed':
        return AppLocalizations.of(context)!.deliveryconfirmed;
      case 'permissionalreadyexist':
        return AppLocalizations.of(context)!.permissionalreadyexist;
      case 'planogramalreadyexist':
        return AppLocalizations.of(context)!.planogramalreadyexist;
      case 'productalreadyexist':
        return AppLocalizations.of(context)!.productalreadyexist;
      case 'duplicateorinvalidsku':
        return AppLocalizations.of(context)!.duplicateorinvalidsku;
      case 'alredylinkedwithsale':
        return AppLocalizations.of(context)!.alredylinkedwithsale;
      case 'areadyexist':
        return AppLocalizations.of(context)!.areadyexist;
      case 'walletareadyexist':
        return AppLocalizations.of(context)!.walletareadyexist;
      case 'notenoughbalance':
        return AppLocalizations.of(context)!.notenoughbalance;
      case 'invalidamount':
        return AppLocalizations.of(context)!.invalidamount;
      case 'deductionisnegative':
        return AppLocalizations.of(context)!.deductionisnegative;
      case 'something_is_wrong_try_again':
        return AppLocalizations.of(context)!.something_is_wrong_try_again;
      case 'loginsuccessmessage':
        return AppLocalizations.of(context)!.loginsuccessmessage;
      case 'accountnotapprove':
        return AppLocalizations.of(context)!.account_not_approve;
      case 'rivchitcredentialsnotset':
        return AppLocalizations.of(context)!.rivchitcredentialsnotset;
      case 'comaxinvoicenotfound':
        return AppLocalizations.of(context)!.comaxinvoicenotfound;
      case 'totalamountcantbezero':
        return AppLocalizations.of(context)!.total_amount_cant_be_zero;
      case 'comaxinvoicenotfound':
        return AppLocalizations.of(context)!.comaxinvoicenotfound;
      case 'salenotexistssalenotexists':
        return AppLocalizations.of(context)!.sale_not_exists;
        case 'comaxordererror':
      return AppLocalizations.of(context)!.comax_order_error;
      case 'comaxclienterror':
        return AppLocalizations.of(context)!.comax_client_error;
      case 'issueremoved':
        return AppLocalizations.of(context)!.issueremoved;
      case 'notsufficientpermission':
        return AppLocalizations.of(context)!.notsufficientpermission;
      case 'needtoapprovepreviousorder':
        return AppLocalizations.of(context)!.needtoapprovepreviousorder;
      case 'subuserphonenumberalreadyexist':
        return AppLocalizations.of(context)!.phone_number_of_other_subuser;
    }
    return key;
  }
}
