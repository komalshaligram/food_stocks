import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:food_stock/ui/utils/app_utils.dart';
import 'package:food_stock/ui/widget/sized_box_widget.dart';
import 'package:html/parser.dart';
import '../utils/themes/app_colors.dart';
import '../utils/themes/app_constants.dart';
import '../utils/themes/app_img_path.dart';
import '../utils/themes/app_styles.dart';
import '../utils/themes/app_urls.dart';
import 'common_product_button_widget.dart';
import 'common_shimmer_widget.dart';

class CommonProductListWidget extends StatelessWidget {
  final double? height;
  final double? width;
  final String productImage;
  final String productName;
  final int totalSaleCount;
  final dynamic price;
  final String productStock;
  final void Function() onButtonTap;
  final bool isGuestUser;
  final String numberOfUnits;
  final String lowStock;
final bool? isPesach;
final bool? isFromSale;
final String? salesDesc;

    CommonProductListWidget({super.key,
     this.height,
     this.width = 140,
     required this.productImage,
     required this.productName,
      this.totalSaleCount =0,
     required this.price,
     required this.onButtonTap, this.productStock = '0',
     this.isGuestUser = false,
     this.numberOfUnits = '0',
      required this.lowStock,
      required this.isPesach,
       this.isFromSale = false,
      this.salesDesc = ''
   });

  @override
  Widget build(BuildContext context) {

    return GestureDetector(
      onTap: onButtonTap,
      child: Container(
        width:double.maxFinite,
      //  height: 150,
        decoration: BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.all(Radius.circular(AppConstants.radius_10)),
          boxShadow: [
            BoxShadow(
                color: AppColors.shadowColor.withOpacity(0.15),
                blurRadius: AppConstants.blur_10),
          ],
        ),
        clipBehavior: Clip.hardEdge,
        margin: EdgeInsets.symmetric(
            vertical: AppConstants.padding_10,
            horizontal: AppConstants.padding_5),
        padding: EdgeInsets.symmetric(
            vertical: AppConstants.padding_5,
            horizontal: AppConstants.padding_10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            !isGuestUser ? productImage.isNotEmpty?  CachedNetworkImage(
              imageUrl: "${AppUrls.baseFileUrl}$productImage",
              height: 70,
              width: 70,
              fit: BoxFit.contain,
              placeholder: (context, url) {
                return CommonShimmerWidget(
                  child: Container(
                    height: 70,
                    width: 70,
                    decoration: BoxDecoration(
                      color: AppColors.whiteColor,
                      borderRadius: BorderRadius.all(
                          Radius.circular(AppConstants.radius_10)),
                    ),
                  ),
                );
              },
              errorWidget: (context, error, stackTrace) {
                 debugPrint('sale list image error : $error');
                return Container(
                  child: Image.asset(AppImagePath.imageNotAvailable5,
                      height: 70, width: 70, fit: BoxFit.cover),
                );
              },
            ) :
            Image.asset(AppImagePath.imageNotAvailable5 , height: 90,
              width: 90, ) :  Image.asset(AppImagePath.imageNotAvailable5 , height: 90,
              width: 90, ),
            Container(
              padding: EdgeInsets.symmetric(
                  vertical: AppConstants.padding_15,
                  horizontal: AppConstants.padding_10),
              width: 150,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    productName,
                    style: AppStyles.rkBoldTextStyle(
                        size: AppConstants.font_14,
                        color: AppColors.blackColor,
                        fontWeight: FontWeight.w600),
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                  ),
                  totalSaleCount == 0 || isGuestUser
                      ? 0.width
                      : Text(
                    "${totalSaleCount} ${AppLocalizations.of(context)!.discount}",
                    style: AppStyles.rkRegularTextStyle(
                        size: AppConstants.font_12,
                        color: AppColors.saleRedColor,
                        fontWeight: FontWeight.w600),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                  (productStock) != '0' && lowStock.isEmpty ||   isGuestUser ? 0.width :
                  (productStock) == '0' && lowStock.isNotEmpty ?Text(
                    AppLocalizations.of(context)!
                        .out_of_stock1,
                    style: AppStyles.rkBoldTextStyle(
                        size: AppConstants.font_14,
                        color: AppColors.redColor,
                        fontWeight: FontWeight.w400),
                  ) : Text(
                   lowStock,
                    style: AppStyles.rkBoldTextStyle(
                        size: AppConstants.font_14,
                        color: AppColors.orangeColor,
                        fontWeight: FontWeight.w400),
                  ),
                  isPesach! ? 3.height :0.height,
                 isPesachLabelShow(isPesach!, context),
                  isPesach! ? 3.height :0.height,
                 !isGuestUser ? numberOfUnits != '0' ? Text(
                    '${numberOfUnits.toString()}${' '}${AppLocalizations.of(context)!.unit_in_box}',
                    style: AppStyles.rkBoldTextStyle(
                        size: AppConstants.font_12,
                        color: AppColors.blackColor,
                        fontWeight: FontWeight.w400),
                  ) : 0.width : 0.width,
                  salesDesc!.isNotEmpty?Center(
                    child: Container(
                      width: width,
                      padding: EdgeInsets.all(3),
                      margin: EdgeInsets.zero,
                      decoration: BoxDecoration(color: AppColors.redColor, border: Border.all(color: AppColors.redColor), borderRadius: BorderRadius.circular(AppConstants.radius_3)),
                      child: Text(
                        "${parse(salesDesc).body?.text}",
                        style: AppStyles.rkRegularTextStyle(size: AppConstants.font_10, color: AppColors.whiteColor,),
                        maxLines: 3,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ):0.width,
                  !isGuestUser? numberOfUnits !='0' && price != 0.0 ? isFromSale!?Text.rich(TextSpan(
                    text: '${AppLocalizations.of(context)?.price_par_box} ',
                    style: AppStyles.rkRegularTextStyle(
                        size: AppConstants.font_12, color: AppColors.blackColor),
                    children: <TextSpan>[
                      TextSpan(
                        text: '${AppLocalizations.of(context)?.currency}${(price * int.parse(numberOfUnits)).toStringAsFixed(2)} ',
                        style: AppStyles.rkRegularTextStyle(
                            size: AppConstants.font_12, color: AppColors.blackColor).copyWith(decoration: TextDecoration.lineThrough),
                      ),
                      TextSpan(
                        text: ' ${AppLocalizations.of(context)?.currency}${(price * int.parse(numberOfUnits)).toStringAsFixed(2)}',
                        style: AppStyles.rkRegularTextStyle(
                            size: AppConstants.font_12, color: AppColors.redColor),
                      ),
                    ],
                  ),
                  ) :Text(
                    '${AppLocalizations.of(context)?.price_par_box}${' '}${AppLocalizations.of(context)?.currency}${(price * int.parse(numberOfUnits)).toStringAsFixed(2)}',
                    style: AppStyles.rkBoldTextStyle(
                        size: AppConstants.font_12,
                        color: AppColors.blueColor,
                        fontWeight: FontWeight.w400),
                  ): 0.width : 0.width,
                ],
              ),
            ),
            !isGuestUser ? CommonProductButtonWidget(
              title:
              "${AppLocalizations.of(context)!.currency}${price.toStringAsFixed(AppConstants.amountFrLength) == "0.00" ? '0' : price.toStringAsFixed(AppConstants.amountFrLength)}",
              onPressed: onButtonTap,
              textColor: AppColors.whiteColor,
              bgColor: AppColors.mainColor,
              borderRadius: AppConstants.radius_3,
              textSize: AppConstants.font_14,
              height: 32,
              width: 80,
            ) : 0.width,
          ],
        ),
      ),
    );
  }
}
